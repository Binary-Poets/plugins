# wp-brand-manager
Manage the WordPress branding from the login page and the admin dashboard.
