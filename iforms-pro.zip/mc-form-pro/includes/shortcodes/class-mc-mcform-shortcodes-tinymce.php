<?php
/**
 * Class for initiating tinyMCE builder for mcForm related shortcodes
 *
 * It does not concerns with what the shortcode should output in the front-end
 * and does not registers any shortcode. Those should be done by the output
 * classes. This provides an easy way so the mcForm core shortcode builder variables
 * can be placed together
 *
 * @package    mcForm - Premium Form System
 * @subpackage Shortcodes\tinyMCE
 */
class MC_MCForm_Shortcodes_TinyMCE {
	/**
	 * Singleton instance variable
	 */
	private static $instance = null;

	/**
	 * Get the instance of this singleton class
	 *
	 * @return     MC_mcForm_Shortcodes_TinyMCE  The instance of the class
	 */
	public static function init() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new MC_MCForm_Shortcodes_TinyMCE();
		}
		return self::$instance;
	}

	/**
	 * The consturctor
	 *
	 * The access is made private so that the class can be singleton
	 */
	private function __construct() {
		// Initiate the AJAX Helpers needed for shortcode constructor callbacks
		$this->shortcode_ajax_helpers();
		// Add action to the init which would initialize the scripts needed for tinyMCE
		add_action( 'init', array( $this, 'admin_init_hook' ) );
	}

	protected function shortcode_ajax_helpers() {
		add_action( 'wp_ajax_mc_form_shortcode_get_form_elements_for_mce', array( $this, 'shortcode_get_form_elements_for_mce' ) );
	}

	/**
	 * Get all form elements for a form along with their default configuration
	 *
	 * This is used by the tinyMCE script which would then create a dynamic
	 * configuration modal based on received values
	 *
	 * @return     array  Form Elements and configuration
	 */
	public function shortcode_get_form_elements_for_mce() {
		$form_id = (int) $_REQUEST['form_id'];
		$report_config = (array) $_REQUEST['reportType'];
		@header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );
		if ( ! wp_verify_nonce( $_REQUEST['wpnonce'], 'mc_form_shortcode_get_mcqs' ) ) {
			$return = array(
				'html' => __( 'Cheatin&#8217; uh?' ),
			);
			echo json_encode( (object) $return );
			die();
		}

		$return = $this->get_form_elements_for_mce( $form_id, $report_config );

		echo json_encode( (object) $return );
		die();
	}

	public function get_form_elements_for_mce( $form_id, $report_config ) {
		global $wpdb, $mc_form_info;
		$form_element = new MC_FORM_Form_Elements_Utilities( $form_id );
		if ( null == $form_element->form_id ) {
			$return = array(
				'html' => __( 'Please select a form and try again.', 'mc_form' ),
			);
			echo json_encode( (object) $return );
			die();
		}
		// Now return elements depending on the report type
		$return = array(
			'mcqs' => array(),
			'freetypes' => array(),
			'pinfos' => array(),
			'filters' => array(),
		);

		// Include mcqs
		if ( isset( $report_config['mcq'] ) && 'true' == $report_config['mcq'] ) {
			$mcqs = $form_element->get_keys_from_layouts_by_m_type( 'mcq', $form_element->layout );
			if ( ! empty( $mcqs ) ) {
				$rmcqs = array();
				$rmcqs[] = array(
					'text' => __( 'Show All', 'mc_form' ),
					'value' => 'all',
				);
				foreach ( $mcqs as $mcq ) {
					$rmcqs[] = array(
						'text' => $form_element->mcq[ $mcq ]['title'],
						'value' => $mcq,
						'type' => $form_element->mcq[ $mcq ]['type'],
					);
				}
				$return['mcqs'] = $rmcqs;
			}
		}

		// Include feedbacks
		if ( isset( $report_config['freetype'] ) && 'true' == $report_config['freetype'] ) {
			$freetypes = $form_element->get_keys_from_layouts_by_m_type( 'freetype', $form_element->layout );
			if ( ! empty( $freetypes ) ) {
				$rfreetypes = array();
				$rfreetypes[] = array(
					'text' => __( 'Show All', 'mc_form' ),
					'value' => 'all',
				);
				foreach ( $freetypes as $freetype ) {
					$rfreetypes[] = array(
						'text' => $form_element->freetype[ $freetype ]['title'],
						'value' => $freetype,
						'type' => $form_element->freetype[ $freetype ]['type'],
					);
				}
				$return['freetypes'] = $rfreetypes;
			}
		}

		// Include pinfos
		if ( isset( $report_config['pinfo'] ) && 'true' == $report_config['pinfo'] ) {
			$pinfos = $form_element->get_keys_from_layouts_by_m_type( 'pinfo', $form_element->layout );
			if ( ! empty( $pinfos ) ) {
				$rpinfos = array();
				$rpinfos[] = array(
					'text' => __( 'Show All', 'mc_form' ),
					'value' => 'all',
				);
				foreach ( $pinfos as $pinfo ) {
					$rpinfos[] = array(
						'text' => $form_element->pinfo[ $pinfo ]['title'],
						'value' => $pinfo,
						'type' => $form_element->pinfo[ $pinfo ]['type'],
					);
				}
				$return['pinfos'] = $rpinfos;
			}
		}

		// Include filters
		// Valid users
		$user_ids = $wpdb->get_col( $wpdb->prepare( "SELECT distinct user_id FROM {$mc_form_info['data_table']} WHERE form_id = %d", $form_id ) );
		$user_id_items = array();
		$user_id_items[] = array(
			'value' => 'all',
			'text' => __( 'Show for all users', 'mc_form' ),
		);
		foreach ( $user_ids as $uid ) {
			if ( '0' === $uid ) {
				continue;
			}
			$userdata = get_userdata( $uid );
			if ( ! is_wp_error( $userdata ) && is_object( $userdata ) ) {
				$user_id_items[] = array(
					'value' => $uid,
					'text' => $userdata->user_nicename,
				);
			} else {
				$user_id_items[] = array(
					'value' => $uid,
					'text' => sprintf( __( '(Deleted User) ID: %s', 'mc_form' ), $uid ),
				);
			}
		}
		$return['filters']['users'] = $user_id_items;

		// Get valid URL tracking
		$url_tracking = (array) $wpdb->get_results( $wpdb->prepare( "SELECT url_track, id, form_id FROM {$mc_form_info['data_table']} GROUP BY url_track HAVING form_id = %d AND url_track != ''", $form_id ) );
		$url_tracking_items = array(
			0 => array(
				'value' => 'all',
				'text' => __( 'Show for all', 'mc_form' ),
			),
		);

		foreach ( $url_tracking as $ut ) {
			if ( null == $ut->url_track || '' == $ut->url_track ) {
				continue;
			}
			$url_tracking_items[] = array(
				'value' => $ut->id,
				'text' => $ut->url_track,
			);
		}
		$return['filters']['urltb'] = $url_tracking_items;

		// Get valid date range
		$return['filters']['dates']['least_date'] = $wpdb->get_var( $wpdb->prepare( "SELECT date FROM {$mc_form_info['data_table']} WHERE form_id = %d ORDER BY date ASC LIMIT 0,1", $form_id ) );
		$return['filters']['dates']['recent_date'] = $wpdb->get_var( $wpdb->prepare( "SELECT date FROM {$mc_form_info['data_table']} WHERE form_id = %d ORDER BY date DESC LIMIT 0,1", $form_id ) );
		return $return;
	}

	/**
	 * Add the tinyMCE shortcode builder scripts and buttons
	 */
	public function admin_init_hook() {
		add_action( 'admin_enqueue_scripts', array( $this, 'form_mce_extendor' ) );
		add_filter( 'mce_external_plugins', array( $this, 'mce_external_plugins' ) );
		add_filter( 'mce_buttons', array( $this, 'mce_buttons' ) );
		add_action( 'before_wp_tiny_mce', array( $this, 'form_mce_icons' ) );
	}

	public function form_mce_icons() {
		// Add icon when tinymce is loaded
		wp_register_style( 'mc-icomoon-fonts', MC_FORM_Loader::$static_location . 'fonts/icomoon/icomoon.min.css', array(), MC_FORM_Loader::$version );
		// manually print style because it would be too late anyway
		wp_print_styles( 'mc-icomoon-fonts' );
	}

	public function form_mce_extendor() {
		// Charting variables
		$chart_helper = MC_MCForm_Core_Shortcodes::get_chart_type_n_toggles();
		// Change it a little for using with JSON
		// We need to keep the order for defaulting
		$chart_maps = $chart_helper['possible_chart_types'];
		foreach ( $chart_maps as $etype => $echarts ) {
			$chart_helper['possible_chart_types'][ $etype ]['default'] = current( array_keys( $echarts ) );
		}
		$report_type = array(
			array(
				'text' => __( 'Survey (MCQ) Elements', 'mc_form' ),
				'value' => 'mcq',
				'checked' => true,
			),
			array(
				'text' => __( 'Feedback & Upload Elements', 'mc_form' ),
				'value' => 'freetype',
				'checked' => true,
			),
			array(
				'text' => __( 'Other Elements', 'mc_form' ),
				'value' => 'pinfo',
				'checked' => true,
			),
		);
		$report_data = array(
			array(
				'text' => __( 'Show data alongside graphs for mcqs', 'mc_form' ),
				'value' => 'data',
				'checked' => true,
			),
			array(
				'text' => __( 'Show optional meta entries for mcqs', 'mc_form' ),
				'value' => 'others',
				'checked' => true,
			),
			array(
				'text' => __( 'Show names for mcq meta entries and feedbacks', 'mc_form' ),
				'value' => 'names',
				'checked' => true,
			),
			array(
				'text' => __( 'Show date for mcq meta entries and feedbacks', 'mc_form' ),
				'value' => 'date',
				'checked' => true,
			),
		);
		$report_appearance = array(
			array(
				'text' => __( 'Wrap inside blocks', 'mc_form' ),
				'value' => 'block',
				'checked' => true,
			),
			array(
				'text' => __( 'Show Element Heading (Shown anyway if Wrap inside blocks is active)', 'mc_form' ),
				'value' => 'heading',
				'checked' => true,
			),
			array(
				'text' => __( 'Show element Description', 'mc_form' ),
				'value' => 'description',
				'checked' => true,
			),
			array(
				'text' => __( 'Show table header', 'mc_form' ),
				'value' => 'header',
				'checked' => true,
			),
			array(
				'text' => __( 'Show table border', 'mc_form' ),
				'value' => 'border',
				'checked' => true,
			),
			array(
				'text' => __( 'Use Google Material Charts instead of Classic Charts (for Bar & Column charts only)', 'mc_form' ),
				'value' => 'material',
				'checked' => false,
			),
			array(
				'text' => __( 'Show the print button', 'mc_form' ),
				'value' => 'print',
				'checked' => false,
			),
		);

		wp_enqueue_script( 'form_mce_extendor', MC_FORM_Loader::$static_location . 'admin/js/mc-form-tinymce-extendor.min.js', MC_FORM_Loader::$version );
		wp_localize_script( 'form_mce_extendor', 'mcFORMTML10n', array(
			'l10n' => array(
				'label' => __( 'Insert Shortcodes for mcForm', 'mc_form' ),
				'slabel' => __( 'mcForm - ', 'mc_form' ),
				'salabel' => __( 'Select Questions', 'mc_form' ),
				'fselect' => __( 'Please select a form', 'mc_form' ),
				'ajax' => __( 'Please wait. Press OK to exit!', 'mc_form' ),
				'ss' => array(
					'ss' => __( 'System Shortcodes', 'mc_form' ),
					'up' => __( 'Centralized User Portal Page', 'mc_form' ),
					'tb' => __( 'Single Submission Trackback', 'mc_form' ),
					'tbfl' => __( 'Form Label', 'mc_form' ),
					'tbfll' => __( 'Track Code', 'mc_form' ),
					'tbfltt' => __( 'Enter the label of the text input where the surveyee will need to paste his/her trackback code.', 'mc_form' ),
					'tbsbtl' => __( 'Submit Button Text', 'mc_form' ),
					'tbsbt' => __( 'Submit', 'mc_form' ),
					'uplabels' => array(
						'llogin_attr' => __( 'Login Page Modifications', 'mc_form' ),
						'lportal_attr' => __( 'Portal Page Modifications', 'mc_form' ),
						'login_attr' => array(
							'login' => __( 'Message to logged out users', 'mc_form' ),
							'show_register' => __( 'Show the registration button', 'mc_form' ),
							'show_forgot' => __( 'Show password recovery link', 'mc_form' ),
						),
						'portal_attr' => array(
							'title' => __( 'Welcome Title', 'mc_form' ),
							'content' => __( 'Welcome message', 'mc_form' ),
							'contenttt' => __( '%NAME% will be replaced by user name', 'mc_form' ),
							'nosubmission' => __( 'No submissions message', 'mc_form' ),
							'formlabel' => __( 'Form Heading Label', 'mc_form' ),
							'filters' => __( 'Show Filters for Forms and Categories', 'mc_form' ),
							'filterstt' => __( 'If enabled then users would be able to select forms and categories from dropdown and enter date/time range.', 'mc_form' ),
							'showcategory' => __( 'Show Category', 'mc_form' ),
							'categorylabel' => __( 'Category Label', 'mc_form' ),
							'datelabel' => __( 'Date Heading Label', 'mc_form' ),
							'showscore' => __( 'Show Score Column', 'mc_form' ),
							'showscorett' => __( 'If enabled then score obtained, total score and percentage would be shown for relevant forms.', 'mc_form' ),
							'scorelabel' => __( 'Score Heading Label', 'mc_form' ),
							'mscorelabel' => __( 'Max Score Heading Label', 'mc_form' ),
							'pscorelabel' => __( 'Percentage Score Heading Label', 'mc_form' ),
							'showremarks' => __( 'Show Admin Remarks Column', 'mc_form' ),
							'showremarkstt' => __( 'If enabled, then administrator remarks will be shown in a column.', 'mc_form' ),
							'remarkslabel' => __( 'Admin Remarks Label', 'mc_form' ),
							'actionlabel' => __( 'Action Column Heading Label', 'mc_form' ),
							'linklabel' => __( 'Trackback Button Label', 'mc_form' ),
							'editlabel' => __( 'Edit Button Label', 'mc_form' ),
							'avatar' => __( 'Avatar Size', 'mc_form' ),
							'theme' => __( 'Portal Theme', 'mc_form' ),
							'logout_r' => __( 'Redirection after Logout', 'mc_form' ),
							'logout_r_tt' => __( 'Any valid URL starting with http:// or https://', 'mc_form' ),
						),
					),
					'updefaults' => array(
						'content' => __( 'Welcome %NAME%. Below is the list of all submissions you have made.', 'mc_form' ),
						'nosubmission' => __( 'No submissions yet.', 'mc_form' ),
						'login' => __( 'You need to login in order to view your submissions.', 'mc_form' ),
						'formlabel' => __( 'Form', 'mc_form' ),
						'categorylabel' => __( 'Category', 'mc_form' ),
						'datelabel' => __( 'Date', 'mc_form' ),
						'scorelabel' => __( 'Score', 'mc_form' ),
						'mscorelabel' => __( 'Max', 'mc_form' ),
						'pscorelabel' => __( '%-age', 'mc_form' ),
						'remarkslabel' => __( 'Remarks', 'mc_form' ),
						'linklabel' => __( 'View', 'mc_form' ),
						'actionlabel' => __( 'Action', 'mc_form' ),
						'editlabel' => __( 'Edit', 'mc_form' ),
						'avatar' => '96',
						'title' => __( 'mcForm User Portal', 'mc_form' ),
						'logout_r' => '',
					),
					'login' => array(
						'lb' => __( 'Login Form', 'mc_form' ),
						'rd' => __( 'Redirect To (empty for current URL)', 'mc_form' ),
						'rg' => __( 'Show Registration', 'mc_form' ),
						'rgtt' => __( 'If checked then the form will have a Registration button', 'mc_form' ),
						'rgurl' => __( 'Registration URL (empty for default)', 'mc_form' ),
						'fg' => __( 'Show Forgot Password', 'mc_form' ),
						'fgtt' => __( 'If checked then the form will have a Forgot Password button', 'mc_form' ),
						'theme' => __( 'Login Form Theme', 'mc_form' ),
						'msg' => __( 'Form Heading', 'mc_form' ),
						'msgdf' => __( 'Please login to our site', 'mc_form' ),
					),
				),
				'lb' => array(
					'lb'              => __( 'Insert Leaderboard', 'mc_form' ),
					'flb'             => __( 'Form Leaderboard', 'mc_form' ),

					'flba'            => __( 'Appearance Options', 'mc_form' ),

					'flbark'          => __( 'Show Rank', 'mc_form' ),
					'flbaa'           => __( 'Show Avatar', 'mc_form' ),
					'flbaas'          => __( 'Avatar Size', 'mc_form' ),
					'flban'           => __( 'Show Name', 'mc_form' ),
					'flbad'           => __( 'Show Date', 'mc_form' ),
					'flbas'           => __( 'Show Score', 'mc_form' ),
					'flbams'          => __( 'Show Max Score', 'mc_form' ),
					'flbap'           => __( 'Show Percentage', 'mc_form' ),
					'flbac'           => __( 'Show Administrator Comment', 'mc_form' ),
					'flbah'           => __( 'Show form name as heading', 'mc_form' ),
					'flbai'           => __( 'Show form header image', 'mc_form' ),
					'flbam'           => __( 'Show User Meta in table', 'mc_form' ),
					'flbatm'          => __( 'Show Time', 'mc_form' ),

					'flbl'            => __( 'Labels', 'mc_form' ),

					'flblvrk'         => __( 'Rank', 'mc_form' ),
					'flblvname'       => __( 'Name', 'mc_form' ),
					'flblvdate'       => __( 'Date', 'mc_form' ),
					'flblvscore'      => __( 'Score', 'mc_form' ),
					'flblvmax_score'  => __( 'Out of', 'mc_form' ),
					'flblvpercentage' => __( 'Percentage', 'mc_form' ),
					'flblvcomment'    => __( 'Remarks', 'mc_form' ),
					'flblvtm'         => __( 'Time', 'mc_form' ),

					'flblrk'          => __( 'Rank Column', 'mc_form' ),
					'flblname'        => __( 'Name Column', 'mc_form' ),
					'flbldate'        => __( 'Date Column', 'mc_form' ),
					'flblscore'       => __( 'Score Column', 'mc_form' ),
					'flblmax_score'   => __( 'Max Score Column', 'mc_form' ),
					'flblpercentage'  => __( 'Percentage Column', 'mc_form' ),
					'flblcomment'     => __( 'Administrator Comment Column', 'mc_form' ),
					'flbltm'          => __( 'Time Column', 'mc_form' ),
					'flblcontent'     => __( 'Content', 'mc_form' ),
				),
				'st' => array(
					'st' => __( 'Insert Statistics Charts', 'mc_form' ),

					'stfs' => __( 'Form Statistics', 'mc_form' ),
					'stus' => __( 'User Statistics', 'mc_form' ),

					'fssb' => __( 'Form Submission Breakdown', 'mc_form' ),
					'fssbtt' => __( 'Combo bar chart to show submissions per day per form.', 'mc_form' ),
					'fssb_lbs' => array(
						'form_ids' => __( 'Form IDs', 'mc_form' ),
						'days' => __( 'Number of days or date', 'mc_form' ),
						'max' => __( 'Max Number of forms to show before grouping', 'mc_form' ),
						'others' => __( 'Grouping Label', 'mc_form' ),
						'totalline' => __( 'Total line title', 'mc_form' ),
						'xlabel' => __( 'X Axis Label', 'mc_form' ),
						'ylabel' => __( 'Y Axis Label', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),
					'fssb_df' => array(
						'form_ids' => 'all',
						'days' => '7',
						'max' => '0',
						'others' => __( 'Others', 'mc_form' ),
						'totalline' => __( 'Total Submissions', 'mc_form' ),
						'xlabel' => __( 'Date', 'mc_form' ),
						'ylabel' => __( 'Submissions', 'mc_form' ),
						'height' => '700',
						'width' => '1920',
					),
					'fssb_tts' => array(
						'form_ids' => __( 'Enter "all" to show all forms. Or Comma separated values like "1,30,51" etc.', 'mc_form' ),
						'days' => __( 'Either enter date in Y-m-d (2016-12-30) format to show since mentioned date. Or enter number of days, like 20, to show for past 20 days. Leave blank to show for all time.', 'mc_form' ),
						'max' => __( 'For rather large number of forms, it is advised to group forms with smaller scales into "Others". Mention the maximum number of forms (exclusive) the system will count before grouping others. Leave empty or 0 to disable.', 'mc_form' ),
						'others' => __( 'Enter the label of the others grouping.', 'mc_form' ),
						'totalline' => __( 'If you wish to show a total line in the graph then enter the title. If empty, then total line would not be shown.', 'mc_form' ),
						'xlabel' => __( 'X Axis Label', 'mc_form' ),
						'ylabel' => __( 'Y Axis Label', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),

					'fsos' => __( 'Overall Submissions', 'mc_form' ),
					'fsostt' => __( 'Pie or Doughnut chart to show overall submissions per form.', 'mc_form' ),
					'fsos_lbs' => array(
						'form_ids' => __( 'Form IDs', 'mc_form' ),
						'days' => __( 'Number of days or date', 'mc_form' ),
						'max' => __( 'Max Number of forms to show before grouping', 'mc_form' ),
						'others' => __( 'Grouping Label', 'mc_form' ),
						'type' => __( 'Type of Graph', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),
					'fsos_df' => array(
						'form_ids' => 'all',
						'days' => '7', // Can work both as days or since
						'max' => '0',
						'others' => __( 'Others', 'mc_form' ),
						'type' => 'pie', // Can be pie, doughnut
						'height' => '400',
						'width' => '600',
					),
					'fsos_tts' => array(
						'form_ids' => __( 'Enter "all" to show all forms. Or Comma separated values like "1,30,51" etc.', 'mc_form' ),
						'days' => __( 'Either enter date in Y-m-d (2016-12-30) format to show since mentioned date. Or enter number of days, like 20, to show for past 20 days. Leave blank to show for all time.', 'mc_form' ),
						'max' => __( 'For rather large number of forms, it is advised to group forms with smaller scales into "Others". Mention the maximum number of forms (exclusive) the system will count before grouping others. Leave empty or 0 to disable.', 'mc_form' ),
						'others' => __( 'Enter the label of the others grouping.', 'mc_form' ),
						'type' => __( 'Type of chart to draw', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),

					'fscb' => __( 'Score Breakdown', 'mc_form' ),
					'fscbtt' => __( 'Pie or Doughnut chart to show score percentage breakdown for selected form.', 'mc_form' ),
					'fscb_lbs' => array(
						'form_ids' => __( 'Form IDs', 'mc_form' ),
						'label' => __( 'Graph Legend Format', 'mc_form' ),
						'days' => __( 'Number of days or date', 'mc_form' ),
						'type' => __( 'Type of Graph', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),
					'fscb_df' => array(
						'form_ids' => 'all',
						'label' => __( 'From %1$d%% to %2$d%% ', 'mc_form' ),
						'days' => '',
						'type' => 'pie', // Can be pie, doughnut
						'height' => '400',
						'width' => '600',
					),
					'fscb_tts' => array(
						'form_ids' => __( 'Enter "all" to show all forms. Or Comma separated values like "1,30,51" etc.', 'mc_form' ),
						'label' => __( 'Enter legend format of the score breakdown. From %d%% to %d%% will be replaced by From 0% to 9%, From 10% to 19% etc. It takes formatting of PHP sprintf. So %1$d will be replaced by min score and %2$d will be replaced by max score, use them if you want to change the scoring order in the labels.', 'mc_form' ),
						'days' => __( 'Either enter date in Y-m-d (2016-12-30) format to show since mentioned date. Or enter number of days, like 20, to show for past 20 days. Leave blank to show for all time.', 'mc_form' ),
						'type' => __( 'Type of chart to draw', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),

					'ussb' => __( 'Submission Breakdown', 'mc_form' ),
					'ussbtt' => __( 'Combo bar chart to show submissions breakdown for selected or current user per day per form.', 'mc_form' ),
					'ussb_lbs' => array(
						'form_ids' => __( 'Form IDs', 'mc_form' ),
						'user_id' => __( 'User ID', 'mc_form' ),
						'show_login' => __( 'Show Login Form', 'mc_form' ),
						'login_msg' => __( 'Login Message', 'mc_form' ),
						'theme' => __( 'Login Form Theme', 'mc_form' ),
						'days' => __( 'Number of days or date', 'mc_form' ),
						'max' => __( 'Max Number of forms to show before grouping', 'mc_form' ),
						'others' => __( 'Grouping Label', 'mc_form' ),
						'totalline' => __( 'Total line title', 'mc_form' ),
						'xlabel' => __( 'X Axis Label', 'mc_form' ),
						'ylabel' => __( 'Y Axis Label', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),
					'ussb_df' => array(
						'form_ids' => 'all',
						'user_id' => 'current',
						'show_login' => '1',
						'login_msg' => __( 'Please login to view statistics', 'mc_form' ),
						'theme' => 'material-default',
						'days' => '7',
						'max' => '0',
						'others' => __( 'Others', 'mc_form' ),
						'totalline' => __( 'Total Submissions', 'mc_form' ),
						'xlabel' => __( 'Date', 'mc_form' ),
						'ylabel' => __( 'Submissions', 'mc_form' ),
						'height' => '700',
						'width' => '1920',
					),
					'ussb_tts' => array(
						'form_ids' => __( 'Enter "all" to show all forms. Or Comma separated values like "1,30,51" etc.', 'mc_form' ),
						'user_id' => __( 'ID of the user for which you want to show stat. Enter current to show for currently logged in user.', 'mc_form' ),
						'show_login' => __( 'If set to checked and if the stat is for currently logged in user, then a login form would be shown if user is not logged in already.', 'mc_form' ),
						'login_msg' => __( 'The login form heading. Keep it short.', 'mc_form' ),
						'theme' => __( 'Login form theme. Please select from the presets.', 'mc_form' ),
						'days' => __( 'Either enter date in Y-m-d (2016-12-30) format to show since mentioned date. Or enter number of days, like 20, to show for past 20 days. Leave blank to show for all time.', 'mc_form' ),
						'max' => __( 'For rather large number of forms, it is advised to group forms with smaller scales into "Others". Mention the maximum number of forms (exclusive) the system will count before grouping others. Leave empty or 0 to disable.', 'mc_form' ),
						'others' => __( 'Enter the label of the others grouping.', 'mc_form' ),
						'totalline' => __( 'If you wish to show a total line in the graph then enter the title. If empty, then total line would not be shown.', 'mc_form' ),
						'xlabel' => __( 'X Axis Label', 'mc_form' ),
						'ylabel' => __( 'Y Axis Label', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),

					'usob' => __( 'Overall Submissions', 'mc_form' ),
					'usobtt' => __( 'Pie or Doughnut chart to show overall submissions for selected or current user for selected forms.', 'mc_form' ),
					'usob_lbs' => array(
						'form_ids' => __( 'Form IDs', 'mc_form' ),
						'user_id' => __( 'User ID', 'mc_form' ),
						'show_login' => __( 'Show Login Form', 'mc_form' ),
						'login_msg' => __( 'Login Message', 'mc_form' ),
						'theme' => __( 'Login Form Theme', 'mc_form' ),
						'days' => __( 'Number of days or date', 'mc_form' ),
						'max' => __( 'Max Number of forms to show before grouping', 'mc_form' ),
						'others' => __( 'Grouping Label', 'mc_form' ),
						'type' => __( 'Type of Graph', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),
					'usob_df' => array(
						'form_ids' => 'all',
						'user_id' => 'current',
						'show_login' => '1',
						'login_msg' => __( 'Please login to view statistics', 'mc_form' ),
						'theme' => 'material-default',
						'days' => '',
						'max' => '0',
						'others' => __( 'Others', 'mc_form' ),
						'type' => 'pie', // Can be pie, doughnut
						'height' => '400',
						'width' => '600',
					),
					'usob_tts' => array(
						'form_ids' => __( 'Enter "all" to show all forms. Or Comma separated values like "1,30,51" etc.', 'mc_form' ),
						'user_id' => __( 'ID of the user for which you want to show stat. Enter current to show for currently logged in user.', 'mc_form' ),
						'show_login' => __( 'If set to checked and if the stat is for currently logged in user, then a login form would be shown if user is not logged in already.', 'mc_form' ),
						'login_msg' => __( 'The login form heading. Keep it short.', 'mc_form' ),
						'theme' => __( 'Login form theme. Please select from the presets.', 'mc_form' ),
						'days' => __( 'Either enter date in Y-m-d (2016-12-30) format to show since mentioned date. Or enter number of days, like 20, to show for past 20 days. Leave blank to show for all time.', 'mc_form' ),
						'max' => __( 'For rather large number of forms, it is advised to group forms with smaller scales into "Others". Mention the maximum number of forms (exclusive) the system will count before grouping others. Leave empty or 0 to disable.', 'mc_form' ),
						'others' => __( 'Enter the label of the others grouping.', 'mc_form' ),
						'type' => __( 'Type of chart to draw', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),


					'usscb' => __( 'Score Breakdown', 'mc_form' ),
					'usscbtt' => __( 'Pie or Doughnut chart to show score percentage breakdown for selected forms and selected or current user.', 'mc_form' ),
					'usscb_lbs' => array(
						'form_ids' => __( 'Form IDs', 'mc_form' ),
						'user_id' => __( 'User ID', 'mc_form' ),
						'show_login' => __( 'Show Login Form', 'mc_form' ),
						'login_msg' => __( 'Login Message', 'mc_form' ),
						'theme' => __( 'Login Form Theme', 'mc_form' ),
						'label' => __( 'Graph Legend Format', 'mc_form' ),
						'type' => __( 'Type of Graph', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),
					'usscb_df' => array(
						'form_ids' => 'all',
						'user_id' => 'current',
						'show_login' => '1',
						'login_msg' => __( 'Please login to view statistics', 'mc_form' ),
						'theme' => 'material-default',
						'label' => __( 'From %1$d%% to %2$d%% ', 'mc_form' ),
						'type' => 'pie', // Can be pie, doughnut
						'height' => '400',
						'width' => '600',
					),
					'usscb_tts' => array(
						'form_ids' => __( 'Enter "all" to show all forms. Or Comma separated values like "1,30,51" etc.', 'mc_form' ),
						'user_id' => __( 'ID of the user for which you want to show stat. Enter current to show for currently logged in user.', 'mc_form' ),
						'show_login' => __( 'If set to checked and if the stat is for currently logged in user, then a login form would be shown if user is not logged in already.', 'mc_form' ),
						'login_msg' => __( 'The login form heading. Keep it short.', 'mc_form' ),
						'theme' => __( 'Login form theme. Please select from the presets.', 'mc_form' ),
						'label' => __( 'Enter legend format of the score breakdown. From %d%% to %d%% will be replaced by From 0% to 9%, From 10% to 19% etc. It takes formatting of PHP sprintf. So %1$d will be replaced by min score and %2$d will be replaced by max score, use them if you want to change the scoring order in the labels.', 'mc_form' ),
						'type' => __( 'Type of chart to draw', 'mc_form' ),
						'height' => __( 'Graph Height (px)', 'mc_form' ),
						'width' => __( 'Graph Width (px)', 'mc_form' ),
					),

					'charts' => array(
						0 => array(
							'text' => __( 'Pie Chart', 'mc_form' ),
							'value' => 'pie',
						),
						1 => array(
							'text' => __( 'Doughnut Chart', 'mc_form' ),
							'value' => 'doughnut',
						),
					),
				),
				'if' => __( 'Insert Form', 'mc_form' ),
				'ifl' => __( 'Select Form', 'mc_form' ),
				'it' => __( 'Insert Trends', 'mc_form' ),
				'itvc' => __( 'Title of the Visualization Column', 'mc_form' ),
				'itvcv' => __( 'Trends', 'mc_form' ),
				'itvsl' => __( 'Server Load', 'mc_form' ),
				'itvsllb' => array(
					array(
						'text' => __( 'Light Load: 15 queries per hit', 'mc_form' ),
						'value' => '0',
					),
					array(
						'text' => __( 'Medium Load: 30 queries per hit (Recommended)', 'mc_form' ),
						'value' => '1',
						'selected' => true,
					),
					array(
						'text' => __( 'Heavy Load: 50 queries per hit', 'mc_form' ),
						'value' => '2',
					),
				),
				'pf' => __( 'Insert Popup Forms', 'mc_form' ),
				'pfbt' => __( 'Button Text', 'mc_form' ),
				'pfbtl' => __( 'Contact Form', 'mc_form' ),
				'pfbc' => __( 'Button Color', 'mc_form' ),
				'pfbbc' => __( 'Button Background Color', 'mc_form' ),
				'pfbp' => __( 'Button Position', 'mc_form' ),
				'pfbplb' => array(
					array(
						'text' => __( 'Right', 'mc_form' ),
						'value' => 'r',
					),
					array(
						'text' => __( 'Bottom Right', 'mc_form' ),
						'value' => 'br',
						'selected' => true,
					),
					array(
						'text' => __( 'Bottom Center', 'mc_form' ),
						'value' => 'bc',
					),
					array(
						'text' => __( 'Bottom Left', 'mc_form' ),
						'value' => 'bl',
					),
					array(
						'text' => __( 'Left', 'mc_form' ),
						'value' => 'l',
					),
					array(
						'text' => __( 'Hidden / Manual Trigger' ),
						'value' => 'h',
					),
				),
				'pfbs' => __( 'Button Style', 'mc_form' ),
				'pfbslb' => array(
					array(
						'text' => __( 'Rectangular', 'mc_form' ),
						'value' => 'rect',
					),
					array(
						'text' => __( 'Circular', 'mc_form' ),
						'value' => 'circ',
					),
				),
				'pfbheader' => __( 'Popup Header Title, %FORM% is form name', 'mc_form' ), // form name
				'pfbsubtitle' => __( 'Popup Header Subtitle', 'mc_form' ), // Some subtitle
				'pfbicon' => __( 'Popup Button Icon class', 'mc_form' ), // icon class needs to be supplied by vendor
				'pfbwidth' => __( 'Initial Popup Width', 'mc_form' ), // Initial popup width in pixels
				'pfpv' => __( 'Button Preview', 'mc_form' ),
				'pfmt' => __( 'Since you have chosen manual trigger, you need to insert the following code somewhere in the post. Do you want to insert automatically?', 'mc_form' ),
				'pfmtf' => __( 'Alternately you can note down the href attribute of the button and put it in any custom button through theme shortcode or any preferred method.', 'mc_form' ),
				'twb1' => array(
					'rt' => __( 'Report Type', 'mc_form' ),
					'rdc' => __( 'Report Data Customizations', 'mc_form' ),
					'ra' => __( 'Report Appearance', 'mc_form' ),
				),
				'twb2' => array(
					'sm' => __( 'Select the Multiple Choice Type Questions', 'mc_form' ),
					'sf' => __( 'Select the Feedback Type Questions', 'mc_form' ),
					'sp' => __( 'Select the Other Form Elements', 'mc_form' ),
					'sct' => __( 'Chart Type', 'mc_form' ),
					'sctl' => __( 'Show Chart Title', 'mc_form' ),
					'scl' => __( 'Show Chart Legend and Axis Ticks', 'mc_form' ),
					'spm' => __( 'Percentage Meta Line (Overrides graph to combo)', 'mc_form' ),
					'fl' => __( 'Filter Report', 'mc_form' ),
					'su' => __( 'Select Users', 'mc_form' ),
					'surl' => __( 'Select URL Tracks', 'mc_form' ),
					'umk' => __( 'User Meta Key', 'mc_form' ),
					'umv' => __( 'User Meta Value', 'mc_form' ),
					'somin' => __( 'Minimum Score Obtained (Inclusive)', 'mc_form' ),
					'somax' => __( 'Maximum Score Obtained (Inclusive)', 'mc_form' ),
					'dtmin' => __( 'Start Date Y-m-d H:i:s ( %s ) (Inclusive)', 'mc_form' ),
					'dtmax' => __( 'End Date Y-m-d H:i:s ( %s ) (Inclusive)', 'mc_form' ),
				),
			),
			'addons' => apply_filters( 'mc_form_mce', array() ),
			'forms' => (array) MC_FORM_Form_Elements_Static::get_forms_for_select(),
			'nonce' => wp_create_nonce( 'mc_form_shortcode_get_mcqs' ),
			'themes' => (array) MC_FORM_Form_Elements_Static::get_form_themes_for_select(),
			// Trends variables
			'trends' => array(
				'cTypeToggle' => $chart_helper,
				'reportTypes' => $report_type,
				'reportData' => $report_data,
				'reportAppearance' => $report_appearance,
			),
		) );

		do_action( 'mc_form_tmce_extendor_script' );
	}

	public function mce_external_plugins( $plugins ) {
		$plugins['mcFORMv3'] = MC_FORM_Loader::$static_location . 'admin/js/mc-form-tinymce-plugin.min.js';
		return $plugins;
	}

	public function mce_buttons( $buttons ) {
		array_push( $buttons, 'mc_form_tmce_menubutton' );
		return $buttons;
	}
}
