<?php
/**
 * MC FORM Settings
 *
 * Class for handling the Settings page under mcForm
 *
 * @author BinaryPoets <hello@binarypoets.net>
 * @package mcForm - Premium Form System
 * @subpackage Admin\Settings
 * @codeCoverageIgnore
 */
class MC_FORM_Settings extends MC_FORM_Admin_Base {
	public function __construct() {
		$this->capability = 'manage_feedback';
		$this->action_nonce = 'mc_form_settings_nonce';

		parent::__construct();

		$this->icon = 'settings';

		$this->post_result[4] = array(
			'type' => 'okay',
			'msg' => __( 'Successfully saved the options as well as created sample forms. You may now head to <a href="admin.php?page=mc_form_all_forms">View all Forms</a> to start editing them.', 'mc_form' ),
		);
	}

	/*==========================================================================
	 * SYSTEM METHODS
	 *========================================================================*/

	public function admin_menu() {
		$this->pagehook = add_submenu_page( 'mc_form_dashboard', __( 'mcForm Settings', 'mc_form' ), __( 'Settings', 'mc_form' ), $this->capability, 'mc_form_settings', array( &$this, 'index' ) );
		parent::admin_menu();
	}

	public function index() {
		global $mc_form_settings;
		$mc_form_key = get_option( 'mc_form_key' );
		$updater = MCForm_AutoUpdate::instance();
		$this->index_head( __( 'mcForm <span class="mc-icomoon-arrow-right2"></span> Settings', 'mc_form' ) );
		$mcform_activation_status = $updater->current_activation_status( $mc_form_settings['purchase_code'] );
		$purchase_code_items = array();
		$purchase_code_items[] = array(
			'name' => 'global[purchase_code]',
			'label' => __( 'mcForm Purchase Code', 'mc_form' ),
			'ui' => 'text',
			'param' => array( 'global[purchase_code]', $mc_form_settings['purchase_code'], __( 'Required', 'mc_form' ), 'fit', 'normal', array( 'code' ) ),
			'help' => __( 'Enter your purchase code to activate.', 'mc_form' ),
			// translators: %1$s is the URL of the purchase code guide
			'description' => sprintf( __( '<a href="https://www.binarypoets.net" target="_blank" rel="noopener">Follow this</a> to find out your purchase code.', 'mc_form' ), 'https://mcms.co/envatopc' ),
		);
		$purchase_code_items[] = array(
			'name' => '',
			'ui' => true == $mcform_activation_status['activated'] ? 'msg_okay' : 'msg_error',
			'param' => array( $mcform_activation_status['msg'] ),
		);
		$purchase_code_items = apply_filters( 'mcform_purchase_code_form', $purchase_code_items );
?>

<div class="mc_uif_iconbox mc_uif_shadow glowy">
	<div class="mc_uif_box cyan">
		<h3><span class="mc-icomoon-cog"></span><?php _e( 'Global API Keys', 'mc_form' ); ?></h3>
	</div>
	<div class="mc_uif_iconbox_inner">
		<table class="form-table">
			<tbody>
				<tr>
					<th scope="row">
						<label for="global_email"><?php _e( 'Google Places API Key', 'mc_form' ); ?></label>
					</th>
					<td>
						<?php $this->ui->password( 'global[gplaces_api]', $mc_form_settings['gplaces_api'] ); ?>
					</td>
					<td>
						<?php $this->ui->help_head(); ?>
							<p><?php _e( 'You need to enter a valid Google Places API to make sure the localtion picker (GPS) element works.', 'mc_form' ); ?></p>
							<p><?php _e( 'More instructions can be found <a href="https://www.binarypoets.net/kb/?p=9859">here</a>.', 'mc_form' ); ?></p>
						<?php $this->ui->help_tail(); ?>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
<?php $this->print_form_buttons( __( 'Save Changes', 'mc_form' ), false ); ?>
<div class="mc_uif_iconbox mc_uif_shadow glowy">
	<div class="mc_uif_box cyan">
		<h3><span class="mc-icomoon-cog"></span><?php _e( 'Modify Plugin Settings', 'mc_form' ); ?></h3>
	</div>
	<div class="mc_uif_iconbox_inner">
		<table class="form-table">
			<tr>
				<th scope="row">
					<label for="global_email"><?php _e( 'Global Notification Email', 'mc_form' ); ?></label>
				</th>
				<td>
					<?php $this->print_input_text( 'global[email]', $mc_form_settings['email'], 'regular-text code' ); ?>
				</td>
				<td>
					<?php $this->ui->help_head(); ?>
						<?php _e( 'Enter the email where you want to send notifications for all the feedback forms.', 'mc_form' ); ?>
					<?php $this->ui->help_tail(); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="global_track_page"><?php _e( 'Single Submission Trackback Page for Unregistered Users', 'mc_form' ); ?></label>
				</th>
				<td>
					<?php $this->ui->dropdown_pages( array(
						'name' => 'global[track_page]',
						'selected' => $mc_form_settings['track_page'],
						'show_option_none' => __( 'Please select a page', 'mc_form' ),
					) ); ?>
				</td>
				<td>
					<?php $this->ui->help_head(); ?>
						<?php _e( 'Select the page where you\'ve put the <code>[mc_form_trackback]</code> shortcode. The page will be linked throughout all the notification email.', 'mc_form' ); ?>
					<?php $this->ui->help_tail(); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="global_utrack_page"><?php _e( 'Central Trackback page for Registered Users', 'mc_form' ); ?></label>
				</th>
				<td>
					<?php $this->ui->dropdown_pages( array(
						'name' => 'global[utrack_page]',
						'selected' => $mc_form_settings['utrack_page'],
						'show_option_none' => __( 'Please select a page', 'mc_form' ),
					) ); ?>
				</td>
				<td>
					<?php $this->ui->help_head(); ?>
						<?php _e( 'Select the page where you\'ve put the <code>[mc_form_utrackback]</code> shortcode. The page will be linked throughout all the notification email.', 'mc_form' ); ?>
					<?php $this->ui->help_tail(); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<?php $this->ui->generate_label( 'global[key]', __( 'Secret Encryption Key', 'mc_form' ) ); ?>
				</th>
				<td>
					<?php $this->ui->text( 'global[key]', $mc_form_key, __( 'Can not be empty', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help_head(); ?>
					<p><?php _e( 'This key is used to generate the trackback keys. If you change this, then all the trackback codes will get reset.', 'mc_form' ); ?></p>
					<p><?php _e( 'Use this with extreme caution and change only if necessary. The new trackback keys will not be sent to the users.', 'mc_form' ); ?></p>
					<?php $this->ui->help_tail(); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<?php $this->ui->generate_label( 'global[disable_un]', __( 'Disable Activation Notice', 'mc_form' ) ); ?>
				</th>
				<td>
					<?php $this->ui->toggle( 'global[disable_un]', __( 'yes', 'mc_form' ), 'no', $mc_form_settings['disable_un'] ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Starting mcForm version 4.0, mcForm and add-ons will show a notice if you haven\'t activated with a purchase code. Enable this option to hide the notice.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<?php $this->ui->generate_label( 'global[delete_uninstall]', __( 'Delete all Data when uninstalling plugin', 'mc_form' ) ); ?>
				</th>
				<td>
					<?php $this->ui->toggle( 'global[delete_uninstall]', __( 'yes', 'mc_form' ), 'no', $mc_form_settings['delete_uninstall'] ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'If you want to completely wipe out all data when uninstalling, then have this enabled. Keep it disabled, if you are planning to update the plugin by uninstalling and then reinstalling.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<?php $this->ui->generate_label( 'global[sandboxing]', __( 'Sandbox mcForm Admin Pages', 'mc_form' ) ); ?>
				</th>
				<td>
					<?php $this->ui->toggle( 'global[sandboxing]', __( 'yes', 'mc_form' ), 'no', $mc_form_settings['sandboxing'] ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Some plugins may enqueue CSS and JS assets all over the admin pages which could potentially break mcForm functionality. Enabling it ensures that only WordPress core and mcForm assets are loaded when accessing mcForm related admin pages.', 'mc_form' ) ); ?>
				</td>
			</tr>
		</table>
	</div>
</div>
<?php $this->print_form_buttons( __( 'Save Changes', 'mc_form' ), false ); ?>
<div class="mc_uif_iconbox mc_uif_shadow glowy">
	<div class="mc_uif_box cyan">
		<h3><span class="mc-icomoon-file2"></span><?php _e( 'Modify Standalone Forms Settings', 'mc_form' ); ?></h3>
	</div>
	<div class="mc_uif_iconbox_inner">
		<table class="form-table">
			<tbody>
				<tr>
				<th scope="row">
					<?php $this->ui->generate_label( 'global[standalone][base]', __( 'Permalink Base', 'mc_form' ) ); ?>
				</th>
				<td>
					<?php $this->ui->text( 'global[standalone][base]', $mc_form_settings['standalone']['base'], __( 'Can not be empty', 'mc_form' ), 'fit', 'normal', 'code' ); ?>
				</td>
				<td>
					<?php $this->ui->help_head(); ?>
					<p><?php _e( 'This will be the base of any permalink generated for your standalone forms.', 'mc_form' ); ?></p>
					<p><?php _e( 'If you want the links to be like <code>http://example.com/<strong>webforms</strong>/my-awesome-form/01/</code> then use <code>webforms</code> as the base.', 'mc_form' ); ?></p>
					<?php $this->ui->help_tail(); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<?php $this->ui->generate_label( 'global[standalone][head]', __( 'HTML Head Section', 'mc_form' ) ); ?>
				</th>
				<td>
					<?php $this->ui->textarea( 'global[standalone][head]', $mc_form_settings['standalone']['head'], __( 'CSS or JS or Meta Tags', 'mc_form' ), 'widefat', 'normal', 'code' ); ?>
				</td>
				<td>
					<?php $this->ui->help_head(); ?>
					<p><?php _e( 'If you want to put any custom CSS code or other HTML tags inside the <code>&lt;head&gt;</code> section, then do it here.', 'mc_form' ); ?></p>
					<p><?php _e( 'Please note that, if a css file named form-pro.css or form-pro-{form_id}.css is present inside your current theme directory, then it will be included by default.', 'mc_form' ); ?></p>
					<?php $this->ui->help_tail(); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<?php $this->ui->generate_label( 'global[standalone][before]', __( 'Before Form HTML', 'mc_form' ) ); ?>
				</th>
				<td>
					<?php $this->ui->wp_editor( 'global[standalone][before]', $mc_form_settings['standalone']['before'] ); ?>
				</td>
				<td>
					<?php $this->ui->help_head(); ?>
					<p><?php _e( 'This content will be appended before the output of the form.', 'mc_form' ); ?></p>
					<?php $this->ui->help_tail(); ?>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<?php $this->ui->generate_label( 'global[standalone][after]', __( 'After Form HTML', 'mc_form' ) ); ?>
				</th>
				<td>
					<?php $this->ui->wp_editor( 'global[standalone][after]', $mc_form_settings['standalone']['after'] ); ?>
				</td>
				<td>
					<?php $this->ui->help_head(); ?>
					<p><?php _e( 'This content will be appended after the output of the form.', 'mc_form' ); ?></p>
					<?php $this->ui->help_tail(); ?>
				</td>
			</tr>
			</tbody>
		</table>
	</div>
</div>
		<?php
		$this->index_foot();
	}

	public function save_post( $check_referer = true ) {
		parent::save_post();

		$settings = array(
			'email' => $this->post['global']['email'],
			'track_page' => $this->post['global']['track_page'],
			'utrack_page' => $this->post['global']['utrack_page'],
			'delete_uninstall' => isset( $this->post['global']['delete_uninstall'] ) && '' != $this->post['global']['delete_uninstall'] ? true : false,
			'sandboxing' => isset( $this->post['global']['sandboxing'] ) && '' != $this->post['global']['sandboxing'] ? true : false,
			'standalone' => array(
				'base' => $this->post['global']['standalone']['base'],
				'before' => $this->post['global']['standalone']['before'],
				'after' => $this->post['global']['standalone']['after'],
				'head' => $this->post['global']['standalone']['head'],
			),
			'disable_un' => isset( $this->post['global']['disable_un'] ) && '' != $this->post['global']['disable_un'] ? true : false,
			'gplaces_api' => $this->post['global']['gplaces_api'],
			'purchase_code' => $this->post['global']['purchase_code'],
		);

		if ( trim( $settings['standalone']['base'] ) == '' ) {
			$settings['standalone']['base'] = 'mcforms';
		}

		$settings['standalone']['base'] = sanitize_title( $settings['standalone']['base'] );

		update_option( 'mc_form_settings', $settings );

		$key = $this->post['global']['key'];
		if ( trim( $key ) == '' ) {
			$key = NONCE_SALT;
		}
		update_option( 'mc_form_key', $key );

		// Get the activation token
		$license = MCForm_AutoUpdate::instance();
		$license->set_token_from_code( $this->post['global']['purchase_code'] );

		wp_redirect( add_query_arg( array( 'post_result' => 1 ), $_POST['_wp_http_referer'] ) );
		die();
	}

	public function on_load_page() {
		flush_rewrite_rules();
		parent::on_load_page();
		get_current_screen()->add_help_tab( array(
				'id' => 'track',
				'title' => __( 'Settings', 'mc_form' ),
				'content' =>
				'<p>' . __( 'There are five settings which you can change.', 'mc_form' ) . '<p>' .
				'<ul>' .
				'<li>' . __( '<strong>Global Notification Email:</strong> Enter an email where the notification will be sent everytime a user submits any of the forms.', 'mc_form' ) . '</li>' .
				'<li>' . __( '<strong>Single Submission Trackback Page for Unregistered Users:</strong> Select the page where you\'ve put the <code>[mc_form_trackback]</code> shortcode. From this page users can see their submission and print if they want. The page will be linked throughout all the notification email.', 'mc_form' ) . '</li>' .
				'<li>' . __( '<strong>Central Trackback page for Registered Users:</strong> Select the page where you\'ve put the [mc_form_utrackback] shortcode. From this page, logged in users will be able to see all their submissions and also they will be getting a link to the trackback page. The page will be linked throughout all the trackbacks whenever applicable.', 'mc_form' ) . '</li>' .
				'<li>' . __( '<strong>Backward Compatible Shortcode:</strong> If you are coming from older version (prior to version 2.x) then you need to leave it enabled in order to make the older format of shortcodes work. Since version 2.x, the shortcode format was changed to a more localized form.', 'mc_form' ) . '</li>' .
				'<li>' . __( '<strong>Secret Encryption Key:</strong> This key is used to generate the trackback keys. If you change this, then all the trackback codes will get reset.', 'mc_form' ) . '</li>' .
				'</ul>' .
				'<p>' . __( 'Please set the settings up before going live with your forms.', 'mc_form' ) . '</p>',
			) );
		get_current_screen()->set_help_sidebar(
			'<p><strong>' . __( 'For more information:', 'mc_form' ) . '</strong></p>' .
			'<p>' . sprintf( __( '<a href="%s" target="_blank">Documentation</a>', 'mc_form' ), MC_FORM_Loader::$documentation ) . '</p>' .
			'<p>' . sprintf( __( '<a href="%s" target="_blank">Support Forums</a>', 'mc_form' ), MC_FORM_Loader::$support_forum ) . '</p>'
		);
	}
}
