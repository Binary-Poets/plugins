<?php
/**
 * Helper class for Eform live view
 * @since 4.5.0
 */

class MCForm_Live_View {
	/**
	 * Form Instance
	 *
	 * @var MC_FORM_Form_Elements_Front
	 */
	protected $form;

	public function __construct( $form_id )	{
		$this->form = new MC_FORM_Form_Elements_Front( null, $form_id );
		$this->form->enable_live_view();
	}

	public function preview() {
		?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $this->form->name; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style type="text/css">
		body {
			font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
		}
		/**/
	</style>
	<?php $this->enqueue(); ?>
</head>
<body class="mc_uif_common">
	<div id="mcform.live-view-messages" style="display: none;"></div>
	<div id="mcform.live-view-loading" style="display: none;">
		<div class="mcform-refresh">
			<div class="mcform-refresh-bar"></div>
			<div class="mcform-refresh-bar"></div>
			<div class="mcform-refresh-bar"></div>
			<div class="mcform-refresh-bar"></div>
		</div>
	</div>
	<div id="mcform.live-view">
		<div class="mcform.live-view-removable">
			<?php $this->form->show_form( true, false ); ?>
		</div>
	</div>
	<div id="mcform.live-demo-mode-token"></div>
	<?php
	wp_print_scripts();
	wp_print_styles();
	?>
</body>
</html>
		<?php
	}

	public function stream_html() {
		ob_start();
		$this->form->show_form( true, false );
		$form = ob_get_clean();
		return [
			'success' => true,
			'html' => $form,
			'id' => $this->form->form_id,
		];
	}

	protected function enqueue() {
		global $mc_form_settings;
		// Enqueue
		$this->form->ui->enqueue_all( $mc_form_settings['gplaces_api'] );
		$this->form->enqueue( true );
		wp_enqueue_script( 'mcform.live-sync', MC_FORM_Loader::$static_location . 'admin/js/mcform.live-sync.min.js', [], MC_FORM_Loader::$version );
		wp_enqueue_style( 'mcform.live-sync-css', MC_FORM_Loader::$static_location . 'admin/css/mcform.live-sync.css', [], MC_FORM_Loader::$version );
		wp_localize_script( 'mcform.live-sync', 'mcFormLiveSync', [
			'ajaxurl' => admin_url('admin-ajax.php'),
			'_wpnonce' => wp_create_nonce( 'mcform_builder_form_html' ),
			'form_id' => $this->form->form_id,
		] );
		wp_print_styles();
		wp_print_scripts();
	}
}
