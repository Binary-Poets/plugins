<?php
/**
 * MC FORM Payments
 *
 * Class for handling the Payments page under mcForm
 *
 * @author BinaryPoets <hello@binarypoets.net>
 * @package mcForm - Premium Form System
 * @subpackage Admin\Payments
 * @codeCoverageIgnore
 */
class MC_FORM_Payments extends MC_FORM_Admin_Base {
	/**
	 * @var        MC_Payments_Table  $table_view  payment table class
	 */
	public $table_view;

	public function __construct() {
		$this->capability = 'manage_feedback';
		$this->action_nonce = 'mc_form_payment_nonce';

		parent::__construct();

		$this->icon = 'file-text';
		add_filter( 'set-screen-option', array( $this, 'table_set_option' ), 10, 3 );

		$this->post_result[4] = array(
			'type' => 'okay',
			'msg' => __( 'Successfully updated the payment.', 'mc_form' ),
		);

		$this->post_result[5] = array(
			'type' => 'okay',
			'msg' => __( 'Successfully deleted the payment.', 'mc_form' ),
		);
		$this->post_result[6] = array(
			'type' => 'okay',
			'msg' => __( 'Successfully deleted the payments.', 'mc_form' ),
		);

		// Add ajax actions
		add_action( 'wp_ajax_mc_form_payment_set_status', [ $this, 'ajax_set_status' ], 10 );
	}

	public function ajax_set_status() {
		if ( ! current_user_can( 'manage_feedback' ) ) {
			wp_die( __( 'Cheatin&#8217; uh?' ) );
		}
		$id = @$_REQUEST['id'];
		$status = @$_REQUEST['status'];
		// Verify nonce
		if ( ! wp_verify_nonce( @$_REQUEST['_wpnonce'], 'mcform_set_' . $status . '_' . $id ) ) {
			wp_die( __( 'Cheatin&#8217; uh?' ) );
		}
		// All set, now set the status
		$payment_offline = MCForm_Payment_Handler_Offline::instance();
		$success = $payment_offline->set_payment_status( $id, $status );
		$return = [
			'success' => $success,
			'msg' => __( 'Something went wrong, please retry.', 'mc_form' ),
		];
		if ( $success ) {
			$return['msg'] = __( 'Operation successful', 'mc_form' );
		}
		@header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );
		echo json_encode( $return );
		die();
	}

	public function admin_menu() {
		$this->pagehook = add_submenu_page( 'mc_form_dashboard', __( 'mcForm Payments', 'mc_form' ), __( 'Payments', 'mc_form' ), $this->capability, 'mc_form_payments', array( $this, 'index' ) );
		parent::admin_menu();
	}

	public function index() {
		$this->index_head( __( 'mcForm <span class="mc-icomoon-arrow-right2"></span> Payments', 'mc_form' ), false );
		$this->table_view->prepare_items();
		?>
		<style type="text/css">
			.column-title {
				width: 250px;
			}
			.column-txn {
				width: 300px;
			}
		</style>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$('#mcform-payments-box').on( 'click', 'a.payment-action', function( e ) {
					e.preventDefault();
					var elm = $( this ),
					link = elm.attr( 'href' ),
					main = elm.closest( '.row-actions' ),
					helper = $( '<div>Please Wait...</div>' );
					main.before( helper );
					elm.hide();
					$.ajax({
						url: link,
						type: 'GET',
						dataType: 'json',
						data: {param1: 'value1'},
					})
					.done( function( data ) {
						helper.html( data.msg );
						elm.remove();
					} )
					.fail(function() {
						helper.html( 'Error' );
						elm.show();
					})
					.always(function() {
						setTimeout( function() {
							helper.fadeOut( 'slow', function() {
								helper.remove();
							} );
						}, 2000 );
					});
				} );
			});
		</script>
		<div class="mc_uif_iconbox mc_uif_shadow glowy">
			<div class="mc_uif_box cyan">
				<h3><span class="mc-icomoon-pencil"></span><?php _e( 'Modify and/or View Payments', 'mc_form' ); ?></h3>
			</div>
			<div class="mc_uif_iconbox_inner" id="mcform-payments-box">
				<form action="" method="get">
					<?php foreach ( $_GET as $k => $v ) : ?>
						<?php if ( $k == 'order' || $k == 'orderby' || $k == 'page' ) : ?>
						<input type="hidden" name="<?php echo $k; ?>" value="<?php echo $v; ?>" />
						<?php endif; ?>
					<?php endforeach; ?>
					<?php $this->table_view->search_box( __( 'Search Tranasction ID', 'mc_form' ), 'search_id' ); ?>
					<?php $this->table_view->display(); ?>
				</form>
				<div class="clear"></div>
			</div>
		</div>
		<?php $this->index_foot( false );
	}

	public function save_post( $check_referer = true ) {
		parent::save_post( $check_referer );
	}

	public function on_load_page() {
		global $wpdb, $mc_form_info;

		$this->table_view = new MC_FORM_Payments_Table();

		if ( !empty( $_GET['_wp_http_referer'] ) ) {
			wp_redirect( remove_query_arg( array( '_wp_http_referer', '_wpnonce' ) ) );
			die();
		}

		$option = 'per_page';
		$args = array(
			'label' => __( 'Payments per page', 'mc_form' ),
			'default' => 20,
			'option' => 'form_payment_per_page',
		);

		add_screen_option( $option, $args );


		parent::on_load_page();

		get_current_screen()->add_help_tab( array(
			'id'  => 'overview',
			'title'  => __( 'Overview' ),
			'content' =>
			'<p>' . __( 'This screen provides access to all of your payments. You can customize the display of this screen to suit your workflow.', 'mc_form' ) . '</p>' .
			'<p>' . __( 'By default, this screen will show all the payments of all the available forms. Please check the Screen Content for more information.', 'mc_form' ) . '</p>'
		) );
		get_current_screen()->add_help_tab( array(
			'id'  => 'screen-content',
			'title'  => __( 'Screen Content' ),
			'content' =>
			'<p>' . __( 'You can customize the display of this screen&#8217;s contents in a number of ways:' ) . '</p>' .
			'<ul>' .
			'<li>' . __( 'You can select a particular form and filter payments on that form only.', 'mc_form' ) . '</li>' .
			'<li>' . __( 'You can select a particular payment method and filter payments on that method only.', 'mc_form' ) . '</li>' .
			'<li>' . __( 'You can select a particular payment status and filter payments on that status only.', 'mc_form' ) . '</li>' .
			'<li>' . __( 'You can hide/display columns based on your needs and decide how many payments to list per screen using the Screen Options tab.', 'mc_form' ) . '</li>' .
			'<li>' . __( 'You can search a particular payment by transaction ID through the Search Form.', 'mc_form' ) . '</li>' .
			'</ul>'
		) );
		get_current_screen()->add_help_tab( array(
			'id'  => 'action-links',
			'title'  => __( 'Available Actions' ),
			'content' =>
			'<p>' . __( 'Hovering over a row in the payments list will display action links that allow you to manage your payments. You can perform the following actions:', 'mc_form' ) . '</p>' .
			'<ul>' .
			'<li>' . __( '<strong>Quick Preview</strong>: Pops up a modal window with the detailed preview of the particular payment. You can also print the payment if you wish to.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Full View</strong>: Opens up a page where you can view the form along with the payment data.', 'mc_form' ) . '</li>' .
			'</ul>'
		) );
	}

	public function table_set_option( $status, $option, $value ) {
		return $value;
	}
}
