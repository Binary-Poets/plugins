<form id="bps_shortcode_columns">
	<table class="form-table">
		<tbody>
		 <tr>
		 	<th><h3><?php _e('Standard','binary-flexible-shortcodes'); ?></h3></th><td></td>
		 </tr>
	   <tr>
				<th><?php _e('Two columns','binary-flexible-shortcodes'); ?>:</th> 
				<td><input type="radio" name="columns" value="<p>[bps_one_half]Your awesome content goes here[/bps_one_half]</p><p>[bps_one_half]Your awesome content goes here[/bps_one_half]</p>" checked /> (1/2) + (1/2)</td>
		</tr>
		<tr>
				<th><?php _e('Three columns','binary-flexible-shortcodes'); ?>:</th> 
				<td><input type="radio" name="columns" value="<p>[bps_one_third]Your awesome content goes here[/bps_one_third]</p><p>[bps_one_third]Your awesome content goes here[/bps_one_third]</p><p>[bps_one_third]Your awesome content goes here[/bps_one_third]</p>"/> (1/3) + (1/3) + (1/3)</td>
		</tr>
		<tr>
				<th><?php _e('Four columns','binary-flexible-shortcodes'); ?>:</th> 
				<td><input type="radio" name="columns" value="<p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p><p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p><p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p><p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p>"/> (1/4) + (1/4) + (1/4) + (1/4)</td>
		</tr>
		 <tr>
		 	<th><h3><?php _e('Complex','binary-flexible-shortcodes'); ?></h3></th><td></td>
		 </tr>
	   <tr>
				<th><?php _e('Two thirds + one third','binary-flexible-shortcodes'); ?>:</th> 
				<td><input type="radio" name="columns" value="<p>[bps_two_thirds]Your awesome content goes here[/bps_two_thirds]</p><p>[bps_one_third]Your awesome content goes here[/bps_one_third]</p>"/> (2/3) + (1/3)</td>
		</tr>
		<tr>
				<th><?php _e('One third + two thirds','binary-flexible-shortcodes'); ?>:</th>
				<td><input type="radio" name="columns" value="<p>[bps_one_third]Your awesome content goes here[/bps_one_third]</p><p>[bps_two_thirds]Your awesome content goes here[/bps_two_thirds]</p>"/> (1/3) + (2/3)</td>
		</tr>
		<tr>
				<th><?php _e('One half + two quarters','binary-flexible-shortcodes'); ?>:</th> 
				<td><input type="radio" name="columns" value="<p>[bps_one_half]Your awesome content goes here[/bps_one_half]</p><p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p><p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p>"/> (1/2) + (1/4) + (1/4) </td>
		</tr>
		
		<tr>
				<th><?php _e('Two quarters + one half','binary-flexible-shortcodes'); ?>:</th> 
				<td><input type="radio" name="columns" value="<p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p><p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p><p>[bps_one_half]Your awesome content goes here[/bps_one_half]</p>"/> (1/4) + (1/4) + (1/2) </td>
		</tr>
		<tr>
				<th><?php _e('One quarter + one half + one quarter','binary-flexible-shortcodes'); ?>:</th> 
				<td><input type="radio" name="columns" value="<p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p><p>[bps_one_half]Your awesome content goes here[/bps_one_half]</p><p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p>"/> (1/4) + (1/2) + (1/4) </td>
		</tr>

		<tr>
				<th><?php _e('One quarter + one half + one quarter','binary-flexible-shortcodes'); ?>:</th> 
				<td><input type="radio" name="columns" value="<p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p><p>[bps_one_half]Your awesome content goes here[/bps_one_half]</p><p>[bps_one_quarter]Your awesome content goes here[/bps_one_quarter]</p>"/> (1/4) + (1/2) + (1/4) </td>
		</tr>

		<tr>
		 	<th><?php _e('Enable Bootstrap columns','binary-flexible-shortcodes'); ?></th>
			<td><input type="checkbox"  class="bootstrap-columns" name="bootstrap_columns" /></td> 
		</tr>
		<tr>
		 	<th></th>
			<td><small style="width: 200px; position:relative; top:-30px;" class="howto"><?php _e('Check this option if your theme uses Bootstrap CSS framework to apply its styling on columns','binary-flexible-shortcodes'); ?> </small></td>
		</tr>
		
		<tr>
			<th><input type="submit" class="button-primary" value="<?php _e('Insert Columns','binary-flexible-shortcodes'); ?>"/></th> 
            <td>&nbsp;</td>
        </tr>
	
	</tbody>
	</table>
</form>

<script type="text/javascript">
	/* <![CDATA[ */
  (function($) {
    	$('#bps_shortcode_columns').submit(function(e) {
			e.preventDefault();
			bps_shortcode_modal_obj.dialog('close');
			var is_bootstrap_columns = $(this).closest('#bps_shortcode_columns').find('input[name="bootstrap_columns"]').prop("checked");
			var bootstrap_columns_enabled = is_bootstrap_columns ? ' bootstrap="true"' : '';    			
			var content = '[bps_col'+ bootstrap_columns_enabled +']'+$(this).find('input[name="columns"]:checked').val()+'[/bps_col]';
			content = content.replace('{content}',bps_shortcode_content);
			bps_shortcode.setContent(content);
		});
	})(jQuery);
	/* ]]> */
</script>