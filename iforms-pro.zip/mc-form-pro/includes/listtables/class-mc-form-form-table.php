<?php
/**
 * Form Table
 *
 * A child class of WP_List_Table
 *
 * Used for showing all forms available under mcForm > View all Forms
 *
 * @author BinaryPoets <hello@binarypoets.net>
 * @package mcForm - Premium Form System
 * @subpackage ListTables\Form
 * @codeCoverageIgnore
 */
class MC_FORM_Form_Table extends MC_FORM_Listtable {
	public function __construct() {
		parent::__construct( array(
				'singular' => 'mc_form_form_item',
				'plural' => 'mc_form_form_items',
				'ajax' => false,
			) );
	}

	public function get_columns() {
		$columns = array(
			'cb' => '<input type="checkbox" /><label for="cb-select-all-1"></label>',
			'title' => __( 'Name', 'mc_form' ),
			'shortcode' => __( 'Shortcode', 'mc_form' ),
			'submission' => __( 'Submissions', 'mc_form' ),
			'category' => __( 'Category', 'mc_form' ),
			'updated' => __( 'Last Updated', 'mc_form' ),
		);
		return $columns;
	}

	public function get_sortable_columns() {
		$sortable = array(
			'title' => array( 'f.name', false ),
			'submission' => array( 'sub', true ),
			'category' => array( 'c.name', false ),
			'updated' => array( 'f.updated', true ),
		);

		return $sortable;
	}

	public function column_default( $item, $column_name ) {
		switch ( $column_name ) {
		case 'title' :
			$permalinks = MC_FORM_Form_Elements_Static::standalone_permalink_parts( $item['id'] );
			$actions = array(
				'form_id' => sprintf( __( 'ID: %d', 'mc_form' ), $item['id'] ),
				'permalink' => sprintf( '<a class="view" title="%3$s" href="%1$s" target="_blank">%2$s</a>', $permalinks['url'], __( 'Preview', 'mc_form' ), __( 'Preview the form or copy the permalink', 'mc_form' ) ),
				'view'      => sprintf( '<a class="view" href="admin.php?page=mc_form_view_all_submissions&form_id=%d">%s</a>', $item['id'], __( 'View Submissions', 'mc_form' ) ),
				'download' => sprintf( '<a class="view" href="%1$s" title="%3$s" target="_blank">%2$s</a>', wp_nonce_url( admin_url( 'admin-ajax.php?action=mc_form_submission_download&form_id=' . $item['id'] ), 'mc_form_submission_download_' . $item['id'] ), __( 'Export Submissions', 'mc_form' ), esc_attr__( 'Export all submissions in a CSV file', 'mc_form' ) ),
				'edit'      => sprintf( '<a class="edit" href="admin.php?page=mc_form_all_forms&action=edit&form_id=%d">%s</a>', $item['id'], __( 'Edit', 'mc_form' ) ),
				'copy'      => sprintf( '<a class="copy" href="%s">%s</a>', wp_nonce_url( '?page=' . $_REQUEST['page'] . '&action=copy&id=' . $item['id'], 'mc_form_form_copy_' . $item['id'] ), __( 'Copy', 'mc_form' ) ),
				'delete'    => sprintf( '<a class="delete" href="%s">%s</a>', wp_nonce_url( '?page=' . $_REQUEST['page'] . '&action=delete&id=' . $item['id'], 'mc_form_form_delete_' . $item['id'] ), __( 'Delete', 'mc_form' ) ),
			);
			return sprintf( '%1$s %2$s', '<strong><a title="' . __( 'View all submissions under this form', 'mc_form' ) . '" href="admin.php?page=mc_form_view_all_submissions&form_id=' . $item['id'] . '">' . $item['name'] . '</a></strong>' , $this->row_actions( apply_filters( 'mc_form_all_forms_row_action', $actions ) ) );
			break;
		case 'shortcode' :
			return '[mc_form_form id="' . $item['id'] . '"]';
			break;
		case 'submission' :
			return $item['sub'];
			break;
		case 'category' :
			if ( $item['category'] == 0 ) {
				return __( 'Unassigned', 'mc_form' );
			} else {
				return $item['catname'];
			}
			break;
		case 'updated' :
			if ( 0 == $item['sub'] )
				return __( 'N/A', 'mc_form' );
			else
				return date_i18n( get_option( 'date_format' ) . __(' \a\t ', 'mc_form') . get_option( 'time_format' ), strtotime( $item[$column_name] ) );
			break;
		default :
			print_r( $item );
		}
	}

	public function column_cb( $item ) {
		return sprintf( '<input type="checkbox" name="forms[]" id="mcform-forms_%1$s" value="%1$s" />', $item['id'] );
	}

	public function get_bulk_actions() {
		$actions = array(
			'delete' => __( 'Delete' ),
		);
		return $actions;
	}

	/**
	 *
	 *
	 * @global wpdb $wpdb
	 * @global array $mc_form_info
	 */
	public function prepare_items() {
		global $wpdb, $mc_form_info;

		//prepare our query
		$query = "SELECT f.id id, f.name name, f.updated updated, f.category category, COUNT(d.id) sub, c.name catname FROM {$mc_form_info['form_table']} f LEFT JOIN {$mc_form_info['data_table']} d ON f.id = d.form_id LEFT JOIN {$mc_form_info['category_table']} c ON f.category = c.id";
		$sanitized_order = $this->get_sanitized_orderby( 'f.id', 'desc' );
		$orderby = $sanitized_order['orderby'];
		$order = $sanitized_order['order'];
		$wheres = array();
		$where = '';

		if ( ! empty( $_GET['s'] ) ) {
			$search = '%' . $_GET['s'] . '%';
			$wheres[] = $wpdb->prepare( "f.name LIKE %s", $search );
		}

		if ( isset( $_GET['cat_id'] ) && $_GET['cat_id'] !== '' ) {
			$wheres[] = $wpdb->prepare( "f.category = %d", $_GET['cat_id'] );
		}

		if ( ! empty( $wheres ) ) {
			$where .= ' WHERE ' . implode( ' AND ', $wheres );
		}

		$query .= $where;

		//pagination
		$totalitems = $wpdb->get_var( "SELECT COUNT(id) FROM {$mc_form_info['form_table']} f{$where}" );
		$perpage = $this->get_items_per_page( 'feedback_forms_per_page', 20 );
		$totalpages = ceil( $totalitems/$perpage );

		$this->set_pagination_args( array(
				'total_items' => $totalitems,
				'total_pages' => $totalpages,
				'per_page' => $perpage,
			) );
		$current_page = $this->get_pagenum();

		//put pagination and order on the query
		$query .= ' GROUP BY f.id ORDER BY ' . $orderby . ' ' . $order . ' LIMIT ' . ( ( $current_page - 1 ) * $perpage ) . ',' . (int) $perpage;

		//register the columns
		$this->_column_headers = $this->get_column_info();

		//fetch the items
		$this->items = $wpdb->get_results( $query, ARRAY_A );
	}

	public function extra_tablenav( $which ) {
		$form_categories = array(
			array(
				'value' => '0',
				'label' => __( 'Unassigned Forms', 'mc_form' ),
			),
		);
		$db_categories = MC_FORM_Form_Elements_Static::get_all_categories();
		if ( null != $db_categories ) {
			foreach ( $db_categories as $dbc ) {
				$form_categories[] = array(
					'value' => $dbc->id,
					'label' => $dbc->name,
				);
			}
		}
		switch ( $which ) {
			case 'top' :
			?>
<div class="alignleft actions">
	<select name="cat_id" id="cat_id">
		<option value=""<?php if ( !isset( $_GET['cat_id'] ) || '' == $_GET['cat_id'] ) echo ' selected="selected"'; ?>><?php _e( 'Show forms from all categories', 'mc_form' ); ?></option>
		<?php foreach ( $form_categories as $form_cat ) : ?>
		<option value="<?php echo $form_cat['value']; ?>"<?php if ( isset( $_GET['cat_id'] ) && (string) $form_cat['value'] == $_GET['cat_id'] ) echo ' selected="selected"' ?>><?php echo $form_cat['label']; ?></option>
		<?php endforeach; ?>
	</select>
	<?php submit_button( __( 'Filter' ), 'secondary', false, false, array( 'id' => 'form-cat-query-submit' ) ); ?>
</div>
			<?php
				break;

			case 'bottom' :
				if ( isset( $_GET['s'] ) && !empty( $_GET['s'] ) ) {
					?>
<div class="actions alignleft">
	<?php printf( __( 'Showing search results for "%s"', 'mc_form' ), $_GET['s'] ); ?>
</div>
					<?php
				}
				break;
		}
	}
}
