<?php
/**
 * MCForm Gutenberg Block bootstrapping
 *
 * @package MCForm
 * @subpackage Gutenberg
 */
namespace MCFormV4\Core;

class Bootstrap {
	public static function get_blocks() {
		return [
			// Forms
			"\\MCFormV4\\Blocks\\Form\\Embed",
			"\\MCFormV4\\Blocks\\Form\\Popup",
			// Reports
			"\\MCFormV4\\Blocks\\Report\\Trends",

		];
	}

	public static function enqueue_block_assets() {
		// prepare all forms
		$all_forms = \MC_FORM_Form_Elements_Static::get_forms_for_select_with_count();

		\wp_enqueue_script(
			'mcform-gutenberg-blocks',
			plugins_url( 'gutenberg/dist/mcform-gutenberg.js', \MC_FORM_Loader::$abs_file ),
			[ 'wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wp-editor' ],
			\MC_FORM_Loader::$version
		);
		// Also gutenberg localization
		if ( \function_exists( 'gutenberg_get_jed_locale_data' ) ) {
			$locale = \gutenberg_get_jed_locale_data( 'mc_form' );
			$content = 'wp.i18n.setLocaleData( ' . \json_encode( $locale ) . ', "mc_form" );';
			\wp_script_add_data( 'mcform-gutenberg-blocks', 'data', $content );
		}
		// Pass in some data
		\wp_localize_script( 'mcform-gutenberg-blocks', 'mcFormGTB', [
			'forms' => $all_forms,
			'i18n' => [
				'embedMCForm' => __( 'Embed mcForm', 'mc_form' ),
				'selectForm' => __( 'Select Form', 'mc_form' ),
				'selectFormOption' => __( '--please select a form--', 'mc_form' ),
			],
		] );

		// Enqueue style
		\wp_enqueue_style(
			'mcform-gutenberg-blocks',
			plugins_url( 'gutenberg/dist/mcform-gutenberg-style.css', \MC_FORM_Loader::$abs_file ),
			[],
			\MC_FORM_Loader::$version
		);
	}

	public static function register() {
		$mcform_blocks = self::get_blocks();
		foreach ( $mcform_blocks as $block ) {
			( new $block() )->register();
		}
	}

	public static function extend_gutenberg_categories( $categories, $post ) {
		$categories = array_merge(
			$categories,
			[
				[
					'slug' => 'mcform-v4',
					'title' => __( 'mcForm', 'mc_form' ),
				],
			]
		);
		return $categories;
	}

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_action( 'enqueue_block_editor_assets', [ __CLASS__, 'enqueue_block_assets' ] );
		add_filter( 'block_categories', [ __CLASS__, 'extend_gutenberg_categories' ], 10, 2 );
	}
}
