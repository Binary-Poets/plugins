<?php
/**
 * Portal with Gutenberg
 */

namespace MCFormV4\Blocks\System;

class Portal {

}
