<?php
/**
 * mcForm Material UI class
 *
 * It extends and overrides the front UI to print in material style
 *
 * It also overrides some enqueues, especially with JS validation and UI
 * initiator
 *
 * @package mcForm - Premium Form System
 * @subpackage UI\Material
 * @author Masum Hasan <hello@binarypoets.net>
 */
class MCForm_Material_UI extends MC_Plugin_UIF_Front {
	/**
	 * The instance variable
	 *
	 * This is a singleton class and we are going to use this
	 * for getting the only instance
	 */
	protected static $instance = false;

	protected function __construct() {
		parent::__construct();
	}

	public function enqueue( $ignore_css = array(), $ignore_js = array(), $additional_css = array(), $additional_js = array(), $additional_localize = array() ) {
		// Enqueue from the MC_Plugin_UIF_Front
		parent::enqueue( $ignore_css, $ignore_js );
		// Now we need some specific CSS and JS for our material themes
		// Some shortcut URLs
		$static_location = $this->static_location;
		$bower_components = $this->bower_components;
		$bower_builds = $this->bower_builds;
		$version = MC_FORM_Loader::$version;

		// Styles
		$styles = array(
			'mc-mcform-material-jquery-ui-structure' => array( $static_location . 'front/css/jquery-ui/jquery-ui.structure.css', array() ),
		);
		// If RTL
		if ( is_rtl() ) {
			$styles['mcform-material-rtl'] = array( $static_location . 'front/css/material-themes/rtl/mcform-rtl.css', array() );
		}
		// Add the additionals
		$styles = $styles + $additional_css;

		// Scripts
		$scripts = array(
			'mcform-material-waves' => array( $bower_components . 'Waves/dist/waves.min.js', array() ),
			'mcform-material-js' => array( $static_location . 'front/js/jquery.mcform-material.min.js', array( 'jquery', 'mcform-material-waves', 'mc-plugin-uif-front-js' ) ),
		);
		// And the additionals
		$scripts = $scripts + $additional_js;
		// Scrmc Localize
		$scripts_localize = array();
		// And the additionals
		$scripts_localize = $scripts_localize + $additional_localize;
		// Enqueue
		parent::enqueue( $ignore_css, $ignore_js, $styles, $scripts, $scripts_localize );

		do_action( 'mc_mcform_material_enqueue', $this );
	}

	/*==========================================================================
	 * UI Elements
	 *========================================================================*/
	/**
	 * Create jQuery UI Tabs
	 *
	 * @param      array    $tabs      Associative array of tabs
	 * @param      array    $data      HTML data attributes
	 * @param      boolean  $vertical  Whether to print vertical tab ( not used
	 *                                 )
	 * @param      array    $classes   Additional classes
	 */
	public function tabs( $tabs, $data = array(), $vertical = false, $classes = array() ) {
		if ( !is_array( $classes ) ) {
			$classes = (array) $classes;
		}
		$classes[] = 'mc_uif_tabs';
		$data_attr = $this->convert_data_attributes( $data );
		$classes[] = ( $vertical == true ) ? 'vertical' : 'horizontal';
?>
<div<?php echo $data_attr; ?> class="<?php echo implode( ' ', $classes ); ?>">
	<div class="mc-mcform-tab-nav-wrap">
		<ul>
			<?php foreach ( $tabs as $tab ) : ?>
			<?php $tab = wp_parse_args( $tab, array(
				'id' => '',
				'label' => '',
				'sublabel' => '',
				'callback' => '',
				'icon' => 'none',
				'classes' => array(),
			) ); ?>
			<li id="<?php echo $tab['id'] . '_control_li'; ?>"><a class="mcform-ripple" href="#<?php echo $tab['id']; ?>"><?php $this->print_icon( $tab['icon'], false ); ?><span class="mcform-tab-labels"><?php echo $tab['label']; ?> <?php if ( ! empty( $tab['sublabel'] ) ) echo '<span class="mc_uif_tab_subtitle">' . $tab['sublabel'] . '</span>'; ?></span></a></li>
			<?php endforeach; ?>
		</ul>
		<i class="mcform-tab-nav mcform-tab-nav-right mc-icomoon-angle-right disabled mcform-ripple"></i>
		<i class="mcform-tab-nav mcform-tab-nav-left mc-icomoon-angle-left disabled mcform-ripple"></i>
		<span class="mcform-tab-passive-notifier"></span>
		<span class="mcform-tab-active-notifier"></span>
	</div>

	<?php foreach ( $tabs as $tab ) : ?>
	<?php
		$tab = wp_parse_args( $tab, array(
			'id' => '',
			'label' => '',
			'callback' => '',
			'icon' => 'none',
			'classes' => array(),
		) );

		if ( !$this->check_callback( $tab['callback'] ) ) {
			$tab['callback'] = array(
				array( $this, 'msg_error' ), 'Invalid Callback',
			);
		}
		$tab['callback'][1][] = $tab;
		$tab_classes = isset( $tab['classes'] ) && is_array( $tab['classes'] ) ? $tab['classes'] : array();
?>
	<div id="<?php echo $tab['id']; ?>" class="<?php echo implode( ' ', $tab_classes ); ?>">
		<?php call_user_func_array( $tab['callback'][0], $tab['callback'][1] ); ?>
		<?php $this->clear(); ?>
	</div>
	<?php endforeach; ?>
</div>
<div class="clear"></div>
		<?php
	}
}
