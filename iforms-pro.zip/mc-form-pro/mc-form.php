<?php
/*
Plugin Name: mcForm- Premium Form System
Plugin URI: https://www.binarypoets.net
Description: A robust plugin to gather feedback, run surveys or host Quizzes on your WordPress Blog. Stores the gathered data on database for advanced analysis.
Author: BinaryPoets
Version: 1.0.1
Author URI: https://www.binarypoets.net/
License: GPLv3
Text Domain: mc_form
*/

/**
 * Copyright Masum Hasan - BinaryPoets <hello@binarypoets.net>, 2013-2020
 * This WordPress Plugin is comprised of two parts:
 *
 * (1) The PHP code and integrated HTML are licensed under the GPL license as is
 * WordPress itself. You will find a copy of the license text in the same
 * directory as this text file. Or you can read it here:
 * http://wordpress.org/about/gpl/
 *
 * (2) All other parts of the plugin including, but not limited to the CSS code,
 * images, and design are licensed according to the license purchased.
 * Read about licensing details here:
 * http://themeforest.net/licenses/regular_extended
 */

// Our plugin path
define( 'MC_MCFORM_ABSPATH', trailingslashit( dirname( __FILE__ ) ) );

// Little Error Log
if ( ! function_exists( 'mc_error_log' ) ) {
	/**
	 * Logs error in the WordPress debug mode
	 *
	 * @param      mixed  $var    The variable
	 */
	function mc_error_log() {
		// Do nothing if not in debugging environment
		if ( ! defined( 'WP_DEBUG' ) || true != WP_DEBUG || 'cli' == php_sapi_name() ) {
			return;
		}
		$arg_list = func_get_args();
		if ( ! empty( $arg_list ) ) {
			foreach ( $arg_list as $var ) {
				// Log the variable
				error_log( print_r( $var, true ) );
			}
		}
	}
}

/**
 * Register the loaders
 */
require_once MC_MCFORM_ABSPATH . 'autoload.php';

/**
 * Holds the plugin information
 *
 * @global     array  $mc_form_info
 */
global $mc_form_info;

/**
 * Holds the global settings
 *
 * @global     array  $mc_form_settings
 */
global $mc_form_settings, $mc_form;

$mc_form = new MC_FORM_Loader( __FILE__, 'mc_form', '1.0.1', 'mc_form' );

$mc_form->load();

// Get our auto updater
MCForm_AutoUpdate::instance();
