<?php
/**
 * Popup Form with Gutenberg
 */

namespace MCFormV4\Blocks\Form;
use MCFormV4\Blocks\Base;

class Popup extends Base {
	public function get_block_name() {
		return 'popup-form';
	}

	public function get_block_config() {
		return [
			'render_callback' => [ $this, 'render' ],
			'attributes' => [
				'form_id' => [
					'type' => 'string',
					'default' => '',
				],
				'pos' => [
					'type' => 'string',
					'default' => 'r',
				],
				'style' => [
					'type' => 'string',
					'default' => 'rect',
				],
				'header' => [
					'type' => 'string',
					'default' => '%FORM%',
				],
				'subtitle' => [
					'type' => 'string',
					'default' => '',
				],
				'icon' => [
					'type' => 'string',
					'default' => 'fa fa-file-text',
				],
				'width' => [
					'type' => 'string',
					'default' => '600',
				],
				'color' => [
					'type' => 'string',
					'default' => '#ffffff',
				],
				'bgcolor' => [
					'type' => 'string',
					'default' => '#3c609e',
				],
				'label' => [
					'type' => 'string',
					'default' => __('Sample Form', 'mc_form'),
				],
			]
		];
	}

	public function render( $attributes ) {
		$atts = $attributes;
		$content = $attributes['label'];
		return \MC_MCForm_Core_Shortcodes::mc_form_popup_cb($atts, $content);
	}
}
