<?php
/**
 * Font Awesome
 *
 */

require_once dirname( __FILE__ ) . '/font.php';

/**
 * Icon type: Font Awesome
 *
 */
class OE_Icon_Picker_Type_Font_Awesome extends OE_Icon_Picker_Type_Font {

	/**
	 * Icon type ID
	 *
	 */
	protected $id = 'far';

	/**
	 * Icon type name
	 *
	 */
	protected $name = 'FontAwesome Regular';

	/**
	 * Icon type version
	 *
	 */
	protected $version = '5.11.2';

	/**
	 * Stylesheet ID
	 *
	 */
	protected $stylesheet_id = 'font-awesome';

	/**
	 * Get icon groups
	 *
	 */
	public function get_groups() {
		$groups = array(
			array(
				'id'   => 'regular',
				'name' => __( 'Regular', 'binary-extra' ),
			),
		);

		/**
		 * Filter genericon groups
		 *
		 */
		$groups = apply_filters( 'oe_icon_picker_fa_groups', $groups );

		return $groups;
	}

	/**
	 * Get icon names
	 *
	 */
	public function get_items() {
		$items = array(
			array(
				'group' => 'regular',
				'id'    => 'fa-address-book',
				'name'  => __( 'Address Book', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-address-card',
				'name'  => __( 'Address Card', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-angry',
				'name'  => __( 'Angry', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-arrow-alt-circle-down',
				'name'  => __( 'Arrow Circle Down', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-arrow-alt-circle-left',
				'name'  => __( 'Arrow Circle Left', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-arrow-alt-circle-right',
				'name'  => __( 'Arrow Circle Right', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-arrow-alt-circle-up',
				'name'  => __( 'Arrow Circle Up', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-bell',
				'name'  => __( 'Bell', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-bell-slash',
				'name'  => __( 'Bell Slash', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-bookmark',
				'name'  => __( 'Bookmark', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-building',
				'name'  => __( 'Building', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-calendar',
				'name'  => __( 'Calendar', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-calendar-alt',
				'name'  => __( 'Calendar Alt', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-calendar-check',
				'name'  => __( 'Calendar Check', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-calendar-minus',
				'name'  => __( 'Calendar Minus', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-calendar-plus',
				'name'  => __( 'Calendar Plus', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-calendar-times',
				'name'  => __( 'Calendar Times', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-caret-square-down',
				'name'  => __( 'Caret Square Down', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-caret-square-left',
				'name'  => __( 'Caret Square Left', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-caret-square-right',
				'name'  => __( 'Caret Square Right', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-caret-square-up',
				'name'  => __( 'Caret Square Up', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-chart-bar',
				'name'  => __( 'Chart Bar', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-check-circle',
				'name'  => __( 'Check Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-check-square',
				'name'  => __( 'Check Square', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-circle',
				'name'  => __( 'Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-clipboard',
				'name'  => __( 'Clipboard', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-clock',
				'name'  => __( 'Clock', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-clone',
				'name'  => __( 'Clone', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-closed-captioning',
				'name'  => __( 'Closed Captioning', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-comment',
				'name'  => __( 'Comment', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-comment-alt',
				'name'  => __( 'Comment Alt', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-comment-dots',
				'name'  => __( 'Comment Dots', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-comments',
				'name'  => __( 'Comments', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-compass',
				'name'  => __( 'Compass', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-copy',
				'name'  => __( 'Copy', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-copyright',
				'name'  => __( 'Copyright', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-credit-card',
				'name'  => __( 'Credit Card', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-dizzy',
				'name'  => __( 'Dizzy', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-dot-circle',
				'name'  => __( 'Dot Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-edit',
				'name'  => __( 'Edit', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-envelope',
				'name'  => __( 'Envelope', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-envelope-open',
				'name'  => __( 'Envelope Open', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-eye',
				'name'  => __( 'Eye', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-eye-slash',
				'name'  => __( 'Eye Slash', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file',
				'name'  => __( 'File', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-alt',
				'name'  => __( 'File Alt', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-archive',
				'name'  => __( 'File Archive', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-audio',
				'name'  => __( 'File Audio', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-code',
				'name'  => __( 'File Code', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-excel',
				'name'  => __( 'File Excel', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-image',
				'name'  => __( 'File Image', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-pdf',
				'name'  => __( 'File PDF', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-powerpoint',
				'name'  => __( 'File Powerpoint', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-video',
				'name'  => __( 'File Video', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-file-word',
				'name'  => __( 'File Word', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-flag',
				'name'  => __( 'Flag', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-flushed',
				'name'  => __( 'Flushed', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-folder',
				'name'  => __( 'Folder', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-folder-open',
				'name'  => __( 'Folder Open', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-frown',
				'name'  => __( 'Frown', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-frown-open',
				'name'  => __( 'Frown Open', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-futbol',
				'name'  => __( 'Futbol', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-gem',
				'name'  => __( 'Gem', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grimace',
				'name'  => __( 'Grimace', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin',
				'name'  => __( 'Grin', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-alt',
				'name'  => __( 'Grin Alt', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-beam',
				'name'  => __( 'Grin Beam', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-beam-sweat',
				'name'  => __( 'Grin Beam Sweat', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-hearts',
				'name'  => __( 'Grin Hearts', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-squint',
				'name'  => __( 'Grin Squint', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-squint-tears',
				'name'  => __( 'Grin Squint Tears', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-stars',
				'name'  => __( 'Grin Stars', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-tears',
				'name'  => __( 'Grin Tears', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-tongue',
				'name'  => __( 'Grin Tongue', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-tongue-squint',
				'name'  => __( 'Grin Tongue Squint', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-tongue-wink',
				'name'  => __( 'Grin Tongue Wink', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-grin-wink',
				'name'  => __( 'Grin Wink', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-lizard',
				'name'  => __( 'Hand Lizard', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-paper',
				'name'  => __( 'Hand Paper', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-peace',
				'name'  => __( 'Hand Peace', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-point-down',
				'name'  => __( 'Hand Point Down', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-point-left',
				'name'  => __( 'Hand Point Left', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-point-right',
				'name'  => __( 'Hand Point Right', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-point-up',
				'name'  => __( 'Hand Point Up', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-pointer',
				'name'  => __( 'Hand Pointer', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-rock',
				'name'  => __( 'Hand Rock', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-scissors',
				'name'  => __( 'Hand Scissors', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hand-spock',
				'name'  => __( 'Hand Spock', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-handshake',
				'name'  => __( 'Handshake', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hdd',
				'name'  => __( 'HDD', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-heart',
				'name'  => __( 'Heart', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hospital',
				'name'  => __( 'Hospital', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-hourglass',
				'name'  => __( 'Hourglass', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-id-badge',
				'name'  => __( 'Id Badge', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-id-card',
				'name'  => __( 'Id Card', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-image',
				'name'  => __( 'Image', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-images',
				'name'  => __( 'Images', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-keyboard',
				'name'  => __( 'Keyboard', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-kiss',
				'name'  => __( 'Kiss', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-kiss-beam',
				'name'  => __( 'Kiss Beam', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-kiss-wink-heart',
				'name'  => __( 'Kiss Wink Heart', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-laugh',
				'name'  => __( 'Laugh', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-laugh-beam',
				'name'  => __( 'Laugh Beam', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-laugh-squint',
				'name'  => __( 'Laugh Squint', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-laugh-wink',
				'name'  => __( 'Laugh Wink', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-lemon',
				'name'  => __( 'Lemon', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-life-ring',
				'name'  => __( 'Life Ring', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-lightbulb',
				'name'  => __( 'Lightbulb', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-list-alt',
				'name'  => __( 'List Alt', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-map',
				'name'  => __( 'Map', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-meh',
				'name'  => __( 'Meh', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-meh-blank',
				'name'  => __( 'Me Blank', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-meh-rolling-eyes',
				'name'  => __( 'Meh Rolling Eyes', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-minus-square',
				'name'  => __( 'Minus Square', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-money-bill-alt',
				'name'  => __( 'Money Bill Alt', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-moon',
				'name'  => __( 'Moon', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-newspaper',
				'name'  => __( 'Newspaper', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-object-group',
				'name'  => __( 'Object Group', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-object-ungroup',
				'name'  => __( 'Object Ungroup', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-paper-plane',
				'name'  => __( 'Paper Plane', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-pause-circle',
				'name'  => __( 'Pause Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-play-circle',
				'name'  => __( 'Play Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-plus-square',
				'name'  => __( 'Plus Square', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-question-circle',
				'name'  => __( 'Question Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-registered',
				'name'  => __( 'Registered', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-save',
				'name'  => __( 'Save', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-share-square',
				'name'  => __( 'Share Square', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-smile',
				'name'  => __( 'Smile', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-smile-beam',
				'name'  => __( 'Smile Beam', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-smile-wink',
				'name'  => __( 'Smile Wink', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-snowflake',
				'name'  => __( 'Snowflake', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-square',
				'name'  => __( 'Square', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-snowflake',
				'name'  => __( 'Snowflake', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-star',
				'name'  => __( 'Star', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-star-half',
				'name'  => __( 'Star Half', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-sticky-note',
				'name'  => __( 'Sticky Note', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-stop-circle',
				'name'  => __( 'Stop Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-sun',
				'name'  => __( 'Sun', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-surprise',
				'name'  => __( 'Surprise', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-thumbs-down',
				'name'  => __( 'Thumbs Down', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-thumbs-up',
				'name'  => __( 'Thumbs Up', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-times-circle',
				'name'  => __( 'Times Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-tired',
				'name'  => __( 'Tired', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-trash-alt',
				'name'  => __( 'Trash Alt', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-user',
				'name'  => __( 'User', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-user-circle',
				'name'  => __( 'User Circle', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-window-close',
				'name'  => __( 'Window Close', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-window-maximize',
				'name'  => __( 'Window Maximize', 'binary-extra' ),
			),
			array(
				'group' => 'regular',
				'id'    => 'fa-window-restore',
				'name'  => __( 'Window Restore', 'binary-extra' ),
			),
		);

		/**
		 * Filter FontAwesome items
		 *
		 */
		$items = apply_filters( 'oe_icon_picker_fa_items', $items );

		return $items;
	}
}
