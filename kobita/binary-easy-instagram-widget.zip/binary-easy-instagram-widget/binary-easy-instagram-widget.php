<?php
/*
Plugin Name: Binary Easy Photo Feed Widget
Description: Easily display Instagram photos as a widget that looks good in (almost) any WordPress theme.
Version: 1.1.2
Author: BinaryPoets
Author URI: https://binarypoets.net
Text Domain: binary-easy-instagram-widget
Domain Path: /languages
*/
 
/* Prevent Direct access */
if ( !defined( 'DB_NAME' ) ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

define( 'BINARY_INSTAGRAM_WIDGET_URL', trailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'BINARY_INSTAGRAM_WIDGET_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );
define( 'BINARY_INSTAGRAM_WIDGET_VER', '1.1.2' );
define( 'BINARY_INSTAGRAM_BASENAME', plugin_basename( __FILE__ ) );

/* Initialize Options */
if ( !function_exists( 'binary_instagram_options_init' ) ):
    function binary_instagram_options_init() {
        require_once BINARY_INSTAGRAM_WIDGET_DIR.'inc/class-instagram-options.php';
        Binary_Instagram_Options::get_instance();
    }
endif;

add_action( 'init', 'binary_instagram_options_init' );


/* Initialize Widget */
if ( !function_exists( 'binary_instagram_widget_init' ) ):
    function binary_instagram_widget_init() {
        require_once BINARY_INSTAGRAM_WIDGET_DIR.'inc/class-instagram-widget.php';
        register_widget( 'Binary_Instagram_Widget' );
    }
endif;

add_action( 'widgets_init', 'binary_instagram_widget_init' );

/* Load text domain */
function binary_load_instagram_widget_text_domain() {
    load_plugin_textdomain( 'binary-easy-instagram-widget', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

add_action( 'plugins_loaded', 'binary_load_instagram_widget_text_domain' );



/* Inform existing users that the plugin changed its name and was formerly known as Instagram Widget */

function binary_instagram_widget_name_suffix( $plugins ){

	if( isset($plugins['binary-easy-instagram-widget/binary-easy-instagram-widget.php'])){
		$plugins['binary-easy-instagram-widget/binary-easy-instagram-widget.php']['Name'] .= ' (formerly Binary Easy Instagram Widget)';
	}

	return $plugins;
}

add_filter( 'all_plugins', 'binary_instagram_widget_name_suffix' );