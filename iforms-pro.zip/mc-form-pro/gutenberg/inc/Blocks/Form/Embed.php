<?php
/**
 * Embed Form with Gutenberg
 */

namespace MCFormV4\Blocks\Form;
use MCFormV4\Blocks\Base;

class Embed extends Base {
	public function get_block_name() {
		return 'embed-form';
	}

	public function get_block_config() {
		return [
			'attributes' => [
				'formId' => [
					'type' => 'string',
					'default' => '',
				],
			],
			'render_callback' => [ $this, 'render' ],
		];
	}

	public function render( $attributes, $content ) {
		return \MC_MCForm_Core_Shortcodes::mc_form_form_cb([
			'id' => $attributes['formId'],
		]);
	}
}
