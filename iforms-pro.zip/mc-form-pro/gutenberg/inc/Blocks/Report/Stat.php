<?php
/**
 * Stat with Gutenberg
 */

namespace MCFormV4\Blocks\Report;

class Stat {

}
