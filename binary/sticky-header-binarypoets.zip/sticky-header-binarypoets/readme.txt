=== BinaryPoets sticky header ===
Contributors: scriptcoil
Tags: Binarywp, Binary theme header, binary sticky header
Requires at least: 3.5
Tested up to: 4.9.5
License: GPLv2 or later

== Plugin Description ==

How to use  the plugin:

1. Install by upload the package file or upload the folder into wp-content/plugins directory.
2. Activate the `BinaryPoets Sticky header` Plugin.
 - That`s it. Done.
 Dont forget to share with friends and rate ♥