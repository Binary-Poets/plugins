<?php
/**
 * A helper class to properly populate PopUp forms both for widgets and shortcode
 *
 * @package mcForm - Premium Form System
 * @subpackage Helpers
 * @author Masum Hasan <hello@binarypoets.net>
 */
class MCForm_Popup_Helper {
	/**
	 * Form ID for which popup is to be generated
	 *
	 * @var        integer
	 */
	protected $form_id = 0;

	/**
	 * Configuration array
	 *
	 * @var        array
	 */
	protected $config = array();

	/**
	 * Constructor
	 *
	 * @param      int    $form_id  The form identifier
	 * @param      array  $config   The configuration array
	 */
	public function __construct( $form_id, $config ) {
		$this->form_id = $form_id;
		$config = wp_parse_args( $config, array(
			'label' => '',
			'color' => '',
			'bgcolor' => '',
			'position' => '',
			'style' => '',
			'header' => '',
			'subtitle' => '',
			'icon' => '',
			'width' => '',
		) );
		$this->config = $config;
	}

	/**
	 * Initialize the popup JS which would be used by our JS to populate the
	 * popups
	 *
	 * Call this to actually print the popup forms and buttons
	 *
	 * @return     boolean  false if an invalid form was passed, true on success
	 */
	public function init_js() {
		// Globals
		global $mc_form_popup_forms, $mc_mcform_popup_config;
		self::init_globals();
		// Get the Form and URL
		$form = MC_FORM_Form_Elements_Static::get_form( $this->form_id );
		if ( ! $form ) {
			return false;
		}
		$form_urls = MC_FORM_Form_Elements_Static::standalone_permalink_parts( $this->form_id );
		// Configure the JSON
		$config = $this->config;
		$config['formID'] = $this->form_id;
		$config['header'] = str_replace( '%FORM%', $form->name, $config['header'] );
		$config['url'] = $form_urls['url'];
		$mc_form_popup_forms[] = $this->form_id;
		$mc_mcform_popup_config[] = $config;
		// Print stuff
		?>
<script type="text/javascript">
	if ( window.mcFORMModalPopupForms == undefined ) {
		window.mcFORMModalPopupForms = [];
	}
	window.mcFORMModalPopupForms[window.mcFORMModalPopupForms.length] = <?php echo json_encode( $config ); ?>;
</script>
		<?php
		return true;
	}

	/**
	 * Print popup form modal divs
	 *
	 * Call this at wp_footer to print the divs needed for iziModal to showup
	 *
	 * @return     boolean  true if popup was configured false if no popups
	 */
	public static function print_popup_modals() {
		global $mc_form_popup_forms, $mc_mcform_popup_config;
		self::init_globals();
		if ( count( $mc_form_popup_forms ) == 0 ) {
			return false;
		}
		// Add the scripts + style
		wp_enqueue_script( 'iziModal', MC_FORM_Loader::$bower_components . 'izimodal/js/iziModal.min.js', array( 'jquery' ), MC_FORM_Loader::$version, true );
		wp_enqueue_style( 'iziModal.css', MC_FORM_Loader::$bower_components . 'izimodal/css/iziModal.min.css', array(), MC_FORM_Loader::$version );
		wp_enqueue_script( 'ba-throttle-debounce', MC_FORM_Loader::$bower_components . 'jquery-throttle-debounce/jquery.ba-throttle-debounce.min.js', array( 'jquery' ), MC_FORM_Loader::$version, true );
		wp_enqueue_script( 'mc-form-modal-popup', MC_FORM_Loader::$static_location . 'front/js/mc-form-modal-popup.min.js', array( 'jquery', 'iziModal', 'ba-throttle-debounce' ), MC_FORM_Loader::$version );
		wp_enqueue_style( 'mc-form-modal-popup-css', MC_FORM_Loader::$static_location . 'front/css/modal-popup/mc-form-modal-popup.css', array(), MC_FORM_Loader::$version );

		// Make things unique
		$mc_form_popup_forms = array_unique( $mc_form_popup_forms );

		// Now print them all
		?>
		<?php foreach ( $mc_form_popup_forms as $key => $form_id ) : ?>
			<div id="mc-form-popup-form-<?php echo $form_id ?>" data-mcform-popup="<?php echo esc_attr( json_encode( $mc_mcform_popup_config[ $key ] ) ) ?>" class="mcform-popup-modal"></div>
		<?php endforeach; ?>
		<?php
		return true;
	}

	/**
	 * Initialize the globals needed by and for popups
	 */
	protected static function init_globals() {
		global $mc_form_popup_forms, $mc_mcform_popup_config;
		if ( ! is_array( $mc_form_popup_forms ) ) {
			$mc_form_popup_forms = array();
		}
		if ( ! isset( $mc_mcform_popup_config ) ) {
			$mc_mcform_popup_config = array();
		}
	}
}
