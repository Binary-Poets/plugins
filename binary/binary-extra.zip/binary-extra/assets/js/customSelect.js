var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
	// Custom select
	binarypoetsCustomSelects();
} );

/* ==============================================
CUSTOM SELECT
============================================== */
function binarypoetsCustomSelects() {
	"use strict"

	$j( binarypoetsLocalize.customSelects ).customSelect( {
		customClass: 'theme-select'
	} );

}