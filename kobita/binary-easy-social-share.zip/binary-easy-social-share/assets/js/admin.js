(function($) {
    
    "use strict";

    $(document).ready(function() {

        // platforms field sortable
        $(".platforms-sortable").sortable({
            revert: false,
            cursor: "move",
            placeholder: "platforms-state-highlight"
        });

        // custom color picker
        $('#binary_ess-custom-color').wpColorPicker();

        // show/hide color picker 
        var color_picker = $('.settings_page_binary-easy-social-share .wp-picker-container');
        var custom_color = $('#binary_ess-color-custom');

        if (!custom_color.is(':checked')) {
            color_picker.hide();
        }

        $('.binary_ess-color input[type="radio"]').on('change', function() {
            if (custom_color.is(':checked')) {
                color_picker.show();
            } else {
                color_picker.hide();
            }
        });


        // disable variant base on style selection
        var style_checked = $('.binary-ess-style input:checked').val();
        if (style_checked == '5' || style_checked == '8') {
            $('.binary-ess-style-variant input').attr('disabled', true);
        }
        $('.binary-ess-style input').on('change', function() {
            var style = $(this).val();
            console.log(style);
            if (style == '5' || style == '8') {
                $('.binary-ess-style-variant input').attr('disabled', true);
            } else {
                $('.binary-ess-style-variant input').attr('disabled', false);
            }
        });


    });

})(jQuery);