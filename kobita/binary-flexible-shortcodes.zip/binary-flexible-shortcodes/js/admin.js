var bps_shortcode;
var bps_shortcode_content;
var bps_shortcode_modal_obj;
(function() {

    tinymce.create('tinymce.plugins.bps_shortcodes', {
        init: function(ed, url) {
            ed.addButton('bps_shortcodes_button', {
                title: 'Binary Shortcodes',
                image: url.substring(0, url.length - 3) + "/img/shortcodes-button.png",
                onclick: function() {

                    bps_shortcode = ed.selection;
                    bps_shortcode_content = ed.selection.getContent();

                    var shortcodes_loaded = jQuery("#bps_shortcodes_holder").length;

                    if (shortcodes_loaded) {
                        bps_shortcode_modal(bps_shortcode_modal_obj, 'Binary Shortcodes');

                    } else {

                        jQuery("body").append('<div id="bps_shortcodes_holder" style="display: none;"><div id="bps_shortcodes"></div></div>');

                        jQuery.get('admin-ajax.php?action=bps_generate_shortcodes_ui', function(data) {
                            bps_shortcode_modal_obj = jQuery('#bps_shortcodes').html(data);
                            bps_shortcode_modal( bps_shortcode_modal_obj, 'Binary Shortcodes');
                        });
                    }
                }
            });
        },
        createControl: function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('bps_shortcodes', tinymce.plugins.bps_shortcodes);

    /* Open modal */

    function bps_shortcode_modal(obj, title) {

        obj.dialog({
            'dialogClass': 'wp-dialog',
            'appendTo': false,
            'modal': true,
            'autoOpen': false,
            'closeOnEscape': true,
            'draggable': false,
            'resizable': false,
            'width': 800,
            'height': jQuery(window).height() - 60,
            'title': title,
            'close': function(event, ui) {
                jQuery('body').removeClass('modal-open');
            },
            'buttons': []
        });

        obj.dialog('open');

        jQuery('body').addClass('modal-open');
    }

})();