var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
    // Responsive Video
	binarypoetsInitFitVids();
} );

/* ==============================================
RESPONSIVE VIDEOS
============================================== */
function binarypoetsInitFitVids() {
	"use strict"

	$j( '.responsive-video-wrap, .responsive-audio-wrap' ).fitVids();

}