<?php
/**
 * WP Feedback, Surver & Quiz Manager - Pro Form Elements Class
 * Admin area
 *
 * Populates the form builder
 * Works along with MC_Plugin_UIF_Admin
 *
 *
 * @package mcForm - Premium Form System
 * @subpackage Form\Admin
 * @author Masum Hasan <swashata@intechgrity.com>
 * @codeCoverageIgnore
 */
class MC_FORM_Form_Elements_Admin extends MC_FORM_Form_Elements_Base {
	/**
	 * The UI variable to populate all the necessary HTML
	 *
	 * @var MC_Plugin_UIF_Admin
	 */
	public $ui;

	public $save_process = array();

	/*==========================================================================
	 * CONSTRUCTOR
	 *========================================================================*/
	public function __construct( $form_id = null ) {
		$this->ui = MC_Plugin_UIF_Admin::instance();
		parent::__construct( $form_id );
	}

	/*==========================================================================
	 * Help Section
	 *========================================================================*/
	public function add_help() {
		get_current_screen()->add_help_tab( array(
			'id' => 'overview',
			'title' => __( 'Overview', 'mc_form' ),
			'content' =>
			'<p>' . __( 'This page provides you all the tool you can use to create and customize a form. A form can have any number of containers. Simple click on the Add Containers button and it will add a new container where you can drag and drop new form elements.', 'mc_form' ) . '</p>' .
			'<p>' . __( 'A form can have a total of 48 elements as of now (without any extensions) which are catrgorized into 4 type.', 'mc_form' ) . '</p>' .
			'<ul>' .
			'<li>' . __( '<strong>Design & Security:</strong> Use the elements to add eye candy or security elements to your form. Check the Design Elements section for more.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Multiple Choice Questions:</strong> Add MCQs to your form which can be used to generate quiz and/or collect surveys. Elements have scoring option whenever applicable and all of them will appear on the Report & Analysis. Check Multiple Choice Question Elements for more information.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Feedback Questions:</strong> These are basically freetype questions, where users have to put their own answers. All of the answers can be set to go to one or more specific emails. This becomes handy if you are collecting feedbacks on different topics and have to email different people the answers of different topics.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Other Form Elements:</strong> Here we have 4 predefined text fields (First Name, Last Name, Email, Phone Number) which you can add to the form. Apart from that, another 14 types of form elements can be added. Check Other Form Elements for more information.', 'mc_form' ) . '</li>' .
			'</ul>' .
			'<p>' . __( 'You can get more help by clicking the [?] icon beside every options. Or you can check the corresponding tabs inside this help screen...', 'mc_form' ) . '</p>'
		) );

		get_current_screen()->add_help_tab( array(
			'id' => 'form-customization',
			'title' => __( 'Form Customization', 'mc_form' ),
			'content' =>
			'<p>' . __( 'Right above the form builder, you will see 4 tabs from where you can customize many aspects of the form.', 'mc_form' ) . '</p>' .
			'<ul>' .
			'<li>' . __( '<strong>Form Name:</strong> As the title suggests, enter the name of the form.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Form Type:</strong> Select the type of the form. Currently we support 3 kinds of appearances. Each appearance has it\'s own different sets of options. Please check the help icon associated with the option to get more information.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Form Settings:</strong> Various form related settings. Please read below:', 'mc_form' ) .
			'<ul>' .
			'<li>' . __( '<strong>General Settings:</strong> Have a Terms & Conditions Page, which shows a single checkbox with a link to your page just before submitting the form, an Administrator Remarks Title and Default Administrator Remarks.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Submission Limitation:</strong> Limit submission of this form per email address and/or per IP address.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Progress Buttons:</strong> Change the labels of the Next, Previous and Submit buttons. They will show up, whenever applicable.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Form Submission:</strong> Enter your own processing and success title along with a success message.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>User Notification:</strong> Customize how users (the one submitting the form) are notified.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Admin Notification:</strong> Customize how admins are notified.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Redirection:</strong> Set customized redirection to a page when user submits. They can be redirected to a particular page or specific pages depending on their score.', 'mc_form' ) . '</li>' .
			'</ul>' .
			'</li>' .
			'<li>' . __( '<strong>Form Theme:</strong> Various jQuery UI Themes are available for you to use directly. We have also added font customization options.', 'mc_form' ) . '</li>' .
			'</ul>' .
			'<p>' . __( 'You can get more help by clicking the [?] icon beside every options.', 'mc_form' ) . '</p>'
		) );

		foreach ( $this->elements as $element_type => $elements ) {
			if ( $element_type == 'layout' ) {
				continue;
			}
			$content = '<p>' . $elements['description'] . '</p>';
			if ( isset( $elements['elements'] ) && is_array( $elements['elements'] ) && !empty( $elements['elements'] ) ) {
				$content .= '<ul>';
				foreach ( $elements['elements'] as $element ) {
					$content .= '<li><strong>' . $element['title'] . ':</strong> ' . $element['description'] . '</li>';
				}
				$content .= '</ul>';
			}
			get_current_screen()->add_help_tab( array(
					'id' => 'form-elements-' . $element_type,
					'title' => $elements['title'],
					'content' => $content,
				) );
		}
	}

	/*==========================================================================
	 * PRIMARY APIs
	 *========================================================================*/
	public function enqueue_assets() {
		// Check if user has already checked the onboarding script
		$has_user_onboarded = get_user_meta( get_current_user_id(), 'mcform-builder-onboarded', true );
		// If not, then update the value so that she doesn't see
		// it again
		if ( ! $has_user_onboarded ) {
			update_user_meta( get_current_user_id(), 'mcform-builder-onboarded', '1' );
		}
		// but delete it, if a special url parameter is present
		if ( isset( $_GET['mcform-reset-onboarding'] ) ) {
			delete_user_meta( get_current_user_id(), 'mcform-builder-onboarded' );
			$has_user_onboarded = false;
		}
		wp_enqueue_script( 'mcform-izi-toast', MC_FORM_Loader::$bower_components . 'izitoast/dist/js/iziToast.min.js', [], MC_FORM_Loader::$version );
		wp_enqueue_script( 'mcform-tippyjs', MC_FORM_Loader::$bower_components . 'tippyjs/dist/tippy.all.min.js', [], MC_FORM_Loader::$version );
		wp_enqueue_style( 'mcform-izitoast-style', MC_FORM_Loader::$bower_components . 'izitoast/dist/css/iziToast.min.css', [], MC_FORM_Loader::$version );
		wp_enqueue_script( 'mcform-onboarding-driver', MC_FORM_Loader::$bower_components . 'driver.js/dist/driver.min.js', [], MC_FORM_Loader::$version );
		wp_enqueue_style( 'mcform-onboarding-css', MC_FORM_Loader::$bower_components . 'driver.js/dist/driver.min.css', [], MC_FORM_Loader::$version );
		wp_enqueue_script( 'mcform-form-builder', MC_FORM_Loader::$static_location . 'admin/js/jquery.mcform-form-builder.min.js', array( 'jquery', 'mcform-onboarding-driver', 'mcform-tippyjs', 'mcform-izi-toast', 'mc-plugin-uif-admin-js' ), MC_FORM_Loader::$version );
		wp_localize_script( 'mcform-form-builder', 'mcFormBuilderL10n', [
			'elementAdded' => __( 'Element added', 'mc_form' ),
			'elementMoved' => __( 'Element moved', 'mc_form' ),
			'elementDeleted' => __( 'Element deleted', 'mc_form' ),
			'elementCopied' => __( 'Element copied', 'mc_form' ),
			'pageAdded' => __( 'Page added', 'mc_form' ),
			'pageDeleted' => __( 'Page deleted', 'mc_form' ),
			'pageCopied' => __( 'Page copied', 'mc_form' ),
			'pageSorted' => __( 'Page moved', 'mc_form' ),
			'settingsClose' => __( 'Element config updated', 'mc_form' ),
			'formSaved' => __( 'Form saved', 'mc_form' ),
			'nameChanged' => __( 'Form name updated', 'mc_form' ),
			'customizerClose' => __( 'Form config updated', 'mc_form' ),
			'done' => __( 'Done', 'mc_form' ),
			'saveError' => __( 'Could not connect to server. Please try again!', 'mc_form' ),
			'addingElement' => __( 'Adding new form element', 'mc_form' ),
			'addingPage' => __( 'Adding new form page', 'mc_form' ),
			'onBoarding' => [
				'prev' => __( 'Previous', 'mc_form' ),
				'next' => __( 'Next', 'mc_form' ),
				'done' => __( 'Done', 'mc_form' ),
				'close' => __( 'Close', 'mc_form' ),
				'isOnBoarded' => (bool) $has_user_onboarded,
				'openVideo' => __( 'Video Guide', 'mc_form' ),
				'startTour' => __( 'Start Tour', 'mc_form' ),
				'steps' => [
					[
						'title' => __( 'mcForm Builder Tour', 'mc_form' ),
						'description' => __( 'This is your first time using mcForm so we can quickly go through the interface to get you upto speed. Click on Video Guide to see a 9 mins video instead. You will not see this dialog again. But you can start the tour or play the video from the sidebar.', 'mc_form' ),
					],
					[
						'title' => __( 'Editor Pane', 'mc_form' ),
						'description' => __( 'On left you see the building blocks of your form. You can sort elements by dragging and click on it to open configuration. You can sort pages by dragging horizontally.', 'mc_form' ),
					],
					[
						'title' => __( 'Preview Pane', 'mc_form' ),
						'description' => __( 'On right you see the form itself. You can hover on an element and click the gear icon to quickly open it\'s configuration.', 'mc_form' ),
					],
					[
						'title' => __( 'Toolbar', 'mc_form' ),
						'description' => __( 'You can toggle the views with these buttons, or change the live view screen size.', 'mc_form' ),
					],
					[
						'title' => __( 'Add pages', 'mc_form' ),
						'description' => __( 'Add new page to your form by clicking this button.', 'mc_form' ),
					],
					[
						'title' => __( 'Add elements', 'mc_form' ),
						'description' => __( 'Add elements by clicking on them or drag and drop to the page. You can search or click on the help icon to quickly filter through elements.', 'mc_form' ),
					],
					[
						'title' => __( 'Form Config', 'mc_form' ),
						'description' => __( 'Configure form settings like notifications, integrations, payment, quiz score, timer, stopwatch, redirection etc.', 'mc_form' ),
					],
					[
						'title' => __( 'Form Style', 'mc_form' ),
						'description' => __( 'Personalize your form theme, colors, button styles, fonts and more.', 'mc_form' ),
					],
					[
						'title' => __( 'Learn More', 'mc_form' ),
						'description' => __( 'For a quick start video click on this button. Also find links for documentation and support. You are now all set. Have fun. Remember to check the <strong>video</strong> for quick introduction.', 'mc_form' ),
					],
				],
			],
		] );
	}

	public function show_form() {
		//array( 'text', 'name', 'size', 'style', 'state', 'classes', 'type', 'data', 'atts', 'url', 'icon', 'icon_position' )
		$mcform_standalone_permalink = MC_FORM_Form_Elements_Static::standalone_permalink_parts( $this->form_id );
		$mcform_standalone_url = '';
		if ( is_array( $mcform_standalone_permalink ) ) {
			$mcform_standalone_url = $mcform_standalone_permalink['url'];
		}
		$toolbar_buttons = array(
			1 => array( __( 'Save', 'mc_form' ), '', 'large', '2', 'normal', array(), 'button', array(), array(), '', 'disk' ),
		);
		$tab_settings = array();

		$tab_settings[] = array(
			'id' => 'mc_form_form_type',
			'label' => __( 'Form Type', 'mc_form' ),
			'callback' => array( $this, 'form_type' ),
		);
		$tab_settings[] = array(
			'id' => 'mc_form_form_settings',
			'label' => __( 'Form Settings', 'mc_form' ),
			'callback' => array( $this, 'form_settings' ),
			'has_inner_tab' => true,
		);
		$tab_settings[] = array(
			'id' => 'mc_form_form_quiz_settings',
			'label' => __( 'Quiz Settings', 'mc_form' ),
			'callback' => array( $this, 'quiz_settings' ),
			'has_inner_tab' => true,
		);
		$tab_settings[] = array(
			'id' => 'mc_form_form_rmail',
			'label' => __( 'Result & email', 'mc_form' ),
			'callback' => array( $this, 'result_email' ),
			'has_inner_tab' => true,
		);
		$tab_settings[] = array(
			'id' => 'mc_form_form_integration',
			'label' => __( 'Integration', 'mc_form' ),
			'callback' => array( $this, 'integration' ),
			'has_inner_tab' => true,
		);
		// $tab_settings[] = array(
		// 	'id' => 'mc_form_form_theme',
		// 	'label' => __( 'Theme', 'mc_form' ),
		// 	'callback' => array( $this, 'theme' ),
		// );
		$tab_settings[] = array(
			'id' => 'mc_form_core_intg',
			'label' => __( 'WP Core', 'mc_form' ),
			'callback' => array( $this, 'wp_core' ),
			'has_inner_tab' => true,
		);
		$tab_settings[] = array(
			'id' => 'mc_form_form_payment',
			'label' => __( 'Payment', 'mc_form' ),
			'callback' => array( $this, 'payment' ),
			'has_inner_tab' => true,
		);
		$builder_labels = array(
			'design' => __( 'D', 'mc_form' ),
			'mcq' => __( 'M', 'mc_form' ),
			'freetype' => __( 'F', 'mc_form' ),
			'pinfo' => __( 'O', 'mc_form' ),
		);

		$tab_settings = apply_filters( 'mc_form_admin_tab_settings', $tab_settings, $this );
?>
<?php wp_nonce_field( 'mc_form_form_save_ajax', 'mc_form_form_save_ajax' ); ?>
<?php $this->ui->clear(); ?>
<?php $this->ui->ajax_loader( false, 'mc_form_fb_p_al', array(), true, __( 'Loading', 'mc_form' ) ); ?>
<div id="mc_form_form" class="mc_uif_container mc_form_fb_hidden_init">
	<?php if ( $this->form_id != null ) : ?>
	<input type="hidden" name="form_id" id="form_id" value="<?php echo $this->form_id; ?>" />
	<?php endif; ?>
	<!-- Form Settings -> Tabs -->
	<div id="mc_form_form_customization_wrap" class="wpq-mcform-main-settings-wrap" style="display: none">
		<div id="mc_form_form_customization" class="mc-mcform-backoffice wpq-mcform-main-settings">
			<?php $this->ui->tabs( $tab_settings, false ); ?>
			<div class="wpq-mcform-main-settings-close"><i class="mc-icomoon-check"></i></div>
			<?php $this->ui->buttons( $toolbar_buttons, '', [ 'mc_uif_toolbar', 'wpq-mcform-main-settings-toolbar', 'mc-mcform-customizer-save' ] ); ?>
		</div>
	</div>
	<!-- End Form Settings -->

	<!-- Form Theme -> Tabs -->
	<div id="mc_form_form_theme_settings_wrap" class="wpq-mcform-main-settings-wrap" style="display: none">
		<div id="mc_form_form_theme_settings" class="mc-mcform-backoffice wpq-mcform-main-settings">
			<h3 class="wpq-mcform-main-settings-head"><?php _e( 'FORM STYLE', 'mc_form' ); ?></h3>
			<div id="mc_form_form_theme" class="wpq-mcform-main-settings-body">
				<?php $this->theme(); ?>
			</div>
			<div class="wpq-mcform-main-settings-close"><i class="mc-icomoon-check"></i></div>
			<?php $this->ui->buttons( $toolbar_buttons, '', [ 'mc_uif_toolbar', 'wpq-mcform-main-settings-toolbar', 'mc-mcform-customizer-save' ] ); ?>
		</div>
	</div>
	<!-- End Form Theme -->

	<!-- Builder Layout -->
	<?php $this->ui->builder_init( 'mc_form_form_builder', array( $this, 'builder' ), $builder_labels ); ?>
	<!-- End Builder Layout -->
	<div class="clear"></div>
</div>
		<?php
		$this->ui->ajax_loader( true, 'mc_form_ajax_loader', array(
			'save' => __( 'Saving', 'mc_form' ),
			'preview' => __( 'Generating Preview', 'mc_form' ),
			'success' => __( 'Success', 'mc_form' ),
		) );
	}

	public function ajax_save() {
		if ( !wp_verify_nonce( $this->post['mc_form_form_save_ajax'], 'mc_form_form_save_ajax' ) || ! current_user_can( 'manage_feedback' ) ) {
			echo 'cheating';
			die();
		}

		$id = $this->process_save();
		$live_view = new MCForm_Live_View( $id );
		$html_stream = $live_view->stream_html();
		@header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );
		echo json_encode( $html_stream );
		die();
	}

	/**
	 * Process the save
	 *
	 * @global array $mc_form_info
	 * @global wpdb $wpdb
	 */
	public function process_save() {
		global $mc_form_info, $wpdb;
		// Reinit to the current form
		if ( isset( $this->post['form_id'] ) ) {
			$this->init( $this->post['form_id'] );
		}

		//Set all the variables
		$layout = array();
		$this->save_process = array(
			'design' => array(),
			'mcq' => array(),
			'freetype' => array(),
			'pinfo' => array(),
		);

		// Get the settings
		$settings = $this->merge_elements( $this->post['settings'], $this->get_default_settings() );
		if ( '' != $settings['user']['smtp_config']['password'] ) {
			$settings['user']['smtp_config']['password'] = $this->encrypt( $settings['user']['smtp_config']['password'] );
		}
		// Manage Aweber
		// Is the settings enabled?
		if ( $settings['integration']['aweber']['enabled'] == true ) {
			// Can be a new authorization code
			if ( $this->settings['integration']['aweber']['prevac'] != $settings['integration']['aweber']['authorization_code'] ) {
				try {
					$aw_credentials = AWeberAPI::getDataFromAweberID( $settings['integration']['aweber']['authorization_code'] );
					foreach ( array( 'consumerKey', 'consumerSecret', 'accessKey', 'accessSecret' ) as $aweber_key => $aweber_val ) {
						$settings['integration']['aweber'][$aweber_val] = $aw_credentials[$aweber_key];
					}
					$settings['integration']['aweber']['prevac'] = $settings['integration']['aweber']['authorization_code'];
				} catch ( Exception $e ) {
					foreach ( array( 'consumerKey', 'consumerSecret', 'accessKey', 'accessSecret' ) as $aweber_key ) {
						$settings['integration']['aweber'][$aweber_key] = '';
					}
					$settings['integration']['aweber']['authorization_code'] = __( 'Invalid Code provided', 'mc_form' );
					$settings['integration']['aweber']['prevac'] = '';
				}
			// It is the same one
			} else {
				// Use the same tokens
				foreach ( array( 'consumerKey', 'consumerSecret', 'accessKey', 'accessSecret' ) as $aweber_key ) {
					$settings['integration']['aweber'][$aweber_key] = $this->settings['integration']['aweber'][$aweber_key];
				}
				$settings['integration']['aweber']['prevac'] = $settings['integration']['aweber']['authorization_code'];
			}

		// Reset aweber, if anything was even present
		} else {
			$settings['integration']['aweber']['authorization_code'] = '';
			$settings['integration']['aweber']['prevac'] = '';
			foreach ( array( 'consumerKey', 'consumerSecret', 'accessKey', 'accessSecret' ) as $aweber_key ) {
				$settings['integration']['aweber'][$aweber_key] = '';
			}
		}



		//Get the name
		$form_name = trim( strip_tags( $this->post['name'] ) );
		if ( $form_name == '' ) {
			$form_name = __( 'Untitled', 'mc_form' );
		}
		//Get the type

		$form_type = (int) $this->post['type'];

		$form_category = (int) $this->post['category'];

		//Process the layout and recursively process all the inner elements as well ;-)
		if ( isset( $this->post['containers'] ) ) {
			foreach ( (array) $this->post['containers'] as $container_key ) {
				//Get default structure
				$layout_new = $this->get_element_structure( 'tab' );

				//Merge with the date sent by user
				$layout_new = $this->merge_elements( $this->post['layout'][$container_key], $layout_new );

				//Reset the elements
				$layout_new['elements'] = array();

				//If no elements, then no need to continue
				if ( !isset( $this->post['layout'][$container_key]['elements']['m_type'] ) ) {
					continue;
				}

				//For all elements, check it and then add it
				foreach ( (array) $this->post['layout'][$container_key]['elements']['m_type'] as $e_key => $m_type ) {
					if ( !isset( $this->save_process[$m_type] ) ) {
						continue;
					}
					$type = $this->post['layout'][$container_key]['elements']['type'][$e_key];
					$key = $this->post['layout'][$container_key]['elements']['key'][$e_key];

					$element = $this->process_element( $m_type, $type, $key );

					if ( false !== $element ) {
						$layout_new['elements'][] = array(
							'm_type' => $m_type,
							'type' => $type,
							'key' => $key,
						);
					}
				}

				if ( !empty( $layout_new['elements'] ) ) {
					$layout[] = $layout_new;
				}
			}
		}

		$return_id = isset( $this->post['form_id'] ) ? $this->post['form_id'] : null;

		if ( $return_id !== null ) {
			$wpdb->update( $mc_form_info['form_table'], array(
					'name' => $form_name,
					'settings' => maybe_serialize( $settings ),
					'layout' => maybe_serialize( $layout ),
					'design' => maybe_serialize( $this->save_process['design'] ),
					'mcq' => maybe_serialize( $this->save_process['mcq'] ),
					'freetype' => maybe_serialize( $this->save_process['freetype'] ),
					'pinfo' => maybe_serialize( $this->save_process['pinfo'] ),
					'type' => $form_type,
					'category' => $form_category,
				), array( 'id' => $return_id ), '%s', '%d' );
			do_action( 'mc_form_form_updated', $return_id, $this );
		} else {
			$wpdb->insert( $mc_form_info['form_table'], array(
					'name' => $form_name,
					'settings' => maybe_serialize( $settings ),
					'layout' => maybe_serialize( $layout ),
					'design' => maybe_serialize( $this->save_process['design'] ),
					'mcq' => maybe_serialize( $this->save_process['mcq'] ),
					'freetype' => maybe_serialize( $this->save_process['freetype'] ),
					'pinfo' => maybe_serialize( $this->save_process['pinfo'] ),
					'type' => $form_type,
					'category' => $form_category,
				) );
			$return_id = $wpdb->insert_id;
			do_action( 'mc_form_form_created', $return_id, $this );
		}

		// Call for any theme related functions
		$active_theme = $settings['theme']['template'];
		$active_theme_info = $this->get_theme_by_id( $active_theme );
		if ( isset( $active_theme_info['admin_save_cb'] ) && ! is_null( $active_theme_info['admin_save_cb'] ) && is_callable( $active_theme_info['admin_save_cb'] ) ) {
			call_user_func( $active_theme_info['admin_save_cb'], $return_id, $form_name, $settings, $layout, $this->save_process, $form_type, $form_category );
		}

		return $return_id;
	}

	/*==========================================================================
	 * Save Processors
	 *========================================================================*/
	protected function process_element( $m_type, $type, $key ) {
		$element_definition = $this->get_element_definition( array( 'm_type' => $m_type, 'type' => $type ) );
		$element_structure = $this->get_element_structure( $type );

		if ( false === $element_structure ) {
			return false;
		}

		//Infinite recursion check - Who knows what the devil may do
		if ( isset( $this->save_process[$m_type][$key] ) ) {
			return false;
		}

		$element_from_post = isset( $this->post[$m_type][$key] ) ? $this->post[$m_type][$key] : array();

		$element = $this->merge_elements( $element_from_post, $element_structure );

		if ( isset( $element_definition['droppable'] ) && $element_definition['droppable'] == true ) {
			$element['elements'] = array();

			if ( isset( $this->post[$m_type][$key]['elements']['m_type'] ) ) {
				foreach ( (array) $this->post[$m_type][$key]['elements']['m_type'] as $e_key => $child_m_type ) {
					$child_type = $this->post[$m_type][$key]['elements']['type'][$e_key];
					$child_key = $this->post[$m_type][$key]['elements']['key'][$e_key];

					$child_element = $this->process_element( $child_m_type, $child_type, $child_key );

					if ( false !== $child_element ) {
						$element['elements'][] = array(
							'm_type' => $child_m_type,
							'type' => $child_type,
							'key' => $child_key,
						);
					}
				}
			}
		}

		$this->save_process[$m_type][$key] = $element;
		return true;
	}

	/*==========================================================================
	 * BUILDER LAYOUT CALLBACKS
	 *========================================================================*/
	public function builder_contextbar() {
		?>
<div id="mc-mcform-builder-contextbar">
	<div id="mc-mcform-builder-form-actions" class="mc-mcform-builder-contextgroup">
		<a data-tippy-placement="bottom-start" class="mc-mcform-builder-contextbar__link mcform-builder-tippy" href="#" id="mc-mcform-builder-toolbar-save" title="<?php esc_attr_e( 'Save Form', 'mc_form' ); ?>">
			<span class="idle">
				<i class="mc-icomoon-save2"></i>
			</span>
			<span class="saving">
				<span class="mcform-saving-block">
					<span class="mcform-saving-block__circle"></span>
					<span class="mcform-saving-block__circle"></span>
				</span>
			</span>
		</a>

		<div id="mc-mcform-builder-form-help">
			<span class="mcform-builder-main-help">
				<a data-tippy-placement="top-start" class="mc-mcform-builder-contextbar__link mc-mcform-builder-context-help mcform-builder-tippy" data-target="mcform-builder-help-quickstart" rel="noopener noreferrer" href="https://www.youtube.com/watch?v=UyP7jakeBbE" title="<?php _e( 'Get help', 'mc_form' ); ?>">
					<i class="mc-icomoon-live_help"></i>
					<span style="display: none" class="screen-reader-text"><?php _e( 'Quick Start Video', 'mc_form' ); ?></span>
				</a>
				<ul class="mcform-builder-main-help-nested">
					<li>
						<a target="_blank" rel="noopener noreferrer" class="mc-mcform-builder-context-help" data-target="mcform-builder-help-quickstart" href="https://www.youtube.com/watch?v=UyP7jakeBbE">
							<i class="mc-icomoon-rocket"></i>
							<span><?php _e( 'Quick Start Video', 'mc_form' ); ?></span>
						</a>
					</li>
					<li>
						<a class="mc-mcform-builder-context-help" data-target="mcform-builder-help-addtosite" href="#" id="mc-mcform-builder-toolbar-addtosite">
							<i class="mc-icomoon-add_circle"></i>
							<span><?php _e( 'Add to site', 'mc_form' ) ?></span>
						</a>
					</li>
					<li>
						<a target="_blank" rel="noopener noreferrer" class="mc-mcform-builder-context-help" data-target="mcform-builder-help-shortcut-keys" href="#mcform-builder-help-shortcut-keys">
							<i class="mc-icomoon-keyboard2"></i>
							<span><?php _e( 'Shortcut keys', 'mc_form' ); ?></span>
						</a>
					</li>
					<li>
						<a href="#" id="mcform-onboarding-trigger">
							<i class="mc-icomoon-directions"></i>
							<span><?php _e( 'Take a tour', 'mc_form' ); ?></span>
						</a>
					</li>
					<li>
						<a target="_blank" rel="noopener noreferrer" href="https://www.binarypoets.net/kb/form/form-video-tutorials/">
							<i class="mc-icomoon-video_library"></i>
							<span><?php _e( 'Video Tutorials', 'mc_form' ); ?></span>
						</a>
					</li>
					<li>
						<a target="_blank" rel="noopener noreferrer" href="https://www.binarypoets.net/kb/form/">
							<i class="mc-icomoon-library_books"></i>
							<span><?php _e( 'Documentation', 'mc_form' ); ?></span>
						</a>
					</li>
					<li>
						<a target="_blank" rel="noopener noreferrer" href="https://www.binarypoets.net/kb/support/forum/wordpress-plugins/wp-feedback-survey-quiz-manager-pro/">
							<i class="mc-icomoon-support2"></i>
							<span><?php _e( 'Get Support', 'mc_form' ); ?></span>
						</a>
					</li>
				</ul>
			</span>
		</div>

		<?php $this->ui->builder_add_container_button( 'mc-mcform-builder-contextbar__link mcform-builder-tippy' ); ?>
	</div>
</div>
		<?php
	}

	public function builder_context_helps() {
		?>
<div class="mcform-context-help-element" id="mcform-builder-help-quickstart">
	<div class="mcform-context-help-element__inner embed-video">
		<div class="embed-container">
			<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/SylAM0uPxMw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
		</div>
	</div>
</div>
<div class="mcform-context-help-element" id="mcform-builder-help-shortcut-keys">
	<div class="mcform-context-help-element__inner">
		<p><?php _e( 'You can use the following keyboard shortcuts within form builder.', 'mc_form' ); ?></p>
		<ul class="ul-disc">
			<li><kbd>Ctrl/⌘ + s</kbd>: Save form.</li>
			<li><kbd>Alt/⌥ + p</kbd>: Add new page.</li>
			<li><kbd>Alt/⌥ + c</kbd>: Add Checkbox element.</li>
			<li><kbd>Alt/⌥ + r</kbd>: Add Radio element.</li>
			<li><kbd>Alt/⌥ + d</kbd>: Add Dropdown element.</li>
			<li><kbd>Alt/⌥ + t</kbd>: Add Textarea element.</li>
			<li><kbd>Alt/⌥ + i</kbd>: Add Input element.</li>
			<li><kbd>Alt/⌥ + f</kbd>: Add First Name element.</li>
			<li><kbd>Alt/⌥ + l</kbd>: Add Last Name element.</li>
			<li><kbd>Alt/⌥ + e</kbd>: Add Email element.</li>
			<li><kbd>Alt/⌥ + g</kbd>: Add Grading(Slider/Range) element.</li>
			<li><kbd>Alt/⌥ + s</kbd>: Add Star Rating element.</li>
			<li><kbd>Alt/⌥ + o</kbd>: Add Sortable element.</li>
			<li><kbd>Alt/⌥ + m</kbd>: Add Matrix element.</li>
			<li><kbd>Alt/⌥ + a</kbd>: Add Repeatable element.</li>
		</ul>
	</div>
</div>
<div class="mcform-context-help-element" id="mcform-builder-help-addtosite">
	<div class="mcform-context-help-element__inner">
		<h3>
			<i class="mc-icomoon-code3"></i>
			<span><?php _e( 'Using Shortcodes', 'mc_form' ); ?></span>
		</h3>
		<p><img class="align-right" src="<?php echo MC_FORM_Loader::$static_location . 'admin/images/help/tinymce-editor.jpg' ?>" /></p>
		<p><?php _e( 'To embed the form in a post or page use the following shortcode.', 'mc_form' ); ?></p>
		<pre>[mc_form_form form_id="<?php echo $this->form_id; ?>"]</pre>
		<p><?php _e( 'To use popup form, use the shortcode', 'mc_form' ); ?></p>
		<pre>[mc_form_popup form_id="<?php echo $this->form_id; ?>"]<?php _e( 'Open Form', 'mc_form' ); ?>[/mc_form_popup]</pre>
		<p><?php _e( 'Or simply use <i class="mc-formic-mcform"></i> icon under WordPress editor to customize different shortcode options.', 'mc_form' ); ?></p>
		<p><?php _e( 'Each of the editor button will take you through a widget with which you can easily insert shortcodes without modifying by hand.', 'mc_form' ); ?></p>
		<h3>
			<i class="mc-icomoon-edit"></i>
			<span><?php _e( 'Using Gutenberg Blocks', 'mc_form' ); ?></span>
		</h3>
		<p><img class="" src="<?php echo MC_FORM_Loader::$static_location . 'admin/images/help/gutenberg-editor.jpg' ?>" /></p>
		<p><?php _e( 'If you are using Gutenberg blocks, then it can be found under mcForm block category.', 'mc_form' ); ?></p>
		<p><?php _e( 'The blocks can be customized right within the editor. You can even publish and customize later during update.', 'mc_form' ); ?></p>
		<h3>
			<i class="mc-icomoon-widgets"></i>
			<span><?php _e( 'Using Widgets', 'mc_form' ); ?></span>
		</h3>
		<p><img src="<?php echo MC_FORM_Loader::$static_location . 'admin/images/help/widgets.jpg' ?>" /></p>
		<p><?php _e( 'Go to Appearance > Widgets and search for <code>mcForm - Insert Form</code>.', 'mc_form' ); ?></p>
		<h3>
			<i class="mc-icomoon-code"></i>
			<span><?php _e( 'Advanced Usage', 'mc_form' ); ?></span>
		</h3>
		<p><?php _e( 'Use the following PHP code to insert anywhere.', 'mc_form' ); ?></p>
		<pre>
&lt;?php
$form = new \MC_FORM_Form_Elements_Front( null, <?php echo $this->form_id; ?> );
$form->show_form();</pre>
	</div>
</div>
		<?php
	}

	public function builder_toolbar() {
		$mcform_standalone_permalink = MC_FORM_Form_Elements_Static::standalone_permalink_parts( $this->form_id );
		$mcform_standalone_url = '';
		if ( is_array( $mcform_standalone_permalink ) ) {
			$mcform_standalone_url = $mcform_standalone_permalink['url'];
		}
		?>
<div id="mc-mcform-builder-toolbar">
	<!-- Loader -->
	<div class="loader-viewer">
		<div class="loader-viewer__load">
			<div class="loader-viewer__bar"></div>
			<div class="loader-viewer__bar"></div>
			<div class="loader-viewer__bar"></div>
		</div>
	</div>
	<span class="toolbar-left toolbar-group">
		<!-- Save & Settings -->
		<span id="mc-mcform-builder-toolbar-save-settings">
			<a data-tippy-placement="bottom-start" href="#" id="mc-mcform-builder-toolbar-settings" class="mc-mcform-customizer-trigger mcform-builder-tippy" title="<?php _e( 'Change form settings and integrations.', 'mc_form' ); ?>" data-target="mc_form_form_customization_wrap">
				<i class="mc-icomoon-wrench"></i> <?php _e( 'CONFIG', 'mc_form' ); ?>
			</a>
			<a href="#" id="mc-mcform-builder-toolbar-theme" class="mc-mcform-customizer-trigger mcform-builder-tippy" title="<?php _e( 'Change form themes, colors, progress buttons etc.', 'mc_form' ); ?>" data-target="mc_form_form_theme_settings_wrap">
				<i class="mc-icomoon-paint-format"></i> <?php _e( 'STYLE', 'mc_form' ); ?>
			</a>
		</span>

		<span id="mc-mcform-builder-toolbar-form-id">
			<span class="mcform-badge"><?php printf( __( 'id: %d', 'mc_form' ), $this->form_id ); ?></span>
		</span>

		<!-- Form name -->
		<span id="mc-mcform-builder-toolbar-formname">
			<?php $this->form_name(); ?>
		</span>
	</span>

	<span class="toolbar-center toolbar-group">
		<!-- Split pane mode -->
		<span id="mc-mcform-builder-toolbar-split-pane-mode">
			<a data-class="builder-only" href="#" id="mc-mcform-builder-toolbar-builder-only" class="mcform-builder-tippy" title="<?php esc_attr_e( 'Show Builder Only', 'mc_form' ); ?>">
				<svg width="14px" height="12px" viewBox="0 0 14 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
					<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
						<g fill="currentColor" fill-rule="nonzero">
							<path d="M12.544,0.116 C12.881.0.156 13.14,0.415 13.18,0.753 C13.318,4.246 13.182,7.744 13.182,11.24 C13.168,11.599 12.903,11.888 12.544,11.931 C8.616,12.085 4.683,11.933 0.752,11.933 C0.394,11.919 0.104,11.654 0.062,11.294 C-0.076,7.801 0.059,4.303 0.059,0.807 C0.074,0.449 0.339,0.159 0.698,0.116 C4.644,-0.039 8.598,-0.039 12.544,0.116 Z M0.752,0.807 L0.752,11.24 L12.489,11.24 L12.489,0.807 C8.577,0.807 4.665,0.807 0.752,0.807 Z" id="Shape"></path>
							<g id="Group" transform="translate(2.000000, 2.000000)">
								<rect id="Rectangle-path" x="0.143" y="0.451" width="9.042" height="1"></rect>
								<rect id="Rectangle-path" x="0.143" y="5.288" width="9.042" height="1"></rect>
								<rect id="Rectangle-path" x="0.143" y="3.676" width="9.042" height="1"></rect>
								<rect id="Rectangle-path" x="0.143" y="2.064" width="9.042" height="1"></rect>
								<rect id="Rectangle-path" x="0.143" y="6.9" width="9.042" height="1"></rect>
							</g>
						</g>
					</g>
				</svg>
			</a>
			<a data-class="builder-form" href="#" id="mc-mcform-builder-toolbar-builder-form" class="active mcform-builder-tippy" title="<?php esc_attr_e( 'Show Builder and Form', 'mc_form' ); ?>">
				<svg width="14px" height="12px" viewBox="0 0 14 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
					<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
						<g fill="currentColor" fill-rule="nonzero">
							<g>
								<g transform="translate(1.000000, 2.000000)">
									<g id="Rectangle-path">
										<rect x="0.89" y="0.634" width="3.26" height="1"></rect>
										<rect x="0.89" y="5.168" width="3.26" height="1"></rect>
										<rect x="0.89" y="3.657" width="3.26" height="1"></rect>
										<rect x="0.89" y="2.145" width="3.26" height="1"></rect>
										<rect x="0.89" y="6.679" width="3.26" height="1"></rect>
									</g>
								</g>
								<path d="M12.541.0.116 C12.877,0.156 13.135,0.414 13.175,0.75 C13.311,4.218 13.177,7.691 13.177,11.161 C13.163,11.518 12.899,11.807 12.541,11.849 C8.613,12.003 4.68,11.851 0.749,11.851 C0.392,11.837 0.103,11.573 0.061,11.215 C-0.075,7.747 0.059,4.275 0.059,0.805 C0.073,0.1.0.1.337,0.159 0.695,0.116 C4.641,-0.039 8.595,-0.039 12.541.0.116 Z M0.749,11.161 L6.292,11.161 L6.292,0.805 L0.749,0.805 L0.749,11.161 Z M12.486,11.161 L12.486,0.805 L6.944,0.805 L6.944,11.161 L12.486,11.161 Z" id="Shape"></path>
							</g>
						</g>
					</g>
				</svg>
			</a>
			<a data-class="form-only" href="#" id="mc-mcform-builder-toolbar-form-only" class="mcform-builder-tippy" title="<?php esc_attr_e( 'Show Form Only', 'mc_form' ); ?>">
				<svg width="14px" height="12px" viewBox="0 0 14 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
					<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
						<g id="3" fill="currentColor" fill-rule="nonzero">
							<path d="M12.544,0.116 C12.881.0.156 13.14,0.415 13.18,0.753 C13.318,4.246 13.182,7.744 13.182,11.24 C13.168,11.599 12.903,11.888 12.544,11.931 C8.616,12.085 4.683,11.933 0.752,11.933 C0.394,11.919 0.104,11.654 0.062,11.294 C-0.076,7.801 0.059,4.303 0.059,0.807 C0.074,0.449 0.339,0.159 0.698,0.116 C4.644,-0.039 8.598,-0.039 12.544,0.116 Z M0.752,0.807 L0.752,11.24 L12.489,11.24 L12.489,0.807 C8.577,0.807 4.665,0.807 0.752,0.807 Z" id="Shape"></path>
						</g>
					</g>
				</svg>
			</a>
		</span>
	</span>

	<span class="toolbar-right toolbar-group">
		<span id="mc-mcform-builder-toolbar-iframe-size">
			<a title="<?php _e( 'Fit Screen', 'mc_form' ); ?>" data-stretch="fit" class="active mcform-builder-tippy">
				<svg width="24px" height="24px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
					<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
						<g id="baseline-wallpaper-24px" transform="translate(-2.000000, -2.000000)">
							<path d="M4,4 L11,4 L11,2 L4,2 C2.9,2 2,2.9 2,4 L2,11 L4,11 L4,4 Z M20,2 L13,2 L13,4 L20,4 L20,11 L22,11 L22,4 C22,2.9 21.1,2 20,2 Z M20,20 L13,20 L13,22 L20,22 C21.1,22 22,21.1 22,20 L22,13 L20,13 L20,20 Z M4,13 L2,13 L2,20 C2,21.1 2.9,22 4,22 L11,22 L11,20 L4,20 L4,13 Z" id="Shape" fill="currentColor" fill-rule="nonzero"></path>
							<polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
						</g>
					</g>
				</svg>
			</a>
			<a title="<?php _e( 'Desktop View', 'mc_form' ); ?>" class="mcform-builder-tippy" data-stretch="desktop">
				<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
					<path d="M0 0h24v24H0z" fill="none"/>
					<path fill="currentColor" d="M20 18c1.1.0.1.99-.9 1.99-2L22 5c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v11.0.1.1.9 2 2 2H0c0 1.1.9 2 2 2h20c1.1 0 2-.9 2-2h-4zM4 5h16v11H4V5zm8 14c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"/>
				</svg>
			</a>
			<a title="<?php _e( 'Tablet View', 'mc_form' ); ?>" class="mcform-builder-tippy" data-stretch="tablet">
				<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
					<path fill="currentColor" d="M18.5 0h-14C3.12 0 2 1.12 2 2.5v19C2 22.88 3.12 24 4.5 24h14c1.38 0 2.5-1.12 2.5-2.5v-19C21 1.12 19.88 0 18.5 0zm-7 23c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm7.5-4H4V3h15v16z"/>
				</svg>
			</a>
			<a title="<?php _e( 'Mobile View', 'mc_form' ); ?>" class="mcform-builder-tippy" data-stretch="mobile">
				<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
					<path fill="currentColor" d="M15.5 1h-8C6.12 1 5 2.12 5 3.5v17C5 21.88 6.12 23 7.5 23h8c1.38 0 2.5-1.12 2.5-2.5v-17C18 2.12 16.88 1 15.5 1zm-4 21c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm4.5-4H7V4h9v14z"/>
					<path d="M0 0h24v24H0z" fill="none"/>
				</svg>
			</a>
		</span>
		<span id="mc-mcform-builder-toolbar-actions">
			<a class="refresher mcform-builder-tippy" title="<?php _e( 'Refresh Live View', 'mc_form' ); ?>"><i class="mc-icomoon-refresh"></i></a>
			<a class="mcform-builder-tippy" href="<?php echo $mcform_standalone_url; ?>" target="<?php echo "mcform-preview-" . $this->form_id; ?>" title="<?php _e( 'Open form in new tab', 'mc_form' ); ?>"><i class="mc-icomoon-external-link"></i></a>
		</span>
	</span>
</div>
		<?php
	}

	public function builder() {
		$msgs = array(
			'layout_helper_msg' => __( 'You can customize this layout by simply dragging a form element and dropping over the area. You can also have nested elements inside any droppable element. You can and should further set the title and subtitle of this container so that the tabular layout can be properly populated.' ),
			'layout_helper_title' => __( 'Customizable Layout', 'mc_form' ),
			'deleter_title' => __( 'Confirm Deletion', 'mc_form' ),
			'deleter_msg' => __( 'Are you sure you want to remove this container? This action can not be undone.', 'mc_form' ),
			'deldropper_title' => __( 'Confirm Removal', 'mc_form' ),
			'deldropper_msg' => __( 'Are you sure you want to remove this element? This action can not be undone.', 'mc_form' ),
		);
		$keys = array(
			'layout' => 0,
			'design' => 0,
			'mcq' => 0,
			'freetype' => 0,
			'pinfo' => 0,
		);
		foreach ( $keys as $type => $key ) {
			if ( !empty( $this->{$type} ) ) {
				$keys[$type] = max( array_keys( $this->{$type} ) ) + 1;
			}
		}
		foreach ( $this->layout as $l_key => $layout ) {
			$this->layout[$l_key]['grayed_out'] = false;
			if ( isset($layout['conditional']) && $layout['conditional']['active'] == true && $layout['conditional']['status'] == false ) {
				$this->layout[$l_key]['grayed_out'] = true;
			}
		}
?>
<style type="text/css">
	#screen-meta-links {
		display: none;
	}
</style>

	<!-- Toolbar -->
	<?php $this->builder_toolbar(); ?>
	<!-- End toolbar -->

	<!-- Add Layout template -->
	<?php $this->ui->builder_adder( 'mc_form_add_layout', '__LKEY__', array( $this, 'builder_layout_settings' ), array( '__LKEY__', array() ), array( 'm_type' => 'layout', 'type' => 'tab' ), 'layout' ); ?>
	<!-- End Add Layout Template -->

	<!-- End Droppables & Containers & Toolbar -->

	<!-- Element Settings -->
	<div id="mc-mcform-builder-settings-wrap" data-margin-top="32" style="display: none">
		<div class="mc_uif_tabs" id="mc-mcform-settings-tab-wrapper">
			<ul>
				<li><a href="#mc-mcform-settings-element"><i class="mc-icomoon-tasks"></i> <?php _e( 'Configuration', 'mc_form' ); ?></a></li>
				<li id="mc-mcform-settings-editor-li"><a href="#mc-mcform-settings-editor"><i class="mc-icomoon-pen"></i> <?php _e( 'Description', 'mc_form' ); ?></a></li>
			</ul>
			<div id="mc-mcform-settings-element">
				<!-- Settings Box -->
				<?php $this->ui->builder_settings_box( 'mc_form_settings', __( 'Save Settings', 'mc_form' ) ); ?>
				<!-- End Settings Box -->
			</div>
			<div id="mc-mcform-settings-editor">
				<!-- WP Editor -->
				<?php $this->ui->builder_wp_editor( 'mc_form_form_richtext', __( 'Element Description (HTML)', 'mc_form' ) ); ?>
				<!-- End WP Editor -->
			</div>
			<div class="mc_uif_builder_settings_toolbar">
				<a href="#" class="builder_settings_drag mcform-builder-tippy" title="<?php _e( 'Move Window and double click to reset', 'mc_form' ); ?>">
					<i class="mc-icomoon-drag_handle"></i>
				</a>
				<a href="#" class="builder_settings_prev mcform-builder-tippy" title="<?php _e( 'Previous element', 'mc_form' ); ?>">
					<i class="mc-icomoon-angle-left"></i>
				</a>
				<a href="#" class="builder_settings_next mcform-builder-tippy" title="<?php _e( 'Next element', 'mc_form' ); ?>">
					<i class="mc-icomoon-angle-right"></i>
				</a>
				<a href="#" class="builder_settings_save mcform-builder-tippy" title="<?php _e( 'Save and Close', 'mc_form' ); ?>">
					<i class="mc-icomoon-check2"></i>
				</a>
			</div>
			<?php $this->ui->button( __( 'Save Settings', 'mc_form' ), 'mc-mcform-builder-settings-save', 'large', 'ui', 'normal', array( 'mc_uif_builder_settings_save', 'center' ) ); ?>
		</div>
		<div class="clear"></div>
	</div>
	<!-- End Element Settings -->

	<div id="mc-mcform-builder-app">
		<div id="mc-mcform-builder-app__sidebar">
			<!-- Contextbar -->
			<?php $this->builder_contextbar(); ?>
			<!-- End contextbar -->
			<!-- Element Adder -->
			<div id="mc-mcform-builder-droppables-container" class="mc-mcform-builder-split-window__sidebar">
				<!-- Droppable Search -->
				<?php $this->ui->builder_droppables_search(); ?>
				<!-- Droppable Elements -->
				<?php $this->builder_droppables(); ?>
				<!-- End Droppable Elements -->
			</div>
			<!-- End Element Adder -->
		</div>
		<div id="mc-mcform-builder-app__splitpane">
			<div id="mc-mcform-builder-split-window" class="mc-mcform-builder-split-window builder-form">
				<!-- Left Column -->
				<div id="mcform-split-view-left" class="mc-mcform-builder-split-window__builder">
					<div class="mc-mcform-builder-split-window__inner">
						<div id="mc-mcform-builder-layout-wrap">
							<!-- Layout area -->
							<?php $this->ui->builder_sortables( 'mc_form_form_builder_layout', $this->type, $this->layout, array( $this, 'builder_sortable' ), array( $this, 'builder_layout_settings' ), $msgs, 'layout', $keys ); ?>
							<!-- End Layout Area -->
							<div class="clear"></div>
						</div>
					</div>
				</div>
				<!-- End Left Column -->

				<div class="mc-mcform-builder-split-window__resizer" title="<?php esc_attr_e( 'Double click to reset', 'mc_form' ); ?>" id="mcform-split-view-resize">
					<i class="mc-icomoon-more"></i>
				</div>

				<!-- Right Column -->
				<div id="mcform-split-view-right" class="mc-mcform-builder-split-window__form">
					<div class="mc-mcform-builder-split-window__inner">
						<div class="mcform-builder-live-form">
							<div class="mcform-builder-form-iframe fit">
								<iframe id="mcform-builder-liveview-iframe" src="<?php echo esc_url( add_query_arg( [
									'action' => 'mcform_builder_preview',
									'form_id' => $this->form_id,
									'_wpnonce' => wp_create_nonce( 'mcform_builder_preview' ),
								], admin_url( 'admin-ajax.php' ) ) ); ?>" allowtransparency="true" width="100%" height="100%"></iframe>
							</div>
							<div class="mcform-builder-live-form-loading" id="mcform-builder-live-iframe-loading">
								<?php $this->ui->builder_request_animation_block(); ?>
							</div>
						</div>
					</div>
				</div>
				<!-- End Right Column -->
			</div>
		</div>
	</div>
	<div class="clear"></div>
		<?php
		$this->builder_context_helps();
	}

	public function builder_sortable( $layout_element, $layout_key ) {
		$e_key = $layout_element['key'];
		$element = $this->get_element_from_layout( $layout_element );
		$callback = array( $this, 'build_element_html' );
		$parameters = array( $element['type'], $e_key, $element, null, '' );
		$element_definition = $this->get_element_definition( $element );
		$data_attr = $this->ui->builder_data_attr( $element_definition );
		$element_definition['sub_title'] = strip_tags( $element['title'] );
		$element_grayed_out = false;
		if ( isset($element['conditional']) && $element['conditional']['active'] == true && $element['conditional']['status'] == false ) {
			$element_grayed_out = true;
		}

		$element_definition['grayed_out'] = $element_grayed_out;
		return array( $element_definition, $e_key, $layout_key, $element['type'], $callback, $parameters, $data_attr, $element, array( $this, 'builder_sortable' ) );
	}

	public function builder_layout_settings( $layout_key, $layout = array() ) {
		$structure = wp_parse_args( $layout, $this->get_element_structure( 'tab' ) );
		$tab_names = $this->ui->generate_id_from_name( 'layout[' . $layout_key . '][settings_wrap]' );
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Layout', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( 'layout[' . $layout_key . '][title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( 'layout[' . $layout_key . '][title]', $structure['title'], __( 'Title of the Container', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( 'layout[' . $layout_key . '][subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( 'layout[' . $layout_key . '][subtitle]', $structure['subtitle'], __( 'Secondary title of the Container', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<td colspan="3"><p class="description"><?php _e( 'You can also have any rich text which will be shown on the top of the container.', 'mc_form' ); ?></p></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label('layout[' . $layout_key . '][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( 'layout[' . $layout_key . '][icon]', $structure['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the heading. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr class="mc_form_page_specific_time">
						<th><?php $this->ui->generate_label( 'layout[' . $layout_key . '][timer]', __( 'Container Time Limit (Seconds)', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( 'layout[' . $layout_key . '][timer]', $structure['timer'], __( 'Seconds', 'mc_form' ), '0' ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Set the time in seconds after which this container will automatically progress.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( 'layout[' . $layout_key . ']', $structure['conditional'] ); ?>
		</div>
	</div>

		<?php

		$this->ui->textarea_linked_wp_editor( 'layout[' . $layout_key . '][description]', $structure['description'], 'Enter' );
		return;

	}


	public function builder_droppables() {
		$id = 'mc_form_builder_droppable';
		$key = '__EKEY__';
		$layout_key = '__LKEY__';
		$items = $this->elements;
		unset( $items['layout'] );
		foreach ( $items as $i_key => $item ) {
			foreach ( $item['elements'] as $elem_key => $element ) {
				$items[ $i_key ]['elements'][ $elem_key ]['callback'] = array( $this, 'build_element_html' );
				$items[ $i_key ]['elements'][ $elem_key ]['parameters'] = array( $elem_key, $key, null, null, '' );
				$items[ $i_key ]['elements'][ $elem_key ]['sub_title'] = '';
			}
		}
		$this->ui->builder_droppables( $id, $items, $key, $layout_key, __( 'Go Back', 'mc_form' ) );
	}

	private function icon_tester() {
		$icons = $this->ui->get_valid_icons();
		$i_check = array();
		?>
<table class="widefat">
	<thead>
		<tr>
			<th>Name</th>
			<th>Data</th>
			<th>Icon</th>
			<th>Image</th>
			<th>Duplicate</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $icons as $i_gr ) : ?>
		<?php foreach ( $i_gr['elements'] as $i_key => $ic ) : ?>
			<?php $duplicate = isset( $i_check[$i_key] ) ? true : false; ?>
			<?php $i_check[$i_key] = true; ?>
		<tr>
			<th><?php echo $ic; ?></th>
			<td><?php echo $i_key . ' / ' . dechex( $i_key ); ?></td>
			<td><span data-mc-icomoon="&#x<?php echo dechex( $i_key ); ?>;" style="font-size: 32px; margin: 5px 0; display: inline-block; color: #333;"></span></td>
			<td><?php echo '<img src="' . plugins_url( '/lib/images/iconmoon/' . $this->ui->get_icon_image_name( $i_key ), MC_FORM_Loader::$abs_file ) . '" />'; ?></td>
			<td><?php echo ($duplicate ? 'Yes' : 'No'); ?></td>
		</tr>
		<?php endforeach; ?>
		<?php endforeach; ?>
	</tbody>
</table>
		<?php
	}

	/*==========================================================================
	 * TABBED AND OTHER FORM SETTINGS
	 *========================================================================*/
	public function form_name() {
		$this->ui->text( 'name', $this->name, __( 'Enter the Name of the Form', 'mc_form' ), 'large' );
	}

	public function form_type() {
		$items = array();
		$items[] = array(
			'value' => '0',
			'label' => __( 'Normal Single Paged', 'mc_form' ),
			'data' => array(
				'condID' => 'mc_form_type_zero,mc_form_type_scroll',
			),
		);
		$items[] = array(
			'value' => '1',
			'label' => __( 'Tabular Appearance', 'mc_form' ),
			'data' => array(
				'condID' => 'mc_form_type_one,mc_form_type_scroll',
			),
		);
		$items[] = array(
			'value' => '2',
			'label' => __( 'Paginated Appearance', 'mc_form' ),
			'data' => array(
				'condID' => 'mc_form_type_one,mc_form_type_two,mc_form_type_scroll',
			),
		);
?>
<div class="mc_uif_msg mc_uif_float_right">
	<a href="javascript:;" class="mc_uif_msg_icon" title="<?php _e( 'Form Appearance Type', 'mc_form' ); ?>"><i class="mc-icomoon-live_help"></i></a>
	<div class="mc_uif_msg_body">
		<p><?php _e( 'Currently we support 3 kinds of appearances. Each appearance has it\'s own different sets of options.', 'mc_form' ); ?></p>
		<h3><?php _e( 'Normal Single Paged', 'mc_form' ); ?></h3>
		<ul class="ul-square">
			<li>
				<?php _e( 'Form will appear with a general single paged layout.', 'mc_form' ) ?>
			</li>
			<li>
				<?php _e( 'Ideal for small bussiness or contact forms.', 'mc_form' ); ?>
			</li>
		</ul>
		<h3><?php _e( 'Tabular Appearance', 'mc_form' ); ?></h3>
		<ul class="ul-square">
			<li>
				<?php _e( 'Form elements can be grouped into tabs.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'A user will need to navigate through all the tabs and fill them up before submitting.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'You can create as many tabs as you want. Simply click on the <strong>Add Tab/Pagination button</strong>.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'You can also select if the user is able to navigate to a previously viewed tab without validating or completely filling the form elements inside the current tab.', 'mc_form' ); ?>
			</li>
		</ul>
		<h3><?php _e( 'Paginated Appearance', 'mc_form' ); ?></h3>
		<ul class="ul-square">
			<li>
				<?php _e( 'Form elements can be grouped into pages.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'A user will need to navigate through all the pages and fill them up before submitting.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'You can create as many pages as you want. Simply click on the <strong>Add Tab/Pagination button</strong>.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'You can select to show a progress bar which will show the percentage of completion.', 'mc_form' ); ?>
			</li>
		</ul>
	</div>
</div>
		<?php
		echo '<div class="align-center">';
		$this->ui->radios( 'type', $items, $this->type, false, true );
		echo '</div>';

		$this->ui->shadowbox( array( 'lifted_corner', 'cyan' ), array( $this, 'type_normal' ), 0, 'mc_form_type_zero' );
		$this->ui->shadowbox( array( 'lifted_corner', 'cyan' ), array( $this, 'type_pagination' ), 0, 'mc_form_type_two' );
		$this->ui->shadowbox( array( 'lifted_corner', 'cyan' ), array( $this, 'type_tab' ), 0, 'mc_form_type_one' );
		$this->ui->shadowbox( array( 'lifted_corner', 'cyan' ), array( $this, 'type_scroll' ), 0, 'mc_form_type_scroll' );
	}

	public function type_scroll() {
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th style="width: 50%"><?php $this->ui->generate_label( 'settings[type_specific][scroll][progress]', __( 'Scroll to Progress Block', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][scroll][progress]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['scroll']['progress'] ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'If enabled, then during form submission, the page will scroll to the progress block.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 50%"><?php $this->ui->generate_label( 'settings[type_specific][scroll][message]', __( 'Scroll to Message Block', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][scroll][message]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['scroll']['message'] ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'If enabled, then after form submission, the page will scroll to the message block.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 50%"><?php $this->ui->generate_label( 'settings[type_specific][scroll][offset]', __( 'Scroll Offset', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[type_specific][scroll][offset]', $this->settings['type_specific']['scroll']['offset'], __( 'Pixels', 'mc_form' ) ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'Adjust the scroll offset value. This is useful if your theme has fixed header or similar. The plugin will try to determine the offset automatically, but sometimes it would not be enough (due to varity in HTML and CSS) and you would need to set it manually here.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function type_normal() {
?>
	<table class="form-table">
		<tbody>
			<tr>
				<th><?php $this->ui->generate_label( 'settings[type_specific][normal][wrapper]', __( 'Wrap Inside', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->toggle( 'settings[type_specific][normal][wrapper]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['normal']['wrapper'] ); ?>
				</td>
				<td style="width: 40px;">
					<?php $this->ui->help( __( 'If yes then the form will be populated inside a wrapper matching the theme. Otherwise, it will simply try to inherit the default style of your theme. If your form looks bad, then turning this on, might tune things up.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( 'settings[type_specific][normal][center_heading]', __( 'Center Main Heading', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->toggle( 'settings[type_specific][normal][center_heading]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['normal']['center_heading'] ); ?>
				</td>
				<td style="width: 40px;">
					<?php $this->ui->help( __( 'If yes then the container heading (if any) will be put on center.', 'mc_form' ) ); ?>
				</td>
			</tr>
		</tbody>
	</table>
		<?php
	}

	public function type_pagination() {
?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[type_specific][pagination][show_progress_bar]', __( 'Show Progress Bar', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][pagination][show_progress_bar]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $this->settings['type_specific']['pagination']['show_progress_bar'] ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'You can select to show a progress bar which will show the percentage of completion.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[type_specific][pagination][progress_bar_bottom]', __( 'Place Progress Bar on Bottom', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][pagination][progress_bar_bottom]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['pagination']['progress_bar_bottom'] ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'If you want to show the progressbar on the bottom, enable this.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 50%"><?php $this->ui->generate_label( 'settings[type_specific][pagination][decimal_point]', __( 'Percentage Decimal Points', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[type_specific][pagination][decimal_point]', $this->settings['type_specific']['pagination']['decimal_point'], __( 'Digits', 'mc_form' ) ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'Mention the number of digits that will be shown after decimal point in the progress bar.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function type_tab() {
?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[type_specific][tab][auto_progress]', __( 'Auto Progress Page if all validates', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][tab][auto_progress]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['tab']['auto_progress'], '1', false, true, array(
					'condid' => 'mc_form_ts_t_as_wrap,mc_form_ts_t_ad_wrap',
				) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'If enabled, then form will automatically progress if all the elements under current page validates.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_ts_t_as_wrap">
			<th><?php $this->ui->generate_label( 'settings[type_specific][tab][auto_submit]', __( 'Auto Submit last page if validates', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][tab][auto_submit]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['tab']['auto_submit'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'If enabled, then form will automatically submit if all the elements under last page validates.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_ts_t_ad_wrap">
			<th><?php $this->ui->generate_label( 'settings[type_specific][tab][auto_progress_delay]', __( 'Auto Progress Delay (Milliseconds)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[type_specific][tab][auto_progress_delay]', $this->settings['type_specific']['tab']['auto_progress_delay'], __( 'Immediate', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Number of milliseconds to wait for before progressing since last change.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th style="width: 50%"><?php $this->ui->generate_label( 'settings[type_specific][tab][block_previous]', __( 'Block Navigation to Previous Tab/Page', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][tab][block_previous]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['tab']['block_previous'] ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'If enabled, then this will prevent users from navigating back to the previous tab once they click on the next button.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 50%"><?php $this->ui->generate_label( 'settings[type_specific][tab][can_previous]', __( 'Can navigate to previous Tab without validation?', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][tab][can_previous]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['tab']['can_previous'] ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'You can also select if the user is able to navigate to a previously viewed tab without validating or completely filling the form elements inside the current tab.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 50%"><?php $this->ui->generate_label( 'settings[type_specific][tab][any_tab]', __( 'Can navigate to any Tab?', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][tab][any_tab]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['tab']['any_tab'] ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'If selected, then user can navigate to any tab by clicking the tab button. This overrides all previous settings. If the current tab has any validation error, then it will only be caught after submitting the form. So do this only if all the elements are non-required or only the last tab has required/compulsory elements.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 50%"><?php $this->ui->generate_label( 'settings[type_specific][tab][scroll]', __( 'Scroll to the page top', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[type_specific][tab][scroll]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['tab']['scroll'] ); ?>
			</td>
			<td style="width: 40px;">
				<?php $this->ui->help( __( 'If enabled then the page will automatically scroll to the page top when next/previous button is pressed.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[type_specific][tab][scroll_on_error]', __( 'Scroll to element on validation error', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->toggle( 'settings[type_specific][tab][scroll_on_error]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['type_specific']['tab']['scroll_on_error'] ); ?></td>
			<td><?php $this->ui->help( __( 'If enabled (by default) then when progressing to the next tab/page, if a validation error occurs, then the page will scroll to the element.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function form_settings() {
		$hor_tabs = array();

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_general',
			'label' => __( 'General Settings', 'mc_form' ),
			'callback' => array( $this, 'general' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_limitation',
			'label' => __( 'Submission Limitation', 'mc_form' ),
			'callback' => array( $this, 'limitation' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_buttons',
			'label' => __( 'Progress Buttons', 'mc_form' ),
			'callback' => array( $this, 'buttons' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_save_progress',
			'label' => __( 'Save Progress', 'mc_form' ),
			'callback' => array( $this, 'save_progress' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_format',
			'label' => __( 'Format Strings', 'mc_form' ),
			'callback' => array( $this, 'format_options' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_submission',
			'label' => __( 'Form Submission', 'mc_form' ),
			'callback' => array( $this, 'submission' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_redirect',
			'label' => __( 'Redirection', 'mc_form' ),
			'callback' => array( $this, 'redirect' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_ganalytics',
			'label' => __( 'Google Analytics', 'mc_form' ),
			'callback' => array( $this, 'ganalytics' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_standalone',
			'label' => __( 'Standalone Page SEO', 'mc_form' ),
			'callback' => array( $this, 'standalone_config' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_opengraph',
			'label' => __( 'Standalone Page OpenGraph', 'mc_form' ),
			'callback' => array( $this, 'standalone_opengraph' ),
		);

		$this->ui->tabs( $hor_tabs, false, true );
	}

	public function standalone_opengraph() {
		$op = $this->settings['opengraph'];
		MCForm_OpenGraph_Helper::admin_settings( 'settings[opengraph]', $this->ui, $op );
	}

	public function standalone_config() {
		$op = $this->settings['standalone'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[standalone][title]', __( 'Page Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[standalone][title]', $op['title'], __( 'Form Name', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the title of the page. Leaving empty will use the form name.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[standalone][description]', __( 'Meta Description', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[standalone][description]', $op['description'], __( 'Disabled', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the description of the page.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[standalone][image]', __( 'Feature Image', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->upload( 'settings[standalone][image]', $op['image'], '', __( 'Set Image', 'mc_form' ), __( 'Choose Image', 'mc_form' ), __( 'Use Image', 'mc_form' ), '100%', '150px', 'cover' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the feature image for open graph. Recommended size is 1200X613 pixels.', 'mc_form' ) ) ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function quiz_settings() {
		$hor_tabs = array();
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_ranking',
			'label' => __( 'Ranking System', 'mc_form' ),
			'callback' => array( $this, 'ranking' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_timer',
			'label' => __( 'Quiz Timer', 'mc_form' ),
			'callback' => array( $this, 'timer' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_stopwatch',
			'label' => __( 'Quiz Stopwatch', 'mc_form' ),
			'callback' => array( $this, 'stopwatch' ),
		);
		$this->ui->tabs( $hor_tabs, false, true );
	}

	public function result_email() {
		$hor_tabs = array();

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_social',
			'label' => __( 'Social Sharing', 'mc_form' ),
			'callback' => array( $this, 'social' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_user',
			'label' => __( 'User Notification', 'mc_form' ),
			'callback' => array( $this, 'user' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_admin',
			'label' => __( 'Admin Notification', 'mc_form' ),
			'callback' => array( $this, 'admin' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_email_template',
			'label' => __( 'Email Design', 'mc_form' ),
			'callback' => array( $this, 'email_template' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_summary',
			'label' => __( 'Summary Tables', 'mc_form' ),
			'callback' => array( $this, 'summary' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_trackback',
			'label' => __( 'Trackback Page', 'mc_form' ),
			'callback' => array( $this, 'trackback' ),
		);

		$this->ui->tabs( $hor_tabs, false, true );
	}

	public function wp_core() {
		$hor_tabs = array();

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_core_reg',
			'label' => __( 'User Registration', 'mc_form' ),
			'callback' => array( $this, 'wp_core_reg' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_core_guestpost',
			'label' => __( 'Guest/Frontend Posting', 'mc_form' ),
			'callback' => array( $this, 'wp_core_guestpost' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_core_user_meta',
			'label' => __( 'User Meta Update', 'mc_form' ),
			'callback' => array( $this, 'wp_core_user_meta' ),
		);
		$this->ui->tabs( apply_filters( 'mc_form_settings_core_tabs', $hor_tabs ), false, true );
	}

	public function wp_core_user_meta() {
		$op = $this->settings['core']['user_meta'];

		// Prepare data for sda
		$m_type_select = array(
			0 => array(
				'value' => 'mcq',
				'label' => __( '(M) MCQ', 'mc_form' ),
			),
			1 => array(
				'value' => 'freetype',
				'label' => __( '(F) Text Input', 'mc_form' ),
			),
			2 => array(
				'value' => 'pinfo',
				'label' => __( '(O) Others', 'mc_form' ),
			),
		);
		$sda_columns = array(
			0 => array(
				'label' => __( '(X)', 'mc_form' ),
				'size' => '25',
				'type' => 'select',
			),
			1 => array(
				'label' => __( '{KEY}', 'mc_form' ),
				'size' => '25',
				'type' => 'spinner',
			),
			2 => array(
				'label' => __( 'Meta Key (No Space, Underscore and alphabets only)', 'mc_form' ),
				'size' => '50',
				'type' => 'text',
			),
		);
		$sda_labels = array(
			'add' => __( 'Add New Meta', 'mc_form' ),
		);
		$sda_data_name_prefix = 'settings[core][user_meta][meta][__SDAKEY__]';
		$sda_data = array(
			0 => array( $sda_data_name_prefix . '[m_type]', $m_type_select, 'mcq', false, false, false, true, array( 'fit-text' ) ),
			1 => array( $sda_data_name_prefix . '[key]', '0', __( '{key}', 'mc_form' ), 0, 500 ),
			2 => array( $sda_data_name_prefix . '[meta_key]', '', '' ),
		);
		$sda_items = array();
		$sda_max_key = null;
		$sda_items_name_prefix = 'settings[core][user_meta][meta][%d]';
		foreach ( (array) $op['meta'] as $meta_key => $metadata ) {
			$sda_max_key = max( array( $sda_max_key, $meta_key ) );
			$sda_items[] = array(
				0 => array( sprintf( $sda_items_name_prefix . '[m_type]', $meta_key ), $m_type_select, $metadata['m_type'], false, false, false, true, array( 'fit-text' ) ),
				1 => array( sprintf( $sda_items_name_prefix . '[key]', $meta_key ), $metadata['key'], __( '{key}', 'mc_form' ), 0, 500 ),
				2 => array( sprintf( $sda_items_name_prefix . '[meta_key]', $meta_key ), $metadata['meta_key'], '' ),
			);
		}
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[core][user_meta][enabled]', __( 'Enable User Meta Update', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][user_meta][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_mcform_core_um_ma_wrap,mc_form_mcform_core_um_msda_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you wish to enable updating user metadata through this form, please enable it first. Other settings will follow.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_mcform_core_um_ma_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][user_meta][metaarray]', __( 'Store Array instead of Stringified Value', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][user_meta][metaarray]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['metaarray']  ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The element submission data will be stringified before being added as the metadata. You can change this behavior by changing the toggle.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_mcform_core_um_msda_wrap">
			<td colspan="3">
				<?php $this->ui->sda_list( array(
					'columns' => $sda_columns,
					'labels' => $sda_labels,
					'features' => array(
						'draggable' => false,
					),
				), $sda_items, $sda_data, $sda_max_key ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function wp_core_reg() {
		$op = $this->settings['core']['reg'];

		// Hide everything if user registration is turned off
		if ( ! get_option( 'users_can_register' ) ) {
			$this->ui->msg_error( sprintf( __( 'User Registration is disabled on your website. Please enable it first by going to <a href="%1$s" target="_blank">Settings > General</a> from your WordPress Dashboard.', 'mc_form' ), admin_url( 'options-general.php' ) ) );

			return;
		}

		// Prepare data for sda
		$m_type_select = array(
			0 => array(
				'value' => 'mcq',
				'label' => __( '(M) MCQ', 'mc_form' ),
			),
			1 => array(
				'value' => 'freetype',
				'label' => __( '(F) Text Input', 'mc_form' ),
			),
			2 => array(
				'value' => 'pinfo',
				'label' => __( '(O) Others', 'mc_form' ),
			),
		);
		$sda_columns = array(
			0 => array(
				'label' => __( '(X)', 'mc_form' ),
				'size' => '25',
				'type' => 'select',
			),
			1 => array(
				'label' => __( '{KEY}', 'mc_form' ),
				'size' => '25',
				'type' => 'spinner',
			),
			2 => array(
				'label' => __( 'Meta Key (No Space, Underscore and alphabets only)', 'mc_form' ),
				'size' => '50',
				'type' => 'text',
			),
		);
		$sda_labels = array(
			'add' => __( 'Add New Meta', 'mc_form' ),
		);
		$sda_data_name_prefix = 'settings[core][reg][meta][__SDAKEY__]';
		$sda_data = array(
			0 => array( $sda_data_name_prefix . '[m_type]', $m_type_select, 'mcq', false, false, false, true, array( 'fit-text' ) ),
			1 => array( $sda_data_name_prefix . '[key]', '0', __( '{key}', 'mc_form' ), 0, 500 ),
			2 => array( $sda_data_name_prefix . '[meta_key]', '', '' ),
		);
		$sda_items = array();
		$sda_max_key = null;
		$sda_items_name_prefix = 'settings[core][reg][meta][%d]';
		foreach ( (array) $op['meta'] as $meta_key => $metadata ) {
			$sda_max_key = max( array( $sda_max_key, $meta_key ) );
			$sda_items[] = array(
				0 => array( sprintf( $sda_items_name_prefix . '[m_type]', $meta_key ), $m_type_select, $metadata['m_type'], false, false, false, true, array( 'fit-text' ) ),
				1 => array( sprintf( $sda_items_name_prefix . '[key]', $meta_key ), $metadata['key'], __( '{key}', 'mc_form' ), 0, 500 ),
				2 => array( sprintf( $sda_items_name_prefix . '[meta_key]', $meta_key ), $metadata['meta_key'], '' ),
			);
		}
		$roles_item = array();
		$roles_item[] = array(
			'value' => 'wp_default',
			'label' => __( 'WordPress Default', 'mc_form' ),
		);
		$editable_roles = get_editable_roles();
		foreach ( $editable_roles as $role_key => $role ) {
			$roles_item[] = array(
				'value' => $role_key,
				'label' => $role['name'] . ' (' . $role_key . ')',
			);
		}
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[core][reg][enabled]', __( 'Enable User Registration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][reg][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_core_reg_uid_wrap,mc_form_core_reg_pid_wrap,mc_form_core_reg_meta_wrap,mc_form_core_reg_metaarray_wrap,mc_form_core_reg_metatitle_wrap,mc_form_core_reg_role_wrap,mc_form_core_reg_hide_pinfo_wrap,mc_form_core_reg_hide_meta_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you wish to enable user registration through this form, please enable it first. Other settings will follow.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_core_reg_uid_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][reg][username_id]', __( 'Username Field ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[core][reg][username_id]', $op['username_id'], __( 'ID', 'mc_form' ) ); ?>
				<div class="clear"></div>
				<span class="description"><?php _e( 'Mention ID (like <code>F12</code>) of a <strong>Text Input</strong> element from <strong>Text Input & Upload (F)</strong>.', 'mc_form' ); ?></span>
			</td>
			<td><?php $this->ui->help( __( 'You need to add a Text Input element from Text Input & Upload inside your form and mention the ID here. It will be used to create the username.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_core_reg_pid_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][reg][password_id]', __( 'Password Field ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[core][reg][password_id]', $op['password_id'], __( 'ID', 'mc_form' ) ); ?>
				<div class="clear"></div>
				<span class="description"><?php _e( 'Mention ID (like <code>O13</code>) of a <strong>Password</strong> element from <strong>Other Form Elements (O)</strong>.', 'mc_form' ); ?></span>
			</td>
			<td><?php $this->ui->help( __( 'You need to add a Password element from Other Form Elements inside your form and mention the ID here. It will be used to create the password.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_core_reg_hide_pinfo_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][reg][hide_pinfo]', __( 'Hide First Name, Last Name & Email for logged in users', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][reg][hide_pinfo]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['hide_pinfo'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If the form is viewed by logged in users, then username and password fields would always be hidden. But in case you would like to hide First Name, Last Name and Email fields too, then please enable this option.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_core_reg_role_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][reg][role]', __( 'Set Default Role', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[core][reg][role]', $roles_item, $op['role'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'By default the newly created user will have the default WordPress Role that you have set under Settings. If you wish mcForm to override this, please set another role here.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_core_reg_metatitle_wrap">
			<th colspan="2"><?php $this->ui->generate_label( 'settings[core][reg][meta]', __( 'Additional User Meta Data', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->help( __( 'If you want to add additional user metadata while registration, please mention the fields here.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_core_reg_metaarray_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][reg][metaarray]', __( 'Store Array instead of Stringified Value', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][reg][metaarray]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['metaarray']  ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The element submission data will be stringified before being added as the metadata. You can change this behavior by changing the toggle.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_core_reg_meta_wrap">
			<td colspan="3">
				<?php $this->ui->sda_list( array(
					'columns' => $sda_columns,
					'labels' => $sda_labels,
					'features' => array(
						'draggable' => false,
					),
				), $sda_items, $sda_data, $sda_max_key ); ?>
			</td>
		</tr>
		<tr id="mc_form_core_reg_hide_meta_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][reg][hide_meta]', __( 'Hide Specified Meta Elements for logged in users', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][reg][hide_meta]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['hide_meta'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enable to hide the elements you have specified above for logged in users.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function wp_core_guestpost() {
		$op = $this->settings['core']['post'];

		// Get post types
		$post_types = array(
			'post' => 'post',
			'page' => 'page',
		);
		// Add custom post types
		$post_types = array_merge( $post_types, (array) get_post_types( array(
			'public' => true,
			'_builtin' => false,
		), 'names' ) );

		$post_type_items = array();
		foreach ( $post_types as $post_type ) {
			$post_type_obj = get_post_type_object( $post_type );
			if ( is_null( $post_type_obj ) ) {
				continue;
			}
			$post_type_items[] = array(
				'label' => $post_type_obj->labels->singular_name,
				'value' => $post_type,
				'data' => array(
					'condid' => 'mc_form_settings_core_bio_post_tax_op_wrap_' . $post_type,
				),
			);
		}

		// Get taxonomies per post type
		$taxonomies = array();
		$taxonomies_single = array();
		$taxonomies_required = array();
		foreach ( $post_types as $post_type ) {
			$object_taxonomies = get_object_taxonomies( $post_type, 'objects' );
			$taxonomies[ $post_type ] = array();
			$taxonomies_single[ $post_type ] = array();
			$taxonomies_required[ $post_type ] = array();
			if ( ! empty( $object_taxonomies ) ) {
				// Create default set of data
				if ( ! isset( $op['taxnomy_single'][ $post_type ] ) ) {
					$op['taxnomy_single'][ $post_type ] = array();
				}
				if ( ! isset( $op['taxonomy_required'][ $post_type ] ) ) {
					$op['taxonomy_required'][ $post_type ] = array();
				}
				if ( ! isset( $op['taxonomies'][ $post_type ] ) ) {
					$op['taxonomies'][ $post_type ] = array();
				}

				// loop through and add taxonomies
				foreach ( $object_taxonomies as $objtxn ) {
					if ( true == $objtxn->public ) {
						$taxonomies[ $post_type ][] = array(
							'label' => $objtxn->label,
							'value' => $objtxn->name,
						);
						$taxonomies_single[ $post_type ][] = array(
							'label' => __( 'Can select only one', 'mc_form' ),
							'value' => $objtxn->name,
						);
						$taxonomies_required[ $post_type ][] = array(
							'label' => __( 'Compulsory', 'mc_form' ),
							'value' => $objtxn->name,
						);
					}
				}
			}
		}
		// Post status
		$post_statuses = get_post_statuses();
		// Prepare data for sda
		$m_type_select = array(
			0 => array(
				'value' => 'mcq',
				'label' => __( '(M) MCQ', 'mc_form' ),
			),
			1 => array(
				'value' => 'freetype',
				'label' => __( '(F) Text Input', 'mc_form' ),
			),
			2 => array(
				'value' => 'pinfo',
				'label' => __( '(O) Others', 'mc_form' ),
			),
		);
		$sda_columns = array(
			0 => array(
				'label' => __( '(X)', 'mc_form' ),
				'size' => '25',
				'type' => 'select',
			),
			1 => array(
				'label' => __( '{KEY}', 'mc_form' ),
				'size' => '25',
				'type' => 'spinner',
			),
			2 => array(
				'label' => __( 'Meta Key (No Space, Underscore and alphabets only)', 'mc_form' ),
				'size' => '50',
				'type' => 'text',
			),
		);
		$sda_labels = array(
			'add' => __( 'Add New Meta', 'mc_form' ),
		);
		$sda_data_name_prefix = 'settings[core][post][meta][__SDAKEY__]';
		$sda_data = array(
			0 => array( $sda_data_name_prefix . '[m_type]', $m_type_select, 'mcq', false, false, false, true, array( 'fit-text' ) ),
			1 => array( $sda_data_name_prefix . '[key]', '0', __( '{key}', 'mc_form' ), 0, 500 ),
			2 => array( $sda_data_name_prefix . '[meta_key]', '', '' ),
		);
		$sda_items = array();
		$sda_max_key = null;
		$sda_items_name_prefix = 'settings[core][post][meta][%d]';
		foreach ( (array) $op['meta'] as $meta_key => $metadata ) {
			$sda_max_key = max( array( $sda_max_key, $meta_key ) );
			$sda_items[] = array(
				0 => array( sprintf( $sda_items_name_prefix . '[m_type]', $meta_key ), $m_type_select, $metadata['m_type'], false, false, false, true, array( 'fit-text' ) ),
				1 => array( sprintf( $sda_items_name_prefix . '[key]', $meta_key ), $metadata['key'], __( '{key}', 'mc_form' ), 0, 500 ),
				2 => array( sprintf( $sda_items_name_prefix . '[meta_key]', $meta_key ), $metadata['meta_key'], '' ),
			);
		}
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[core][post][enabled]', __( 'Enable Guest Posting', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][post][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_settings_core_post_uid_wrap,mc_form_settings_core_post_bio_wrap,mc_form_settings_core_post_gms_wrap,mc_form_settings_core_post_type_wrap,mc_form_settings_core_post_biotitle_wrap,mc_form_settings_core_taxnomies_wrap,mc_form_core_post_status_wrap,mc_form_core_post_metatitle_wrap,mc_form_core_post_metaarray_wrap,mc_form_core_post_meta_wrap,mc_form_settings_core_post_fm_wrap,mc_form_settings_core_post_adms_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you wish to enable guest posting this form, please enable it first. Other settings will follow. You will also need to place a Guest Blogging Element inside your form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_core_post_uid_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][user_id]', __( 'Map Post to User (ID)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[core][post][user_id]', $op['user_id'], __( 'ID', 'mc_form' ), '1' ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Mention the ID of the user to whom the guest post would be mapped. If you have registration enabled under the same form then this will be ignored and the guest post would be created under the newly registered user. If user is logged in, then also it will be ignored and the post would be mapped to the current logged in user.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_settings_core_post_bio_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][bio]', __( 'Show field for entering author bio', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][post][bio]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['bio'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you wish to collect author biography then please enable this option. It will show a textarea through which author can post their biography. It will be saved as a metadata under the created draft. This will not show up for logged in users.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_core_post_biotitle_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][bio_title]', __( 'Bio Field Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[core][post][bio_title]', $op['bio_title'], __( 'Write here', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enter the label that will be shown beside the bio field.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_settings_core_post_fm_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][feature_image]', __( 'Upload Element for Feature Image', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[core][post][feature_image]', $op['feature_image'], __( 'ID of Upload Element', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php _e( 'Make sure the upload element has only one image upload and WordPress Media Integration is turned on.', 'mc_form' ); ?></span>
			</td>
			<td><?php $this->ui->help( __( 'If you want to add feature images through frontend, then enter the ID of the upload element here. Make sure the upload element has only one image upload and WordPress Media Integration is turned on.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_settings_core_post_adms_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][add_msg]', __( 'Additional Content', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[core][post][add_msg]', $op['add_msg'], __( 'HTML Enabled', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'This content will be added at the end of the guest post automatically. All format strings are supported.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_settings_core_post_gms_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][guest_msg]', __( 'Editor\'s Note', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[core][post][guest_msg]', $op['guest_msg'], __( 'HTML Enabled', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'If you want to automatically add some editor\'s note to the submitted article then you can put it here. This field is HTML enabled. Possible format strings are <code>%NAME%, %BIO%, %AVATAR%</code>. This would be added only for non-logged in users.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_settings_core_post_type_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][post_type]', __( 'Select Post Type', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[core][post][post_type]', $post_type_items, $op['post_type'], false, true ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'You can put the draft under any custom post type too. Please select your desired post type.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_core_taxnomies_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][taxonomies]', __( 'Select Taxonomies to show', 'mc_form' ) ); ?></th>
			<td>
				<?php foreach ( $taxonomies as $p_type => $p_txm_items ) : ?>
					<div id="mc_form_settings_core_bio_post_tax_op_wrap_<?php echo $p_type; ?>">
						<?php if ( empty( $p_txm_items ) ) : ?>
							<?php $this->ui->msg_update( __( 'No registered taxonomies for this post type.', 'mc_form' ) ); ?>
							<?php echo '</div>'; ?>
							<?php continue; ?>
						<?php endif; ?>
						<table style="width: 100%;">
							<tbody>
								<tr>
									<td>
										<?php $this->ui->checkboxes( 'settings[core][post][taxonomies][' . $p_type . '][]', $p_txm_items, $op['taxonomies'][ $p_type ], false, false, '<div class="clear"></div>' ); ?>
									</td>
									<td>
										<?php $this->ui->checkboxes( 'settings[core][post][taxnomy_single][' . $p_type . '][]', $taxonomies_single[ $p_type ], $op['taxnomy_single'][ $p_type ], false, false, '<div class="clear"></div>' ); ?>
									</td>
									<td>
										<?php $this->ui->checkboxes( 'settings[core][post][taxonomy_required][' . $p_type . '][]', $taxonomies_required[ $p_type ], $op['taxonomy_required'][ $p_type ], false, false, '<div class="clear"></div>' ); ?>
									</td>
								</tr>
							</tbody>
						</table>

					</div>
					<?php ?>
				<?php endforeach; ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you wish to let the author select taxonomies while submitting the post, then you can select which taxonomies to show. You can select multiple taxonomies and the list will be populated automatically. If you select "Can select only one" then radio buttons would appear instead of checkboxes.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_core_post_status_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][status]', __( 'Set Post Status', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[core][post][status]', $post_statuses, $op['status'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Set the post status you would like the article to publish with. It is recommended to use Draft.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_core_post_metatitle_wrap">
			<th colspan="2"><?php $this->ui->generate_label( 'settings[core][post][meta]', __( 'Additional Post Meta Data', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->help( __( 'If you want to add additional post metadata while submitting, please mention the fields here.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_core_post_metaarray_wrap">
			<th><?php $this->ui->generate_label( 'settings[core][post][metaarray]', __( 'Store Array instead of Stringified Value', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[core][post][metaarray]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['metaarray']  ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The element submission data will be stringified before being added as the metadata. You can change this behavior by changing the toggle.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_core_post_meta_wrap">
			<td colspan="3">
				<?php $this->ui->sda_list( array(
					'columns' => $sda_columns,
					'labels' => $sda_labels,
					'features' => array(
						'draggable' => false,
					),
				), $sda_items, $sda_data, $sda_max_key ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function integration() {
		$hor_tabs = array();

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_intg_cond',
			'label' => __( 'Conditional Activation', 'mc_form' ),
			'callback' => array( $this, 'intg_conditional' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_mailchimp',
			'label' => __( 'MailChimp', 'mc_form' ),
			'callback' => array( $this, 'mailchimp' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_aweber',
			'label' => __( 'Aweber', 'mc_form' ),
			'callback' => array( $this, 'aweber' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_get_response',
			'label' => __( 'Get Response', 'mc_form' ),
			'callback' => array( $this, 'get_response' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_campaign_monitor',
			'label' => __( 'Campaign Monitor', 'mc_form' ),
			'callback' => array( $this, 'campaign_monitor' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_mymail',
			'label' => __( 'Mailster (MyMail)', 'mc_form' ),
			'callback' => array( $this, 'mymail' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_sendy',
			'label' => __( 'Sendy.co', 'mc_form' ),
			'callback' => array( $this, 'sendy' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_active_campaign',
			'label' => __( 'Active Campaign', 'mc_form' ),
			'callback' => array( $this, 'active_campaign' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_mailpoet',
			'label' => __( 'MailPoet 2', 'mc_form' ),
			'callback' => array( $this, 'mailpoet' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_mailpoet3',
			'label' => __( 'MailPoet 3', 'mc_form' ),
			'callback' => array( $this, 'mailpoet3' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_mailerlite',
			'label' => __( 'MailerLite', 'mc_form' ),
			'callback' => array( $this, 'mailerlite' ),
		);

		$hor_tabs[] = [
			'id' => 'mc_form_settings_mailwizz',
			'label' => __( 'MailWizz', 'mc_form' ),
			'callback' => [ $this, 'mailwizz' ],
		];

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_enormail',
			'label' => __( 'Enormail', 'mc_form' ),
			'callback' => array( $this, 'enormail' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_convertkit',
			'label' => __( 'Convertkit', 'mc_form' ),
			'callback' => array( $this, 'convertkit' ),
		);

		$hor_tabs[] = array(
			'id' => 'mc_form_settings_formhandler',
			'label' => __( 'Webhook (Custom URL)', 'mc_form' ),
			'callback' => array( $this, 'formhandler_integration' ),
		);

		$hor_tabs = apply_filters( 'mc_form_integration_settings_tabs', $hor_tabs, $this );

		$this->ui->tabs( $hor_tabs, false, true );
	}

	public function general() {
		$form_categories = array(
			array(
				'value' => '0',
				'label' => __( 'None', 'mc_form' ),
			),
		);
		$db_categories = MC_FORM_Form_Elements_Static::get_all_categories();
		if ( null != $db_categories ) {
			foreach ( $db_categories as $dbc ) {
				$form_categories[] = array(
					'value' => $dbc->id,
					'label' => $dbc->name,
				);
			}
		}
?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'category', __( 'Form Category', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'category', $form_categories, $this->category ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the category of the form for quick filtering.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[general][pipe]', __( 'Interactive Form', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[general][pipe]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['general']['pipe'] ); ?>
				<span class="description"><?php _e( 'Pipe Element Values to Labels and Description with template tags like <code>%M0%, %F2%, %O11%</code> etc.', 'mc_form' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enable this settings to have interactive forms. Once enabled, you can use the template tags in the format <code>%(X){KEY}%</code>. For example, if you wish to substitute the element <code>(M){12}</code>, then just write <code>%M12</code> in any label, option label or description or richtext. If for some reason, you would like to just include the keyword as <code>%M12%</code> as is, then you need to escape it like <code>%%M12%%</code>.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[general][terms_page]', __( 'Terms & Condition Page', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->dropdown_pages( array(
				'selected' => $this->settings['general']['terms_page'],
				'name' => 'settings[general][terms_page]',
				'show_option_none' => __( 'None -- Do not show', 'mc_form' ),
				'option_none_value' => '0'
			) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If any page ID is given here, then user will be presented with a checkbox which he/she has to check before submitting. This will lead to the specified page on click (depending on the terms phrase).', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[general][terms_phrase]', __( 'Terms Phrase', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[general][terms_phrase]', $this->settings['general']['terms_phrase'], __( 'Disabled', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the phrase of the terms and condition. <code>%1$s</code> will be replaced by the link to the page and <code>%2$s</code> will be replaced by the IP Address of the user.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[general][comment_title]', __( 'Administrator Remarks Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[general][comment_title]', $this->settings['general']['comment_title'], __( 'Disabled', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the Remarks title that will be shown on the print section and the track page. Leave it empty to disable this feature.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[general][default_comment]', __( 'Default Administrator Remarks', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[general][default_comment]', $this->settings['general']['default_comment'], __( 'Enter default administrator remarks', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the default Remarks that will automatically added to the database while submitting the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[general][can_edit]', __( 'Users Can Edit Submission', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[general][can_edit]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['general']['can_edit'], '1', false, true, array(
					'condid' => 'mc_form_general_edit_time_wrap',
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then registered users can edit their submissions through the User Portal page.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_general_edit_time_wrap">
			<th><?php $this->ui->generate_label( 'settings[general][edit_time]', __( 'Edit Time Limit (in hours)', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->spinner( 'settings[general][edit_time]', $this->settings['general']['edit_time'], __( 'Always', 'mc_form' ) ); ?></td>
			<td><?php $this->ui->help( __( 'Limit the edit time in hours. Can be fraction. Also a zero value or an empty or a negative value means unlimited.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function user() {
		$op = $this->settings['user'];
?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][notification_email]', __( 'Sender\'s Email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[user][notification_email]', $op['notification_email'], __( 'Disabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the email which the user will see as the Sender\'s Email on the email he/she receives. It is recommended to use an email from the same domain. Otherwise it might end up into spams. Entering an empty email will stop the user notification service. So leave it empty to disable sending emails to users.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][notification_from]', __( 'Sender\'s Name', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[user][notification_from]', $op['notification_from'], __( 'Enter sender\'s name', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the name which the user will see as the Sender\'s Name on the email he/she receives.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][notification_sub]', __( 'Notification Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[user][notification_sub]', $op['notification_sub'], __( 'Enter the subject', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'Enter the subject of the notification email of the user/surveyee. Following format strings are available.', 'mc_form' ); ?></p>
				<ul class="ul-square">
					<li><code>%FORMNAME%</code> : <?php _e( 'Replaced by the Form Name.', 'mc_form' ); ?></li>
					<li><code>%SITENAME%</code> : <?php _e( 'Replaced by the Site name.', 'mc_form' ); ?></li>
					<li><code>%FNAME%</code> : <?php _e( 'Replaced by the user\'s first name.', 'mc_form' ); ?></li>
					<li><code>%LNAME%</code> : <?php _e( 'Replaced by the user\'s last name.', 'mc_form' ); ?></li>
					<li><code>%PHONE%</code> : <?php _e( 'Replaced by the user\'s phone number.', 'mc_form' ); ?></li>
					<li><code>%EMAIL%</code> : <?php _e( 'Replaced by the user\'s email address.', 'mc_form' ); ?></li>
				</ul>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][notification_msg]', __( 'Notification Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[user][notification_msg]', $op['notification_msg'], __( 'Enter the message', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
					<p><?php _e( 'Enter the message that you want to send to the user/surveyee on form submission. Paragraphs and line breaks will be added automatically. In addition you can also put custom HTML code. You can use a few format strings which will be replaced by their corresponding values.', 'mc_form' ) ?></p>
					<ul class="ul-square">
						<li><strong>%NAME%</strong> : <?php _e( 'Will be replaced by the full name of the user.', 'mc_form' ); ?></li>
						<li><strong>%TRACK_LINK%</strong> : <?php _e( 'Will be replaced by the raw link from where the user can see the status of his submission.', 'mc_form' ); ?></li>
						<li><strong>%TRACK%</strong> : <?php _e( 'Will be replaced by a "Click Here" button linked to the track page.', 'mc_form' ); ?></li>
						<li><strong>%SCORE%</strong> : <?php _e( 'Will be replaced by the score obtained/total score.', 'mc_form' ); ?></li>
						<li><strong>%OSCORE%</strong> : <?php _e( 'Will be replaced by the score obtained.', 'mc_form' ); ?></li>
						<li><strong>%MSCORE%</strong> : <?php _e( 'Will be replaced by the total score.', 'mc_form' ); ?></li>
						<li><strong>%SCOREPERCENT%</strong> : <?php _e( 'Will be replaced by the percentage score obtained.', 'mc_form' ); ?></li>
						<li><strong>%DESIGNATION%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation title.', 'mc_form' ); ?></li>
						<li><strong>%DESIGNATIONMSG%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation message.', 'mc_form' ); ?></li>
						<li><strong>%TRACK_ID%</strong> : <?php _e( 'Will be replaced by the Tracking ID of the submission which the user can enter in the track page.', 'mc_form' ); ?></li>
						<li><strong>%SUBMISSION_ID%</strong> : <?php _e( 'Will be replaced by the ID of the submission.', 'mc_form' ); ?></li>
						<li><strong>%PORTAL%</strong> : <?php _e( 'Will be replaced by the raw link of the user portal page from where registered users can see all their submissions.', 'mc_form' ); ?></li>
					</ul>
					<p><?php _e( 'If you are using the %TRACK_LINK% make sure you have placed <code>[mc_form_track]</code> on some page/post and have entered its ID in the settings section.', 'mc_form' ); ?></p>
					<p><?php printf( __( 'An updated list can always be found <a href="%1$s" target="_blank">here</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/form-submission-related/available-format-strings-custom-notifications/' ); ?></p>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][update_sub]', __( 'Form Update Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[user][update_sub]', $op['update_sub'], __( 'Enter the subject', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'Enter the subject of the notification email if the user updates an existing submission. Following format strings are available.', 'mc_form' ); ?></p>
				<ul class="ul-square">
					<li><code>%FORMNAME%</code> : <?php _e( 'Replaced by the Form Name.', 'mc_form' ); ?></li>
					<li><code>%SITENAME%</code> : <?php _e( 'Replaced by the Site name.', 'mc_form' ); ?></li>
					<li><code>%FNAME%</code> : <?php _e( 'Replaced by the user\'s first name.', 'mc_form' ); ?></li>
					<li><code>%LNAME%</code> : <?php _e( 'Replaced by the user\'s last name.', 'mc_form' ); ?></li>
					<li><code>%PHONE%</code> : <?php _e( 'Replaced by the user\'s phone number.', 'mc_form' ); ?></li>
					<li><code>%EMAIL%</code> : <?php _e( 'Replaced by the user\'s email address.', 'mc_form' ); ?></li>
				</ul>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][update_msg]', __( 'Update Notification Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[user][update_msg]', $op['update_msg'], __( 'Enter the message', 'mc_form' ), 'large' ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
					<p><?php _e( 'Enter the message that you want to send to the user/surveyee on form updation. Paragraphs and line breaks will be added automatically. In addition you can also put custom HTML code. You can use a few format strings which will be replaced by their corresponding values.', 'mc_form' ) ?></p>
					<ul class="ul-square">
						<li><strong>%NAME%</strong> : <?php _e( 'Will be replaced by the full name of the user.', 'mc_form' ); ?></li>
						<li><strong>%TRACK_LINK%</strong> : <?php _e( 'Will be replaced by the raw link from where the user can see the status of his submission.', 'mc_form' ); ?></li>
						<li><strong>%TRACK%</strong> : <?php _e( 'Will be replaced by a "Click Here" button linked to the track page.', 'mc_form' ); ?></li>
						<li><strong>%SCORE%</strong> : <?php _e( 'Will be replaced by the score obtained/total score.', 'mc_form' ); ?></li>
						<li><strong>%OSCORE%</strong> : <?php _e( 'Will be replaced by the score obtained.', 'mc_form' ); ?></li>
						<li><strong>%MSCORE%</strong> : <?php _e( 'Will be replaced by the total score.', 'mc_form' ); ?></li>
						<li><strong>%SCOREPERCENT%</strong> : <?php _e( 'Will be replaced by the percentage score obtained.', 'mc_form' ); ?></li>
						<li><strong>%DESIGNATION%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation title.', 'mc_form' ); ?></li>
						<li><strong>%DESIGNATIONMSG%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation message.', 'mc_form' ); ?></li>
						<li><strong>%TRACK_ID%</strong> : <?php _e( 'Will be replaced by the Tracking ID of the submission which the user can enter in the track page.', 'mc_form' ); ?></li>
						<li><strong>%SUBMISSION_ID%</strong> : <?php _e( 'Will be replaced by the ID of the submission.', 'mc_form' ); ?></li>
						<li><strong>%PORTAL%</strong> : <?php _e( 'Will be replaced by the raw link of the user portal page from where registered users can see all their submissions.', 'mc_form' ); ?></li>
					</ul>
					<p><?php _e( 'If you are using the %TRACK_LINK% make sure you have placed <code>[mc_form_track]</code> on some page/post and have entered its ID in the settings section.', 'mc_form' ); ?></p>
					<p><?php printf( __( 'An updated list can always be found <a href="%1$s" target="_blank">here</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/form-submission-related/available-format-strings-custom-notifications/' ); ?></p>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][header]', __( 'Additional Email Header', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[user][header]', $op['header'], __( 'One per line', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'You can enter one custom header per line. This field accepts all format strings. Do note that, headers like <strong><code>Cc, Reply-To</code></strong> are already managed by FORM and should be avoided.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][email_logo]', __( 'Email Logo', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->upload( 'settings[user][email_logo]', $op['email_logo'], '', __( 'Set Logo', 'mc_form' ), __( 'Choose Image', 'mc_form' ), __( 'Use Image', 'mc_form' ), '90%', '150px', 'auto' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the logo image that will be used in the email sent to the user. Image size should be 150X28px and with transparent background.', 'mc_form' ) ) ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][top_line]', __( 'Show the header line', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[user][top_line]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['top_line']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled then this will show a header line with link to the trackback page. Keep this enabled to allow users to view the submission through browser.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][form_name]', __( 'Show form name', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[user][form_name]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['form_name']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled then this will show the name of the form in a headline manner.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][show_submission]', __( 'Attach Submission to user email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[user][show_submission]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['show_submission']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want to attach the complete submission to the user email, then enable it here.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][view_online]', __( 'View Online Button', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[user][view_online]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['view_online']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Show a button with view online text. It will be linked to the trackback page.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][view_online_text]', __( 'Button Text', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->text( 'settings[user][view_online_text]', $op['view_online_text'], '', 'large' ); ?></td>
			<td><?php $this->ui->help( __( 'The text of the button.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][footer_msg]', __( 'Email Footer Message', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->text( 'settings[user][footer_msg]', $op['footer_msg'], '', 'large' ); ?></td>
			<td><?php $this->ui->help( __( 'The footer message of the email. This is usually unscription link or instruction.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[user][smtp]', __( 'Use SMTP Emailing', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[user][smtp]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['smtp'], '1', false, true, array(
					'condid' => 'mc_form_form_settings_smtp_enc_type_wrap,mc_form_form_settings_smtp_host_wrap,mc_form_form_settings_smtp_port_wrap,mc_form_form_settings_smtp_username_wrap,mc_form_form_settings_smtp_password_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want to send email using SMTP method then enable it here and enter the settings.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_form_settings_smtp_enc_type_wrap">
			<th><?php $this->ui->generate_label( 'settings[user][smtp_config][enc_type]', __( 'Encryption Type', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[user][smtp_config][enc_type]', array(
					array(
						'value' => '',
						'label' => __( 'None', 'mc_form' ),
					),
					array(
						'value' => 'ssl',
						'label' => __( 'SSL', 'mc_form' ),
					),
					array(
						'value' => 'tls',
						'label' => __( 'TLS', 'mc_form' ),
					),
				), $op['smtp_config']['enc_type'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'For most servers SSL is the recommended option.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_form_settings_smtp_host_wrap">
			<th><?php $this->ui->generate_label( 'settings[user][smtp_config][host]', __( 'SMTP Host', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->text( 'settings[user][smtp_config][host]', $op['smtp_config']['host'], __( 'eg: smtp.gmail.com', 'mc_form' ), 'large' ); ?></td>
			<td><?php $this->ui->help( __( 'Enter the host of your SMTP server.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_form_settings_smtp_port_wrap">
			<th><?php $this->ui->generate_label( 'settings[user][smtp_config][port]', __( 'SMTP port', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->spinner( 'settings[user][smtp_config][port]', $op['smtp_config']['port'], __( 'Port', 'mc_form' ) ); ?></td>
			<td><?php $this->ui->help( __( 'Enter the port of your SMTP server.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_form_settings_smtp_username_wrap">
			<th><?php $this->ui->generate_label( 'settings[user][smtp_config][username]', __( 'SMTP Username', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->text( 'settings[user][smtp_config][username]', $op['smtp_config']['username'], __( 'eg: smtp.gmail.com', 'mc_form' ), 'large' ); ?></td>
			<td><?php $this->ui->help( __( 'Enter the username you use to login.', 'mc_form' ) ); ?></td>
		</tr>
		<?php $password = $op['smtp_config']['password']; ?>
		<?php if ( $password != '' ) $password = $this->decrypt( $password ); ?>
		<tr id="mc_form_form_settings_smtp_password_wrap">
			<th><?php $this->ui->generate_label( 'settings[user][smtp_config][password]', __( 'SMTP password', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->password( 'settings[user][smtp_config][password]', $password, 'large' ); ?></td>
			<td><?php $this->ui->help( __( 'Enter the password you use to login. Please note that it is always encrypted before storing in database.', 'mc_form' ) ); ?></td>
		</tr>
		<?php do_action( 'mc_mcform_settings_user', $op, $this ); ?>
	</tbody>
</table>
		<?php
	}

	public function admin() {
		$op = $this->settings['admin'];
		$cond_email_data = array();
		foreach ( (array) $op['conditional'] as $item_key => $item ) {
			$new_cond_email_data = array();
			foreach ( $item as $data_key => $data ) {
				if ( 'logics' == $data_key ) {
					$new_cond_email_data[ $data_key ] = $data;
				} else {
					$new_cond_email_data[ $data_key ] = array( 'settings[admin][conditional][' . $item_key . '][' . $data_key . ']', $data, __( 'Required', 'mc_form' ) );
				}
			}
			if ( ! isset( $new_cond_email_data['logics'] ) ) {
				$new_cond_email_data['logics'] = array();
			}
			$cond_email_data[ $item_key ] = $new_cond_email_data;
		}

		$cond_email = array(
			'name_prefix' => 'settings[admin][conditional]',
			'configs' => array(),
			'cond_suffix' => 'logics',
			'cond_id' => 'mcform_admin_cond_url_wrap',
			'data' => $cond_email_data,
		);
		$cond_email['configs'][0] = array(
			'label' => __( 'Email (Comma Separated)', 'mc_form' ),
			'type' => 'text',
			'size' => '100',
			'data' => array( 'settings[admin][conditional][__SDAKEY__][email]', '', __( 'Required', 'mc_form' ) ),
		);
?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][email]', __( 'Admin Notification Email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[admin][email]', $op['email'], __( 'Enter admin email', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the email address where the notification email will be sent. Make sure you have set anti-spam filter for wordpress@yourdomain.tld otherwise automated emails might go into spam folder.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr><th colspan="3"><?php $this->ui->generate_label( 'settings[admin][conditional]', __( 'Conditional Admin Email', 'mc_form' ) ); ?></th></tr>
		<tr><td colspan="3">
		<?php $this->build_conditional_config( $cond_email['name_prefix'], $cond_email['configs'], $cond_email['cond_suffix'], $cond_email['cond_id'], $cond_email['data'] ); ?>
		</td></tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][from]', __( 'Admin Notification From Email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[admin][from]', $op['from'], __( 'Enter from email', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want to change the "FROM" for admin notification email, set an email address here. Make sure the email is under the same domain of your website. Otherwise it might get spammed.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][from_name]', __( 'Admin Notification From Name', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[admin][from_name]', $op['from_name'], __( 'Enter sender name', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'By default the senders name is the website name. If you wish to change it, then please specify here.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][header]', __( 'Additional Email Header', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[admin][header]', $op['header'], __( 'One per line', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'You can enter one custom header per line. This field accepts all format strings. Do note that, headers like <strong><code>cc, Reply-To</code></strong> are already managed by FORM and should be avoided.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][email_logo]', __( 'Email Logo', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->upload( 'settings[admin][email_logo]', $op['email_logo'], '', __( 'Set Logo', 'mc_form' ), __( 'Choose Image', 'mc_form' ), __( 'Use Image', 'mc_form' ), '90%', '150px', 'auto' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the logo image that will be used in the email sent to the admin. Image size should be 150X28px and with transparent background.', 'mc_form' ) ) ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][sub]', __( 'New Submission Notification Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[admin][sub]', $op['sub'], __( 'Enter Subject Line', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
					<p><?php _e( 'Enter a descriptive and short subject line. The following format strings are available.', 'mc_form' ); ?></p>
					<ul class="ul-square">
						<li><code>%FORMNAME%</code> : <?php _e( 'Replaced by the Form Name.', 'mc_form' ); ?></li>
						<li><code>%SITENAME%</code> : <?php _e( 'Replaced by the Site name.', 'mc_form' ); ?></li>
						<li><code>%FNAME%</code> : <?php _e( 'Replaced by the user\'s first name.', 'mc_form' ); ?></li>
						<li><code>%LNAME%</code> : <?php _e( 'Replaced by the user\'s last name.', 'mc_form' ); ?></li>
						<li><code>%PHONE%</code> : <?php _e( 'Replaced by the user\'s phone number.', 'mc_form' ); ?></li>
						<li><code>%EMAIL%</code> : <?php _e( 'Replaced by the user\'s email address.', 'mc_form' ); ?></li>
					</ul>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][usub]', __( 'Update Notification Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[admin][usub]', $op['usub'], __( 'Enter Subject Line', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
					<p><?php _e( 'Enter a descriptive and short subject line. The following format strings are available.', 'mc_form' ); ?></p>
					<ul class="ul-square">
						<li><code>%FORMNAME%</code> : <?php _e( 'Replaced by the Form Name.', 'mc_form' ); ?></li>
						<li><code>%SITENAME%</code> : <?php _e( 'Replaced by the Site name.', 'mc_form' ); ?></li>
						<li><code>%FNAME%</code> : <?php _e( 'Replaced by the user\'s first name.', 'mc_form' ); ?></li>
						<li><code>%LNAME%</code> : <?php _e( 'Replaced by the user\'s last name.', 'mc_form' ); ?></li>
						<li><code>%PHONE%</code> : <?php _e( 'Replaced by the user\'s phone number.', 'mc_form' ); ?></li>
						<li><code>%EMAIL%</code> : <?php _e( 'Replaced by the user\'s email address.', 'mc_form' ); ?></li>
					</ul>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][fsub]', __( 'Feedback Notification Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[admin][fsub]', $op['fsub'], __( 'Enter Subject Line', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
					<p><?php _e( 'Enter a descriptive and short subject line. The following format strings are available.', 'mc_form' ); ?></p>
					<ul class="ul-square">
						<li><code>%FORMNAME%</code> : <?php _e( 'Replaced by the Form Name.', 'mc_form' ); ?></li>
						<li><code>%SITENAME%</code> : <?php _e( 'Replaced by the Site name.', 'mc_form' ); ?></li>
						<li><code>%ENAME%</code> : <?php _e( 'Will be replaced by the title of the element.', 'mc_form' ); ?></li>
						<li><code>%FNAME%</code> : <?php _e( 'Replaced by the user\'s first name.', 'mc_form' ); ?></li>
						<li><code>%LNAME%</code> : <?php _e( 'Replaced by the user\'s last name.', 'mc_form' ); ?></li>
						<li><code>%PHONE%</code> : <?php _e( 'Replaced by the user\'s phone number.', 'mc_form' ); ?></li>
						<li><code>%EMAIL%</code> : <?php _e( 'Replaced by the user\'s email address.', 'mc_form' ); ?></li>
					</ul>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][top_line]', __( 'Show the header line', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[admin][top_line]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['top_line']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled then this will show a header line with link to the admin management page.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][summary_header]', __( 'Show form information on general admin email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[admin][summary_header]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['summary_header']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled then this will show basic form information.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][f_summary_header]', __( 'Show form information on feedback email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[admin][f_summary_header]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['f_summary_header']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled then this will show basic form information.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][user_info]', __( 'Show user information on general admin email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[admin][user_info]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['user_info']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled then this will show basic user information.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][f_user_info]', __( 'Show user information on feedback email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[admin][f_user_info]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['f_user_info']); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled then this will show basic user information.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][body]', __( 'New Submission Notification Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[admin][body]', $op['body'], __( 'Enter message', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter a descriptive admin notification message here. <code>%ADMINLINK%</code> will be replaced by administrative link for the submission.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][ubody]', __( 'Submission Update Notification Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[admin][ubody]', $op['ubody'], __( 'Enter message', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter a descriptive admin notification message here. <code>%ADMINLINK%</code> will be replaced by administrative link for the submission.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][mail_submission]', __( 'Email Submission to Admin', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[admin][mail_submission]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['mail_submission'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Tick this, if you wish to send the full submission detail to the admin email', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][send_from_user]', __( 'Email on behalf of User', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[admin][send_from_user]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['send_from_user'], '1', false, true, array(
					'condid' => 'mc_form_settings_admin_rto',
				) ); ?>
				<p class="description"><?php _e( 'will remove sensitive links from the email.', 'mc_form' ); ?></p>
			</td>
			<td>
				<?php $this->ui->help( __( 'Tick this, if you wish to receive the email on behalf of the user. Otherwise email is sent from the WordPress email.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_admin_rto">
			<th><?php $this->ui->generate_label( 'settings[admin][reply_to_only]', __( 'Just add Reply-To', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[admin][reply_to_only]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['reply_to_only'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Instead of changing the FROM address, only add a reply-to header. This is useful for avoiding email blacklisting like <a href="https://yahoomail.tumblr.com/post/82426900353/yahoo-dmarc-policy-change-what-should-senders">Yahoo DMARC</a>.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[admin][footer]', __( 'Admin Notification Footer Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[admin][footer]', $op['footer'], __( 'Enter admin footer message', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter a descriptive admin notification footer message here.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<?php do_action( 'mc_mcform_settings_admin', $op, $this ); ?>
	</tbody>
</table>
		<?php
	}

	public function limitation() {
		$op = $this->settings['limitation'];
		$login_select = array(
			0 => array(
				'label' => __( 'Show Login Form', 'mc_form' ),
				'value' => 'show_login',
			),
			1 => array(
				'label' => __( 'Redirect to the mentioned page', 'mc_form' ),
				'value' => 'redirect',
			),
		);
?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][email_limit]', __( 'Submission Limit Per Email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[limitation][email_limit]', $op['email_limit'], __( '0 to disable', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Select the maximum number of submissions per email address. Leave 0 to disable this check.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][ip_limit]', __( 'Submission Limit Per IP Address', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[limitation][ip_limit]', $op['ip_limit'], __( '0 to disable', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Select the maximum number of submissions per IP address. Leave 0 to disable this check.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][user_limit]', __( 'Submission Limit Per Registered User', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[limitation][user_limit]', $op['user_limit'], __( '0 to disable', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Select the maximum number of submissions per registered user. Leave 0 to disable this check.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][ip_limit_msg]', __( 'IP Limitation Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][ip_limit_msg]', $op['ip_limit_msg'], __( 'Please enter a message', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter a message you want to show to when ip limit has been exceeded.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][user_limit_msg]', __( 'Message Shown to Registered Users', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][user_limit_msg]', $op['user_limit_msg'], __( 'Please enter a message', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter a message you want to show to registered users who has exceeded their limit. Use placeholder <code>%PORTAL_LINK%</code> to replace it by User Portal Page permalink.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][total_limit]', __( 'Total Submission Limit', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[limitation][total_limit]', $op['total_limit'], __( '0 to disable', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Select the maximum number of overall submissions for the form. Leave 0 to disable this check.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][total_msg]', __( 'Message Shown if Total Limit is enabled', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][total_msg]', $op['total_msg'], __( 'Please enter a message', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want to show how many submissions are left on the top of your form, enter a message here. <code>%1$d</code> will be replaced by total available submissions whereas <code>%2$d</code> will be replaced by total number of submissions.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][total_limit_msg]', __( 'Message Shown to Exceeded Total Limit', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][total_limit_msg]', $op['total_limit_msg'], __( 'Please enter a message', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter a message you want to show to users when the limit has exceeded.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][cookie_limit]', __( 'Cookie Submission Limit', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[limitation][cookie_limit]', $op['cookie_limit'], __( '0 to disable', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Select the maximum number of submission per user session. A Cookie will be set on the client browser to prevent future submissions.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][cookie_limit_msg]', __( 'Message Shown to Exceeded Cookie Limit', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][cookie_limit_msg]', $op['cookie_limit_msg'], __( 'Please enter a message', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter a message you want to show to users when the cookie limit has exceeded.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][logged_in]', __( 'Only Logged In user can submit', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[limitation][logged_in]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['logged_in'], '1', false, true, array(
					'condID' => 'mc_form_settings_limitation_logged_in_fb_wrap,mc_form_settings_limitation_nlr_wrap',
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then only logged in users can access the form. If the user is not logged in, then the fallback action is performed.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_limitation_logged_in_fb_wrap">
			<th><?php $this->ui->generate_label( 'settings[limitation][logged_in_fallback]', __( 'What to do when user not logged in', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[limitation][logged_in_fallback]', $login_select, $op['logged_in_fallback'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Please select what to do when the user is not logged in. Choosing Show Form will print a FORM Styled (with the same theme as this form) login form. If you use some other login system, then you can redirect to that system page using the redirect option.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_limitation_nlr_wrap">
			<th><?php $this->ui->generate_label( 'settings[limitation][non_logged_redirect]', __( 'Redirection URL', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[limitation][non_logged_redirect]', $op['non_logged_redirect'], __( 'Enter URL', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the redirection URL. You can have the placeholder <code>_self_</code> which will be replaced by the current URL.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][logged_out]', __( 'Only Logged Out user can submit', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[limitation][logged_out]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['logged_out'], '1', false, true, array(
					'condID' => 'mc_form_settings_limitation_logged_out_msg_wrap',
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then only logged out users can access the form. If the user is logged in, then the mentioned message is shown. Make sure to disable the option Only Logged In user can submit, otherwise the form wont be shown to anyone.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_limitation_logged_out_msg_wrap">
			<th><?php $this->ui->generate_label( 'settings[limitation][logged_msg]', __( 'Message for Logged In Users', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][logged_msg]', $op['logged_msg'], __( 'Write Here', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
				<br>
				<p class="description"><?php _e( 'Leave empty to silently discard the form.', 'mc_form' ); ?></p>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the message you want to show when the user is logged in. HTML is enabled. Leave empty to silently discard the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<!-- New Limitations v3.0.0 -->
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][interval_limit]', __( 'Submission Interval (Minutes)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[limitation][interval_limit]', $op['interval_limit'], __( '0 to disable', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the minimum number of minutes the same user has to wait between successive submissions. This would have no effect if user limit is set to 1.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_limitation_intrmsg_wrap">
			<th><?php $this->ui->generate_label( 'settings[limitation][interval_msg]', __( 'Interval Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][interval_msg]', $op['interval_msg'], __( 'Write Here', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the message you want to show when the interval limit violates. HTML is enabled. <code>%1$s</code> is replaced by the remaining minutes user needs to wait.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][expiration_limit]', __( 'Form Expiration Date', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->datetimepicker( 'settings[limitation][expiration_limit]', $op['expiration_limit'], __( 'Disabled', 'mc_form' ), false ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the form to expire after a centain date, then set it here. Once a form is expired, new submissions can not be made.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_limitation_exmsg_wrap">
			<th><?php $this->ui->generate_label( 'settings[limitation][expiration_msg]', __( 'Expiration Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][expiration_msg]', $op['expiration_msg'], __( 'Write Here', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the message you want to show when the form expires. HTML is enabled.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][starting_limit]', __( 'Form Opening Date', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->datetimepicker( 'settings[limitation][starting_limit]', $op['starting_limit'], __( 'Disabled', 'mc_form' ), false ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the form to be accessible only after a centain date, then set it here. Before a form is open, new submissions can not be made.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_limitation_sttitle_wrap">
			<th><?php $this->ui->generate_label( 'settings[limitation][starting_title]', __( 'Opening Box Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[limitation][starting_title]', $op['starting_title'], __( 'Write Here', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the title you want to show before the form opens. HTML is enabled. A countdown timer will be added automatically.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_limitation_stmsg_wrap">
			<th><?php $this->ui->generate_label( 'settings[limitation][starting_msg]', __( 'Opening Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][starting_msg]', $op['starting_msg'], __( 'Write Here', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the message you want to show before the form opens. HTML is enabled. A countdown timer will be added automatically.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][no_edit_expiration]', __( 'Disable edit of existing submissions once expired', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[limitation][no_edit_expiration]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['no_edit_expiration'], '1', false, true ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then once the form has expired, users would not be able to edit their existing submissions.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[limitation][submission_info]', __( 'Show Notice to users who has submitted previously', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[limitation][submission_info]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['submission_info'], '1', false, true, array(
					'condID' => 'mc_form_settings_limitation_submsg_wrap',
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then user has submitted before, then a message would be shown. This would not have any effect if the user limit disables form submission for a user.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_limitation_submsg_wrap">
			<th><?php $this->ui->generate_label( 'settings[limitation][submission_msg]', __( 'Previously Submitted Notice', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[limitation][submission_msg]', $op['submission_msg'], __( 'Write Here', 'mc_form' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the notice you want to show to the users who has previously submitted the form. HTML is enabled.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function buttons() {
		$op = $this->settings['buttons'];
?>
<table class="form-table">
	<tbody>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'settings[buttons][hidden]', __( 'Hide Button Toolbar', 'mc_form' ) ); ?>
			</th>
			<td>
				<?php $this->ui->toggle( 'settings[buttons][hidden]', '', '', $op['hidden'] ); ?>
				<span class="description"><?php _e( 'Useful when manually adding buttons using LINKS BUTTONS element.', 'mc_form' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you disable, then make sure to add navigations buttons manually using LINKS BUTTONS element. You need to add them on every page.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[buttons][next]', __( 'Next Button Label', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[buttons][next]', $op['next'], __( 'Enter the label', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the label of the next button', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[buttons][prev]', __( 'Previous Button Label', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[buttons][prev]', $op['prev'], __( 'Enter the label', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the label of the previous button', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[buttons][submit]', __( 'Submit Button Label', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[buttons][submit]', $op['submit'], __( 'Enter the label', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the label of the submit button', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[buttons][supdate]', __( 'Update Button Label', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[buttons][supdate]', $op['supdate'], __( 'Enter the label', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the label of the update button', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[buttons][reset]', __( 'Reset Button Label', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[buttons][reset]', $op['reset'], __( 'Disabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the label of the reset button. It will be shown using an icon, with the label as title.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[buttons][reset_msg]', __( 'Reset Confirm Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[buttons][reset_msg]', $op['reset_msg'], __( 'Direct Reset', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the confirm message that is shown to the user before the reset happens.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[buttons][hide]', __( 'Hide Buttons instead of Disabling', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[buttons][hide]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['hide'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'By default if the previous/next/submit buttons are not needed then they are disabled. Enabling this option would hide them.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
		<?php
		$this->build_conditional( 'settings[buttons]', $op['conditional'], __( 'Conditional Logic for Submit Button', 'mc_form' ) );
		$this->build_conditional( 'settings[buttons]', $op['conditional_next'], __( 'Conditional Logic for Next Button', 'mc_form' ), true, '[conditional_next]' );
	}

	public function save_progress() {
		$op = $this->settings['save_progress'];
		?>
<table class="form-table" style="margin-bottom: 0">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[save_progress][auto_save]', __( 'Auto Save Form Progress', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[save_progress][auto_save]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['auto_save'], '1', false, true, array(
					'condid' => 'mcform_settings_fs_sp_as_wrap',
				) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enabling this will automatically save user inputs on the client (user\'s) machine. So, even if they close and want to resume later, it would be possible. Do note that auto saving of file uploads is not possible right now.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
<table class="form-table" id="mcform_settings_fs_sp_as_wrap">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[save_progress][show_restore]', __( 'Show Restore Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[save_progress][show_restore]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['show_restore'], '1', false, true, array(
					'condid' => 'mc_form_settings_sp_rh_wrap,mc_form_settings_sp_rm_wrap,mc_form_settings_sp_rr_wrap',
				) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enabling this would show a restore message to user. And it will also place a button with which user can reset the form.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_settings_sp_rh_wrap">
			<th><?php $this->ui->generate_label( 'settings[save_progress][restore_head]', __( 'Restore Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[save_progress][restore_head]', $op['restore_head'], __( 'Enter title', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'This title will be shown above the restore message.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_sp_rm_wrap">
			<th><?php $this->ui->generate_label( 'settings[save_progress][restore_msg]', __( 'Restore Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[save_progress][restore_msg]', $op['restore_msg'], __( 'Enter message', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The auto restore message that is shown to the user.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_sp_rr_wrap">
			<th><?php $this->ui->generate_label( 'settings[save_progress][restore_reset]', __( 'Restore Reset Button', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[save_progress][restore_reset]', $op['restore_reset'], __( 'Button Text', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Clicking on this button would reset the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[save_progress][interval_save]', __( 'Interval Save', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[save_progress][interval_save]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['interval_save'], '1', false, true, array(
					'condid' => 'mc_form_settings_as_int_wrap,mc_form_settings_as_int_tt_wrap,mc_form_settings_as_int_tts_wrap',
				) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'If your form is really large, then live auto-save can slow it down. In this case, please enable this option to save in an interval, instead of saving live.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_settings_as_int_wrap">
			<th><?php $this->ui->generate_label( 'settings[save_progress][interval]', __( 'Save Interval (Seconds)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[save_progress][interval]', $op['interval'], __( 'Seconds', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Mention seconds after which the form would be saved automatically. If value is less than or equals zero, then form would not be saved automatically at all. It will only be saved if user clicks on the save button.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_as_int_tt_wrap">
			<th><?php $this->ui->generate_label( 'settings[save_progress][interval_title]', __( 'Auto Save Button Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[save_progress][interval_title]', $op['interval_title'], __( 'Disabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Clicking this button would do a manual save triggered by the user. Leave empty to disable.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_settings_as_int_tts_wrap">
			<th><?php $this->ui->generate_label( 'settings[save_progress][interval_saved_title]', __( 'Form Saved Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[save_progress][interval_saved_title]', $op['interval_saved_title'], __( 'Saved title', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Message to show when button action was successful.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function format_options() {
		$op = $this->settings['format'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[format][math_format]', __( 'Add format strings for mathematical elements', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[format][math_format]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['math_format'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then you will have format strings like <code>%MATH{id}%</code> where <code>{id}</code> is the key of the form element (visible in form builder). These format strings would be replaced by values of the mathematical elements. For example, <code>%MATH3%, %MATH14%</code> etc. Use the format string in success message and admin or user notifications.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<?php do_action( 'mc_form_admin_format_options', $this, $op ); ?>
	</tbody>
</table>
		<?php
	}

	public function submission() {
		$op = $this->settings['submission'];
?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][no_auto_complete]', __( 'Prevent Form Auto Complete', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[submission][no_auto_complete]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['no_auto_complete'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enabling this will prevent form field auto complete from previous entries and page refresh. This will impact all form elements globally and enabling it is not recommended.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][url_track]', __( 'Track Submission from URL data', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[submission][url_track]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['url_track'], '1', false, true, array(
					'condid' => 'mc_form_submission_utk_wrap'
				) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enabling this will give you an option to share the form URL with optional query parameter like <code>http://path.to/form/?url_track_key=value</code>, where <code>value</code> will be stored as the URL track code. You can later filter submissions from the admin side.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_submission_utk_wrap">
			<th><?php $this->ui->generate_label( 'settings[submission][url_track_key]', __( 'Key Parameter of URL Tracking', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[submission][url_track_key]', $op['url_track_key'], __( 'URL Query Key Parameter', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the key of the URL tracking. Depending on this, you will need to work out the URL.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][process_title]', __( 'Processing Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[submission][process_title]', $op['process_title'], __( 'Shown when ajax submission in progress', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'This title will be shown above the ajax bar during form submission.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][success_title]', __( 'Success Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[submission][success_title]', $op['success_title'], __( 'Shown when successfully submitted', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'This title will be shown above the success message.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][success_message]', __( 'Success Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[submission][success_message]', $op['success_message'], __( 'Fullbody message', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'This message will be shown to the users when they submit the form.', 'mc_form' ); ?></p>
				<p><?php _e( 'While entering the Message, you have the following format strings available.', 'mc_form' ); ?></p>
				<ul class="ul-square">
					<li><strong>%NAME%</strong> : <?php _e( 'Will be replaced by the full name of the user.', 'mc_form' ); ?></li>
					<li><strong>%TRACK_LINK%</strong> : <?php _e( 'Will be replaced by the raw link from where the user can see the status of his submission.', 'mc_form' ); ?></li>
					<li><strong>%TRACK%</strong> : <?php _e( 'Will be replaced by a "Click Here" button linked to the track page.', 'mc_form' ); ?></li>
					<li><strong>%SCORE%</strong> : <?php _e( 'Will be replaced by the score obtained/total score.', 'mc_form' ); ?></li>
					<li><strong>%OSCORE%</strong> : <?php _e( 'Will be replaced by the score obtained.', 'mc_form' ); ?></li>
					<li><strong>%MSCORE%</strong> : <?php _e( 'Will be replaced by the total score.', 'mc_form' ); ?></li>
					<li><strong>%SCOREPERCENT%</strong> : <?php _e( 'Will be replaced by the percentage score obtained.', 'mc_form' ); ?></li>
					<li><strong>%DESIGNATION%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation title.', 'mc_form' ); ?></li>
					<li><strong>%DESIGNATIONMSG%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation message.', 'mc_form' ); ?></li>
					<li><strong>%TRACK_ID%</strong> : <?php _e( 'Will be replaced by the Tracking ID of the submission which the user can enter in the track page.', 'mc_form' ); ?></li>
					<li><strong>%SUBMISSION_ID%</strong> : <?php _e( 'Will be replaced by the ID of the submission.', 'mc_form' ); ?></li>
					<li><strong>%PORTAL%</strong> : <?php _e( 'Will be replaced by the raw link of the user portal page from where registered users can see all their submissions.', 'mc_form' ); ?></li>
				</ul>
				<p><?php _e( 'Please note that the designation related format string might only work if you have ranking system enabled and the user score falls under a valid ranking range. Head to Ranking System to use this feature.', 'mc_form' ); ?></p>
				<p><?php printf( __( 'An updated list can always be found <a href="%1$s" target="_blank">here</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/form-submission-related/available-format-strings-custom-notifications/' ); ?></p>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][update_message]', __( 'Update Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[submission][update_message]', $op['update_message'], __( 'Fullbody message', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'This message will be shown to the users when they update the submission.', 'mc_form' ); ?></p>
				<p><?php _e( 'While entering the Message, you have the following format strings available.', 'mc_form' ); ?></p>
				<ul class="ul-square">
					<li><strong>%NAME%</strong> : <?php _e( 'Will be replaced by the full name of the user.', 'mc_form' ); ?></li>
					<li><strong>%TRACK_LINK%</strong> : <?php _e( 'Will be replaced by the raw link from where the user can see the status of his submission.', 'mc_form' ); ?></li>
					<li><strong>%TRACK%</strong> : <?php _e( 'Will be replaced by a "Click Here" button linked to the track page.', 'mc_form' ); ?></li>
					<li><strong>%SCORE%</strong> : <?php _e( 'Will be replaced by the score obtained/total score.', 'mc_form' ); ?></li>
					<li><strong>%OSCORE%</strong> : <?php _e( 'Will be replaced by the score obtained.', 'mc_form' ); ?></li>
					<li><strong>%MSCORE%</strong> : <?php _e( 'Will be replaced by the total score.', 'mc_form' ); ?></li>
					<li><strong>%SCOREPERCENT%</strong> : <?php _e( 'Will be replaced by the percentage score obtained.', 'mc_form' ); ?></li>
					<li><strong>%DESIGNATION%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation title.', 'mc_form' ); ?></li>
					<li><strong>%DESIGNATIONMSG%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation message.', 'mc_form' ); ?></li>
					<li><strong>%TRACK_ID%</strong> : <?php _e( 'Will be replaced by the Tracking ID of the submission which the user can enter in the track page.', 'mc_form' ); ?></li>
					<li><strong>%SUBMISSION_ID%</strong> : <?php _e( 'Will be replaced by the ID of the submission.', 'mc_form' ); ?></li>
					<li><strong>%PORTAL%</strong> : <?php _e( 'Will be replaced by the raw link of the user portal page from where registered users can see all their submissions.', 'mc_form' ); ?></li>
				</ul>
				<p><?php _e( 'Please note that the designation related format string might only work if you have ranking system enabled and the user score falls under a valid ranking range. Head to Ranking System to use this feature.', 'mc_form' ); ?></p>
				<p><?php printf( __( 'An updated list can always be found <a href="%1$s" target="_blank">here</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/form-submission-related/available-format-strings-custom-notifications/' ); ?></p>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][log_ip]', __( 'Log IP Address', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[submission][log_ip]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['log_ip'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enable to log user\'s IP Address.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][log_registered_user]', __( 'Log Registered Users', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[submission][log_registered_user]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['log_registered_user'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enable to log registered user accounts during submission.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[submission][reset_on_submit]', __( 'Reset Form after submit', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[submission][reset_on_submit]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['reset_on_submit'], '1', false, true, array(
					'condid' => 'mc_form_sub_rd_wrap,mc_form_sub_rm_wrap',
				) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'After submission, reset the form for successive submission. Will not work if redirection is also turned on.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_sub_rd_wrap">
			<th><?php $this->ui->generate_label( 'settings[submission][reset_delay]', __( 'Reset Delay (seconds)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[submission][reset_delay]', $op['reset_delay'], __( 'Instant reset', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Number of seconds to wait before reseting and showing the form. If set to 0 or blanked out, it will be reset immediately. If you want to show a brief success message, then setting this to 10 is recommended.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_sub_rm_wrap">
			<th><?php $this->ui->generate_label( 'settings[submission][reset_msg]', __( 'Reset Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[submission][reset_msg]', $op['reset_msg'], __( 'Shown during reset delay', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'This will be shown beside the success message title. <code>%time%</code> will be replaced by a timer.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function ganalytics() {
		$op = $this->settings['ganalytics'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[ganalytics][enabled]', __( 'Enable Google Analytics Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[ganalytics][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_ganalytics_wrap'
				) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'If enabled then the form would integrate with Google Analytics Event Tracking.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
<table class="form-table" id="mc_form_ganalytics_wrap">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[ganalytics][manual_load]', __( 'Let FORM Load Google Analytics Source', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[ganalytics][manual_load]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['manual_load'], '1', false, true, array(
					'condid' => 'mc_form_ganalytics_ml_wrap,mc_form_ganalytics_ck_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you are not using any sort of Google Analytics plugin (all plugins following latest analytics integration will work) and want FORM to load the script, then enable it here. Otherwise FORM assumes you have already loaded Analytics codes and initiated the <code>ga</code> tracking object. If you let FORM create a tracker object, then it will be uniquely namespaced as <code>FORM{form_id}</code>. So even if you have another Google Analytics tracker in your webpages, but want to differentiate tracking for FORM, it will still work and would not break existing trackers.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_ganalytics_ml_wrap">
			<th><?php $this->ui->generate_label( 'settings[ganalytics][tracking_id]', __( 'Property (Tracking ID)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[ganalytics][tracking_id]', $op['tracking_id'], __( 'UA-XXXXX-Y', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the Tracking ID or Property related to your Google Analytics account. If you do not know your property ID, you can use the <a target="_blank" href="https://ga-dev-tools.appspot.com/account-explorer/">Account Explorer</a> to find it.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_ganalytics_ck_wrap">
			<th><?php $this->ui->generate_label( 'settings[ganalytics][cookie]', __( 'Cookie Domain', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[ganalytics][cookie]', $op['cookie'], __( 'auto', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the <a href="https://developers.google.com/analytics/devguides/collection/analyticsjs/field-reference#cookieDomain" target="_blank">cookie domain</a>. If you are testing on localhost, set this to none.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
<h3><?php _e( 'Custom Dimensions', 'mc_form' ); ?></h3>
<p><?php _e( 'Following dimension variables are sent when making relevant event trackings', 'mc_form' ); ?></p>
<ul class="ul-disc">
	<li><strong>dimension1</strong>: <?php _e( 'Would be element category (like Multiple Choice Questions).', 'mc_form' ); ?></li>
	<li><strong>dimension2</strong>: <?php _e( 'Would be element type (like radios, checkboxes, grading etc).', 'mc_form' ); ?></li>
	<li><strong>dimension3</strong>: <?php _e( 'Would be element key.', 'mc_form' ); ?></li>
	<li><strong>dimension4</strong>: <?php _e( 'Would be element calculated and stringified value.', 'mc_form' ); ?></li>
	<li><strong>dimension5</strong>: <?php _e( 'Would be page number completed in case of paginated/tabbed forms.', 'mc_form' ); ?></li>
</ul>
<p><?php _e( 'It is recommended that you also <a href="https://support.google.com/analytics/answer/2709829?hl=en" target="_blank">setup dimensions</a> with appropriate index and meaningful names.', 'mc_form' ); ?></p>
		<?php
	}

	public function redirect() {
		$items = array();
		$items[] = array(
			'value' => 'none',
			'label' => __( 'No Redirection', 'mc_form' ),
			'data' => array(
				'condid' => 'redirect_none',
			),
		);
		$items[] = array(
			'value' => 'flat',
			'label' => __( 'Flat Redirection', 'mc_form' ),
			'data' => array(
				'condid' => 'redirect_url,redirect_delay',
			),
		);
		$items[] = array(
			'value' => 'score',
			'label' => __( 'Score Based Redirection', 'mc_form' ),
			'data' => array(
				'condid' => 'redirect_url,redirect_delay,redirect_score',
			),
		);
		$items[] = array(
			'value' => 'conditional',
			'label' => __( 'Conditional Redirection', 'mc_form' ),
			'data' => array(
				'condid' => 'redirect_url,redirect_delay,redirect_condtional',
			),
		);
?>
<div class="mc_uif_msg mc_uif_float_right">
	<a href="javascript:;" class="mc_uif_msg_icon" title="<?php _e( 'Redirection', 'mc_form' ); ?>"><i class="mc-icomoon-live_help"></i></a>
	<div class="mc_uif_msg_body">
		<p><?php _e( 'Please select the type of the redirection. Each redirection has it\'s own different sets of options.', 'mc_form' ); ?></p>
		<h3><?php _e( 'Redirection URL', 'mc_form' ); ?></h3>
		<ul class="ul-square">
			<li>
				<?php _e( 'The page will be redirected to the mentioned URL for flat redirection.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'The Redirection URL for Score based redirection will be used if the score does not satisfy any of the conditions.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'You can use the format string <code>%TRACKBACK%</code> to redirect the user to the results page. You need to have a valid trackback page set on the settings for this to work.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'All format strings are available for URL redirection. Some of them are listed below.', 'mc_form' ); ?>
				<ul class="ul-disc">
					<li><code>%NAME%</code> : <?php _e( 'Replaced by the user\'s full name.', 'mc_form' ); ?></li>
					<li><code>%FNAME%</code> : <?php _e( 'Replaced by the user\'s first name.', 'mc_form' ); ?></li>
					<li><code>%LNAME%</code> : <?php _e( 'Replaced by the user\'s last name.', 'mc_form' ); ?></li>
					<li><code>%PHONE%</code> : <?php _e( 'Replaced by the user\'s phone number.', 'mc_form' ); ?></li>
					<li><code>%EMAIL%</code> : <?php _e( 'Replaced by the user\'s email address.', 'mc_form' ); ?></li>
					<li><code>%ID%</code> : <?php _e( 'Replaced by the submission ID.', 'mc_form' ); ?></li>
					<li><code>%TRACK_ID%</code> : <?php _e( 'Replaced by the system generated trackback id.', 'mc_form' ); ?></li>
					<li><code>%SCORE%</code> : <?php _e( 'Replaced by the score obtained.', 'mc_form' ); ?></li>
					<li><code>%TSCORE%</code> : <?php _e( 'Replaced by the total score of the form.', 'mc_form' ); ?></li>
					<li><code>%SCOREPERCENT%</code> : <?php _e( 'Replaced by the percentage score obtained, formatted properly in your locale.', 'mc_form' ); ?></li>
					<li><code>%DESIGNATION%</code> : <?php _e( 'Replaced by the assigned designation.', 'mc_form' ); ?></li>
				</ul>
				<?php _e( 'For a more comprehensive list, check our <a href="https://www.binarypoets.net/kb/form/form-submission-related/available-format-strings-custom-notifications/" target="_blank" rel="noopener">knowledgebase</a>. Also you can purchase easySubmission add-on to pass any form element as URL parameters.' ) ?>
			</li>
		</ul>
		<h3><?php _e( 'Score Range', 'mc_form' ); ?></h3>
		<ul class="ul-square">
			<li>
				<?php _e( 'Select the range of the score (in terms of percentage, which will be calculated automatically) and mentioned the redirection URL.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'All the ranges are inclusive.', 'mc_form' ); ?>
			</li>
			<li>
				<?php _e( 'If more than one range overlaps for a score, then the first range found in the list will be used.', 'mc_form' ); ?>
			</li>
		</ul>
	</div>
</div>
		<?php
		echo '<div class="align-center">';
		$this->ui->radios( 'settings[redirection][type]', $items, $this->settings['redirection']['type'], false, true );
		echo '</div>';

		$this->ui->div( 'clear', array( $this->ui, 'clear' ), 0, 'redirect_none' );
		$this->ui->shadowbox( array( 'glowy', 'cyan' ), array( $this, 'redirect_url' ), 0, 'redirect_url' );
		$this->ui->shadowbox( array( 'glowy', 'cyan' ), array( $this, 'redirect_delay' ), 0, 'redirect_delay' );
		$this->ui->div( '', array( $this, 'redirect_score' ), 0, 'redirect_score' );
		$this->ui->div( '', array( $this, 'redirect_conditional' ), 0, 'redirect_condtional' );
	}

	public function redirect_conditional() {
		$op = $this->settings['redirection']['conditional'];
		// Conditional Product ID
		//build_conditional_config( $name_prefix, $configs, $cond_suffix, $cond_id, $data )
		$cond_redr_data = array();
		foreach ( (array) $op as $item_key => $item ) {
			$new_cond_redr_data = array();
			foreach ( $item as $data_key => $data ) {
				if ( 'logics' == $data_key ) {
					$new_cond_redr_data[ $data_key ] = $data;
				} else {
					$new_cond_redr_data[ $data_key ] = array( 'settings[redirection][conditional][' . $item_key . '][' . $data_key . ']', $data, __( 'Required', 'mc_form' ) );
				}
			}
			if ( ! isset( $new_cond_redr_data['logics'] ) ) {
				$new_cond_redr_data['logics'] = array();
			}
			$cond_redr_data[ $item_key ] = $new_cond_redr_data;
		}

		$cond_redr = array(
			'name_prefix' => 'settings[redirection][conditional]',
			'configs' => array(),
			'cond_suffix' => 'logics',
			'cond_id' => 'mcform_redirection_cond_url_wrap',
			'data' => $cond_redr_data,
		);
		$cond_redr['configs'][0] = array(
			'label' => __( 'URL', 'mc_form' ),
			'type' => 'text',
			'size' => '100',
			'data' => array( 'settings[redirection][conditional][__SDAKEY__][url]', '', __( 'Required', 'mc_form' ) ),
		);

		$this->build_conditional_config( $cond_redr['name_prefix'], $cond_redr['configs'], $cond_redr['cond_suffix'], $cond_redr['cond_id'], $cond_redr['data'] );
	}

	public function redirect_delay() {
?>
	<table class="form-table">
		<tbody>
			<tr>
				<th><?php $this->generate_label( 'settings[redirection][delay]', __( 'Redirection Delay', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->slider( 'settings[redirection][delay]', $this->settings['redirection']['delay'], 0, 10000, 100 ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Select the delay to the redirection in milliseconds. A value somewhere between 1000 and 5000 is recommended.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<tr>
				<th><?php $this->generate_label( 'settings[redirection][message]', __( 'Custom Message', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->textarea( 'settings[redirection][message]', $this->settings['redirection']['message'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Set a custom message that will be shown below any notification. <code>%LINK%</code> will be replaced by the redirection link and <code>%TIME%</code> will be replaced by time (in seconds). Leave empty to disable this feature.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( 'settings[redirection][top]', __( 'Redirect Parent from iFrame', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->toggle( 'settings[redirection][top]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $this->settings['redirection']['top'] ); ?>
				</td>
				<td><?php $this->ui->help( __( 'If you are planning to load this form inside iFrame, then enabling this option will redirect the parent page, not just the iFrame. Useful to put sidebar widgets as iframe.', 'mc_form' ) ); ?></td>
			</tr>
		</tbody>
	</table>
		<?php
	}

	public function redirect_url() {
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[redirection][url]', __( 'Redirection URL', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[redirection][url]', $this->settings['redirection']['url'], __( 'https://', 'mc_form' ), 'large' ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enter redirection URL here. <code>%TRACKBACK%</code> will be replaced by the trackback/view submission URL.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
		<?php

	}

	public function redirect_score() {
		$r_select = array();
		$r_select[] = array(
			'value' => 'percentage',
			'label' => __( 'Percentage Score', 'mc_form' ),
			'data' => array(
				'condid' => 'redirect_percentage',
			),
		);
		$r_select[] = array(
			'value' => 'raw',
			'label' => __( 'Total Score', 'mc_form' ),
			'data' => array(
				'condid' => 'redirect_raw',
			),
		);
		$settings = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Score Range', 'mc_form' ),
					'size' => '60',
					'type' => 'slider_range',
				),
				1 => array(
					'label' => __( 'Redirect URL', 'mc_form' ),
					'size' => '40',
					'type' => 'text',
				),
			),
			'labels' => array(
				'add' => __( 'Add New Range', 'mc_form' ),
			),
		);
		$items = array();
		$max_key = null;
		foreach ( $this->settings['redirection']['score'] as $s_key => $score ) {
			$max_key = max( array( $max_key, $s_key ) );
			$items[] = array(
				0 => array( 'settings[redirection][score][' . $s_key . ']', array( $score['min'], $score['max'] ), 0, 100.001, 0.01, '%' ),
				1 => array( 'settings[redirection][score][' . $s_key . '][url]', $score['url'], __( 'Enter the Redirect URL', 'mc_form' ), 'large' ),
			);
		}
		$data = array(
			0 => array( 'settings[redirection][score][__SDAKEY__]', array( 10, 80 ), 0, 100.001, 0.01, '%' ),
			1 => array( 'settings[redirection][score][__SDAKEY__][url]', '', __( 'Enter the Redirect URL', 'mc_form' ), 'large' ),
		);

		$r_settings = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Score From', 'mc_form' ),
					'size' => '30',
					'type' => 'spinner',
				),
				1 => array(
					'label' => __( 'Score To', 'mc_form' ),
					'size' => '30',
					'type' => 'spinner',
				),
				2 => array(
					'label' => __( 'Redirect URL', 'mc_form' ),
					'size' => '40',
					'type' => 'text',
				),
			),
			'labels' => array(
				'add' => __( 'Add New Range', 'mc_form' ),
			),
		);
		$r_items = array();
		$r_max_key = null;
		foreach ( $this->settings['redirection']['rscore'] as $rs_key => $rscore ) {
			$r_max_key = max( array( $r_max_key, $rs_key ) );
			$r_items[] = array(
				0 => array( 'settings[redirection][rscore][' . $rs_key . '][min]', $rscore['min'], __( 'Min Score', 'mc_form' ), 0 ),
				1 => array( 'settings[redirection][rscore][' . $rs_key . '][max]', $rscore['max'], __( 'Max Score', 'mc_form' ), 0 ),
				2 => array( 'settings[redirection][rscore][' . $rs_key . '][url]', $rscore['url'], __( 'Enter the Redirect URL', 'mc_form' ), 'large' ),
			);
		}
		$r_data = array(
			0 => array( 'settings[redirection][rscore][__SDAKEY__][min]', '', __( 'Min Score', 'mc_form' ), 0 ),
			1 => array( 'settings[redirection][rscore][__SDAKEY__][max]', '', __( 'Max Score', 'mc_form' ), 0 ),
			2 => array( 'settings[redirection][rscore][__SDAKEY__][url]', '', __( 'Enter the Redirect URL', 'mc_form' ), 'large' ),
		);

		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[redirection][rtype]', __( 'Redirection Based On', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->select( 'settings[redirection][rtype]', $r_select, $this->settings['redirection']['rtype'], false, true ); ?></td>
			<td><?php $this->ui->help( __( 'Here you can set the redirection based on either percentage obtained or total score obtained.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
		<?php
		$this->ui->sda_list( $settings, $items, $data, $max_key, 'redirect_percentage' );
		$this->ui->sda_list( $r_settings, $r_items, $r_data, $r_max_key, 'redirect_raw' );
	}

	public function theme() {
		$op = $this->settings['theme'];
		$web_fonts = $this->get_available_webfonts();
		$themes = $this->get_available_themes();
		// Get the custom options
		$custom_options = array();
		$callback_cache = array();
		foreach ( $themes as $theme_grp ) {
			foreach ( $theme_grp['themes'] as $theme_key => $theme ) {
				if ( isset( $theme['has_option'] ) && true == $theme['has_option'] ) {
					if ( in_array( $theme['option_container'], $callback_cache ) ) {
						$custom_options[ $theme_key ] = array( $theme['option_container'] );
						continue;
					}
					$callback_cache[] = $theme['option_container'];
					$custom_options[ $theme_key ] = array( $theme['option_container'], $theme['option_callback'] );
				}
			}
		}
		$svg_location = MC_MCFORM_ABSPATH . 'static/admin/images/builder-icons/';
		$svg_boxy = file_get_contents( $svg_location . 'boxy.svg' );
		$svg_material = file_get_contents( $svg_location . 'material.svg' );

		$svg_inherit = file_get_contents( $svg_location . 'inherit.svg' );
		$svg_vertical = file_get_contents( $svg_location . 'vertical.svg' );
		$svg_horizontal = file_get_contents( $svg_location . 'horizontal.svg' );
		$svg_centered = file_get_contents( $svg_location . 'centered.svg' );

		$element_styles = [
			[
				'value' => 'material',
				'label' => __( 'Material', 'mc_form' ),
				'svg' => $svg_material,
			],
			[
				'value' => 'boxy',
				'label' => __( 'Boxy', 'mc_form' ),
				'svg' => $svg_boxy,
			],
		];

		$align_overrides = [
			[
				'value' => 'inherit',
				'label' => __( 'Inherit', 'mc_form' ),
				'svg' => $svg_inherit,
			],
			[
				'value' => 'vertical',
				'label' => __( 'Vertical', 'mc_form' ),
				'svg' => $svg_vertical,
			],
			[
				'value' => 'centered',
				'label' => __( 'Centered', 'mc_form' ),
				'svg' => $svg_centered,
			],
			[
				'value' => 'horizontal',
				'label' => __( 'Horizontal', 'mc_form' ),
				'svg' => $svg_horizontal,
			],
		];

		$font_sources = [
			[
				'value' => 'system',
				'label' => __( 'System Font', 'mc_form' ),
				'data' => [
					'condid' => '',
				],
			],
			[
				'value' => 'google_webfont',
				'label' => __( 'Google WebFont', 'mc_form' ),
				'data' => [
					'condid' => 'mc_form_form_settings_theme_style_head_font_wrap,mc_form_form_settings_theme_style_body_font_wrap',
				],
			],
			[
				'value' => 'custom',
				'label' => __( 'Custom', 'mc_form' ),
				'data' => [
					'condid' => 'mcform-style-settings-cfont-head,mcform-style-settings-cfont-body',
				],
			],
		];

		$custom_font_options = [
			[
				'name' => 'settings[theme][style][head_custom]',
				'label' => __( 'Heading Font Name', 'mc_form' ),
				'ui' => 'text',
				'id' => 'mcform-style-settings-cfont-head',
				'param' => [ 'settings[theme][style][head_custom]', $op['style']['head_custom'], __( 'CSS Font Family', 'mc_form' ) ],
				'help' => __( 'Specify the font-family for the heading texts.', 'mc_form' ),
			],
			[
				'name' => 'settings[theme][style][body_custom]',
				'label' => __( 'Body Font Name', 'mc_form' ),
				'id' => 'mcform-style-settings-cfont-body',
				'ui' => 'text',
				'param' => [ 'settings[theme][style][body_custom]', $op['style']['body_custom'], __( 'CSS Font Family', 'mc_form' ) ],
				'help' => __( 'Specify the font-family for the heading texts.', 'mc_form' ),
			],
		];
?>
<table class="form-table">
	<tbody>
		<tr>
			<th style="width: 150px;"><?php $this->ui->generate_label( 'settings[theme][template]', __( 'Select Theme', 'mc_form' ) ); ?></th>
			<td>
				<div class="mc_uif_conditional_select">
					<select name="settings[theme][template]" id="<?php echo $this->generate_id_from_name( 'settings[theme][template]' ); ?>" class="mc_uif_select mc_uif_theme_selector">
						<?php foreach ( $themes as $theme_grp ) : ?>
						<optgroup label="<?php echo $theme_grp['label']; ?>">
							<?php foreach ( $theme_grp['themes'] as $theme_key => $theme ) : ?>
							<option data-colors="<?php echo esc_attr( isset( $theme['colors'] ) ? json_encode( $theme['colors'] ) : json_encode( array() ) ); ?>" value="<?php echo $theme_key; ?>"<?php if ( $op['template'] == $theme_key ) echo ' selected="selected"'; ?><?php echo ( isset( $custom_options[ $theme_key ] ) ? 'data-condID="' . esc_attr( $custom_options[ $theme_key ][0] ) . '"' : '' ); ?>><?php echo $theme['label']; ?></option>
							<?php endforeach; ?>
						</optgroup>
						<?php endforeach; ?>
					</select>
					<div class="mc_uif_theme_preview"></div>
				</div>
			</td>
			<td style="width: 50px;">
				<?php $this->ui->help( __( 'Select a theme for this form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<?php foreach ( $custom_options as $theme_key => $option_cb ) : ?>
					<?php
					if ( ! isset( $custom_options[ $theme_key ][1] ) ) {
						continue;
					}
					?>
					<div id="<?php echo esc_attr( $custom_options[ $theme_key ][0] ) ?>">
						<?php call_user_func( $custom_options[ $theme_key ][1], $this ); ?>
					</div>
				<?php endforeach; ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[theme][element_style]', __( 'Element Style', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->svg_picker( 'settings[theme][element_style]', $element_styles, $op['element_style'], false ); ?></td>
			<td>
				<?php $this->ui->help( __( 'Set element style.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[theme][align_override]', __( 'Global Alignment', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->svg_picker( 'settings[theme][align_override]', $align_overrides, $op['align_override'], false ); ?></td>
			<td>
				<?php $this->ui->help( __( 'Override form alignment. If set to inherit, then you can control elements individually, otherwise it will override.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 150px"><?php $this->ui->generate_label( 'settings[theme][logo]', __( 'Add a header image/logo', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->upload( 'settings[theme][logo]', $op['logo'], '', __( 'Set Header', 'mc_form' ), __( 'Choose Image', 'mc_form' ), __( 'Use Image', 'mc_form' ), '90%', '150px', 'auto' ); ?>
			</td>
			<td style="width: 50px">
				<?php $this->ui->help( __( 'You can put a logo or header image right before the form if you want. This will shown on the form page, trackback page, emails and also on standalone pages.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 150px;"><?php $this->ui->generate_label( 'settings[theme][waypoint]', __( 'Animated Form Elements', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[theme][waypoint]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['waypoint'], '1' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Select Yes to create an animating form with CSS3 animation. The form elements will fade and slide once they enter the viewport. Great way to attract user attention.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 150px;"><?php $this->ui->generate_label( 'settings[theme][icon][color]', __( 'Icon Color', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->colorpicker( 'settings[theme][icon][color]', $op['icon']['color'], '', '#333333' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the icon color for summary table.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th style="width: 150px;"><?php $this->ui->generate_label( 'settings[theme][style][custom_font]', __( 'Customize Fonts', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[theme][style][custom_font]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['style']['custom_font'], '1', false, true, array(
				'condid' => 'mcform-style-settings-all-fonts'
			) ); ?>
			</td>
			<td style="width: 50px;">
				<?php $this->ui->help( __( 'If you wish then you can change fonts and also put your own css code.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_form_settings_theme_style_fonts_wrap">
			<td colspan="3">
				<table class="form-table">
					<tbody>

						<tr id="mcform-style-settings-all-fonts">
							<td colspan="3">
								<table class="form-table">
									<tbody>
										<tr>
											<th><?php $this->ui->generate_label( 'settings[theme][style][font_source]', __( 'Font Source', 'mc_form' ) ); ?></th>
											<td>
												<?php
												$this->ui->select( 'settings[theme][style][font_source]', $font_sources, $op['style']['font_source'], false, true );
												?>
											</td>
											<td>
												<?php $this->ui->help( __( 'Select the font source. If you select custom, then you have to make sure the font is present.', 'mc_form' ) ); ?>
											</td>
										</tr>
										<tr id="mc_form_form_settings_theme_style_head_font_wrap">
											<th style="width: 150px;"><?php $this->ui->generate_label( 'settings[theme][style][head_font]', __( 'Heading Font', 'mc_form' ) ); ?></th>
											<td>
												<?php $this->ui->webfonts( 'settings[theme][style][head_font]', $op['style']['head_font'], $web_fonts ); ?>
											</td>
											<td style="width: 50px;">
												<?php $this->ui->help( __( 'Select the font.', 'mc_form' ) ); ?>
											</td>
										</tr>
										<tr id="mc_form_form_settings_theme_style_body_font_wrap">
											<th style="width: 150px;"><?php $this->ui->generate_label( 'settings[theme][style][body_font]', __( 'Body Font', 'mc_form' ) ); ?></th>
											<td>
												<?php $this->ui->webfonts( 'settings[theme][style][body_font]', $op['style']['body_font'], $web_fonts ); ?>
											</td>
											<td style="width: 50px;">
												<?php $this->ui->help( __( 'Select the font.', 'mc_form' ) ); ?>
											</td>
										</tr>
										<?php $this->ui->form_table( $custom_font_options, false ); ?>
										<tr id="mc_form_form_settings_theme_style_font_size_wrap">
											<th><?php $this->ui->generate_label( 'settings[theme][style][base_font_size]', __( 'Base Font Size', 'mc_form' ) ); ?></th>
											<td>
												<?php $this->ui->slider( 'settings[theme][style][base_font_size]', $op['style']['base_font_size'], 10, 20 ); ?>
											</td>
											<td style="width: 50px;">
												<?php $this->ui->help( __( 'Select the base font size. Rest of the sizes will be calculated automatically.', 'mc_form' ) ); ?>
											</td>
										</tr>
										<tr id="mc_form_form_settings_theme_style_font_typo_wrap">
											<th><?php $this->ui->generate_label( '', __( 'Heading Font Customization', 'mc_form' ) ); ?></th>
											<td>
												<?php $this->ui->checkbox( 'settings[theme][style][head_font_typo][bold]', array(
													'label' => __( '<strong>Bold</strong>', 'mc_form' ),
													'value' => '1',
												), $op['style']['head_font_typo']['bold'] ); ?>
												<div class="clear"></div>
												<?php $this->ui->checkbox( 'settings[theme][style][head_font_typo][italic]', array(
													'label' => __( '<em>Italic</em>', 'mc_form' ),
													'value' => '1',
												), $op['style']['head_font_typo']['italic'] ); ?>
											</td>
											<td><?php $this->ui->help( __( 'Make the heading fonts bold or italic.', 'mc_form' ) ); ?></td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr>
			<th style="width: 150px;"><?php $this->ui->generate_label( 'settings[theme][custom_style]', __( 'Add Custom CSS', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[theme][custom_style]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['custom_style'], '1', false, true, array(
				'condid' => 'mc_form_form_settings_theme_style_custom_wrap'
			) ); ?>
			</td>
			<td style="width: 50px;">
				<?php $this->ui->help( __( 'If you wish then you can change fonts and also put your own css code.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_form_settings_theme_style_custom_wrap">
			<th><?php $this->ui->generate_label( 'settings[theme][style][custom]', __( 'Custom CSS', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->textarea( 'settings[theme][style][custom]', $op['style']['custom'], __( 'CSS Code', 'mc_form' ), 'widefat', array( 'code' ) ); ?></td>
			<td><?php $this->ui->help( __( 'If you are an advanced user and would like to put your own CSS, then this is where you can do so. Please consider having a CSS scope of <code>body #mc_form_form_wrap_{form_id}</code> to modify only this form.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function payment() {
		$hor_tabs = array();
		$hor_tabs[] = array(
			'id' => 'mc_form_payment_general',
			'label' => __( 'General Settings', 'mc_form' ),
			'callback' => array( $this, 'payment_general' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_payment_coupon',
			'label' => __( 'Discount Coupons', 'mc_form' ),
			'callback' => array( $this, 'payment_coupon' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_payment_paypal',
			'label' => __( 'Paypal Settings', 'mc_form' ),
			'callback' => array( $this, 'payment_paypal' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_payment_stripe',
			'label' => __( 'Stripe Settings', 'mc_form' ),
			'callback' => array( $this, 'payment_stripe' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_payment_authorize',
			'label' => __( 'Authorize.net Settings', 'mc_form' ),
			'callback' => array( $this, 'payment_authorize' ),
		);
		$hor_tabs[] = [
			'id' => 'mc_form_payment_offline',
			'label' => __( 'Offline Settings', 'mc_form' ),
			'callback' => [ $this, 'payment_offline' ],
		];
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_woocommerce',
			'label' => __( 'WooCommerce', 'mc_form' ),
			'callback' => array( $this, 'woocommerce' ),
		);
		$hor_tabs[] = array(
			'id' => 'mc_form_settings_estimation',
			'label' => __( 'Estimation Slider', 'mc_form' ),
			'callback' => array( $this, 'estimation_slider' ),
		);

		$hor_tabs = apply_filters( 'mc_form_payment_settings_tabs', $hor_tabs, $this );

		$this->ui->tabs( $hor_tabs, false, true );
	}

	public function payment_general() {
		$op = $this->settings['payment'];

		// Payment items
		$payment_items = [];
		$payment_name_pf = 'settings[payment]';
		// Payment type
		$payment_type_items = [
			0 => [
				'value' => 'onetime',
				'label' => __( 'One Time Payment', 'mc_form' ),
				'data' => [
					'condid' => '',
				],
			],
			1 => [
				'value' => 'recurring',
				'label' => __( 'Recurring / Subscription', 'mc_form' ),
				'data' => [
					'condid' => 'mcform_pm_gn_rs_wrap',
				],
			],
		];
		$payment_items[] = [
			'name' => $payment_name_pf . '[payment_type]',
			'label' => __( 'Billing Type', 'mc_form' ),
			'ui' => 'select',
			'param' => [ $payment_name_pf . '[payment_type]', $payment_type_items, $op['payment_type'], false, true ],
			'description' => __( 'For recurring billing, subscription settings needs to be enabled and configured within the payment gateway settings. For now only stripe is supported.', 'mc_form' ),
			'help' => __( 'Onetime is the regular billing where customers are charged only once. Recurring or subscription is when customers are charged based on given frequency. The settings and frequency of the charge has to be configured individually within the payment gateway settings. This is because different gateway provides different implementation of subscription and to provide maximum functionality, each needs to be configured differently.', 'mc_form' ),
		];
		// Recurring Statement
		$payment_items[] = [
			'name' => $payment_name_pf . '[recur_statement]',
			'label' => __( 'Invoice Statement for Susbcrmcion', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $payment_name_pf . '[recur_statement]', $op['recur_statement'], __( 'Required', 'mc_form' ) ],
			'help' => __( 'Set the text which will be shown on the invoice. <code>%1$d</code> is replaced by frequency and <code>%2$s</code> is replaced by interval.', 'mc_form' ),
			'id' => 'mcform_pm_gn_rs_wrap',
		];

		$payment_gateways = MC_FORM_Form_Elements_Static::mc_form_get_payment_gateways();
		$types = array();
		foreach ( $payment_gateways as $pg_key => $pg_val ) {
			$types[] = array(
				'value' => $pg_key,
				'label' => $pg_val,
			);
		}
		// Add notice if not using SSL
		if ( ! is_ssl() ) {
			$this->ui->msg_error( __( 'For payment gateway implementations, you need to have SSL certificate and access this site through <code>https</code>. You may get it for free from <a href="https://letsencrypt.org/">Let\'s Encrypt</a>.', 'mc_form' ) );
		}
		?>
<table class="form-table no-margin">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][enabled]', __( 'Enable Payment System', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[payment][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, [
				'condid' => 'mcform_set_payment_config',
			] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Payment will work, only if this settings is enabeld.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
<table class="form-table" id="mcform_set_payment_config">
	<tbody>
		<?php $this->ui->form_table( $payment_items, false ); ?>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][sub_on_success]', __( 'Submission Visible after Successful Payment', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[payment][sub_on_success]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['sub_on_success'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you would like to send email only when payment is successful, then enable this option. If payment is not successful, then the email will only contain the payment link and relevant retry methods. This will also reflect on the trackback page. If this is enabled, then by no means the user would be able to access the submission, neither from email, nor from trackback.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][lock_message]', __( 'Submission Blocking Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[payment][lock_message]', $op['lock_message'], __( 'HTML Enabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the message that would be shown to the user if Submission blocking is enabled and user have not finished payment. <code>%RETRY_LINK%</code> would be replaced by the URL from which user can retry payment.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][formula]', __( 'Mathematical Formula', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][formula]', $op['formula'], __( 'Formula', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the mathematical formula to calculate total. More information <a href="">here</a>.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][currency]', __( 'Currency Code', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][currency]', $op['currency'], __( 'Currency Code', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the currency code for the amount.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][c_prefix]', __( 'Currency Prefix', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][c_prefix]', $op['c_prefix'], __( 'Currency prefix', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the code that needs to be inserted before amount.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][c_suffix]', __( 'Currency Suffix', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][c_suffix]', $op['c_suffix'], __( 'Currency suffix', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the code that needs to be inserted after amount.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][type]', __( 'Preferred Payment Type', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[payment][type]', $types, $op['type'] ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'Following types are available for paypal payments.', 'mc_form' ); ?></p>
				<ul>
					<li><?php _e( '<code>Paypal Direct Payments</code>: User enters his/her card details. When submitting, the card is charged through paypal and user does not leave page.', 'mc_form' ); ?></li>
					<li><?php _e( '<code>Paypal Express Payment</code>: User is redirected to a paypal checkout page. Once payment is done, he/she is redirected back to the trackback page for updating the details.', 'mc_form' ); ?></li>
					<li><?php _e( '<code>Stripe Direct Payments</code>: User enters his/her card details. When submitting, the card is charged through stripe and user does not leave page.', 'mc_form' ); ?></li>
				</ul>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][itemname]', __( 'Item Name', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][itemname]', $op['itemname'], __( 'Form Name', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the name of the item for which the invoice would be created. If empty then form name will be used instead.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][itemdescription]', __( 'Item Description', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][itemdescription]', $op['itemdescription'], __( 'Disabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the description of the item for which the invoice would be created.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][itemsku]', __( 'Item SKU (Number)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][itemsku]', $op['itemsku'], __( 'Form ID', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the sku/unique number of the item for which the invoice would be created. If empty then form ID would be used.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][invoicenumber]', __( 'Invoice Number Format', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][invoicenumber]', $op['invoicenumber'], __( 'Form ID', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the invoice number format. <code>{id}</code> will be replaced by a unique ID. If empty then just the ID will be used.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][success_sub]', __( 'Payment Success Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][success_sub]', $op['success_sub'], __( 'Write Here', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the success message subject that would be shown to the user. This will override form success message if payment field was shown. This will also be used to send the email. <code>%1$s</code> will be replaced by the invoice ID. Other format strings are also available.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][success_msg]', __( 'Payment Success Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[payment][success_msg]', $op['success_msg'], __( 'HTML Enabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the success message that would be shown to the user. This will override form success message if payment field was shown. This will also be used to send the email.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][error_sub]', __( 'Payment Error Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][error_sub]', $op['error_sub'], __( 'Write Here', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the error message subject that would be shown to the user. This will also be used to send the email. <code>%1$s</code> will be replaced by the invoice ID. Other format strings are also available.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][error_msg]', __( 'Payment Error Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[payment][error_msg]', $op['error_msg'], __( 'HTML Enabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the error message that would shown to the user. Additionally repayment form will also be shown.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][cancel_sub]', __( 'Payment Cancel Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][cancel_sub]', $op['cancel_sub'], __( 'Write Here', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the cancel message subject that would be shown to the user. This will also be used to send the email. <code>%1$s</code> will be replaced by the invoice ID. Other format strings are also available.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][cancel_msg]', __( 'Payment Cancel Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[payment][cancel_msg]', $op['cancel_msg'], __( 'HTML Enabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the error message that would shown to the user when the payment was cancelled. Additionally repayment form will also be shown.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][retry_uemail_sub]', __( 'Payment Retry User Email Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][retry_uemail_sub]', $op['retry_uemail_sub'], __( 'Required', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the subject of the email that is sent upon processing of a payment retry form. <code>%1$s</code> will be replaced by the invoice ID. Other format strings are also available.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][retry_uemail_msg]', __( 'Payment Retry User Email Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[payment][retry_uemail_msg]', $op['retry_uemail_msg'], __( 'HTML Enabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the message that is shown to the users who has submitted the payment retry form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][retry_aemail_sub]', __( 'Payment Retry Admin Email Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][retry_aemail_sub]', $op['retry_aemail_sub'], __( 'Required', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the subject of the email that is sent upon processing of a payment retry form.  <code>%1$s</code> will be replaced by the invoice ID. Other format strings are also available.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][redir_aemail_sub]', __( '2 Step Payment Admin Email Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][redir_aemail_sub]', $op['redir_aemail_sub'], __( 'Required', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the admin email subject for 2 step payment gateways. In this case, the first admin notification would say the payment is under processing. When user gets redirected back from the payment gateway, to your website, then only mcForm will know the actual status of the payment and would send another admin email to notify. <code>%1$s</code> will be replaced by the invoice ID. Other format strings are also available.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
<?php
	}

	public function payment_coupon() {
		$op = $this->settings['payment']['coupons'];
		$coupons = array();
		$coupons[] = array(
			'value' => 'percentage',
			'label' => __( 'Percentage Deduction', 'mc_form' ),
		);
		$coupons[] = array(
			'value' => 'amount',
			'label' => __( 'Total Deduction', 'mc_form' ),
		);
		$settings = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Coupon', 'mc_form' ),
					'size' => '35',
					'type' => 'text',
				),
				1 => array(
					'label' => __( 'Type', 'mc_form' ),
					'size' => '20',
					'type' => 'select',
				),
				2 => array(
					'label' => __( 'Value', 'mc_form' ),
					'size' => '15',
					'type' => 'spinner',
				),
				3 => array(
					'label' => __( 'Minimum Amount', 'mc_form' ),
					'size' => '15',
					'type' => 'spinner',
				),
			),
			'labels' => array(
				'add' => __( 'Add New Coupon', 'mc_form' ),
			),
		);
		// 0 => array(
		// 	'code' => 'xyz',
		// 	'type' => 'per', // per => percentage, val => value, formula => 10+M1*0.25
		// 	'value' => '',
		// ),
		$items = array();
		$max_key = null;
		foreach ( $op as $c_key => $coupon ) {
			$max_key = max( array( $max_key, $c_key ) );
			$items[] = array(
				0 => array( 'settings[payment][coupons][' . $c_key . '][code]', $coupon['code'], __( 'Code', 'mc_form' ) ),
				1 => array( 'settings[payment][coupons][' . $c_key . '][type]', $coupons, $coupon['type'] ),
				2 => array( 'settings[payment][coupons][' . $c_key . '][value]', $coupon['value'], __( 'Value', 'mc_form' ) ),
				3 => array( 'settings[payment][coupons][' . $c_key . '][min]', $coupon['min'], __( 'Minimum', 'mc_form' ) ),
			);
		}
		$data = array(
			0 => array( 'settings[payment][coupons][__SDAKEY__][code]', '', __( 'Code', 'mc_form' ) ),
			1 => array( 'settings[payment][coupons][__SDAKEY__][type]', $coupons, 'percentage' ),
			2 => array( 'settings[payment][coupons][__SDAKEY__][value]', '', __( 'Value', 'mc_form' ) ),
			3 => array( 'settings[payment][coupons][__SDAKEY__][min]', '0', __( 'Minimum', 'mc_form' ) ),
		);
		$this->ui->sda_list( $settings, $items, $data, $max_key );
	}

	public function payment_stripe() {
		$op = $this->settings['payment']['stripe'];
		$modes = array();
		$modes[] = array(
			'value' => 'sandbox',
			'label' => __( 'Sandbox', 'mc_form' ),
		);
		$modes[] = array(
			'value' => 'live',
			'label' => __( 'Live', 'mc_form' ),
		);
		$stripe_items_pf = 'settings[payment][stripe]';
		$sub_item_name_pf = $stripe_items_pf . '[subscription]';
		// Stripe Items
		$stripe_items = [];
		// Enable Subscription
		$stripe_items[] = [
			'name' => $sub_item_name_pf . '[enabled]',
			'label' => __( 'Enable Stripe Subscription', 'mc_form' ),
			'description' => __( 'Enabling this will disable all payment gateways and will make login mandatory before submitting the form.', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $sub_item_name_pf . '[enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['subscription']['enabled'], '1', false, true, [
				'condid' => 'mcform_pm_st_sb_wrap',
			] ],
		];

		// Subscription items
		$subscription_items = [];
		// Plan types
		$sub_plan_types = [
			0 => [
				'label' => __( 'Dynamic Plan', 'mc_form' ),
				'value' => 'dynamic',
				'data' => [
					'condid' => 'mcform_pm_st_sb_pn,mcform_pm_st_sb_pif,mcform_pm_st_sb_sd,mcform_pm_st_sb_pic,mcform_pm_st_sb_prn'
				],
			],
			1 => [
				'label' => __( 'Predefined Plans', 'mc_form' ),
				'value' => 'static',
				'data' => [
					'condid' => 'mcform_pm_st_sb_dpi,mcform_pm_st_sb_condplans'
				],
			],
		];
		// Intervals
		$sub_plan_intervals = [
			'day' => __( 'Day', 'mc_form' ),
			'week' => __( 'Week', 'mc_form' ),
			'month' => __( 'Month', 'mc_form' ),
			'year' => __( 'Year', 'mc_form' ),
		];
		// Subscription Type
		$subscription_items[] = [
			'name' => $sub_item_name_pf . '[type]',
			'label' => __( 'Plan Type', 'mc_form' ),
			'ui' => 'select',
			'param' => [ $sub_item_name_pf . '[type]', $sub_plan_types, $op['subscription']['type'], false, true ],
			'help' => __( 'Select the subscription plan type. If your amount changes based on the form, then select the dynamic. This will create a new plan and will assign the customer to the specific plan. Otherwise, you can use the static plan where you will use a pre defined plan you have made from the Stripe Dashboard and conditionally assign the plan. In this case, the amount will be what you have defined in the plan, not the one calculated by payment element. It is a good idea to have the payment element reflect the same amount.', 'mc_form' ),
		];
		// Product Name
		$subscription_items[] = [
			'name' => $sub_item_name_pf . '[product_name]',
			'label' => __( 'Product Name', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $sub_item_name_pf . '[product_name]', $op['subscription']['product_name'], __( 'Required', 'mc_form' ) ],
			'description' => __( 'Product ID will be generated automatically based on form ID', 'mc_form' ),
			'help' => __( 'Starting with Stripe API Update 2018-02-05 all plans now go under a service type product. mcForm leverages this new feature by grouping all dynamic plans under a specific product linked to this form. Please enter a name of the product so that you can easily search. All previous plans will not get automatically assigned to this product. If you want, you can do this manually. Also make sure you have upgraded the Stripe API to latest from Stripe Dashboard.', 'mc_form' ),
			'id' => 'mcform_pm_st_sb_prn',
		];
		// Dynamic Plan Statement Description
		$subscription_items[] = [
			'name' => $sub_item_name_pf . '[statement_descriptor]',
			'label' => __( 'Statement Descriptor', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $sub_item_name_pf . '[statement_descriptor]', $op['subscription']['statement_descriptor'], __( 'Required', 'mc_form' ), 'fit', 'normal', [], false, false, [
				'maxlength' => '22',
			] ],
			'help' => __( 'Set the description that appears on CC billing. Max 22 characters.', 'mc_form' ),
			'id' => 'mcform_pm_st_sb_sd',
		];
		// Dynamic Plan Name
		$subscription_items[] = [
			'name' => $sub_item_name_pf . '[plan_name]',
			'label' => __( 'Dynamic Plan Name', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $sub_item_name_pf . '[plan_name]', $op['subscription']['plan_name'], __( 'Required', 'mc_form' ) ],
			'description' => __( 'Plan ID will be generated automatically based on submission ID', 'mc_form' ),
			'help' => __( 'Select the name of the Plan which will appear in your Stripe Dashboard. Format strings are accepted here.', 'mc_form' ),
			'id' => 'mcform_pm_st_sb_pn',
		];
		// Dynamic Plan Interval Count
		$subscription_items[] = [
			'name' => $sub_item_name_pf . '[interval_count]',
			'label' => __( 'Interval Count', 'mc_form' ),
			'ui' => 'spinner',
			'param' => [ $sub_item_name_pf . '[interval_count]', $op['subscription']['interval_count'], __( 'Required', 'mc_form' ), '1', '', '1' ],
			'help' => __( 'The number of intervals between each subscription billing. For example, if count set to 3 and interval set to month, then bills every 3 month. According to Stripe, maximum of one year interval allowed (1 year, 12 months or 52 weeks).', 'mc_form' ),
			'id' => 'mcform_pm_st_sb_pic',
		];
		// Dynamic Plan Interval
		$subscription_items[] = [
			'name' => $sub_item_name_pf . '[plan_interval]',
			'label' => __( 'Plan Interval', 'mc_form' ),
			'description' => __( 'Maximum 1 year.', 'mc_form' ),
			'ui' => 'select',
			'param' => [ $sub_item_name_pf . '[plan_interval]', $sub_plan_intervals, $op['subscription']['plan_interval'] ],
			'help' => __( 'Set the interval/billing frequency. If you are setting year, then make sure the interval count is set to one.', 'mc_form' ),
			'id' => 'mcform_pm_st_sb_pif',
		];
		// Static Default Plan ID
		$subscription_items[] = [
			'name' => $sub_item_name_pf . '[default_plan_id]',
			'label' => __( 'Default Plan ID', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $sub_item_name_pf . '[default_plan_id]', $op['subscription']['default_plan_id'], __( 'Required', 'mc_form' ) ],
			'help' => __( 'Set the default plan ID to subscribe the customer to.', 'mc_form' ),
			'id' => 'mcform_pm_st_sb_dpi',
		];
		// Conditional Plan selector
		$cond_plan_data = [];
		foreach ( (array) $op['subscription']['cond_plans'] as $item_key => $item ) {
			$new_cond_plan_data = [];
			foreach ( $item as $data_key => $data ) {
				if ( 'logics' == $data_key ) {
					$new_cond_plan_data[ $data_key ] = $data;
				} else {
					$new_cond_plan_data[ $data_key ] = [ $sub_item_name_pf . '[cond_plans][' . $item_key . '][' . $data_key . ']', $data, __( 'Required', 'mc_form' ) ];
				}
			}
			if ( ! isset( $new_cond_plan_data['logics'] ) ) {
				$new_cond_plan_data['logics'] = [];
			}
			$cond_plan_data[ $item_key ] = $new_cond_plan_data;
		}
		$cond_plan_config = [
			0 => [
				'label' => __( 'Stripe Plan ID', 'mc_form' ),
				'type' => 'text',
				'size' => '100',
				'data' => [ $sub_item_name_pf . '[cond_plans][__SDAKEY__][planid]', '', __( 'Required', 'mc_form' ) ],
			],
		];
		?>
<table class="form-table" style="margin-bottom: 0;">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][stripe][enabled]', __( 'Enable Stripe Payment', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[payment][stripe][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, [
				'condid' => 'mcform_pm_stripe_config_wrap',
			] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enable Paypal Payment here. Please make sure you have obtaiend and saved the stripe client id and client secrets.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
<div id="mcform_pm_stripe_config_wrap">
	<table class="form-table no-margin">
		<tbody>
			<tr>
				<th><?php $this->ui->generate_label( 'settings[payment][stripe][label_stripe]', __( 'Option label for Stripe Checkout', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->text( 'settings[payment][stripe][label_stripe]', $op['label_stripe'], __( 'Credit Card (Stripe)', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Set the label that is shown in the radio buttons for stripe based direct credit card checkout.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( 'settings[payment][stripe][zero_decimal]', __( 'Zero Decimal Currency', 'mc_form' ) ); ?></th>
				<td>
				<?php $this->ui->toggle( 'settings[payment][stripe][zero_decimal]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['zero_decimal'] ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'By default mcForm would multiply the amount by 100 (as specified in stripe documentation) to generate the resulting amount. But if you have mentioned currency which is zero-decimal (i.e, the currency itself is the lowest/smallest currency unit then you need to enable this feature. More information <a href="https://support.stripe.com/questions/which-zero-decimal-currencies-does-stripe-support" target="_blank">here</a>. For USD always leave it off.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( 'settings[payment][stripe][pub]', __( 'Stripe Publishable API Key', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->text( 'settings[payment][stripe][pub]', $op['pub'], __( 'Required', 'mc_form' ) ); ?>
					<p><span class="description">
						<?php printf( __( 'Get your <a href="%1$s" target="_blank">Publishable API key</a>.', 'mc_form' ), 'https://dashboard.stripe.com/account/apikeys' ); ?>
					</span></p>
				</td>
				<td>
					<?php $this->ui->help( __( 'Please enter your stripe API key. The API key can be for live mode or test mode. The result would be in accordance. If you need help on where to find your API key, you can <a href="https://support.stripe.com/questions/where-do-i-find-my-api-keys" target="_blank">read this</a>.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( 'settings[payment][stripe][api]', __( 'Stripe Secret API Key', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->cpassword( 'settings[payment][stripe][api]', $op['api'], __( 'Required', 'mc_form' ) ); ?>
					<p><span class="description">
						<?php printf( __( 'Get your <a href="%1$s" target="_blank">Secret API key</a>.', 'mc_form' ), 'https://dashboard.stripe.com/account/apikeys' ); ?>
					</span></p>
				</td>
				<td>
					<?php $this->ui->help( __( 'Please enter your stripe API key. The API key can be for live mode or test mode. The result would be in accordance. If you need help on where to find your API key, you can <a href="https://support.stripe.com/questions/where-do-i-find-my-api-keys" target="_blank">read this</a>.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<?php $this->ui->form_table( $stripe_items, false ); ?>
		</tbody>
	</table>
	<div id="mcform_pm_st_sb_wrap">
		<table class="form-table">
			<tbody>
				<?php $this->ui->form_table( $subscription_items, false ); ?>
				<tr id="mcform_pm_st_sb_condplans">
					<td colspan="3">
						<?php $this->build_conditional_config( $sub_item_name_pf . '[cond_plans]', $cond_plan_config, 'logics', '', $cond_plan_data ); ?>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
		<?php
	}

	public function payment_authorize() {
		$op = $this->settings['payment']['authorizenet'];
		$modes = array();
		$modes[] = array(
			'value' => 'sandbox',
			'label' => __( 'Sandbox', 'mc_form' ),
		);
		$modes[] = array(
			'value' => 'live',
			'label' => __( 'Live', 'mc_form' ),
		);

		// Table items
		// With new Admin UI API -- YAY
		$items = array();
		// Enabled
		$items[] = array(
			'name' => 'settings[payment][authorizenet][enabled]',
			'label' => __( 'Enable Authorize.net Credit Card Payment', 'mc_form' ),
			'ui' => 'toggle',
			'param' => array( 'settings[payment][authorizenet][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
				'condid' => 'mc_form_settings_authnet_la,mc_form_settings_authnet_li,mc_form_settings_authnet_tk,mc_form_settings_authnet_am',
			) ),
			'help' => __( 'Enable this settings if you want to use Authorize.net Payment Gateway.', 'mc_form' ),
		);
		// Label
		$items[] = array(
			'name' => 'settings[payment][authorizenet][label]',
			'label' => __( 'Option Label for Authorize.net Checkout', 'mc_form' ),
			'ui' => 'text',
			'param' => array( 'settings[payment][authorizenet][label]', $op['label'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Set the label that is shown in the radio buttons for authorizenet.net based direct credit card checkout.', 'mc_form' ),
			'id' => 'mc_form_settings_authnet_la',
		);
		// Mode
		$items[] = array(
			'name' => 'settings[payment][authorizenet][mode]',
			'label' => __( 'API Mode', 'mc_form' ),
			'ui' => 'select',
			'param' => array( 'settings[payment][authorizenet][mode]', $modes, $op['mode'] ),
			'help' => __( 'Set the API mode.', 'mc_form' ),
			'id' => 'mc_form_settings_authnet_am',
			/** translators: %1$s is replaced by a authorize.net kb article link */
			'description' => __( 'Set the API Key mode. It could be either sandbox or live.', 'mc_form' ),
		);
		// Login ID
		$items[] = array(
			'name' => 'settings[payment][authorizenet][login_id]',
			'label' => __( 'API Login ID', 'mc_form' ),
			'ui' => 'text',
			'param' => array( 'settings[payment][authorizenet][login_id]', $op['login_id'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Set the API Login ID you can obtain from authorize.net.', 'mc_form' ),
			'id' => 'mc_form_settings_authnet_li',
			/** translators: %1$s is replaced by a authorize.net kb article link */
			'description' => sprintf( __( 'Get <a href="%1$s">API Login ID</a>.', 'mc_form' ), 'https://support.authorize.net/authkb/index?page=content&id=A405' ),
		);
		// Transaction Key
		$items[] = array(
			'name' => 'settings[payment][authorizenet][transaction_key]',
			'label' => __( 'API Transaction Key', 'mc_form' ),
			'ui' => 'password',
			'param' => array( 'settings[payment][authorizenet][transaction_key]', $op['transaction_key'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Set the API Transaction Key you can obtain from authorize.net.', 'mc_form' ),
			'id' => 'mc_form_settings_authnet_tk',
			/** translators: %1$s is replaced by a authorize.net kb article link */
			'description' => sprintf( __( 'Get <a href="%1$s">API Transaction Key</a>.', 'mc_form' ), 'https://support.authorize.net/authkb/index?page=content&id=A405' ),
		);
		$this->ui->form_table( $items );
	}

	public function payment_offline() {
		$op = $this->settings['payment']['offline'];
		$items = [];
		// Enabled
		$items[] = array(
			'name' => 'settings[payment][offline][enabled]',
			'label' => __( 'Enable Offline Payment', 'mc_form' ),
			'ui' => 'toggle',
			'param' => array( 'settings[payment][offline][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
				'condid' => 'mc_form_settings_pmofl_la,mc_form_settings_pmofl_ins,mc_form_settings_pmofl_sts,mc_form_settings_pmofl_esub,mc_form_settings_pmofl_emsg',
			) ),
			'help' => __( 'Enable this settings if you want to use Offline Payment Gateway, such as Bank Transfer, Cash on Delivery.', 'mc_form' ),
		);
		// Label
		$items[] = array(
			'name' => 'settings[payment][offline][label]',
			'label' => __( 'Option Label for Offline Checkout', 'mc_form' ),
			'ui' => 'text',
			'param' => array( 'settings[payment][offline][label]', $op['label'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Set the label that is shown in the radio buttons for offline checkout.', 'mc_form' ),
			'id' => 'mc_form_settings_pmofl_la',
		);
		// Instruction
		$items[] = [
			'name' => 'settings[payment][offline][instruction]',
			'label' => __( 'Instruction of Offline Payment', 'mc_form' ),
			'ui' => 'textarea',
			'param' => [ 'settings[payment][offline][instruction]', $op['instruction'], __( 'Required', 'mc_form' ) ],
			'id' => 'mc_form_settings_pmofl_ins',
			'help' => __( 'Enter the instruction text that will appear when your user chooses this gateway.', 'mc_form' ),
		];
		// Invoice Status
		$items[] = [
			'name' => 'settings[payment][offline][status]',
			'label' => __( 'Invoice Status', 'mc_form' ),
			'ui' => 'textarea',
			'param' => [ 'settings[payment][offline][status]', $op['status'], __( 'Required', 'mc_form' ) ],
			'id' => 'mc_form_settings_pmofl_sts',
			'help' => __( 'Enter the text that will appear on the invoice when payment is not confirmed yet. <strong><code>%1$s</code></strong> will be replaced by Invoice ID and <strong><code>%2$s</code></strong> will be replaced by Transaction ID.', 'mc_form' ),
		];
		// Email Subject
		$items[] = array(
			'name' => 'settings[payment][offline][email_sub]',
			'label' => __( 'Payment Email Subject', 'mc_form' ),
			'ui' => 'text',
			'param' => array( 'settings[payment][offline][email_sub]', $op['email_sub'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Set the subject of the payment email. All format strings are available.', 'mc_form' ),
			'id' => 'mc_form_settings_pmofl_esub',
		);
		// Email Message
		$items[] = array(
			'name' => 'settings[payment][offline][email_msg]',
			'label' => __( 'Payment Email Message', 'mc_form' ),
			'ui' => 'textarea',
			'param' => array( 'settings[payment][offline][email_msg]', $op['email_msg'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Set the message of the payment email. All format strings are available.', 'mc_form' ),
			'id' => 'mc_form_settings_pmofl_emsg',
		);
		$this->ui->form_table( $items );
	}

	public function payment_paypal() {
		$op = $this->settings['payment']['paypal'];
		$modes = array();
		$modes[] = array(
			'value' => 'sandbox',
			'label' => __( 'Sandbox', 'mc_form' ),
		);
		$modes[] = array(
			'value' => 'live',
			'label' => __( 'Live', 'mc_form' ),
		);

		?>
<table class="form-table no-margin">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][enabled]', __( 'Enable Paypal Payment', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[payment][paypal][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, [
				'condid' => 'mcform_pm_paypal_config',
			] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enable Paypal Payment here. Please make sure you have obtaiend and saved the paypal client id and client secrets.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
<table class="form-table" id="mcform_pm_paypal_config">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][mode]', __( 'Paypal Payment Mode', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[payment][paypal][mode]', $modes, $op['mode'] ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'Following modes are available for testing and publishing.', 'mc_form' ); ?></p>
				<ul>
					<li><?php _e( '<code>Sandbox</code>: Used for testing.' ) ?></li>
					<li><?php _e( '<code>Live</code>: Used for production.' ) ?></li>
				</ul>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][allow_direct]', __( 'Allow Direct Payment Mode', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[payment][paypal][allow_direct]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['allow_direct'] ); ?>
			<br /><span class="description"><?php _e( 'PayPal has discontinued new direct credit card integration. Existing ones may still work. We will soon implement BrainTreePayments to complement this. For now, kindly use Stripe.', 'mc_form' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then users would be able to directly pay by entering their credit card information. Do note that if you do not have <a href="https://developer.paypal.com/developer/accountStatus" target="_blank">account eligibility</a> then disable this. Otherwise users might get unintended errors.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][label_paypal_e]', __( 'Option label for Express Checkout', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][paypal][label_paypal_e]', $op['label_paypal_e'], __( 'PayPal Express', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the label that is shown in the radio buttons for express checkout.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][label_paypal_d]', __( 'Option label for Direct Checkout', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][paypal][label_paypal_d]', $op['label_paypal_d'], __( 'PayPal Direct', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the label that is shown in the radio buttons for direct credit card checkout.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][d_settings]', __( 'PayPal RESTful APIs', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->generate_label( 'settings[payment][paypal][d_settings][client_id]', __( 'Client ID', 'mc_form' ) ); ?>
			<?php $this->ui->text( 'settings[payment][paypal][d_settings][client_id]', $op['d_settings']['client_id'], __( 'Client ID', 'mc_form' ) ); ?>
			<hr />
			<?php $this->ui->generate_label( 'settings[payment][paypal][d_settings][client_secret]', __( 'Client Secret', 'mc_form' ) ); ?>
			<?php $this->ui->cpassword( 'settings[payment][paypal][d_settings][client_secret]', $op['d_settings']['client_secret'], __( 'Client Secret', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'You can obtain your client id and client secret from the following links.', 'mc_form' ); ?></p>
				<ul>
					<li><?php printf( __( 'Go to <a href="%1$s" target="_blank">Paypal Developer</a>', 'mc_form' ), 'https://developer.paypal.com/developer/applications/' ); ?></li>
					<li><?php _e( 'Create a new REST API app under Dashboard > My Apps & Credentials', 'mc_form' ); ?></li>
					<li><?php _e( 'Copy the client ID and client secret.', 'mc_form' ); ?></li>
				</ul>
				<p><?php _e( 'The REST API app can be created under a sandbox facilitator (business) account.', 'mc_form' ); ?></p>
				<p><?php _e( 'In some country live transactions are not available. Please check your <a href="https://developer.paypal.com/developer/accountStatus" target="_blank">account eligibility</a>. If Direct credit cards isn\'t available, then do not enable Direct Payment Mode, as this may lead to failures.', 'mc_form' ); ?></p>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][partner]', __( 'PayPal Partner ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][paypal][partner]', $op['partner'], __( 'Optional', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Use this if you are a PayPal partner. Specify a unique BN Code to receive revenue attribution. To learn more or to request a BN Code, contact your Partner Manager or visit the PayPal Partner Portal', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][conf_sub]', __( 'Express Checkout Confirmation Email Subject', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][paypal][conf_sub]', $op['conf_sub'], __( 'Required', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the subject of the email that is sent when paypal express checkout has been processed (i.e, user has been sent back to your site). <code>%1$s</code> will be replaced by the invoice ID.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][paypal][conf_msg]', __( 'Express Checkout Confirmation Email Message', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[payment][paypal][conf_msg]', $op['conf_msg'], __( 'HTML Enabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the email body of the same.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function ranking() {
		$op = $this->settings['ranking'];
		$r_select = array();
		$r_select[] = array(
			'value' => 'percentage',
			'label' => __( 'Percentage Score', 'mc_form' ),
			'data' => array(
				'condid' => 'ranking_percentage',
			),
		);
		$r_select[] = array(
			'value' => 'raw',
			'label' => __( 'Total Score', 'mc_form' ),
			'data' => array(
				'condid' => 'ranking_raw',
			),
		);
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[ranking][precision]', __( 'Score Decimal Precision', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[ranking][precision]', $op['precision'], __( 'Enter Number', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Score and Percentage precision after decimal point.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[ranking][enabled]', __( 'Enable Ranking System based on Score', 'mc_form' ) ); ?></th>
			<td>
			<?php $this->ui->toggle( 'settings[ranking][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
				'condid' => 'mc_form_ranking_title_wrap,mc_form_ranking_ranks_wrap,mc_form_ranking_rtype_wrap'
			) ); ?>
			</td>
			<td style="width: 50px;">
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'If you wish to designate some rank to your users based on score, then enable this system. You will have option to put titles and custom messages for each of the designations.', 'mc_form' ); ?></p>
				<p><?php _e( 'While entering the Message, you have the following format strings available.', 'mc_form' ); ?></p>
				<ul class="ul-square">
					<li><strong>%NAME%</strong> : <?php _e( 'Will be replaced by the full name of the user.', 'mc_form' ); ?></li>
					<li><strong>%TRACK_LINK%</strong> : <?php _e( 'Will be replaced by the raw link from where the user can see the status of his submission.', 'mc_form' ); ?></li>
					<li><strong>%TRACK%</strong> : <?php _e( 'Will be replaced by a "Click Here" button linked to the track page.', 'mc_form' ); ?></li>
					<li><strong>%SCORE%</strong> : <?php _e( 'Will be replaced by the score obtained/total score.', 'mc_form' ); ?></li>
					<li><strong>%SCOREPERCENT%</strong> : <?php _e( 'Will be replaced by the percentage score obtained.', 'mc_form' ); ?></li>
					<li><strong>%DESIGNATION%</strong> : <?php _e( 'If the score falls under a valid ranking range, then this will be replaced by the given designation title.', 'mc_form' ); ?></li>
					<li><strong>%TRACK_ID%</strong> : <?php _e( 'Will be replaced by the Tracking ID of the submission which the user can enter in the track page.', 'mc_form' ); ?></li>
				</ul>
				<p><?php printf( __( 'An updated list can always be found <a href="%1$s" target="_blank">here</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/form-submission-related/available-format-strings-custom-notifications/' ); ?></p>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr id="mc_form_ranking_title_wrap">
			<th><?php $this->ui->generate_label( 'settings[ranking][title]', __( 'Ranking Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[ranking][title]', $op['title'], __( 'Shown on Rank Column on trackback page', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The title of the ranking system. For eg, Designation.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_ranking_rtype_wrap">
			<th><?php $this->ui->generate_label( 'settings[ranking][rtype]', __( 'Ranking Based On', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->select( 'settings[ranking][rtype]', $r_select, $op['rtype'], false, true ); ?></td>
			<td><?php $this->ui->help( __( 'Here you can set the ranking based on either percentage obtained or total score obtained.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_ranking_ranks_wrap">
			<td colspan="3">
				<?php $this->ranking_ranks(); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function ranking_ranks() {
		$op = $this->settings['ranking']['ranks'];
		$settings = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Score From (%)', 'mc_form' ),
					'size' => '17',
					'type' => 'spinner',
				),
				1 => array(
					'label' => __( 'Score To (%)', 'mc_form' ),
					'size' => '17',
					'type' => 'spinner',
				),
				2 => array(
					'label' => __( 'Designation', 'mc_form' ),
					'size' => '25',
					'type' => 'text',
				),
				3 => array(
					'label' => __( 'Message', 'mc_form' ),
					'size' => '41',
					'type' => 'textarea',
				),
			),
			'labels' => array(
				'add' => __( 'Add New Rank', 'mc_form' ),
			),
		);
		$items = array();
		$max_key = null;
		foreach ( $op as $r_key => $rank ) {
			$max_key = max( array( $max_key, $r_key ) );
			$items[] = array(
				0 => array( 'settings[ranking][ranks][' . $r_key . '][min]', $rank['min'], __( 'Min Score', 'mc_form' ) ),
				1 => array( 'settings[ranking][ranks][' . $r_key . '][max]', $rank['max'], __( 'Max Score', 'mc_form' ) ),
				2 => array( 'settings[ranking][ranks][' . $r_key . '][title]', $rank['title'], __( 'Rank Designation', 'mc_form' ), 'fit' ),
				3 => array( 'settings[ranking][ranks][' . $r_key . '][msg]', $rank['msg'], __( 'Message Shown', 'mc_form' ), 'fit' ),
			);
		}
		$data = array(
			0 => array( 'settings[ranking][ranks][__SDAKEY__][min]', 10, __( 'Min Score', 'mc_form' ) ),
			1 => array( 'settings[ranking][ranks][__SDAKEY__][max]', 80, __( 'Max Score', 'mc_form' ) ),
			2 => array( 'settings[ranking][ranks][__SDAKEY__][title]', '', __( 'Rank Designation', 'mc_form' ), 'fit' ),
			3 => array( 'settings[ranking][ranks][__SDAKEY__][msg]', '', __( 'Message Shown', 'mc_form' ), 'fit' ),
		);
		$this->ui->sda_list( $settings, $items, $data, $max_key, 'ranking_percentage' );

		$r_settings = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Score From', 'mc_form' ),
					'size' => '17',
					'type' => 'spinner',
				),
				1 => array(
					'label' => __( 'Score To', 'mc_form' ),
					'size' => '17',
					'type' => 'spinner',
				),
				2 => array(
					'label' => __( 'Designation', 'mc_form' ),
					'size' => '25',
					'type' => 'text',
				),
				3 => array(
					'label' => __( 'Message', 'mc_form' ),
					'size' => '41',
					'type' => 'textarea',
				),
			),
			'labels' => array(
				'add' => __( 'Add New Rank', 'mc_form' ),
			),
		);
		$r_items = array();
		$r_max_key = null;
		foreach ( $this->settings['ranking']['rranks'] as $rs_key => $rranks ) {
			$r_max_key = max( array( $r_max_key, $rs_key ) );
			$r_items[] = array(
				0 => array( 'settings[ranking][rranks][' . $rs_key . '][min]', $rranks['min'], __( 'Min Score', 'mc_form' ) ),
				1 => array( 'settings[ranking][rranks][' . $rs_key . '][max]', $rranks['max'], __( 'Max Score', 'mc_form' ) ),
				2 => array( 'settings[ranking][rranks][' . $rs_key . '][title]', $rranks['title'], __( 'Rank Designation', 'mc_form' ), 'fit' ),
				3 => array( 'settings[ranking][rranks][' . $rs_key . '][msg]', $rranks['msg'], __( 'Message Shown', 'mc_form' ), 'fit' ),
			);
		}
		$r_data = array(
			0 => array( 'settings[ranking][rranks][__SDAKEY__][min]', '', __( 'Min Score', 'mc_form' ) ),
			1 => array( 'settings[ranking][rranks][__SDAKEY__][max]', '', __( 'Max Score', 'mc_form' ) ),
			2 => array( 'settings[ranking][rranks][__SDAKEY__][title]', '', __( 'Rank Designation', 'mc_form' ), 'fit' ),
			3 => array( 'settings[ranking][rranks][__SDAKEY__][msg]', '', __( 'Message Shown', 'mc_form' ), 'fit' ),
		);
		$this->ui->sda_list( $r_settings, $r_items, $r_data, $r_max_key, 'ranking_raw' );
	}

	public function timer() {
		$op = $this->settings['timer'];
		$select_types = array(
			0 => array(
				'value' => 'none',
				'label' => __( 'Disabled', 'mc_form' ),
			),
			1 => array(
				'value' => 'overall',
				'label' => __( 'Overall Time Limit', 'mc_form' ),
				'data' => array( 'condid' => 'mc_form_timer_overall_limit_wrap' ),
			),
			2 => array(
				'value' => 'page_specific',
				'label' => __( 'Page Specific Time Limit', 'mc_form' ),
			),
		);
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[timer][time_limit_type]', __( 'Auto Submit Timer', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[timer][time_limit_type]', $select_types, $op['time_limit_type'], false, true ); ?>
			</td>
			<td>
				<?php $this->ui->help_head(); ?>
				<p><?php _e( 'If you want the form to auto submit after a specified time, then enable it from here.', 'mc_form' ); ?></p>
				<p><?php _e('The auto submission can be of two type:', 'mc_form'); ?></p>
				<ol>
					<li><strong><?php _e('Overall Time Limit', 'mc_form'); ?></strong>: <?php _e('The whole of the form is submitted after the specified time (in seconds).', 'mc_form'); ?></li>
					<li><strong><?php _e('Page Specific Time Limit', 'mc_form'); ?></strong>: <?php _e('Each of the pages/tabs/containers are automatically progressed after the specified time (in seconds). If this is selected, then it would automatically disable pagination to left.', 'mc_form'); ?></li>
				</ol>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr id="mc_form_timer_overall_limit_wrap">
			<th><?php $this->ui->generate_label( 'settings[timer][overall_limit]', __( 'Overall Time Limit (seconds)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[timer][overall_limit]', $op['overall_limit'], __( 'Seconds', 'mc_form' ), '0' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the total time in seconds after which the form will auto submit.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function stopwatch() {
		$op = $this->settings['stopwatch'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[stopwatch][enabled]', __( 'Record Form Submission Time', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[stopwatch][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_stopwatch_title,mc_form_stopwatch_seconds,mc_form_stopwatch_hours,mc_form_stopwatch_days,mc_form_stopwatch_add_on_edit,mc_form_stopwatch_rotate,mc_form_stopwatch_hidden'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enabling will record the form submission time. A timer would show up just above the tabs/container.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_stopwatch_title">
			<th><?php $this->ui->generate_label( 'settings[stopwatch][title]', __( 'Summary Table Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[stopwatch][title]', $op['title'], __( 'Required', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Title of the summary table row that would present the time spent.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_stopwatch_seconds">
			<th><?php $this->ui->generate_label( 'settings[stopwatch][seconds]', __( 'Show seconds', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[stopwatch][seconds]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['seconds'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Show the seconds circle.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_stopwatch_hours">
			<th><?php $this->ui->generate_label( 'settings[stopwatch][hours]', __( 'Show hours', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[stopwatch][hours]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['hours'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Show the hours circle.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_stopwatch_days">
			<th><?php $this->ui->generate_label( 'settings[stopwatch][days]', __( 'Show days', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[stopwatch][days]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['days'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Show the days circle.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_stopwatch_add_on_edit">
			<th><?php $this->ui->generate_label( 'settings[stopwatch][add_on_edit]', __( 'Add to time when editing', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[stopwatch][add_on_edit]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['add_on_edit'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then more time would be added when user comes back to edit the form. Otherwise, it would just stay as is from the first time submission.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_stopwatch_rotate">
			<th><?php $this->ui->generate_label( 'settings[stopwatch][rotate]', __( 'Rotated Position on bigger screen', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[stopwatch][rotate]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['rotate'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled, then on bigger screens the timer would appear on the right side of the form with a rotation of 90 degrees. If this causes trouble with your theme, then disable it.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_stopwatch_hidden">
			<th><?php $this->ui->generate_label( 'settings[stopwatch][hidden]', __( 'Hidden Stopwatch', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[stopwatch][hidden]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['hidden'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If enabled then the stopwatch will stay hidden. The time will be recorded but would not be shown to the user.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function summary() {
		$op = $this->settings['summary'];
		$booleans = array(
			'show_details'      => __( 'Show Submission Details Table (ID, date etc).', 'mc_form' ),
			'show_elements'     => __( 'Show Full Form Elements Table', 'mc_form' ),
			'f_name'            => __( 'Show First Name', 'mc_form' ),
			'l_name'            => __( 'Show Last Name', 'mc_form' ),
			'email'             => __( 'Show Email', 'mc_form' ),
			'phone'             => __( 'Show Phone', 'mc_form' ),
			'ip'                => __( 'Show IP Address', 'mc_form' ),
			'total_score'       => __( 'Show Total Score', 'mc_form' ),
			'average_score'     => __( 'Show Average Score', 'mc_form' ),
			'designation'       => __( 'Show Designation', 'mc_form' ),
			'user_account'      => __( 'Show User Account', 'mc_form' ),
			'link'              => __( 'Show Trackback Link', 'mc_form' ),
			'individual_score'  => __( 'Show Individual Scores for elements', 'mc_form' ),
			'hide_options'      => __( 'Hide Unselected Options', 'mc_form' ),
			'highlight_correct' => __( 'Highlight Correct Option (with max score)', 'mc_form' ),
			'positive_correct'  => __( 'Highlight All Positive Score Options', 'mc_form' ),
			'hide_unattempted'  => __( 'Hide Unattempted Questions', 'mc_form' ),
			'show_design'       => __( 'Show Design Elements', 'mc_form' ),
		);
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][id_format]', __( 'Submission ID format', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[summary][id_format]', $op['id_format'], __( 'Disabled', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'A direct <a href="http://php.net/manual/en/function.sprintf.php" target="_blank">sprintf format</a> to customize the output of the ID in the summary table.<br /><ul><li><code>%1$d</code>: Replaced by the submission ID.</li><li><code>%2$s</code>: Replaced by a formatted datetime.</li><li><code>%3$s</code>: Replaced by database stored datetime. It is modified by datetime format of the next field.</li></ul>', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][id_dt_format]', __( 'Submission ID Datetime format', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[summary][id_dt_format]', $op['id_dt_format'], __( 'Disabled', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want to modify the output of <code>%3$s</code> in the ID, then do it here. It accepts any <a href="http://php.net/manual/en/function.date.php" target="_blank">datetime formatting string applicable to PHP</a>.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<?php foreach ( $booleans as $key => $val ) : ?>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][' . $key . ']', $val ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[summary][' . $key . ']', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op[$key] ); ?>
			</td>
			<td></td>
		</tr>
		<?php endforeach; ?>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][correct_color]', __( 'Correct Answer Color', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->colorpicker( 'settings[summary][correct_color]', $op['correct_color'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Choose accent color of the correct answer. Works only if highlight correct answer is enabled. Default: <code>#519548</code>', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][score_title]', __( 'Individual Score Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[summary][score_title]', $op['score_title'], __( 'Write Here', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The title of the individual score cells.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][tscore_title]', __( 'Total Score Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[summary][tscore_title]', $op['tscore_title'], __( 'Write Here', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The title of the total score cell.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][tscore_output]', __( 'Total Score Output', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[summary][tscore_output]', $op['tscore_output'], __( 'Write Here', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The output of the total score cell. <code>%1$s</code> is replaced by formatted obtained score, <code>%2$s</code> is replaced by formatted total score. <code>%3$s</code> is replaced by percentage. Escape <code>%</code> by <code>%%</code> as this string is passed to <code>sprintf</code> family of functions.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][ascore_title]', __( 'Average Score Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[summary][ascore_title]', $op['ascore_title'], __( 'Write Here', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The title of the average score cell. <code>%1$d</code> will be replaced by total number of submissions.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][ascore_output]', __( 'Average Score Output', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[summary][ascore_output]', $op['ascore_output'], __( 'Write Here', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The output of the average score cell. <code>%1$s</code> is replaced by formatted obtained score, <code>%2$s</code> is replaced by formatted total score. <code>%3$s</code> is replaced by percentage. Escape <code>%</code> by <code>%%</code> as this string is passed to <code>sprintf</code> family of functions.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][blacklist]', __( 'Blacklisted Elements', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[summary][blacklist]', $op['blacklist'], __( 'Write Here', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want to hide one or more elements, then mention them here in a comma separated way. For example, <code>L0,D0,M2,F1,O2</code> will blacklist (and there by would not show) Tab 0 (first container in the current order of the form), Design Element 0, MCQ element 2, Feedback Element 1 and Other element 2.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][before]', __( 'Before Summary (HTML)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[summary][before]', $op['before'], __( 'Write Here', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want anything to appear before the summary tables, then put it here.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[summary][after]', __( 'After Summary (HTML)', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[summary][after]', $op['after'], __( 'Write Here', 'mc_form' ), 'widefat', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want anything to appear after the summary tables, then put it here.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function trackback() {
		$op = $this->settings['trackback'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[trackback][show_full]', __( 'Show Full Submission', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[trackback][show_full]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['show_full'] ) ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enable if you want to show the full submission form with it\'s unchanged appearance. Do note that tabbed and paginated forms will be shown in a single page.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[trackback][full_title]', __( 'Full Submission Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[trackback][full_title]', $op['full_title'], __( 'Disabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( 'The title that is shown above the full submission. Leave empty to disable.', 'mc_form' ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[trackback][show_print]', __( 'Show Print Submission', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[trackback][show_print]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['show_print'] ) ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enable if you want to show the print submission summary. This is same as sent in the email and what ever settings you set in the summary area will reflect here.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[trackback][print_title]', __( 'Print Submission Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[trackback][print_title]', $op['print_title'], __( 'Disabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( 'The title that is shown above the print summary. Leave empty to disable.', 'mc_form' ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[trackback][show_trends]', __( 'Show Trends', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[trackback][show_trends]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['show_trends'] ) ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Whether to show a trends of the same form on the same page. This is to give the user a quick comparison look on his/her submission.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[trackback][trends_title]', __( 'Trends Title', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[trackback][trends_title]', $op['trends_title'], __( 'Disabled', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( 'The title shown before the trends/report.', 'mc_form' ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function email_template() {
		$op = $this->settings['email_template'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[email_template][accent_bg]', __( 'Accent Background Color', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->colorpicker( 'settings[email_template][accent_bg]', $op['accent_bg'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Choose accent background color. This is usually the background color of table headings. Default: <code>#0db9ea</code>', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[email_template][accent_color]', __( 'Accent Color', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->colorpicker( 'settings[email_template][accent_color]', $op['accent_color'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Choose accent color. This is usually the text color of table headings. Default: <code>#ffffff</code>', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[email_template][t_color]', __( 'Table Background & Border', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->colorpicker( 'settings[email_template][t_color]', $op['t_color'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Choose email background and table border color. Default: <code>#f6f4f5</code>. Please provide a lighter color code for better readability.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[email_template][color]', __( 'Text Color', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->colorpicker( 'settings[email_template][color]', $op['color'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Choose all text color. Default: <code>#999999</code>', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[email_template][h_color]', __( 'Heading Color', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->colorpicker( 'settings[email_template][h_color]', $op['h_color'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Choose heading text color. Default: <code>#333333</code>', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[email_template][m_color]', __( 'Message Color', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->colorpicker( 'settings[email_template][m_color]', $op['m_color'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Choose message text color. Default: <code>#95a5a6</code>', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[email_template][a_color]', __( 'Anchor Color', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->colorpicker( 'settings[email_template][a_color]', $op['a_color'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Choose anchor (link) text color. Default: <code>#1155cc</code>', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function social() {
		$op = $this->settings['social'];
		$texts = array(
			'facebook_app' => array( __( 'Facebook APP ID', 'mc_form' ), sprintf( __( 'Set the facebook app ID. This is required as only dialog feeds now support custom message and images. To learn about getting app id, <a target="_blank" href="%1$s">click here</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/misc/social-apps/creating-a-facebook-app-and-enabling-login/' ) ),
			'url' => array( __( 'URL of the Form', 'mc_form' ), __( 'Set the URL where the form is shown. If you use <code>%SELF%</code> then it will be replaced by the standalone link.', 'mc_form' ) ),
			'fb_url' => array( __( 'Facebook Redirect URL', 'mc_form' ), __( 'Set the URL where the user would be redirected after a successful share. Make sure the domain is in apps list.', 'mc_form' ) ),
			'fb_hash' => array( __( 'Facebook Share Hash', 'mc_form' ), __( 'Set the single hashtag for facebook share. Write without the hashtag itself.', 'mc_form' ) ),
			'title' => array( __( 'Share Title', 'mc_form' ), __( 'Set the share title. Using <code>%NAME%</code> will make use of the form name.', 'mc_form' ) ),
			'description' => array( __( 'Share Description', 'mc_form' ), __( 'Set the description that is used by different networks. It has the same set of format string available in notification emails. For twitter, google plus and pinterest, it will be appended after the sharing title.', 'mc_form' ) ),
			'twitter_via' => array( __( 'Twitter Via', 'mc_form' ), __( 'Set the name of the twitter profile via which the share is sent.', 'mc_form' ) ),
			'twitter_hash' => array( __( 'Twitter Hashtags', 'mc_form' ), __( 'Enter comma separated hashtags to be used in twitter share.', 'mc_form' ) ),
		);
		$sites_select = array();
		$sites_select[] = array(
			'value' => 'facebook_url',
			'label' => __( 'Facebook', 'mc_form' ),
		);
		$sites_select[] = array(
			'value' => 'twitter_url',
			'label' => __( 'Twitter', 'mc_form' ),
		);
		$sites_select[] = array(
			'value' => 'google_url',
			'label' => __( 'Google Plus', 'mc_form' ),
		);
		$sites_select[] = array(
			'value' => 'pinterest_url',
			'label' => __( 'Pinterest', 'mc_form' ),
		);
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[social][show]', __( 'Show Social Share Buttons', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[social][show]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['show'], '1', false, true, array(
					'condid' => 'mc_form_social_sites_wrap,mc_form_social_image_wrap,mc_form_social_facebook_app_wrap,mc_form_social_url_wrap,mc_form_social_fb_url_wrap,mc_form_social_title_wrap,mc_form_social_description_wrap,mc_form_social_twitter_via_wrap,mc_form_social_twitter_hash_wrap,mc_form_social_fos_wrap,mc_form_social_aau_wrap,mc_form_social_fb_hash_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enabling this setting will have effect on trackback pages, emails, success message and downloads (if using the exporter addon).', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_social_sites_wrap">
			<th><?php $this->ui->generate_label( 'settings[social][sites]', __( 'Active Social Sites', 'mc_form' ) ); ?></th>
			<td>
				<?php foreach ( $sites_select as $social ) : ?>
				<div style="display: inline-block; max-width: 150px">
				<?php $this->ui->generate_label( 'settings[social][sites][' . $social['value'] . ']', $social['label'] ); ?>
				<?php $this->ui->toggle( 'settings[social][sites][' . $social['value'] . ']', __( 'On', 'mc_form' ), __( 'Off', 'mc_form' ), $op['sites'][$social['value']] ); ?>
				</div>
				<?php endforeach; ?>
			</td>
			<td><?php $this->ui->help( __( 'Select the social networking sites for which you want the button to appear.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_social_image_wrap">
			<th><?php $this->ui->generate_label( 'settings[social][image]', __( 'Share Image', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->upload( 'settings[social][image]', $op['image'], '', __( 'Set Image', 'mc_form' ), __( 'Choose Image', 'mc_form' ), __( 'Use Image', 'mc_form' ), '90%', '300px', 'auto' ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The share image used mainly by facebook. If given, this will also render the pinterest link.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_social_fos_wrap">
			<th><?php $this->ui->generate_label( 'settings[social][follow_on_social]', __( 'Forward URL tracking to Social Sharing Links', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[social][follow_on_social]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['follow_on_social'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enabling this will forward the URL tracking key/value parameter to any link you have provided for social sharing. Enable this to track social sharing performace for sharers. Do note that this will work only if you have set URL tracking from Form Settings > Submissions.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_social_aau_wrap">
			<th><?php $this->ui->generate_label( 'settings[social][auto_append_user]', __( 'Auto Append username to URL tracking on Social Sharing Links', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[social][auto_append_user]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['auto_append_user'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'If enabled, then this will automatically append usernames on URL tracking key. This will happen only if no other tracking value is present. Use this for automatically generating trackable URLs for registered users.', 'mc_form' ) ); ?></td>
		</tr>
		<?php foreach ( $texts as $key => $val ) : ?>
		<tr id="mc_form_social_<?php echo $key; ?>_wrap">
			<th><?php $this->ui->generate_label( 'settings[social][' . $key . ']', $val[0] ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[social][' . $key . ']', $op[$key], '', 'fit', 'normal', array('code') ); ?>
			</td>
			<td>
				<?php $this->ui->help( $val[1] ); ?>
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
		<?php
	}

	public function intg_conditional() {
		$this->build_conditional( 'settings[integration]', $this->settings['integration']['conditional'], __( 'Enable Conditional Logic for integration calls', 'mc_form' ), false, '[conditional]', __( 'Call integration only if the conditions are met', 'mc_form' ) );
	}

	public function woocommerce() {
		$woocommerce_dir = 'woocommerce/woocommerce.php';
		if ( ! is_plugin_active( $woocommerce_dir ) ) {
			$installation_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=' . dirname( $woocommerce_dir ) ), 'install-plugin_' . dirname( $woocommerce_dir ) );
			// Check if plugin is installed but not activated
			if ( is_dir( dirname( WP_PLUGIN_DIR . '/' . $woocommerce_dir ) ) && is_plugin_inactive( $woocommerce_dir ) ) {
				$installation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $woocommerce_dir, 'activate-plugin_' . $woocommerce_dir );
			}
			$this->ui->msg_error( sprintf( __( '<strong>WooCommerce Integration</strong> requires <a href="%1$s">WooCommerce Plugin</a> installed and activated.', 'mc_form_mc' ), $installation_url ) );

			return;
		}
		$op = $this->settings['payment']['woocommerce'];
		$redirects = array(
			0 => array(
				'label' => __( 'Cart Page', 'mc_form' ),
				'value' => 'cart',
			),
			1 => array(
				'label' => __( 'Checkout Page', 'mc_form' ),
				'value' => 'checkout',
			),
			2 => array(
				'label' => __( 'Default (as set in Form Settings Redirection)', 'mc_form' ),
				'value' => 'default',
			),
		);
		$woocommerce_statuses = wc_get_order_statuses();
		$woo_status_items = array();
		foreach ( $woocommerce_statuses as $status => $st_name ) {
			// Standardise status names.
			// https://docs.woocommerce.com/wc-apidocs/source-class-WC_Abstract_Order.html#2340
			$status = 'wc-' === substr( $status, 0, 3 ) ? substr( $status, 3 ) : $status;
			$woo_status_items[] = array(
				'value' => $status,
				'label' => $st_name,
			);
		}
		// Backward compatible prior 4.6.1 to mark the paid flag state
		if ( ! is_array( $op['paid_flag_state'] ) ) {
			$op['paid_flag_state'] = [ $op['paid_flag_state'] ];
		}

		// Conditional Product ID
		//build_conditional_config( $name_prefix, $configs, $cond_suffix, $cond_id, $data )
		$cond_pid_data = array();
		foreach ( (array) $op['cond_pid'] as $item_key => $item ) {
			$new_cond_pid_data = array();
			foreach ( $item as $data_key => $data ) {
				if ( 'logics' == $data_key ) {
					$new_cond_pid_data[ $data_key ] = $data;
				} else {
					$new_cond_pid_data[ $data_key ] = array( 'settings[payment][woocommerce][cond_pid][' . $item_key . '][' . $data_key . ']', $data, __( 'Required', 'mc_form' ) );
				}
			}
			if ( ! isset( $new_cond_pid_data['logics'] ) ) {
				$new_cond_pid_data['logics'] = array();
			}
			$cond_pid_data[ $item_key ] = $new_cond_pid_data;
		}

		$cond_pid = array(
			'name_prefix' => 'settings[payment][woocommerce][cond_pid]',
			'configs' => array(),
			'cond_suffix' => 'logics',
			'cond_id' => 'mcform_woointg_cond_pid_wrap',
			'data' => $cond_pid_data,
		);
		$cond_pid['configs'][0] = array(
			'label' => __( 'Product ID', 'mc_form' ),
			'type' => 'spinner',
			'size' => '100',
			'data' => array( 'settings[payment][woocommerce][cond_pid][__SDAKEY__][pid]', '', __( 'Required', 'mc_form' ) ),
		);

		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][enabled]', __( 'Enable WooCommerce Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[payment][woocommerce][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_wc_msg,mc_form_intg_wc_pid_wrap,mc_form_intg_wc_math_wrap,mc_form_intg_wc_rd_wrap,mc_form_intg_wc_pfs_wrap,mc_form_intg_wc_cpid_wrap,mc_form_intg_wc_cpidl_wrap,mc_form_intg_wc_aat_wrap,mc_form_intg_wc_qty_wrap,mc_form_intg_wc_summary_wrap',
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'WooCommerce Integration allows you to dynamically add a product to the cart while changing its checkout value through the form. The product purchase will store the attributes from mathematical evaluator that you select.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_wc_msg">
			<td colspan="3">
				<?php $this->ui->msg_update( __( 'WooCommerce Payment works in a different way. mcForm would just add the product you have selected with modified pricing, as calculated from the form. The variables in the mathematical formula will be used to create attributes on the go. mcForm will not store any payment information directly as with PayPal or Stripe payment. The checkout functionality would be managed by WooCommerce and mcForm would behave just like a form, not a checkout page.<br /><br />You do not need to enable the Payment settings for WooCommerce integration to work. Also you do not need to place a payment element inside the form. Just place a mathematical element and this will work straight out of the box. If you have conditional logic enabled on the mathematical element, and if the element stays conditionally hidden, then WooCommerce integration would not execute.<br /><br />If you do not mention a mathematical element, then mcForm will just add the relevant product without modifying the price.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_wc_summary_wrap">
			<td colspan="3">
				<table class="form-table">
					<tbody>
						<tr>
							<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][show_in_summary]', __( 'Show Payment Status in Summary Table', 'mc_form' ) ); ?></th>
							<td>
								<?php $this->ui->toggle( 'settings[payment][woocommerce][show_in_summary]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['show_in_summary'], '1', false, true, array(
									'condid' => 'mc_form_intg_wc_sum_title_wrap',
								) ); ?>
							</td>
							<td>
								<?php $this->ui->help( __( 'Show WooCommerce Payment Status in Summary Table.', 'mc_form' ) ); ?>
							</td>
						</tr>
						<tr id="mc_form_intg_wc_sum_title_wrap">
							<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][summary_title]', __( 'Summary Table Title', 'mc_form' ) ); ?></th>
							<td>
								<?php $this->ui->text( 'settings[payment][woocommerce][summary_title]', $op['summary_title'], __( 'Required', 'mc_form' ) ); ?>
							</td>
							<td><?php $this->ui->help( __( 'Enter the title text for WooCommerce Payment row on summary table.', 'mc_form' ) ); ?></td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr id="mc_form_intg_wc_pid_wrap">
			<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][product_id]', __( 'WooCommerce Product ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[payment][woocommerce][product_id]', $op['product_id'], __( 'Product ID', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Please enter the ID of the product which will be used to function the cart.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_intg_wc_math_wrap">
			<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][mathematical]', __( 'Mathematical Element ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->spinner( 'settings[payment][woocommerce][mathematical]', $op['mathematical'], __( 'Math ID', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Please enter the ID of the mathematical element which will be used to calculate the total value. The variables inside the mathematical formula will be used to create product variation on the fly. If you have conditional logic enabled on the mathematical element, and if the element stays conditionally hidden, then WooCommerce integration would not execute.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_intg_wc_aat_wrap">
			<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][additional_attr]', __( 'Additional Attributes', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][woocommerce][additional_attr]', $op['additional_attr'], __( 'Comma Separated: F0,M1,M2', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enter here the element ID (<code>F0,M1,M2</code>) in CSV format to include in product attributes. The variables from the mathematical elements are always added, so you dont need to include them here.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_intg_wc_qty_wrap">
			<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][quantity_item]', __( 'Element ID to override Quantity', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[payment][woocommerce][quantity_item]', $op['quantity_item'], __( 'Single Element ID: M8', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'If you wish to let user choose quantity from the form, then either enter a feedback small element with validation set to numeric only or a single slider element. Then enter the field ID here, like <code>M8</code> or <code>F2</code>.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_intg_wc_pfs_wrap">
			<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][paid_flag_state][]', __( 'Order Status to consider payment complete', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->checkboxes( 'settings[payment][woocommerce][paid_flag_state][]', $woo_status_items, $op['paid_flag_state'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Please set the order status where mcForm would consider the payment status to be complete. This would essentially unlock submission data to user if <strong>Submission Visible after Successful Payment</strong> is enabled in the general settings.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_intg_wc_rd_wrap">
			<th><?php $this->ui->generate_label( 'settings[payment][woocommerce][redirect]', __( 'Redirect To', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[payment][woocommerce][redirect]', $redirects, $op['redirect'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Please set the redirection type. You can either redirect to the cart page or the checkout page. To set redirection to any other URL, first select Default here and set the URL from Form Settings > Redirection.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_intg_wc_cpid_wrap">
			<th colspan="2"><?php $this->ui->generate_label( 'settings[payment][woocommerce][cond_pid]', __( 'Conditional Product Selector', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->help( __( 'If you wish to control product ID based on conditional logic, then please add logics here. The ones satisfied, in the order top to bottom, will modify the product ID.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_intg_wc_cpidl_wrap">
			<td colspan="3">
				<?php $this->build_conditional_config( $cond_pid['name_prefix'], $cond_pid['configs'], $cond_pid['cond_suffix'], $cond_pid['cond_id'], $cond_pid['data'] ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function estimation_slider() {
		$op = $this->settings['payment']['estimation'];
		$name_prefix = 'settings[payment][estimation]';

		// Enabled
		$enabled = array();
		$enabled[] = array(
			'name' => $name_prefix . '[enabled]',
			'label' => __( 'Enable Payment Estimator Bubble', 'mc_form' ),
			'ui' => 'toggle',
			'param' => array( $name_prefix . '[enabled]', '', '', $op['enabled'], '1', false, true, array(
				'condid' => 'mcform-settings-payment-estimation-config-wrap',
			) ),
			'help' => __( 'Enable this to show a payment estimator slider/range on top of the form.', 'mc_form' ),
		);
		$items = array();
		// UI Type
		$ui_types = array(
			array(
				'label' => __( 'Slider', 'mc_form' ),
				'value' => 'slider',
				'data' => array(
					'condid' => 'mcform-set-pm-cf-math_total-wrap',
				),
			),
			array(
				'label' => __( 'Range', 'mc_form' ),
				'value' => 'range',
				'data' => array(
					'condid' => 'mcform-set-pm-cf-math_min-wrap,mcform-set-pm-cf-math_max-wrap',
				),
			),
		);
		$items[] = array(
			'name' => $name_prefix . '[ui_type]',
			'label' => __( 'Interface Type', 'mc_form' ),
			'ui' => 'select',
			'param' => array( $name_prefix . '[ui_type]', $ui_types, $op['ui_type'], false, true ),
			'help' => __( 'Select whether you want a slider or a range on the estimator.', 'mc_form' ),
		);
		// Slider Type
		$slider_types = array(
			array(
				'label' => __( 'Block Appearance', 'mc_form' ),
				'value' => 'block',
			),
			array(
				'label' => __( 'Rounded with Knob', 'mc_form' ),
				'value' => 'knob',
			),
		);
		$items[] = array(
			'name' => $name_prefix . '[slider]',
			'label' => __( 'Slider Appearance', 'mc_form' ),
			'ui' => 'select',
			'param' => array( $name_prefix . '[slider]', $slider_types, $op['slider'] ),
			'help' => __( 'Set the appearance of the slider.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-slider-wrap',
		);
		// Total
		$items[] = array(
			'name' => $name_prefix . '[math_total]',
			'label' => __( 'Math Formula for Total', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[math_total]', $op['math_total'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Enter the math formula for the total value.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-math_total-wrap',
		);
		// Min
		$items[] = array(
			'name' => $name_prefix . '[math_min]',
			'label' => __( 'Math Formula for Min', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[math_min]', $op['math_min'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Enter the math formula for the minimum value of the range.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-math_min-wrap',
		);
		// Max
		$items[] = array(
			'name' => $name_prefix . '[math_max]',
			'label' => __( 'Math Formula for Max', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[math_max]', $op['math_max'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Enter the math formula for the maximum value of the range.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-math_max-wrap',
		);
		// Max value
		$items[] = array(
			'name' => $name_prefix . '[max]',
			'label' => __( 'Maximum Slider Value', 'mc_form' ),
			'ui' => 'spinner',
			'param' => array( $name_prefix . '[max]', $op['max'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Enter the maximum value that the slider or range can hold.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-max-wrap',
		);
		// decimal precision
		$items[] = array(
			'name' => $name_prefix . '[decimal]',
			'label' => __( 'Decimal Precision', 'mc_form' ),
			'ui' => 'spinner',
			'param' => array( $name_prefix . '[decimal]', $op['decimal'], __( 'Required', 'mc_form' ), '0', '10', '1' ),
			'help' => __( 'Decimal precision of the calculated mathematical value.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-decimal-wrap',
		);
		// Bubble
		$bubble_types = array(
			array(
				'label' => __( 'Modern', 'mc_form' ),
				'value' => 'modern',
				'data' => array(
					'condid' => 'mcform-set-pm-cf-heading-wrap,mcform-set-pm-cf-prefix-wrap,mcform-set-pm-cf-suffix-wrap,mcform-set-pm-cf-attr-wrap,mcform-set-pm-cf-sep-wrap,mcform-set-pm-cf-numg-wrap,mcform-set-pm-cf-nums-wrap,mcform-set-pm-cf-numd-wrap,mcform-set-pm-cf-attrh-wrap',
				)
			),
			array(
				'label' => __( 'Simple', 'mc_form' ),
				'value' => 'simple',
				'data' => array(
					'condid' => 'mcform-set-pm-cf-heading-wrap,mcform-set-pm-cf-prefix-wrap,mcform-set-pm-cf-suffix-wrap,mcform-set-pm-cf-attr-wrap,mcform-set-pm-cf-sep-wrap,mcform-set-pm-cf-numg-wrap,mcform-set-pm-cf-nums-wrap,mcform-set-pm-cf-numd-wrap,mcform-set-pm-cf-attrh-wrap',
				)
			),
			array(
				'label' => __( 'Do not show bubble', 'mc_form' ),
				'value' => 'none',
				'data' => array(
					'condid' => '',
				),
			),
		);
		$items[] = array(
			'name' => $name_prefix . '[bubble]',
			'label' => __( 'Bubble Type', 'mc_form' ),
			'ui' => 'select',
			'param' => array( $name_prefix . '[bubble]', $bubble_types, $op['bubble'], false, true ),
			'help' => __( 'Select what kind of bubble you would want to show, or simply disable.', 'mc_form' ),
		);
		// Heading
		$items[] = array(
			'name' => $name_prefix . '[heading]',
			'label' => __( 'Bubble Heading', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[heading]', $op['heading'], __( 'Optional', 'mc_form' ) ),
			'help' => __( 'Enter the heading shown on top of the bubble.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-heading-wrap',
		);
		// Prefix
		$items[] = array(
			'name' => $name_prefix . '[prefix]',
			'label' => __( 'Value Prefix', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[prefix]', $op['prefix'], __( 'Optional', 'mc_form' ) ),
			'help' => __( 'Enter the prefix before total value.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-prefix-wrap',
		);
		// Suffix
		$items[] = array(
			'name' => $name_prefix . '[suffix]',
			'label' => __( 'Value Suffix', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[suffix]', $op['suffix'], __( 'Optional', 'mc_form' ) ),
			'help' => __( 'Enter the suffix before total value.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-suffix-wrap',
		);
		// Separator
		$items[] = array(
			'name' => $name_prefix . '[separator]',
			'label' => __( 'Range Separator', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[separator]', $op['separator'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Enter the separator that will be used in case of range.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-sep-wrap',
		);
		// Grouping
		$items[] = array(
			'name' => $name_prefix . '[use_grouping]',
			'label' => __( 'Group Number', 'mc_form' ),
			'ui' => 'toggle',
			'param' => array( $name_prefix . '[use_grouping]', '', '', $op['use_grouping'] ),
			'help' => __( 'Whether or not to group number.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-numg-wrap',
		);
		// Number separator
		$items[] = array(
			'name' => $name_prefix . '[num_separator]',
			'label' => __( 'Number Separator', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[num_separator]', $op['num_separator'], __( 'None', 'mc_form' ) ),
			'help' => __( 'Enter the separator that will be used to format number.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-nums-wrap',
		);
		// Number Decimal
		$items[] = array(
			'name' => $name_prefix . '[num_decimal]',
			'label' => __( 'Decimal Point Character', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[num_decimal]', $op['num_decimal'], __( 'None', 'mc_form' ) ),
			'help' => __( 'Enter the decimal point character for your locale.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-numd-wrap',
		);
		// Attribute Heading
		$items[] = array(
			'name' => $name_prefix . '[attribute_heading]',
			'label' => __( 'Attribute Heading', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[attribute_heading]', $op['attribute_heading'], __( 'None', 'mc_form' ) ),
			'help' => __( 'Enter a custom attribute section heading.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-attrh-wrap',
		);
		// Custom Attributes
		$sda_columns = array(
			0 => array(
				'label' => __( 'Label', 'mc_form' ),
				'size' => '50',
				'type' => 'text',
			),
			1 => array(
				'label' => __( 'Value/Pipe', 'mc_form' ),
				'size' => '50',
				'type' => 'text',
			),
		);
		// First **new** array syntax. We have already bumped to PHP5.4
		// Create the sda_items
		$sda_items = [];
		$max_key = 0;
		foreach ( (array) $op['attributes'] as $a_key => $attr ) {
			$max_key = max( [ $a_key, $max_key ] );
			$sda_items[] = [
				0 => [ "{$name_prefix}[attributes][{$a_key}][label]", $attr['label'], __( 'Required', 'mc_form' ) ],
				1 => [ "{$name_prefix}[attributes][{$a_key}][value]", $attr['value'], __( 'Static/%M0% for pipes', 'mc_form' ) ],
			];
		}
		// Data
		$sda_data = [
			0 => [ "{$name_prefix}[attributes][__SDAKEY__][label]", '', __( 'Required', 'mc_form' ) ],
			1 => [ "{$name_prefix}[attributes][__SDAKEY__][value]", '', __( 'Static/%M0% for pipes', 'mc_form' ) ],
		];
		$items[] = array(
			'name' => $name_prefix . '[attributes]',
			'ui' => 'sda_list',
			'param' => [
				[
					'columns' => $sda_columns,
					'labels' => [
						'add' => __( 'Add New Attribute', 'mc_form' ),
					],
				],
				$sda_items,
				$sda_data,
				$max_key,
			],
			'help' => __( 'Add additional attributes to the bubble. If you wish to show/pipe values from other elements, then make sure you have the interactive elements active from Form Settings.', 'mc_form' ),
			'id' => 'mcform-set-pm-cf-attr-wrap',
		);
		?>
<table class="form-table" style="margin-bottom: 0;">
	<tbody>
		<?php $this->ui->form_table( $enabled, false ); ?>
	</tbody>
</table>
<table class="form-table" id="mcform-settings-payment-estimation-config-wrap">
	<tbody>
		<?php $this->ui->form_table( $items, false ); ?>
	</tbody>
</table>
		<?php
	}

	public function mailchimp() {
		$op = $this->settings['integration']['mailchimp'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][mailchimp][enabled]', __( 'Enable MailChimp Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][mailchimp][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_mc_api_wrap,mc_form_intg_mc_list_id_wrap,mc_form_intg_mc_double_optin_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to a mailchimp list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_mc_api_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][mailchimp][api]', __( 'MailChimp API Key', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][mailchimp][api]', $op['api'], __( 'API Key', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php printf( __( 'Get it from <a href="%s" target="_blank">here</a>.', 'mc_form' ), 'http://kb.mailchimp.com/accounts/management/about-api-keys#Find-or-Generate-Your-API-Key' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( sprintf( __( 'Set MailChimp API Key. If you need to find your API key, please read <a target="_blank" href="%1$s">this article.</a>', 'mc_form' ), 'http://kb.mailchimp.com/accounts/management/about-api-keys#Find-or-Generate-Your-API-Key' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_mc_list_id_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][mailchimp][list_id]', __( 'MailChimp List ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][mailchimp][list_id]', $op['list_id'], __( 'List ID', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php printf( __( 'Get it from <a href="%s" target="_blank">here</a>.', 'mc_form' ), 'http://kb.mailchimp.com/lists/managing-subscribers/find-your-list-id' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( sprintf( __( 'Set MailChimp List ID. If you need to find your List ID, please read <a href="%1$s">this article.</a>', 'mc_form' ), 'http://kb.mailchimp.com/lists/managing-subscribers/find-your-list-id' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_mc_double_optin_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][mailchimp][double_optin]', __( 'Double Optin', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][mailchimp][double_optin]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['double_optin'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Whether a double opt-in confirmation message is sent. <em>Abusing this may cause your account to be suspended.</em>', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function aweber() {
		$op = $this->settings['integration']['aweber'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][aweber][enabled]', __( 'Enable Aweber Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][aweber][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_aw_ac_wrap,mc_form_intg_aw_li_wrap,mc_form_intg_aw_info_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to a aweber list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_aw_ac_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][aweber][authorization_code]', __( 'Aweber Authorization Code', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->textarea( 'settings[integration][aweber][authorization_code]', $op['authorization_code'], __( 'Authorization Code', 'mc_form' ) ); ?>
				<br />
				<span class="description">
					<?php printf( __( 'You can get it from <a target="_blank" href="%s">here.</a>', 'mc_form' ), 'https://auth.aweber.com/1.0/oauth/authorize_app/9d9d3517' ); ?>
				</span>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set the authorization code you get after filling out the form from the link.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_aw_li_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][aweber][list_id]', __( 'List ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][aweber][list_id]', $op['list_id'], __( 'List ID', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php printf( __( 'Get it from <a href="%s" target="_blank">here</a>.', 'mc_form' ), 'https://help.aweber.com/hc/en-us/articles/204028426-What-Is-The-Unique-List-ID-' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( __( 'Put Aweber List ID.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_aw_info_wrap">
			<td colspan="3">
				<?php if ( $op['accessKey'] != '' ) : ?>
				<span class="description"><?php _e( 'Aweber Connected Properly.', 'mc_form' ); ?></span>
				<?php else : ?>
				<span class="description">
					<?php _e( 'Either you have not entered a valid authorization code, or you have not setup aweber integration. Please give a valid authorization code, save the form and reload this page to see the status.', 'mc_form' ); ?>
				</span>
				<?php endif; ?>
			</td>
			<?php foreach ( array( 'consumerKey', 'consumerSecret', 'accessKey', 'accessSecret', 'prevac' ) as $aweber_key ) : ?>
				<input type="hidden" name="settings[integration][aweber][<?php echo esc_attr( $aweber_key ); ?>]" value="<?php echo esc_attr( $op[$aweber_key] ); ?>" />
			<?php endforeach; ?>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function get_response() {
		$op = $this->settings['integration']['get_response'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][get_response][enabled]', __( 'Enable Get Response Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][get_response][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_gr_api_wrap,mc_form_intg_gr_campaign_id_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to a Get Response list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_gr_api_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][get_response][api]', __( 'Get Response API Key', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][get_response][api]', $op['api'], __( 'API Key', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php printf( __( 'Get it from <a href="%s" target="_blank">here</a>.', 'mc_form' ), 'http://support.getresponse.com/faq/where-i-find-api-key' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( sprintf( __( 'Set Get Response API Key. If you need to find your API key, please read <a target="_blank" href="%1$s">this article.</a>', 'mc_form' ), 'http://support.getresponse.com/faq/where-i-find-api-key' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_gr_campaign_id_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][get_response][campaign_id]', __( 'List Token', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][get_response][campaign_id]', $op['campaign_id'], __( 'List Token', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php printf( __( 'Get it from <a href="%s" target="_blank">here</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/form-integration/get-response-integration-with-form-pro/' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( sprintf( __( 'Set List Token. This can be found under the settings > general of lists tab. If you need to find your List token, please read <a href="%1$s">this article.</a>', 'mc_form' ), 'https://www.binarypoets.net/kb/form/form-integration/get-response-integration-with-form-pro/' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function campaign_monitor() {
		$op = $this->settings['integration']['campaign_monitor'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][campaign_monitor][enabled]', __( 'Enable Campaign Monitor Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][campaign_monitor][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_cm_api_wrap,mc_form_intg_cm_list_id_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to a campaign monitor list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_cm_api_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][campaign_monitor][api]', __( 'Campaign Monitor API Key', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][campaign_monitor][api]', $op['api'], __( 'API Key', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php printf( __( 'Get it from <a href="%s" target="_blank">here</a>.', 'mc_form' ), 'http://help.campaignmonitor.com/topic.aspx?t=206' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( sprintf( __( 'Set campaign monitor API Key. If you need to find your API key, please read <a target="_blank" href="%1$s">this article.</a>', 'mc_form' ), 'http://help.campaignmonitor.com/topic.aspx?t=206' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_cm_list_id_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][campaign_monitor][list_id]', __( 'Campaign Monitor List ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][campaign_monitor][list_id]', $op['list_id'], __( 'List ID', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php printf( __( 'Get it from <a href="%s" target="_blank">here</a>.', 'mc_form' ), 'https://www.campaignmonitor.com/api/getting-started/#listid' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( sprintf( __( 'Set Campaign Monitor List ID. If you need to find your List ID, please read <a href="%1$s">this article.</a>', 'mc_form' ), 'https://www.campaignmonitor.com/api/getting-started/#listid' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function formhandler_integration() {
		$op = $this->settings['integration']['formhandler'];
		// Prepare data for sda
		$m_type_select = array(
			0 => array(
				'value' => 'mcq',
				'label' => __( '(M) MCQ', 'mc_form' ),
			),
			1 => array(
				'value' => 'freetype',
				'label' => __( '(F) Text Input', 'mc_form' ),
			),
			2 => array(
				'value' => 'pinfo',
				'label' => __( '(O) Others', 'mc_form' ),
			),
		);
		$sda_columns = array(
			0 => array(
				'label' => __( '(X)', 'mc_form' ),
				'size' => '25',
				'type' => 'select',
			),
			1 => array(
				'label' => __( '{KEY}', 'mc_form' ),
				'size' => '25',
				'type' => 'spinner',
			),
			2 => array(
				'label' => __( 'Parameter Key (No Space, Underscore and alphabets only)', 'mc_form' ),
				'size' => '50',
				'type' => 'text',
			),
		);
		$sda_labels = array(
			'add' => __( 'Add New Parameter', 'mc_form' ),
		);
		$sda_data_name_prefix = 'settings[integration][formhandler][meta][__SDAKEY__]';
		$sda_data = array(
			0 => array( $sda_data_name_prefix . '[m_type]', $m_type_select, 'mcq', false, false, false, true, array( 'fit' ) ),
			1 => array( $sda_data_name_prefix . '[key]', '0', __( '{key}', 'mc_form' ), 0, 500 ),
			2 => array( $sda_data_name_prefix . '[meta_key]', '', '' ),
		);
		$sda_items = array();
		$sda_max_key = null;
		$sda_items_name_prefix = 'settings[integration][formhandler][meta][%d]';
		foreach ( (array) $op['meta'] as $meta_key => $metadata ) {
			$sda_max_key = max( array( $sda_max_key, $meta_key ) );
			$sda_items[] = array(
				0 => array( sprintf( $sda_items_name_prefix . '[m_type]', $meta_key ), $m_type_select, $metadata['m_type'], false, false, false, true, array( 'fit-text' ) ),
				1 => array( sprintf( $sda_items_name_prefix . '[key]', $meta_key ), $metadata['key'], __( '{key}', 'mc_form' ), 0, 500 ),
				2 => array( sprintf( $sda_items_name_prefix . '[meta_key]', $meta_key ), $metadata['meta_key'], '' ),
			);
		}
		$http_methods = array(
			'get' => __( 'Get', 'mc_form' ),
			'post' => __( 'Post', 'mc_form' ),
		);
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][formhandler][enabled]', __( 'Enable Send to Custom URL', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][formhandler][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_formhandler_url_wrap,mc_form_formhandler_method_wrap,mc_form_formhandler_metatitle_wrap,mc_form_formhandler_metaarray_wrap,mc_form_formhandler_meta_wrap',
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you wish to enable sending form data to custom URL, then please check this. Other settings will follow.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_formhandler_url_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][formhandler][url]', __( 'Custom URL', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][formhandler][url]', $op['url'], __( 'https://', 'mc_form' ), 'large', 'normal', array( 'code' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Mention the URL where the form data would be passed. It needs to start with <code>http://</code> or <code>https://</code>.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_formhandler_method_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][formhandler][method]', __( 'HTTP Method', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[integration][formhandler][method]', $http_methods, $op['method'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Mention which http method would be used. It is recommended to use POST method, since a large number of data might be passed.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc_form_formhandler_metatitle_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][formhandler][meta]', __( 'Data Parameters', 'mc_form' ) ); ?></th>
			<td>
				<p class="description"><?php printf( __( '%1$s will always be sent with the corresponding values.', 'mc_form' ), '<code>data_id, submission_date, user_id, f_name, l_name, email, score, max_score, ip, remarks, referrer, url_track, time, link, trackback_id, trackback_url</code>' ); ?></p>
				<p class="description"><?php _e( 'Click the help button to get a snippet to check the form data.', 'mc_form' ); ?></p>
			</td>
			<td><?php $this->ui->help_head(); ?>
				<p><?php _e( 'Add the query parameters you want to pass to the URL. You must specify a valid URL query key, otherwise the function might fail. <code>data_id, submission_date, user_id, f_name, l_name, email, score, max_score, ip, remarks, referrer, url_track, time, link, trackback_id, trackback_url</code> are always passed.', 'mc_form' ); ?></p>
				<p><?php _e( 'The following snippet can be used as a starter to get the form data.', 'mc_form' ); ?></p>
<pre style="max-width: 400px; overflow: auto; max-height: 200px;">&lt;?php
// Check if request is empty
if ( ! empty( $_REQUEST ) ) {
	// Get the request. Works both for GET and POST
	$info = $_REQUEST;
	// Save HTTP METHOD for debugging
	$info[&#39;method&#39;] = $_SERVER[&#39;REQUEST_METHOD&#39;];
	// Create the JSON
	$json = json_encode( $info );
	// Store it in a file
	$filename = dirname( __FILE__ ) . &#39;/mcform-url-&#39; . ( isset( $_REQUEST[&#39;data_id&#39;] ) ? $_REQUEST[&#39;data_id&#39;] : uniqid() ) . &#39;.json&#39;;
	// We are not really checking if the file exists or not
	file_put_contents( $filename, $json );
// Request is empty, so exit
} else {
	echo &#39;Bad Request!&#39;;
}</pre>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr id="mc_form_formhandler_metaarray_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][formhandler][metaarray]', __( 'Send Array instead of Stringified Value', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][formhandler][metaarray]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['metaarray']  ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The element submission data will be stringified before being sent. You can change this behavior by changing the toggle.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_formhandler_meta_wrap">
			<td colspan="3">
				<?php $this->ui->sda_list( array(
					'columns' => $sda_columns,
					'labels' => $sda_labels,
					'features' => array(
						'draggable' => false,
					),
				), $sda_items, $sda_data, $sda_max_key ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function hint_plugin_install( $slug, $name ) {
		if ( current_user_can( 'install_plugins' ) ) {
			if ( is_dir( dirname( WP_PLUGIN_DIR . '/' . $slug ) ) && is_plugin_inactive( $slug ) ) {
				$this->ui->msg_error( sprintf( __( '%2$s is installed but inactive. Please <a href="%1$s">activate</a> the plugin.', 'mc_form' ), wp_nonce_url('plugins.php?action=activate&amp;plugin=' . $slug, 'activate-plugin_' . $slug ), $name ) );
			} else {
				$this->ui->msg_error( sprintf( __( 'Please install <a href="%1$s">%2$s Plugin</a>.', 'mc_form' ), wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=' . dirname( $slug ) ), 'install-plugin_' . dirname( $slug ) ), $name ) );
			}
		} else {
			$this->ui->msg_error( sprintf( __( 'Please ask your administrator to install %1$s plugin.', 'mc_form' ), $name ) );
		}
		return;
	}

	public function mailwizz() {
		$op = $this->settings['integration']['mailwizz'];
		// Create the items
		$items = [];
		$name_prefix = 'settings[integration][mailwizz]';
		// Enabled
		$items[] = [
			'name' => $name_prefix . '[enabled]',
			'label' => __( 'Enable MailWizz Integration', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $name_prefix . '[enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, [
				'condid' => 'mc_form_intg_mlwhzz_url_wrap,mc_form_intg_mlwhzz_puk_wrap,mc_form_intg_mlwhzz_pvk_wrap,mc_form_intg_mlwhzz_lid_wrap',
			] ],
			'help' => __( 'If you want the submitter to get subscribed to your selfhosted MailWizz list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ),
		];
		// API URL
		$items[] = [
			'name' => $name_prefix . '[url]',
			'label' => __( 'API URL', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $name_prefix . '[url]', $op['url'], __( 'API URL of MailWizz', 'mc_form' ) ],
			'help' => __( 'Enter the API URL of the MailWizz Application. Under API Keys of your Application, on the right hand side you will see a small INFO icon. Clicking on it will give API URL like <code>https://website.tld/api/index.php</code>. Copy-Paste the whole URL here.', 'mc_form' ),
			'id' => 'mc_form_intg_mlwhzz_url_wrap',
		];
		// Public Key
		$items[] = [
			'name' => $name_prefix . '[pub_key]',
			'label' => __( 'Public Key', 'mc_form' ),
			'ui' => 'password',
			'param' => [ $name_prefix . '[pub_key]', $op['pub_key'], __( 'Public Key of MailWizz', 'mc_form' ) ],
			'help' => __( 'Enter a Public Key from the MailWizz Application. Under API Keys of your Application, either generate or use an existing pair of public/private keys. Paste the public key here.', 'mc_form' ),
			'id' => 'mc_form_intg_mlwhzz_puk_wrap',
		];
		// Private Key
		$items[] = [
			'name' => $name_prefix . '[priv_key]',
			'label' => __( 'Private Key', 'mc_form' ),
			'ui' => 'password',
			'param' => [ $name_prefix . '[priv_key]', $op['priv_key'], __( 'Private Key of MailWizz', 'mc_form' ) ],
			'help' => __( 'Enter a Private Key from the MailWizz Application. Under API Keys of your Application, either generate or use an existing pair of public/private keys. Paste the private key here.', 'mc_form' ),
			'id' => 'mc_form_intg_mlwhzz_pvk_wrap',
		];
		// List ID
		$items[] = [
			'name' => $name_prefix . '[list_id]',
			'label' => __( 'List ID', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $name_prefix . '[list_id]', $op['list_id'], __( 'List ID', 'mc_form' ) ],
			'help' => __( 'Enter the list ID. You will find it under MailWizz > Lists > Unique ID. Copy the ID here.', 'mc_form' ),
			'id' => 'mc_form_intg_mlwhzz_lid_wrap',
		];
		$this->ui->form_table( $items );
	}

	public function mailpoet3() {
		$op = $this->settings['integration']['mailpoet3'];
		$slug = 'mailpoet/mailpoet.php';
		if ( ! class_exists( '\MailPoet\API\API' ) ) {
			$this->hint_plugin_install( $slug, __( 'MailPoet 3', 'mc_form' ) );
			return;
		}
		// Get available lists
		$subscription_lists = \MailPoet\API\API::MP( 'v1' )->getLists();
		$lists = [];
		foreach ( (array) $subscription_lists as $list ) {
			$lists[] = [
				'value' => $list['id'],
				'label' => $list['name'],
			];
		}
		// Create the items
		$items = [];
		$name_prefix = 'settings[integration][mailpoet3]';
		// Enabled
		$items[] = [
			'name' => $name_prefix . '[enabled]',
			'label' => __( 'Enable MailPoet 3 Integration', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $name_prefix . '[enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, [
				'condid' => 'mc_form_intg_mp3_list_wrap,mc_form_intg_mp3_cnf_wrap,mc_form_intg_mp3_wlc_wrap',
			] ],
			'help' => __( 'If you want the submitter to get subscribed to one or more MailPoet list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ),
		];
		// List
		if ( empty( $lists ) ) {
			$items[] = [
				'ui' => 'msg_error',
				'param' => [ __( 'You have not created any list in MailPoet yet. Please create some list before getting started.', 'mc_form' ) ],
				'id' => 'mc_form_intg_mp3_list_wrap',
			];
		} else {
			$items[] = [
				'name' => $name_prefix . '[list_ids][]',
				'label' => __( 'Subscriber Lists', 'mc_form' ),
				'ui' => 'checkboxes',
				'param' => [ $name_prefix . '[list_ids][]', $lists, $op['list_ids'] ],
				'help' => __( 'Select all the lists where you would like to add the subscriber.', 'mc_form' ),
				'id' => 'mc_form_intg_mp3_list_wrap',
			];
		}
		// Confirmation
		$items[] = [
			'name' => $name_prefix . '[confirmation]',
			'label' => __( 'Send Confirmation Email', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $name_prefix . '[confirmation]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['confirmation'] ],
			'help' => __( 'Enable to send confirmation email.', 'mc_form' ),
			'id' => 'mc_form_intg_mp3_cnf_wrap',
		];
		// Welcome
		$items[] = [
			'name' => $name_prefix . '[welcome]',
			'label' => __( 'Send Welcome Email', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $name_prefix . '[welcome]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['welcome'] ],
			'help' => __( 'Enable to send welcome email.', 'mc_form' ),
			'id' => 'mc_form_intg_mp3_wlc_wrap',
		];
		$this->ui->form_table( $items );
	}

	public function mailpoet() {
		$op = $this->settings['integration']['mailpoet'];
		$slug = 'wysija-newsletters/index.php';
		if ( ! class_exists( 'WYSIJA' ) ) {
			$this->hint_plugin_install( $slug, __( 'MailPoet 2', 'mc_form' ) );
			return;
		}

		$model_list = WYSIJA::get( 'list','model' );
		$mailpoet_lists = $model_list->get( array( 'name', 'list_id' ), array( 'is_enabled' => 1 ) );
		$mailpoet_list_selections = array();
		if ( ! empty( $mailpoet_lists ) ) {
			foreach ( $mailpoet_lists as $ml ) {
				$mailpoet_list_selections[] = array(
					'value' => $ml['list_id'],
					'label' => $ml['name'],
				);
			}
		}

		?>
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( 'settings[integration][mailpoet][enabled]', __( 'Enable MailPoet Integration', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->toggle( 'settings[integration][mailpoet][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
							'condid' => 'mc_form_intg_mp_list_wrap'
						) ); ?>
					</td>
					<td>
						<?php $this->ui->help( __( 'If you want the submitter to get subscribed to one or more MailPoet list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
					</td>
				</tr>
				<tr id="mc_form_intg_mp_list_wrap">
					<?php if ( empty( $mailpoet_lists ) ) : ?>
					<td colspan="3">
						<?php $this->ui->msg_error( __( 'You have not created any list in Mailpoet yet. Please create at least one list and it will appear here.', 'mc_form' ) ); ?>
					</td>
					<?php else : ?>
					<th><?php $this->ui->generate_label( 'settings[integration][mailpoet][list_ids]', __( 'Select Subscriber Lists', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->checkboxes( 'settings[integration][mailpoet][list_ids][]', $mailpoet_list_selections, $op['list_ids'] ); ?>
					</td>
					<td>
						<?php $this->ui->help( __( 'Select the lists to which you want your subscribers to be added automatically. Select none to disable adding to a list.', 'mc_form' ) ); ?>
					</td>
					<?php endif; ?>
				</tr>
			</tbody>
		</table>
		<?php
	}

	public function mymail() {
		$op = $this->settings['integration']['mymail'];
		if ( ! function_exists( 'mymail' ) ) {
			$this->ui->msg_error( sprintf( __( 'Please install <a href="%1$s" target="_blank">MailSter WordPress Plugin</a> to begin integration.', 'mc_form' ), 'http://codecanyon.net/item/mymail-email-newsletter-plugin-for-wordpress/3078294?ref=BinaryPoets' ) );
			return;
		}

		// Get the lists
		$mymail_lists = mymail( 'lists' )->get();
		$mymail_list_selection = array();
		if ( ! empty( $mymail_lists ) ) {
			foreach ( $mymail_lists as $mlist ) {
				$mymail_list_selection[] = array(
					'value' => $mlist->ID,
					'label' => $mlist->name,
				);
			}
		}
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][mymail][enabled]', __( 'Enable MyMail Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][mymail][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_mm_list_wrap,mc_form_intg_mm_ow_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to one or more Mailster list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_mm_list_wrap">
			<?php if ( empty( $mymail_list_selection ) ) : ?>
			<td colspan="3">
				<?php $this->ui->msg_error( __( 'You have not created any list in Mailster yet. Please create at least one list and it will appear here.', 'mc_form' ) ); ?>
			</td>
			<?php else : ?>
			<th><?php $this->ui->generate_label( 'settings[integration][mymail][list_ids]', __( 'Select Subscriber Lists', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->checkboxes( 'settings[integration][mymail][list_ids][]', $mymail_list_selection, $op['list_ids'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Select the lists to which you want your subscribers to be added automatically. Select none to disable adding to a list.', 'mc_form' ) ); ?>
			</td>
			<?php endif; ?>
		</tr>
		<tr id="mc_form_intg_mm_ow_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][mymail][overwrite]', __( 'Overwrite Existing Subscriber Info', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][mymail][overwrite]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['overwrite'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If this is enabled, then existing user information would be updated (first name and last name) if required.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function sendy() {
		$op = $this->settings['integration']['sendy'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][sendy][enabled]', __( 'Enable Sendy.co Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][sendy][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_sc_list_wrap,mc_form_intg_sc_url_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to a <a href="https://sendy.co">Sendy.co</a> Newsletter list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_sc_list_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][sendy][list_id]', __( 'List ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][sendy][list_id]', $op['list_id'], __( 'List ID', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The list id you want to subscribe a user to. This encrypted & hashed id can be found under View all lists section named ID', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_sc_url_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][sendy][url]', __( 'Sendy Installation URL', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][sendy][url]', $op['url'], __( 'Installation URL', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The URL where Sendy.co is installed.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function convertkit() {
		$op = $this->settings['integration']['convertkit'];
		$items = [];
		// Toggle
		$items[] = [
			'name' => 'settings[integration][convertkit][enabled]',
			'ui' => 'toggle',
			'label' => __( 'Enable Convertkit Integration', 'mc_form' ),
			'param' => [ '%', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, [
				'condid' => 'mc_form_intg_cvk_api_key_wrap,mc_form_intg_cvk_form_id_wrap,mc_form_intg_cvk_sequence_id_wrap,mc_form_intg_cvk_tags_wrap',
			] ],
			'description' => __( '<a href="https://wp.me/p3Zesg-8Fm">Learn here</a> about finding different Ids.', 'mc_form' ),
			'help' => __( 'Enable to send submitting users to convertkit subscribers.', 'mc_form' ),
		];
		// Api key
		$items[] = [
			'name' => 'settings[integration][convertkit][api_key]',
			'ui' => 'password',
			'label' => __( 'API Key', 'mc_form' ),
			'param' => [ '%', $op['api_key'] ],
			'help' => __( 'You can find your API Key under convertkit Account Settings.', 'mc_form' ),
			'id' => 'mc_form_intg_cvk_api_key_wrap',
		];
		// Form Id
		$items[] = [
			'name' => 'settings[integration][convertkit][form_id]',
			'label' => __( 'Form Id', 'mc_form' ),
			'ui' => 'text',
			'param' => [ '%', $op['form_id'], __( 'Disabled', 'mc_form' ) ],
			'help' => __( 'Edit a convertkit form and look in the URL for <code>forms/designers/<strong>1231</strong>/edit</code> part. More information can be found <a href="https://wp.me/p3Zesg-8Fm">here</a>.', 'mc_form' ),
			'id' => 'mc_form_intg_cvk_form_id_wrap',
		];
		// Sequence Id
		$items[] = [
			'name' => 'settings[integration][convertkit][sequence_id]',
			'label' => __( 'Sequence Id', 'mc_form' ),
			'ui' => 'text',
			'param' => [ '%', $op['sequence_id'], __( 'Disabled', 'mc_form' ) ],
			'help' => __( 'Edit a convertkit sequence and look in the URL for <code>/sequences/<strong>265794</strong></code> part. More information can be found <a href="https://wp.me/p3Zesg-8Fm">here</a>.', 'mc_form' ),
			'id' => 'mc_form_intg_cvk_sequence_id_wrap',
		];
		// Tag Id
		$items[] = [
			'name' => 'settings[integration][convertkit][tags]',
			'label' => __( 'Tag Ids (Comma Separated)', 'mc_form' ),
			'ui' => 'text',
			'param' => [ '%', $op['tags'], __( 'Disabled', 'mc_form' ) ],
			'help' => __( 'Edit a convertkit tag and look in the URL for <code>subscribers?subscribable_ids=<strong>265794</strong>&subscribable_type=Tag</code> part. More information can be found <a href="https://wp.me/p3Zesg-8Fm">here</a>.', 'mc_form' ),
			'description' => __( 'Enter multiple tags separated by comma.', 'mc_form' ),
			'id' => 'mc_form_intg_cvk_tags_wrap',
		];

		$this->ui->form_table( $items );
	}

	public function enormail() {
		$op = $this->settings['integration']['enormail'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][enormail][enabled]', __( 'Enable Enormail Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][enormail][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_en_list_wrap,mc_form_intg_en_api_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to a <a href="https://enormail.eu/">Enormail</a> Newsletter list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_en_api_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][enormail][api]', __( 'Enormail API', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][enormail][api]', $op['api'], __( 'API Key', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php _e( 'Access <a href="https://app.enormail.eu/account/api" rel="noopener nofollow" target="_blank">this link</a> while being logged in and generate and paste an API key here.', 'mc_form' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( __( 'API key found in your account settings.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_en_list_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][enormail][list_id]', __( 'Enormail List ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][enormail][list_id]', $op['list_id'], __( 'LIST ID', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php _e( 'Access <a href="https://app.enormail.eu/contacts" rel="noopener nofollow" target="_blank">this link</a> while being logged in click on settings of your list. It will show the List ID.', 'mc_form' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( __( 'List ID of your mailing list where the contact would be added.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function mailerlite() {
		$op = $this->settings['integration']['mailerlite'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][mailerlite][enabled]', __( 'Enable MailerLite Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][mailerlite][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_ml_list_wrap,mc_form_intg_ml_api_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to a <a href="https://mailerlite.com/">MailerLite</a> Newsletter list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_ml_api_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][mailerlite][api]', __( 'MailerLite API', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][mailerlite][api]', $op['api'], __( 'API Key', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php _e( 'Access <a href="https://app.mailerlite.com/integrations/" rel="noopener nofollow" target="_blank">this link</a> while being logged in and click on <a href="https://app.mailerlite.com/integrations/api/" rel="nofollow noopener" target="_blank">Developer API</a>. Paste API and Group ID.', 'mc_form' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( __( 'API key found in your account settings.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_ml_list_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][mailerlite][group_id]', __( 'Mailerlite Group ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][mailerlite][group_id]', $op['group_id'], __( 'Group ID', 'mc_form' ) ); ?>
				<br />
				<span class="description"><?php _e( 'After creating a group, access <a href="https://app.mailerlite.com/integrations/api/" rel="nofollow noopener" target="_blank">Developer API</a> and paste the ID of the group.', 'mc_form' ); ?></span>
			</td>
			<td>
				<?php $this->ui->help( __( 'Group ID of your mailing list where the contact would be added.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function active_campaign() {
		$op = $this->settings['integration']['active_campaign'];
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[integration][active_campaign][enabled]', __( 'Enable Active Campaign Integration', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->toggle( 'settings[integration][active_campaign][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['enabled'], '1', false, true, array(
					'condid' => 'mc_form_intg_ac_list_wrap,mc_form_intg_ac_url_wrap,mc_form_intg_ac_api_wrap'
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'If you want the submitter to get subscribed to a <a href="http://www.activecampaign.com/">Active Campaign</a> Newsletter list, please enable it here. After this, make sure you add the Primary Email field to the form.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_ac_url_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][active_campaign][url]', __( 'Active Campaign URL', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][active_campaign][url]', $op['url'], __( 'Active Campaign URL', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The URL found in your developers settings.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_ac_api_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][active_campaign][api]', __( 'Active Campaign API', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][active_campaign][api]', $op['api'], __( 'API Key', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'API key found in your developers settings.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr id="mc_form_intg_ac_list_wrap">
			<th><?php $this->ui->generate_label( 'settings[integration][active_campaign][list_id]', __( 'List ID', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'settings[integration][active_campaign][list_id]', $op['list_id'], __( 'List ID', 'mc_form' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'The ID of the list. It can be found by looking at the URL of your Active Campaign List. <code>https://xyz.activehosted.com/contact/?listid=<strong>1</strong>&status=1</code>, here the ID is <code>1</code>.', 'mc_form' ) ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	/*==========================================================================
	 * DROPPABLE UI HTML
	 * Overrides the parent
	 *========================================================================*/
	/* DESIGN */
	public function build_heading( $element, $key, $data, $default_data, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_elm">
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
					<td></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][type]', __( 'Heading Type', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->heading_type( $name_prefix . '[settings][type]', $data['settings']['type'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the html heading type.', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][align]', __( 'Heading Alignment', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->alignment_radio( $name_prefix . '[settings][align]', $data['settings']['align'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the alignment of the heading.', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the icon you want to appear before the heading. Select none to disable.', 'mc_form' ) ) ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_top]', __( 'Show Scroll to Top', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->toggle( $name_prefix . '[settings][show_top]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['show_top'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Turn the feature on to show a scroll to top anchor beside the heading.', 'mc_form' ) ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>

		<?php
	}

	public function build_richtext( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the heading. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][styled]', __( 'Styled Container Appearance', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][styled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['styled'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enable this option to print like styled container.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
	}

	public function build_embed( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_elm">
		<table class="form-table">
			<tbody>
				<tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][full_size]', __( 'Make iframes and objects full size', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][full_size]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['full_size'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enable this option to force all iframes and objects inside this element full size. While keeping this option to No, you can manually add class <code>resize</code> to your iframes or objects to make them full size.', 'mc_form' ) ); ?></td>
					</tr>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[description]', __( 'Embed Code', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->textarea( $name_prefix . '[description]', $data['description'], __( 'Embed Code', 'mc_form' ), 'large', 'normal', array( 'code' ) ); ?></td>
					<td></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>

		<?php
	}

	public function build_collapsible( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_elm">
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
					<td></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the icon you want to appear before the title. Select none to disable.', 'mc_form' ) ) ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][expanded]', __( 'Show Expanded', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->toggle( $name_prefix . '[settings][expanded]', __( 'Expanded', 'mc_form' ), __( 'Collapsed', 'mc_form' ), $data['settings']['expanded'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'If you wish to make the collapsible appear as expanded by default, then enable this feature.', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
					</td>
					<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>
		<?php
	}

	public function build_container( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_elm">
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
					<td></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the icon you want to appear before the title. Select none to disable.', 'mc_form' ) ) ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
					</td>
					<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>
		<?php
	}

	public function build_blank_container( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
	?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_iconbox( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		$columns = array(
			array(
				'label' => __( 'Icon', 'mc_form' ),
				'size' => '30',
				'type' => 'icon_selector',
			),
			array(
				'label' => __( 'Text', 'mc_form' ),
				'size' => '35',
				'type' => 'text',
			),
			array(
				'label' => __( 'Link', 'mc_form' ),
				'size' => '21',
				'type' => 'text',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Button', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$new_name_prefix = $name_prefix . '[settings][elements][__SDAKEY__]';
		$data_list = array(
			array( $new_name_prefix . '[icon]', (string) hexdec( '0xe0d7' ) ),
			array( $new_name_prefix . '[text]', '', __( 'Optional text', 'mc_form' ), 'fit' ),
			array( $new_name_prefix . '[url]', '', __( 'Link', 'mc_form' ), 'fit' ),
		);
		$items = array();
		$max_key = null;
		foreach ( (array) $data['settings']['elements'] as $e_key => $elem ) {
			$max_key = max( array( $max_key, $e_key ) );
			$new_name_prefix = $name_prefix . '[settings][elements][' . $e_key . ']';
			if ( ! isset( $elem['icon'] ) ) {
				$elem['icon'] = 'none';
			}
			$items[] = array(
				array( $new_name_prefix . '[icon]', $elem['icon'] ),
				array( $new_name_prefix . '[text]', $elem['text'], __( 'Optional text', 'mc_form' ), 'fit' ),
				array( $new_name_prefix . '[url]', $elem['url'], __( 'Link', 'mc_form' ), 'fit' ),
			);
		}

		$open_types = array(
			0 => array(
				'label' => __( 'Current Window/Tab (_self)', 'mc_form' ),
				'value' => 'self',
			),
			1 => array(
				'label' => __( 'New Window/Tab (_blank)', 'mc_form' ),
				'value' => 'blank',
			),
			2 => array(
				'label' => __( 'Popup Window', 'mc_form' ),
				'value' => 'popup',
				'data' => array(
					'condid' => $this->generate_id_from_name( $name_prefix . '[settings][popup][width]_wrap' ) . ',' . $this->generate_id_from_name( $name_prefix . '[settings][popup][height]_wrap' ),
				),
			),
		);

		$size_items = [
			0 => [
				'label' => __( 'Small', 'mc_form' ),
				'value' => 'small',
			],
			1 => [
				'label' => __( 'Medium', 'mc_form' ),
				'value' => 'medium',
			],
			2 => [
				'label' => __( 'Large', 'mc_form' ),
				'value' => 'large',
			],
		];

		$style_items = [
			0 => [
				'label' => __( 'Flat', 'mc_form' ),
				'value' => __( 'flat', 'mc_form' ),
			],
			1 => [
				'label' => __( '3d Bordered', 'mc_form' ),
				'value' => __( 'border', 'mc_form' ),
			],
			2 => [
				'label' => __( 'Gradient', 'mc_form' ),
				'value' => __( 'gradient', 'mc_form' ),
			],
			3 => [
				'label' => __( 'Outline', 'mc_form' ),
				'value' => __( 'outline', 'mc_form' ),
			],
		];

		$new_config_items = [];
		// Font Size
		$new_config_items[] = [
			'name' => $name_prefix . '[settings][size]',
			'label' => __( 'Button Size', 'mc_form' ),
			'ui' => 'select',
			'param' => [ $name_prefix . '[settings][size]', $size_items, $data['settings']['size'] ],
			'help' => __( 'Set the size of the buttons.', 'mc_form' ),
		];

		// Button Style
		$new_config_items[] = [
			'name' => $name_prefix . '[settings][style]',
			'label' => __( 'Button Style', 'mc_form' ),
			'ui' => 'select',
			'param' => [ $name_prefix . '[settings][style]', $style_items, $data['settings']['style'] ],
			'help' => __( 'Set the style of the buttons.', 'mc_form' ),
		];

		// Rounded
		$new_config_items[] = [
			'name' => $name_prefix . '[settings][rounded]',
			'label' => __( 'Rounded Button', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $name_prefix . '[settings][rounded]', '', '', $data['settings']['rounded'] ],
			'help' => __( 'Set button appearance rounder.', 'mc_form' ),
		];

		// Themed
		$new_config_items[] = [
			'name' => $name_prefix . '[settings][themed]',
			'label' => __( 'Button Color', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $name_prefix . '[settings][themed]', __( 'Themed', 'mc_form' ), __( 'Grey', 'mc_form' ), $data['settings']['themed'] ],
			'help' => __( 'Set button color to greyscale or to primary color of your theme.', 'mc_form' ),
		];
?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_buttons"><?php _e( 'Buttons', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_elm">
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][align]', __( 'Button Alignment', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->alignment_radio( $name_prefix . '[settings][align]', $data['settings']['align'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the alignment of the icons.', 'mc_form' ) ); ?></td>
				</tr>
				<?php $this->ui->form_table( $new_config_items, false ); ?>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_ifs">
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][open]', __( 'Open Link In', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->select( $name_prefix . '[settings][open]', $open_types, $data['settings']['open'], false, true ); ?></td>
					<td><?php $this->ui->help( __( 'Set how you would like the links to open.', 'mc_form' ) ); ?></td>
				</tr>
				<tr id="<?php echo $this->generate_id_from_name( $name_prefix . '[settings][popup][width]_wrap' ); ?>">
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][popup][width]', __( 'Popup width (Pixel)', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->text( $name_prefix . '[settings][popup][width]', $data['settings']['popup']['width'], __( 'Pixels', 'mc_form' ) ); ?></td>
					<td><?php $this->ui->help( __( 'Set the popup width in pixels.', 'mc_form' ) ); ?></td>
				</tr>
				<tr id="<?php echo $this->generate_id_from_name( $name_prefix . '[settings][popup][height]_wrap' ); ?>">
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][popup][height]', __( 'Popup height (Pixel)', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->text( $name_prefix . '[settings][popup][height]', $data['settings']['popup']['height'], __( 'Pixels', 'mc_form' ) ); ?></td>
					<td><?php $this->ui->help( __( 'Set the popup height in pixels.', 'mc_form' ) ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_buttons">
		<table class="form-table">
			<tbody>
				<tr>
					<th colspan="2"><?php $this->ui->generate_label( '', __( 'Button List', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->help( __( 'Choose your icons. You can enter url and optional text.', 'mc_form' ) ); ?>
					</td>
				</tr>
				<tr>
					<td colspan="3">
						<?php $this->ui->sda_list( array(
							'columns' => $columns,
							'labels' => $labels,
						), $items, $data_list, $max_key ); ?>
						<?php $this->ui->clear(); ?>
					</td>
				</tr>
				<tr>
					<td colspan="3">
						<p class="description">
							<?php _e( 'Some special LINK values (apart from URLs) are available.', 'mc_form' ); ?>
						</p>
						<ul class="ul-disc">
							<li><code>#mcform-next</code>: <?php _e( 'Take to next page.', 'mc_form' ); ?></li>
							<li><code>#mcform-prev</code>: <?php _e( 'Take to previous page.', 'mc_form' ); ?></li>
							<li><code>#mcform-submit</code>: <?php _e( 'Submit button.', 'mc_form' ); ?></li>
							<li><code>#mcform-reset</code>: <?php _e( 'Reset button.', 'mc_form' ); ?></li>
							<li><code>#mcform-container-1</code>: <?php _e( 'Jump to container #1. Container numbering starts from 1.', 'mc_form' ); ?></li>
							<li><code>#mcform-save</code>: <?php _e( 'Save form data on browser. Only if enabled under CONFIG > FORM SETTINGS > SAVE PROGRESS.', 'mc_form' ); ?></li>
						</ul>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>
		<?php
	}

	public function build_col_half( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_col( $name_prefix, $data );
	}

	public function build_col_third( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_col( $name_prefix, $data );
	}

	public function build_col_two_third( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_col( $name_prefix, $data );
	}

	public function build_col_forth( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_col( $name_prefix, $data );
	}

	public function build_col_three_forth( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_col( $name_prefix, $data );
	}

	public function build_clear( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		?>
<table class="form-table">
	<tbody>
		<tr>
			<td colspan="3">
				<?php echo '<p class="description">' . __( 'This element clears the floating content to avoid unexpected appearance.', 'mc_form' ) . '</p>'; ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php

	}

	public function build_horizontal_line( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {

		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_top]', __( 'Show Scroll to Top', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_top]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['show_top'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn the feature on to show a scroll to top anchor below the content.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
	}

	public function build_divider( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_elm">
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
					<td></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][align]', __( 'Text Alignment', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->alignment_radio( $name_prefix . '[settings][align]', $data['settings']['align'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the alignment of the text.', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the icon you want to appear before the heading. Select none to disable.', 'mc_form' ) ) ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_top]', __( 'Show Scroll to Top', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->toggle( $name_prefix . '[settings][show_top]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['show_top'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Turn the feature on to show a scroll to top anchor beside the divider.', 'mc_form' ) ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>
		<?php
	}

	public function build_button( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		$sizes = array(
			0 => array(
				'label' => __( 'Small', 'mc_form' ),
				'value' => 'small',
			),
			1 => array(
				'label' => __( 'Medium', 'mc_form' ),
				'value' => 'medium',
			),
			2 => array(
				'label' => __( 'Large', 'mc_form' ),
				'value' => 'large'
			),
		);
?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_ifs">
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
					<td></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][container]', __( 'Container Number', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->spinner( $name_prefix . '[settings][container]', $data['settings']['container'], __( 'Container Number', 'mc_form' ), '0', '', 1 ); ?>
					</td>
					<td>
						<?php $this->ui->help( __( 'Enter the container number. Starts from 1 and any number represents nth container from start. So 1 would represent first, 3 would represent third etc.', 'mc_form' ) ); ?>
					</td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][size]', __( 'Button Size', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->select( $name_prefix . '[settings][size]', $sizes, $data['settings']['size'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the size of the button.', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the icon you want to appear before the title. Select none to disable.', 'mc_form' ) ) ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>
		<?php
	}

	public function build_imageslider( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$name_prefix = $name_prefix . '[settings]';
		$animations = array( "sliceDown", "sliceDownLeft", "sliceUp", "sliceUpLeft", "sliceUpDown", "sliceUpDownLeft", "fold", "fade", "random", "slideInRight", "slideInLeft", "boxRandom", "boxRain", "boxRainReverse", "boxRainGrow", "boxRainGrowReverse" );

		$sda_column = array(
			0 => array(
				'label' => __( 'Image', 'mc_form' ),
				'size' => '30',
				'type' => 'upload'
			),
			1 => array(
				'label' => __( 'Title', 'mc_form' ),
				'size' => '25',
				'type' => 'text',
			),
			2 => array(
				'label' => __( 'Link', 'mc_form' ),
				'size' => '25',
				'type' => 'text',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Image', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$data_sda = array(
			0 => array( $name_prefix . '[images][__SDAKEY__][src]', '', $name_prefix . '[images][__SDAKEY__][title]' ),
			1 => array( $name_prefix . '[images][__SDAKEY__][title]', '', __( 'Optional', 'mc_form' ), 'fit' ),
			2 => array( $name_prefix . '[images][__SDAKEY__][url]', '', __( 'Optional', 'mc_form' ), 'fit' ),
		);
		$items = array();
		$max_key = null;
		foreach ( $data['settings']['images'] as $i_key => $image ) {
			$max_key = max( array( $max_key, $i_key ) );
			$items[] = array(
				0 => array( $name_prefix . '[images][' . $i_key . '][src]', $image['src'], $name_prefix . '[images][' . $i_key . '][title]' ),
				1 => array( $name_prefix . '[images][' . $i_key . '][title]', $image['title'], __( 'Optional', 'mc_form' ), 'fit' ),
				2 => array( $name_prefix . '[images][' . $i_key . '][url]', $image['url'], __( 'Optional', 'mc_form' ), 'fit' ),
			);
		}

		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_images"><?php _e( 'Images', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_ifs">
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[autoslide]', __( 'Automatic Slide', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->toggle( $name_prefix . '[autoslide]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['autoslide'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Enable or disable the autoslide feature.', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[duration]', __( 'Slide Duration', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->slider( $name_prefix . '[duration]', $data['settings']['duration'], 2, 100 ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Enter the time duration between two slides (in seconds).', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[transition]', __( 'Transition Time', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->slider( $name_prefix . '[transition]', $data['settings']['transition'], 0.2, 100, 0.1 ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Enter the transition time between two slides (in seconds).', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[animation]', __( 'Transition Animation', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->select( $name_prefix . '[animation]', $animations, $data['settings']['animation'] ); ?>
					</td>
					<td><?php $this->ui->help( __( 'Select the type of transition animation.', 'mc_form' ) ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_images">
		<table class="form-table">
			<tbody>
				<tr>
					<th colspan="2"><?php $this->ui->generate_label( '', __( 'Image List', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->help( __( 'Upload the images which you would like to use inside the slider. It your sole responsibility to select image files only. Otherwise, the slider may not work.', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<td colspan="3">
						<?php $this->ui->sda_list( array(
							'columns' => $sda_column,
							'labels' => $labels,
						), $items, $data_sda, $max_key ); ?>
						<div class="clear"></div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>
		<?php
	}

	public function build_captcha( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_elm">
		<p class="description"><?php _e( 'This will give the surveyee a maths challenge.', 'mc_form' ); ?></p>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>
		<?php
	}

	public function build_recaptcha( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$captcha_types = array(
			'image' => __( 'Image', 'mc_form' ),
			'audio' => __( 'Audio', 'mc_form' ),
		);
		$captcha_themes = array(
			'light' => __( 'Light Color Scheme', 'mc_form' ),
			'dark' => __( 'Dark Color Scheme', 'mc_form' ),
		);
		$captcha_sizes = array(
			'compact' => __( 'Compact', 'mc_form' ),
			'normal' => __( 'Normal', 'mc_form' ),
		);
		$captcha_hls = array(
			'ar'     => 'Arabic',
			'af'     => 'Afrikaans',
			'am'     => 'Amharic',
			'hy'     => 'Armenian',
			'az'     => 'Azerbaijani',
			'eu'     => 'Basque',
			'bn'     => 'Bengali',
			'bg'     => 'Bulgarian',
			'ca'     => 'Catalan',
			'zh-HK'  => 'Chinese (Hong Kong)',
			'zh-CN'  => 'Chinese (Simplified)',
			'zh-TW'  => 'Chinese (Traditional)',
			'hr'     => 'Croatian',
			'cs'     => 'Czech',
			'da'     => 'Danish',
			'nl'     => 'Dutch',
			'en-GB'  => 'English (UK)',
			'en'     => 'English (US)',
			'et'     => 'Estonian',
			'fil'    => 'Filipino',
			'fi'     => 'Finnish',
			'fr'     => 'French',
			'fr-CA'  => 'French (Canadian)',
			'gl'     => 'Galician',
			'ka'     => 'Georgian',
			'de'     => 'German',
			'de-AT'  => 'German (Austria)',
			'de-CH'  => 'German (Switzerland)',
			'el'     => 'Greek',
			'gu'     => 'Gujarati',
			'iw'     => 'Hebrew',
			'hi'     => 'Hindi',
			'hu'     => 'Hungarain',
			'is'     => 'Icelandic',
			'id'     => 'Indonesian',
			'it'     => 'Italian',
			'ja'     => 'Japanese',
			'kn'     => 'Kannada',
			'ko'     => 'Korean',
			'lo'     => 'Laothian',
			'lv'     => 'Latvian',
			'lt'     => 'Lithuanian',
			'ms'     => 'Malay',
			'ml'     => 'Malayalam',
			'mr'     => 'Marathi',
			'mn'     => 'Mongolian',
			'no'     => 'Norwegian',
			'fa'     => 'Persian',
			'pl'     => 'Polish',
			'pt'     => 'Portuguese',
			'pt-BR'  => 'Portuguese (Brazil)',
			'pt-PT'  => 'Portuguese (Portugal)',
			'ro'     => 'Romanian',
			'ru'     => 'Russian',
			'sr'     => 'Serbian',
			'si'     => 'Sinhalese',
			'sk'     => 'Slovak',
			'sl'     => 'Slovenian',
			'es'     => 'Spanish',
			'es-419' => 'Spanish (Latin America)',
			'sw'     => 'Swahili',
			'sv'     => 'Swedish',
			'ta'     => 'Tamil',
			'te'     => 'Telugu',
			'th'     => 'Thai',
			'tr'     => 'Turkish',
			'uk'     => 'Ukrainian',
			'ur'     => 'Urdu',
			'vi'     => 'Vietnamese',
			'zu'     => 'Zulu',
		);
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_ifs">
	<table class="form-table">
		<tbody>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[settings][site_key]', __( 'Site Key', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->text( $name_prefix . '[settings][site_key]', $data['settings']['site_key'], __( 'Site Key', 'mc_form' ) ); ?>
				</td>
				<td><?php $this->ui->help( __( 'Enter the sitekey for your domain. You can get the sitekey from <a href="https://www.google.com/recaptcha/admin" rel="noopener" target="_blank">here</a>.', 'mc_form' ) ); ?></td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[settings][secret_key]', __( 'Secret Key', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->text( $name_prefix . '[settings][secret_key]', $data['settings']['secret_key'], __( 'Secret Key', 'mc_form' ) ); ?>
				</td>
				<td><?php $this->ui->help( __( 'Enter the secret key for your domain. You can get the secret key from <a href="https://www.google.com/recaptcha/admin" rel="noopener" target="_blank">here</a>.', 'mc_form' ) ); ?></td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[settings][type]', __( 'reCaptcha Type', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->select( $name_prefix . '[settings][type]', $captcha_types, $data['settings']['type'] ); ?>
				</td>
				<td><?php $this->ui->help( __( 'Set the preferred type of captcha to use inside reCaptcha. Default is image.', 'mc_form' ) ); ?></td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[settings][hl]', __( 'reCaptcha Language', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->select( $name_prefix . '[settings][hl]', $captcha_hls, $data['settings']['hl'] ); ?>
				</td>
				<td><?php $this->ui->help( __( 'Enter the recaptcha language code.', 'mc_form' ) ); ?></td>
			</tr>
		</tbody>
	</table>
	</div>
	<div id="<?php echo $tab_names; ?>_elm">
		<table class="form-table">
		<tbody>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[settings][theme]', __( 'reCaptcha Theme', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->select( $name_prefix . '[settings][theme]', $captcha_themes, $data['settings']['theme'] ); ?>
				</td>
				<td><?php $this->ui->help( __( 'Set light or dark version of reCaptcha.', 'mc_form' ) ); ?></td>
			</tr>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[settings][size]', __( 'reCaptcha Size', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->select( $name_prefix . '[settings][size]', $captcha_sizes, $data['settings']['size'] ); ?>
				</td>
				<td><?php $this->ui->help( __( 'Set size of reCaptcha widget.', 'mc_form' ) ); ?></td>
			</tr>
		</tbody>
		</table>
	</div>
</div>
		<?php
	}

	/* MCQ */
	public function build_radio( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_mcq_option_questions( $element, $key, $data, $element_structure, $name_prefix );
	}

	public function build_checkbox( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_mcq_option_questions( $element, $key, $data, $element_structure, $name_prefix );
	}

	public function build_select( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_mcq_option_questions( $element, $key, $data, $element_structure, $name_prefix, true );
	}

	public function build_thumbselect( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Image', 'mc_form' ),
				'type' => 'upload',
				'size' => '30',
			),
			1 => array(
				'label' => __( 'Option', 'mc_form' ),
				'type' => 'text',
				'size' => '25',
			),
			2 => array(
				'label' => __( 'Score', 'mc_form' ),
				'type' => 'spinner',
				'size' => '15',
			),
			3 => array(
				'label' => __( 'Numeric', 'mc_form' ),
				'type' => 'spinner',
				'size' => '15',
			),
			4 => array(
				'label' => __( 'Default', 'mc_form' ),
				'type' => 'toggle',
				'size' => '15',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Option', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__][image]', '', __( 'Option Image', 'mc_form' ) ),
			1 => array( $name_prefix . '[settings][options][__SDAKEY__][label]', '', __( 'Enter Option Label', 'mc_form' ), 'fit' ),
			2 => array( $name_prefix . '[settings][options][__SDAKEY__][score]', '', __( 'Score (Optional)', 'mc_form' ), 'fit' ),
			3 => array( $name_prefix . '[settings][options][__SDAKEY__][num]', '', __( 'Numeric Value', 'mc_form' ), 'fit' ),
			4 => array( $name_prefix . '[settings][options][__SDAKEY__][default]', '', '', false )
		);

		$sda_items = array();
		$max_key = null;
		foreach ( (array) $data['settings']['options'] as $o_key => $option ) {
			$max_key = max( array( $max_key, $o_key ) );
			$sda_items[] = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . '][image]', $option['image'], __( 'Option Image', 'mc_form' ) ),
				1 => array( $name_prefix . '[settings][options][' . $o_key . '][label]', $option['label'], __( 'Enter Option Label', 'mc_form' ), 'fit' ),
				2 => array( $name_prefix . '[settings][options][' . $o_key . '][score]', $option['score'], __( 'Score (Optional)', 'mc_form' ), 'fit' ),
				3 => array( $name_prefix . '[settings][options][' . $o_key . '][num]', $option['num'], __( 'Numeric Value', 'mc_form' ), 'fit' ),
				4 => array( $name_prefix . '[settings][options][' . $o_key . '][default]', '', '', ( isset( $option['default'] ) && true == $option['default'] ? true : false ) ),
			);
		}

		$appearance_choices = array(
			0 => array(
				'value' => 'normal',
				'label' => __( 'Regular with Checkbox/Radio', 'mc_form' ),
			),
			1 => array(
				'value' => 'border',
				'label' => __( 'Highlight Border', 'mc_form' ),
			),
			2 => array(
				'value' => 'color',
				'label' => __( 'Highlight Color', 'mc_form' ),
			),
		);
		$prefill_types = array(
			0 => array(
				'value' => 'none',
				'label' => __( 'None', 'mc_form' ),
			),
			1 => array(
				'value' => 'url',
				'label' => __( 'URL Parameter Based', 'mc_form' ),
			),
			2 => array(
				'value' => 'meta',
				'label' => __( 'User Meta Based', 'mc_form' ),
			),
		);
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_options"><?php _e( 'Options', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear inside the selected radio/checkbox.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][multiple]', __( 'Multi Select', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][multiple]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['multiple'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether or not, multiple options can be selected.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_label]', __( 'Show Image Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['show_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether or not, labels will be shown along with the image. Will render a captioned image look.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][appearance]', __( 'Interface Appearance', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][appearance]', $appearance_choices, $data['settings']['appearance'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Choose how you would like the thumbnails to appear..', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][tooltip]', __( 'Hide Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][tooltip]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['tooltip'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether to show tooltip on hover.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][width]', __( 'Image Width', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][width]', $data['settings']['width'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter Image Width, in pixels.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][height]', __( 'Image Height', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][height]', $data['settings']['height'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter Image Height, in pixels.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][type]', __( 'Prefill Type', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][type]', $prefill_types, $data['settings']['type'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Set the type of the prefill value the field will get. It can be based on URL parameter or user meta key. Leave to None if you do not wish to prefill the value.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][parameter]', __( 'Key Parameter', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][parameter]', $data['settings']['parameter'], __( 'Required', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the key parameter. In case of URL type value, <code>$_REQUEST[ $key ]</code> would be used. In case of User meta type value, the mentioned metakey would be used to retrieve the metavalue. It can not be empty or no value would be generated.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_options">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php _e( 'Option List', 'mc_form' ); ?></th>
						<td>
							<?php $this->ui->help( __( 'Enter the options. You can also have score associated to the options. The value of the score should be numeric positive or negative number.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items, $sda_data, $max_key ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_pricing_table( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$appearance_items = array();
		// Title
		$appearance_items[] = array(
			'name' => $name_prefix . '[title]',
			'label' => __( 'Title', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ),
		);
		// Center Content
		$appearance_items[] = array(
			'name' => $name_prefix . '[settings][centered]',
			'label' => __( 'Center Content', 'mc_form' ),
			'ui' => 'toggle',
			'param' => array( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ),
			'help' => __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ),
		);
		// Hidden label
		$appearance_items[] = array(
			'name' => $name_prefix . '[settings][hidden_label]',
			'label' => __( 'Hide Label', 'mc_form' ),
			'ui' => 'toggle',
			'param' => array( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ),
			'help' => __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ),
		);
		// Tooltip
		$appearance_items[] = array(
			'name' => $name_prefix . '[tooltip]',
			'label' => __( 'Tooltip', 'mc_form' ),
			'ui' => 'textarea',
			'param' => array( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ),
			'help' => __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ),
		);
		// Interface items
		$interface_items = array();
		$prefill_types = array(
			0 => array(
				'value' => 'none',
				'label' => __( 'None', 'mc_form' ),
			),
			1 => array(
				'value' => 'url',
				'label' => __( 'URL Parameter Based', 'mc_form' ),
			),
			2 => array(
				'value' => 'meta',
				'label' => __( 'User Meta Based', 'mc_form' ),
			),
		);
		$available_styles = array(
			0 => array(
				'value' => 'default',
				'label' => __( 'Sharp Tables', 'mc_form' ),
			),
			1 => array(
				'value' => 'rounded',
				'label' => __( 'Rounded Tables', 'mc_form' ),
			),
		);
		// Currency Sign
		$interface_items[] = array(
			'name' => $name_prefix . '[settings][currency]',
			'label' => __( 'Currency Sign', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[settings][currency]', $data['settings']['currency'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Enter the currency sign that will be shown before the price.', 'mc_form' ),
		);
		// Styles
		$interface_items[] = array(
			'name' => $name_prefix . '[settings][style]',
			'label' => __( 'Table Style', 'mc_form' ),
			'ui' => 'select',
			'param' => array( $name_prefix . '[settings][style]', $available_styles, $data['settings']['style'] ),
			'help' => __( 'Set the style of the table. You can modify the colors in the OPTIONS tab.', 'mc_form' ),
		);
		// Prefill type
		$interface_items[] = array(
			'name' => $name_prefix . '[settings][type]',
			'label' => __( 'Prefill Type', 'mc_form' ),
			'ui' => 'select',
			'param' => array( $name_prefix . '[settings][type]', $prefill_types, $data['settings']['type'] ),
			'help' => __( 'Set the type of the prefill value the field will get. It can be based on URL parameter or user meta key. Leave to None if you do not wish to prefill the value.', 'mc_form' ),
		);
		// Prefill key
		$interface_items[] = array(
			'name' => $name_prefix . '[settings][parameter]',
			'label' => __( 'Key Parameter', 'mc_form' ),
			'ui' => 'text',
			'param' => array( $name_prefix . '[settings][parameter]', $data['settings']['parameter'], __( 'Required', 'mc_form' ) ),
			'help' => __( 'Enter the key parameter. In case of URL type value, <code>$_REQUEST[ $key ]</code> would be used. In case of User meta type value, the mentioned metakey would be used to retrieve the metavalue. It can not be empty or no value would be generated.', 'mc_form' ),
		);

		// Options SDA
		$sda_columns = array(
			0 => array(
				'label' => __( 'Title', 'mc_form' ),
				'type' => 'text',
				'size' => 50,
			),
			1 => array(
				'label' => __( 'Price', 'mc_form' ),
				'type' => 'spinner',
				'size' => 25,
			),
			2 => array(
				'label' => __( 'Numeric', 'mc_form' ),
				'type' => 'spinner',
				'size' => 25,
			),
			3 => array(
				'label' => __( 'Attributes', 'mc_form' ),
				'type' => 'textarea',
				'size' => 50,
			),
			4 => array(
				'label' => __( 'Highlighted', 'mc_form' ),
				'type' => 'toggle',
				'size' => 20,
			),
			5 => array(
				'label' => __( 'Feature Header', 'mc_form' ),
				'type' => 'text',
				'size' => 30,
				'clear' => true,
			),
			6 => array(
				'label' => __( 'Selected', 'mc_form' ),
				'type' => 'toggle',
				'size' => 15,
			),
			7 => array(
				'label' => __( 'Footer', 'mc_form' ),
				'type' => 'text',
				'size' => 30,
			),
			8 => array(
				'label' => __( 'Color Scheme', 'mc_form' ),
				'type' => 'select',
				'size' => 25,
			),
			9 => array(
				'label' => __( 'Custom Color', 'mc_form' ),
				'type' => 'colorpicker',
				'size' => 30,
			),
		);
		$color_schemes = array(
			array(
				'label' => __( 'Shamrock', 'mc_form' ),
				'value' => 'shamrock',
			),
			array(
				'label' => __( 'Biloba Flower', 'mc_form' ),
				'value' => 'biloba-flower',
			),
			array(
				'label' => __( 'Cinnabar', 'mc_form' ),
				'value' => 'cinnabar',
			),
			array(
				'label' => __( 'Bright Turquoise', 'mc_form' ),
				'value' => 'bright-turquoise',
			),
			array(
				'label' => __( 'Charade', 'mc_form' ),
				'value' => 'charade',
			),
			array(
				'label' => __( 'Meteorite', 'mc_form' ),
				'value' => 'meteorite',
			),
			array(
				'label' => __( 'Vivid Violet', 'mc_form' ),
				'value' => 'vivid-violet',
			),
			array(
				'label' => __( 'Tango', 'mc_form' ),
				'value' => 'tango',
			),
			array(
				'label' => __( 'Tree Poppy', 'mc_form' ),
				'value' => 'tree-poppy',
			),
			array(
				'label' => __( 'Cerulean', 'mc_form' ),
				'value' => 'cerulean',
			),
			array(
				'label' => __( 'Bahama Blue', 'mc_form' ),
				'value' => 'bahama-blue',
			),
			array(
				'label' => __( 'Aqua Deep', 'mc_form' ),
				'value' => 'aqua-deep',
			),
			array(
				'label' => __( 'Theme', 'mc_form' ),
				'value' => 'theme',
			),
			array(
				'label' => __( 'Custom', 'mc_form' ),
				'value' => 'custom',
			),
		);

		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Option', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);

		$sda_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__][label]', '', __( 'Title', 'mc_form' ) ),
			1 => array( $name_prefix . '[settings][options][__SDAKEY__][price]', '', __( 'Shown Price', 'mc_form' ), 'fit' ),
			2 => array( $name_prefix . '[settings][options][__SDAKEY__][numeric]', '', __( 'Numeric Value', 'mc_form' ), 'fit' ),
			3 => array( $name_prefix . '[settings][options][__SDAKEY__][attr]', '', __( 'One Per Line', 'mc_form' ), 'fit' ),
			4 => array( $name_prefix . '[settings][options][__SDAKEY__][highlight]', '', '', false ),
			5 => array( $name_prefix . '[settings][options][__SDAKEY__][header]', '', __( 'Header', 'mc_form' ), 'fit' ),
			6 => array( $name_prefix . '[settings][options][__SDAKEY__][selected]', '', '', false ),
			7 => array( $name_prefix . '[settings][options][__SDAKEY__][footer]', '', __( 'Footer', 'mc_form' ), 'fit' ),
			8 => array( $name_prefix . '[settings][options][__SDAKEY__][scheme]', $color_schemes, 'theme' ),
			9 => array( $name_prefix . '[settings][options][__SDAKEY__][color]', '#F44336', __( 'Accent', 'mc_form' ) ),
		);

		$sda_items = array();
		$max_key = 0;
		foreach ( (array) $data['settings']['options'] as $o_key => $option ) {
			$max_key = max( array( $max_key, $o_key ) );
			$sda_items[] = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . '][label]', $option['label'], __( 'Title', 'mc_form' ) ),
				1 => array( $name_prefix . '[settings][options][' . $o_key . '][price]', $option['price'], __( 'Shown Price', 'mc_form' ), 'fit' ),
				2 => array( $name_prefix . '[settings][options][' . $o_key . '][numeric]', $option['numeric'], __( 'Numeric Value', 'mc_form' ), 'fit' ),
				3 => array( $name_prefix . '[settings][options][' . $o_key . '][attr]', $option['attr'], __( 'One Per Line', 'mc_form' ), 'fit' ),
				4 => array( $name_prefix . '[settings][options][' . $o_key . '][highlight]', '', '', ( isset( $option['highlight'] ) && true == $option['highlight'] ? true : false ) ),
				5 => array( $name_prefix . '[settings][options][' . $o_key . '][header]', $option['header'], __( 'Header', 'mc_form' ), 'fit' ),
				6 => array( $name_prefix . '[settings][options][' . $o_key . '][selected]', '', '', ( isset( $option['selected'] ) && true == $option['selected'] ? true : false ) ),
				7 => array( $name_prefix . '[settings][options][' . $o_key . '][footer]', $option['footer'], __( 'Footer', 'mc_form' ), 'fit' ),
				8 => array( $name_prefix . '[settings][options][' . $o_key . '][scheme]', $color_schemes, $option['scheme'] ),
				9 => array( $name_prefix . '[settings][options][' . $o_key . '][color]', $option['color'], __( 'Accent', 'mc_form' ) ),
			);
		}
		$options_items = array(
			0 => array(
				'ui' => 'sda_list',
				'param' => array(
					array(
						'columns' => $sda_columns,
						'labels' => $labels,
					),
					$sda_items,
					$sda_data,
					$max_key,
				),
			),
		);

		// Generate output
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
		<div class="mc_uif_tabs">
			<ul>
				<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
				<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
				<li><a href="#<?php echo $tab_names; ?>_options"><?php _e( 'Options', 'mc_form' ); ?></a></li>
				<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
				<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
			</ul>
			<div id="<?php echo $tab_names; ?>_elm">
				<?php $this->ui->form_table( $appearance_items ); ?>
			</div>
			<div id="<?php echo $tab_names; ?>_ifs">
				<?php $this->ui->form_table( $interface_items ); ?>
			</div>
			<div id="<?php echo $tab_names; ?>_options">
				<?php $this->ui->form_table( $options_items ); ?>
			</div>
			<div id="<?php echo $tab_names; ?>_validation">
				<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
			</div>
			<div id="<?php echo $tab_names; ?>_logic">
				<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
			</div>
		</div>
		<?php
	}

	public function build_slider( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$id_label_prefix = $this->ui->generate_id_from_name( $name_prefix . '[settings][label]' );

		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_score"><?php _e( 'Scoring', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical_ui]', __( 'Vertical Slider Interface', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical_ui]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['vertical_ui'], '1', false, true, array( 'condid' => $this->ui->generate_id_from_name( $name_prefix . '_st_vertical_slider_wrap' ) ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want the UI of slider to be vertical, then enable this option. You will also need to set the height.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $this->ui->generate_id_from_name( $name_prefix . '_st_vertical_slider_wrap' ); ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][height]', __( 'Slider Height (px)', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->spinner( $name_prefix . '[settings][height]', $data['settings']['height'], __( 'Height in pixel', 'mc_form' ) ); ?></td>
						<td><?php $this->ui->help( __( 'Since you have chosen vertical slider, set the height of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][min]', __( 'Minimum Slider Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][min]', $data['settings']['min'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the minimum value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][max]', __( 'Maximum Slider Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max]', $data['settings']['max'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the maximum value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][step]', __( 'Slider Step Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][step]', $data['settings']['step'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the step value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][dmin]', __( 'Default Slider Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][dmin]', $data['settings']['dmin'], __( 'Defined minimum', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Should be in between minimum and maximum. If left blank, the minimum value will be considered.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][nomin]', __( 'Do not accept minimum value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][nomin]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['nomin'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If enabled, then the element would not accept the minimum value and it will trigger a validation error unless user selects anything but the minimum value.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_count]', __( 'Show Count', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_count]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['show_count'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then it will show the slider value count to the user.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][prefix]', __( 'Count Prefix', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][prefix]', $data['settings']['prefix'], __( 'Prefix', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a string that is displayed before the count. Space is not included, so make sure you provide a space if you want to separate the prefix from the count.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][suffix]', __( 'Count Suffix', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][suffix]', $data['settings']['suffix'], __( 'Suffix', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a string that is displayed after the count. Space is not included, so make sure you provide a space if you want to separate the prefix from the count.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][show]', __( 'Show labels on slider', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][label][show]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['label']['show'], '1', false, true, array(
								'condid' => $id_label_prefix . '_first_wrap,' . $id_label_prefix . '_last_wrap,' . $id_label_prefix . '_mid_wrap,' . $id_label_prefix . '_rest_wrap',
							) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether or not to show labels below slider pips.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_first_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][first]', __( 'First Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][first]', $data['settings']['label']['first'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the first value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_mid_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][mid]', __( 'Middle Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][mid]', $data['settings']['label']['mid'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the mid value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_last_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][last]', __( 'Last Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][last]', $data['settings']['label']['last'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the last value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_rest_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][rest]', __( 'Other Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][rest]', $data['settings']['label']['rest'], __( 'Comma separated', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The labels for the rest of the values of the slider. You have to enter comma separated values and it should match the slider steps less three. The first, last and middle labels will be positioned automatically.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][floats]', __( 'Floating Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][floats]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['floats'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then a floating tooltip will appear with the selected number in it.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_score">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score]', __( 'Assign Score', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][score]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['score'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want this slider contribute to the score obtained, then please enable it here.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score_multiplier]', __( 'Score Multiplier', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][score_multiplier]', $data['settings']['score_multiplier'], '1' ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want to adjust the score by multiplying the selected value with something, then please mention it here. By default it is 1.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_range( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$id_label_prefix = $this->ui->generate_id_from_name( $name_prefix . '[settings][label]' );
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_score"><?php _e( 'Scoring', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical_ui]', __( 'Vertical Range Interface', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical_ui]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['vertical_ui'], '1', false, true, array( 'condid' => $this->ui->generate_id_from_name( $name_prefix . '_st_vertical_slider_wrap' ) ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want the UI of slider to be vertical, then enable this option. You will also need to set the height.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $this->ui->generate_id_from_name( $name_prefix . '_st_vertical_slider_wrap' ); ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][height]', __( 'Range Height (px)', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->spinner( $name_prefix . '[settings][height]', $data['settings']['height'], __( 'Height in pixel', 'mc_form' ) ); ?></td>
						<td><?php $this->ui->help( __( 'Since you have chosen vertical slider, set the height of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][min]', __( 'Minimum Slider Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][min]', $data['settings']['min'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the minimum value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][max]', __( 'Maximum Slider Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max]', $data['settings']['max'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the maximum value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][step]', __( 'Slider Step Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][step]', $data['settings']['step'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the step value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][dmin]', __( 'Default Slider Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][dmin]', $data['settings']['dmin'], __( 'Defined minimum', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Should be in between minimum and maximum. If left blank, the minimum value will be considered.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][dmax]', __( 'Default Maximum Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][dmax]', $data['settings']['dmax'], __( 'Defined minimum', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Should be in between minimum and maximum. If left blank, the minimum value + step will be considered.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][nomin]', __( 'Do not accept minimum value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][nomin]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['nomin'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If enabled, then the element would not accept the minimum value and it will trigger a validation error unless user selects anything but the minimum value.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_count]', __( 'Show Count', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_count]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['show_count'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then it will show the slider value count to the user.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][prefix]', __( 'Count Prefix', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][prefix]', $data['settings']['prefix'], __( 'Prefix', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a string that is displayed before the count. Space is not included, so make sure you provide a space if you want to separate the prefix from the count.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][suffix]', __( 'Count Suffix', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][suffix]', $data['settings']['suffix'], __( 'Suffix', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a string that is displayed after the count. Space is not included, so make sure you provide a space if you want to separate the prefix from the count.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][show]', __( 'Show labels on slider', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][label][show]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['label']['show'], '1', false, true, array(
								'condid' => $id_label_prefix . '_first_wrap,' . $id_label_prefix . '_last_wrap,' . $id_label_prefix . '_mid_wrap,' . $id_label_prefix . '_rest_wrap',
							) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether or not to show labels below slider pips.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_first_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][first]', __( 'First Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][first]', $data['settings']['label']['first'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the first value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_mid_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][mid]', __( 'Middle Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][mid]', $data['settings']['label']['mid'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the mid value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_last_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][last]', __( 'Last Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][last]', $data['settings']['label']['last'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the last value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_rest_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][rest]', __( 'Other Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][rest]', $data['settings']['label']['rest'], __( 'Comma separated', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The labels for the rest of the values of the slider. You have to enter comma separated values and it should match the slider steps less three. The first, last and middle labels will be positioned automatically.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][floats]', __( 'Floating Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][floats]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['floats'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then a floating tooltip will appear with the selected number in it.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_score">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score]', __( 'Assign Score', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][score]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['score'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want this slider contribute to the score obtained, then please enable it here.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score_multiplier]', __( 'Score Multiplier', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][score_multiplier]', $data['settings']['score_multiplier'], '1' ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want to adjust the score by multiplying the selected value with something, then please mention it here. By default it is 1.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<?php
					$score_formula = array(
						array(
							'label' => __( 'Average of two', 'mc_form' ),
							'value' => 'avg',
						),
						array(
							'label' => __( 'Addition of two', 'mc_form' ),
							'value' => 'add',
						),
						array(
							'label' => __( 'Difference of two', 'mc_form' ),
							'value' => 'diff',
						),
						array(
							'label' => __( 'Minimum of two', 'mc_form' ),
							'value' => 'min',
						),
						array(
							'label' => __( 'Maximum of two', 'mc_form' ),
							'value' => 'max',
						),
					);
					?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][formula]', __( 'Score Calculation Formula', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][formula]', $score_formula, $data['settings']['formula'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Since the value is actually a range please specify how the resulting score will be calculated.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_spinners( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Option', 'mc_form' ),
				'type' => 'text',
				'size' => '50',
			),
			1 => array(
				'label' => __( 'Min', 'mc_form' ),
				'type' => 'spinner',
				'size' => '12',
			),
			2 => array(
				'label' => __( 'Max', 'mc_form' ),
				'type' => 'spinner',
				'size' => '12',
			),
			3 => array(
				'label' => __( 'Step', 'mc_form' ),
				'type' => 'spinner',
				'size' => '12',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Option', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__][label]', '', __( 'Enter label', 'mc_form' ) ),
			1 => array( $name_prefix . '[settings][options][__SDAKEY__][min]', '', __( 'Minimum', 'mc_form' ) ),
			2 => array( $name_prefix . '[settings][options][__SDAKEY__][max]', '', __( 'Maximum', 'mc_form' ) ),
			3 => array( $name_prefix . '[settings][options][__SDAKEY__][step]', '', __( 'Step', 'mc_form' ) ),
		);
		$sda_items = array();
		$max_key = null;
		foreach ( (array)$data['settings']['options'] as $o_key => $option ) {
			if ( ! is_array( $option ) ) {
				// backward compatibility -2.5.0
				$option = array(
					'label' => $option,
				);
			}
			// Add overrideable min, max and step
			// With backward compatibility with -2.5.0
			foreach ( array( 'min', 'max', 'step' ) as $ovkey ) {
				if ( ! isset( $option[$ovkey] ) ) {
					$option[$ovkey] = '';
				}
			}
			$max_key = max( array( $max_key, $o_key ) );
			$sda_items[] = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . '][label]', $option['label'], __( 'Enter label', 'mc_form' ) ),
				1 => array( $name_prefix . '[settings][options][' . $o_key . '][min]', $option['min'], __( 'Minimum', 'mc_form' ) ),
				2 => array( $name_prefix . '[settings][options][' . $o_key . '][max]', $option['max'], __( 'Maximum', 'mc_form' ) ),
				3 => array( $name_prefix . '[settings][options][' . $o_key . '][step]', $option['step'], __( 'Step', 'mc_form' ) ),
			);
		}
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_items"><?php _e( 'Items', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_items">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'Item List', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->help( __( 'Enter the options. Any minimum, maximum and/or step value you set here, will override the global one.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<td colspan="3">

							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items, $sda_data, $max_key ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<table class="form-table">
				<tbody>
					<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'], false ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][min]', __( 'Minimum Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][min]', $data['settings']['min'], __( 'No bound', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the minimum value of the spinner.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][max]', __( 'Maximum Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max]', $data['settings']['max'], __( 'No bound', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the maximum value of the spinner.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][step]', __( 'Step Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][step]', $data['settings']['step'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the step value of the spinner.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_grading( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$id_label_prefix = $this->ui->generate_id_from_name( $name_prefix . '[settings][label]' );
		$sda_columns = array(
			0 => array(
				'label' => __( 'Option', 'mc_form' ),
				'type' => 'text',
				'size' => '30',
			),
			1 => array(
				'label' => __( 'Prefix', 'mc_form' ),
				'type' => 'text',
				'size' => '14',
			),
			2 => array(
				'label' => __( 'Suffix', 'mc_form' ),
				'type' => 'text',
				'size' => '14',
			),
			3 => array(
				'label' => __( 'Min', 'mc_form' ),
				'type' => 'spinner',
				'size' => '14',
			),
			4 => array(
				'label' => __( 'Max', 'mc_form' ),
				'type' => 'spinner',
				'size' => '14',
			),
			5 => array(
				'label' => __( 'Step', 'mc_form' ),
				'type' => 'spinner',
				'size' => '14',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Option', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__][label]', '', __( 'Enter label', 'mc_form' ) ),
			1 => array( $name_prefix . '[settings][options][__SDAKEY__][prefix]', '', __( 'Prefix', 'mc_form' ) ),
			2 => array( $name_prefix . '[settings][options][__SDAKEY__][suffix]', '', __( 'Suffix', 'mc_form' ) ),
			3 => array( $name_prefix . '[settings][options][__SDAKEY__][min]', '', __( 'Minimum', 'mc_form' ) ),
			4 => array( $name_prefix . '[settings][options][__SDAKEY__][max]', '', __( 'Maximum', 'mc_form' ) ),
			5 => array( $name_prefix . '[settings][options][__SDAKEY__][step]', '', __( 'Step', 'mc_form' ) ),
		);
		$sda_items = array();
		$max_key = null;
		foreach ( (array)$data['settings']['options'] as $o_key => $option ) {
			if ( ! is_array( $option ) ) {
				// backward compatibility -2.4.0
				$option = array(
					'label' => $option,
					'prefix' => '',
					'suffix' => '',
				);
			}
			// Add overrideable min, max and step
			// With backward compatibility with -2.5.0
			foreach ( array( 'min', 'max', 'step' ) as $ovkey ) {
				if ( ! isset( $option[$ovkey] ) ) {
					$option[$ovkey] = '';
				}
			}

			$max_key = max( array( $max_key, $o_key ) );
			$sda_items[] = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . '][label]', $option['label'], __( 'Enter label', 'mc_form' ) ),
				1 => array( $name_prefix . '[settings][options][' . $o_key . '][prefix]', $option['prefix'], __( 'Prefix', 'mc_form' ) ),
				2 => array( $name_prefix . '[settings][options][' . $o_key . '][suffix]', $option['suffix'], __( 'Suffix', 'mc_form' ) ),
				3 => array( $name_prefix . '[settings][options][' . $o_key . '][min]', $option['min'], __( 'Minimum', 'mc_form' ) ),
				4 => array( $name_prefix . '[settings][options][' . $o_key . '][max]', $option['max'], __( 'Maximum', 'mc_form' ) ),
				5 => array( $name_prefix . '[settings][options][' . $o_key . '][step]', $option['step'], __( 'Step', 'mc_form' ) ),
			);
		}
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_items"><?php _e( 'Items', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_score"><?php _e( 'Scoring', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][range]', __( 'Use Range', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][range]', __( 'Ranged Input', 'mc_form' ), __( 'Single Input', 'mc_form' ), $data['settings']['range'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then it will prompt the user to select a range of values instead of a single value.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical_ui]', __( 'Vertical Slider Interface', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical_ui]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['vertical_ui'], '1', false, true, array( 'condid' => $this->ui->generate_id_from_name( $name_prefix . '_st_vertical_slider_wrap' ) ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want the UI of slider to be vertical, then enable this option. You will also need to set the height.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $this->ui->generate_id_from_name( $name_prefix . '_st_vertical_slider_wrap' ); ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][height]', __( 'Slider Height (px)', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->spinner( $name_prefix . '[settings][height]', $data['settings']['height'], __( 'Height in pixel', 'mc_form' ) ); ?></td>
						<td><?php $this->ui->help( __( 'Since you have chosen vertical slider, set the height of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][min]', __( 'Minimum Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][min]', $data['settings']['min'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the minimum value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][max]', __( 'Maximum Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max]', $data['settings']['max'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the maximum value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][step]', __( 'Step Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][step]', $data['settings']['step'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the step value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][dmin]', __( 'Default Minimum Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][dmin]', $data['settings']['dmin'], __( 'Defined minimum', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Should be in between minimum and maximum. If left blank, the minimum value will be considered.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][dmax]', __( 'Default Maximum Value (for range)', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][dmax]', $data['settings']['dmax'], __( 'Defined maximum', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Should be in between minimum and maximum. If left blank, the minimum value + step will be considered.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][nomin]', __( 'Do not accept minimum value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][nomin]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['nomin'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If enabled, then the element would not accept the minimum value and it will trigger a validation error unless user selects anything but the minimum value.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_count]', __( 'Show Count', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_count]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['show_count'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then it will show the slider value count to the user.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][show]', __( 'Show labels on slider', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][label][show]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['label']['show'], '1', false, true, array(
								'condid' => $id_label_prefix . '_first_wrap,' . $id_label_prefix . '_last_wrap,' . $id_label_prefix . '_mid_wrap,' . $id_label_prefix . '_rest_wrap',
							) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether or not to show labels below slider pips.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_first_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][first]', __( 'First Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][first]', $data['settings']['label']['first'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the first value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_mid_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][mid]', __( 'Middle Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][mid]', $data['settings']['label']['mid'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the mid value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_last_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][last]', __( 'Last Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][last]', $data['settings']['label']['last'], __( 'Label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The label for the last value of the slider.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $id_label_prefix . '_rest_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label][rest]', __( 'Other Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label][rest]', $data['settings']['label']['rest'], __( 'Comma separated', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The labels for the rest of the values of the slider. You have to enter comma separated values and it should match the slider steps less three. The first, last and middle labels will be positioned automatically.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][floats]', __( 'Floating Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][floats]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['floats'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then a floating tooltip will appear with the selected number in it.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_items">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'Item List', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the options. Any minimum, maximum and/or step value you set here, will override the global one.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items, $sda_data, $max_key ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_score">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score]', __( 'Assign Score', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][score]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['score'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want this slider contribute to the score obtained, then please enable it here.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score_multiplier]', __( 'Score Multiplier', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][score_multiplier]', $data['settings']['score_multiplier'], '1' ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want to adjust the score by multiplying the selected value with something, then please mention it here. By default it is 1.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<?php
					$score_formula = array(
						array(
							'label' => __( 'Average of two', 'mc_form' ),
							'value' => 'avg',
						),
						array(
							'label' => __( 'Addition of two', 'mc_form' ),
							'value' => 'add',
						),
						array(
							'label' => __( 'Difference of two', 'mc_form' ),
							'value' => 'diff',
						),
						array(
							'label' => __( 'Minimum of two', 'mc_form' ),
							'value' => 'min',
						),
						array(
							'label' => __( 'Maximum of two', 'mc_form' ),
							'value' => 'max',
						),
					);
					?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][formula]', __( 'Score Calculation Formula', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][formula]', $score_formula, $data['settings']['formula'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Since the value is actually a range please specify how the resulting score will be calculated.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_smileyrating( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Show', 'mc_form' ),
				'type' => 'checkbox',
				'size' => '10',
			),
			1 => array(
				'label' => __( 'Smiley', 'mc_form' ),
				'type' => 'print_icon',
				'size' => '15',
			),
			2 => array(
				'label' => __( 'Feedback Label', 'mc_form' ),
				'type' => 'text',
				'size' => '30',
			),
			3 => array(
				'label' => __( 'Score', 'mc_form' ),
				'type' => 'spinner',
				'size' => '20',
			),
			4 => array(
				'label' => __( 'Numeric', 'mc_form' ),
				'type' => 'spinner',
				'size' => '20',
			),
		);
		$sda_items = array();
		$sda_data = array(
			0 => array( $name_prefix . '[settings][enabled][__SDAKEY__]', array( 'value' => '1', 'label' => '' ), '' ),
			1 => array( 'none', 24 ),
			2 => array( $name_prefix . '[settings][labels][__SDAKEY__]', '', '' ),
			3 => array( $name_prefix . '[settings][scores][__SDAKEY__]', '', __( 'Optional', 'mc_form' ) ),
			4 => array( $name_prefix . '[settings][num][__SDAKEY__]', '', __( 'Optional', 'mc_form' ) ),
		);
		$setting_to_icon_map = array(
			'frown' => 'angry',
			'sad' => 'sad',
			'neutral' => 'neutral',
			'happy' => 'smiley',
			'excited' => 'happy',
		);
		foreach ( array( 'frown', 'sad', 'neutral', 'happy', 'excited' ) as $srkey ) {
			$sda_items[] = array(
				0 => array( $name_prefix . '[settings][enabled][' . $srkey . ']', array( 'value' => '1', 'label' => '' ), $data['settings']['enabled'][$srkey] ),
				1 => array( $setting_to_icon_map[$srkey], 24 ),
				2 => array( $name_prefix . '[settings][labels][' . $srkey . ']', $data['settings']['labels'][$srkey], '' ),
				3 => array( $name_prefix . '[settings][scores][' . $srkey . ']', $data['settings']['scores'][$srkey], __( 'Optional', 'mc_form' ) ),
				4 => array( $name_prefix . '[settings][num][' . $srkey . ']', $data['settings']['num'][$srkey], __( 'Optional', 'mc_form' ) ),
			);
		}
		$max_key = 4;
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_feedback]', __( 'Optional Feedback', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_feedback]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['show_feedback'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want to ask for feedback, then enable it here and a textbox will appear upon selecting a smiley.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][feedback_label]', __( 'Feedback Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][feedback_label]', $data['settings']['feedback_label'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown on an empty feedback textarea.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][reverse_order]', __( 'Reverse Smiley Order', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][reverse_order]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['reverse_order'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'By default smileys appear from frown to happy. Enable this to reverse the order.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th colspan="3">
							<?php $this->ui->sda_list(
								array(
									'columns' => $sda_columns,
									'features' => array(
										'draggable' => false,
										'addable' => false,
									),
								), $sda_items, $sda_data, $max_key
							); ?>
						</th>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

	<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_starrating( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Option', 'mc_form' ),
				'type' => 'text',
				'size' => '85',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Option', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__]', '', __( 'Enter label', 'mc_form' ), 'fit' ),
		);
		$sda_items = array();
		$max_key = null;
		foreach ( (array)$data['settings']['options'] as $o_key => $option ) {
			$max_key = max( array( $max_key, $o_key ) );
			$sda_items[] = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . ']', $option, __( 'Enter label', 'mc_form' ), 'fit' ),
			);
		}
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ratings"><?php _e( 'Items', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_score"><?php _e( 'Scoring', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ratings">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][max]', __( 'Maximum Rating Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max]', $data['settings']['max'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the maximum value of the rating.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label_low]', __( 'Label for lowest value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label_low]', $data['settings']['label_low'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a string that is displayed before the lowest value.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label_high]', __( 'Label for highest value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label_high]', $data['settings']['label_high'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a string that is displayed after the highest value.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'Option List', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the options', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items, $sda_data, $max_key ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_score">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score]', __( 'Assign Score', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][score]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['score'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want this slider contribute to the score obtained, then please enable it here.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score_multiplier]', __( 'Score Multiplier', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][score_multiplier]', $data['settings']['score_multiplier'], '1' ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want to adjust the score by multiplying the selected value with something, then please mention it here. By default it is 1.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_scalerating( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Option', 'mc_form' ),
				'type' => 'text',
				'size' => '85',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Option', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__]', '', __( 'Enter label', 'mc_form' ), 'fit' ),
		);
		$sda_items = array();
		$max_key = null;
		foreach ( (array)$data['settings']['options'] as $o_key => $option ) {
			$max_key = max( array( $max_key, $o_key ) );
			$sda_items[] = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . ']', $option, __( 'Enter label', 'mc_form' ), 'fit' ),
			);
		}
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ratings"><?php _e( 'Items', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_score"><?php _e( 'Scoring', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ratings">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][max]', __( 'Maximum Rating Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max]', $data['settings']['max'], __( 'Enter Number', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the maximum value of the rating.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label_low]', __( 'Label for lowest value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label_low]', $data['settings']['label_low'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a string that is displayed before the lowest value.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][label_high]', __( 'Label for highest value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][label_high]', $data['settings']['label_high'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a string that is displayed after the highest value.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'Option List', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the options', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items, $sda_data, $max_key ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_score">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score]', __( 'Assign Score', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][score]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['score'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want this slider contribute to the score obtained, then please enable it here.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score_multiplier]', __( 'Score Multiplier', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][score_multiplier]', $data['settings']['score_multiplier'], '1' ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want to adjust the score by multiplying the selected value with something, then please mention it here. By default it is 1.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_matrix( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Label', 'mc_form' ),
				'type' => 'text',
				'size' => '100',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Item', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data_row = array(
			0 => array( $name_prefix . '[settings][rows][__SDAKEY__]', '', __( 'Enter label', 'mc_form' ), 'fit' ),
		);
		$sda_items_rows = array();
		$max_key_row = null;
		foreach ( (array)$data['settings']['rows'] as $o_key => $option ) {
			$max_key_row = max( array( $max_key_row, $o_key ) );
			$sda_items_rows[] = array(
				0 => array( $name_prefix . '[settings][rows][' . $o_key . ']', $option, __( 'Enter label', 'mc_form' ), 'fit' ),
			);
		}

		$sda_col_columns = array(
			0 => array(
				'label' => __( 'Label', 'mc_form' ),
				'type' => 'text',
				'size' => '60',
			),
			1 => array(
				'label' => __( 'Score', 'mc_form' ),
				'type' => 'spinner',
				'size' => '20',
			),
			2 => array(
				'label' => __( 'Numeric', 'mc_form' ),
				'type' => 'spinner',
				'size' => '20',
			),
		);
		$sda_data_column = array(
			0 => array( $name_prefix . '[settings][columns][__SDAKEY__]', '', __( 'Enter label', 'mc_form' ), 'fit' ),
			1 => array( $name_prefix . '[settings][scores][__SDAKEY__]', '', __( 'Score (Optional)', 'mc_form' ), 'fit' ),
			2 => array( $name_prefix . '[settings][numerics][__SDAKEY__]', '', __( 'Numeric (Optional)', 'mc_form' ), 'fit' ),
		);
		$sda_items_columns = array();
		$max_key_column = null;
		foreach ( (array) $data['settings']['columns'] as $o_key => $option ) {
			$max_key_column = max( array( $max_key_column, $o_key ) );
			$sda_items_columns[] = array(
				0 => array( $name_prefix . '[settings][columns][' . $o_key . ']', $option, __( 'Enter label', 'mc_form' ), 'fit' ),
				1 => array( $name_prefix . '[settings][scores][' . $o_key . ']', isset( $data['settings']['scores'][$o_key] ) ? $data['settings']['scores'][$o_key] : '', __( 'Score (Optional)', 'mc_form' ), 'fit' ),
				2 => array( $name_prefix . '[settings][numerics][' . $o_key . ']', isset( $data['settings']['numerics'][$o_key] ) ? $data['settings']['numerics'][$o_key] : '', __( 'Numeric (Optional)', 'mc_form' ), 'fit' ),
			);
		}
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_rows"><?php _e( 'Rows', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_columns"><?php _e( 'Cols', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][multiple]', __( 'Multiple Values', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][multiple]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['multiple'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then the user will be able to select multiple values across the row.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear inside the selected radio/checkbox.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_rows">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'List of Rows', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the Rows. These are basically the primary ratings.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items_rows, $sda_data_row, $max_key_row ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_columns">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'List of Columns', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the Columns. These are basically the selection options.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_col_columns,
								'labels' => $labels,
							), $sda_items_columns, $sda_data_column, $max_key_column ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_matrix_dropdown( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Label', 'mc_form' ),
				'type' => 'text',
				'size' => '100',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Item', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data_row = array(
			0 => array( $name_prefix . '[settings][rows][__SDAKEY__]', '', __( 'Enter label', 'mc_form' ), 'fit' ),
		);
		$sda_items_rows = array();
		$max_key_row = null;
		foreach ( (array)$data['settings']['rows'] as $o_key => $option ) {
			$max_key_row = max( array( $max_key_row, $o_key ) );
			$sda_items_rows[] = array(
				0 => array( $name_prefix . '[settings][rows][' . $o_key . ']', $option, __( 'Enter label', 'mc_form' ), 'fit' ),
			);
		}

		$sda_col_columns = array(
			0 => array(
				'label' => __( 'Label', 'mc_form' ),
				'type' => 'text',
				'size' => '70',
			),
			1 => array(
				'label' => __( 'Score Multiplier', 'mc_form' ),
				'type' => 'spinner',
				'size' => '30',
			),
		);
		$sda_data_column = array(
			0 => array( $name_prefix . '[settings][columns][__SDAKEY__]', '', __( 'Enter label', 'mc_form' ), 'fit' ),
			1 => array( $name_prefix . '[settings][scores][__SDAKEY__]', '', __( 'Score (Optional)', 'mc_form' ), 'fit' ),
		);
		$sda_items_columns = array();
		$max_key_column = null;
		foreach ( (array)$data['settings']['columns'] as $o_key => $option ) {
			$max_key_column = max( array( $max_key_column, $o_key ) );
			$sda_items_columns[] = array(
				0 => array( $name_prefix . '[settings][columns][' . $o_key . ']', $option, __( 'Enter label', 'mc_form' ), 'fit' ),
				1 => array( $name_prefix . '[settings][scores][' . $o_key . ']', isset( $data['settings']['scores'][$o_key] ) ? $data['settings']['scores'][$o_key] : '', __( 'Score (Optional)', 'mc_form' ), 'fit' ),
			);
		}

		$sda_opt_columns = array(
			0 => array(
				'label' => __( 'Option', 'mc_form' ),
				'type' => 'text',
				'size' => '60',
			),
			1 => array(
				'label' => __( 'Score', 'mc_form' ),
				'type' => 'spinner',
				'size' => '20',
			),
			2 => array(
				'label' => __( 'Numeric', 'mc_form' ),
				'type' => 'spinner',
				'size' => '20',
			),
		);
		$sda_opt_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__][label]', '', __( 'Enter Option Label', 'mc_form' ), 'fit' ),
			1 => array( $name_prefix . '[settings][options][__SDAKEY__][score]', '', __( 'Score (Optional)', 'mc_form' ), 'fit' ),
			2 => array( $name_prefix . '[settings][options][__SDAKEY__][num]', '', __( 'Numeric Value', 'mc_form' ), 'fit' ),
		);

		$sda_opt_items = array();
		$max_opt_key = null;
		foreach ( $data['settings']['options'] as $o_key => $option ) {
			$max_opt_key = max( array( $max_opt_key, $o_key ) );
			$new_data = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . '][label]', $option['label'], __( 'Enter Option Label', 'mc_form' ), 'fit' ),
				1 => array( $name_prefix . '[settings][options][' . $o_key . '][score]', $option['score'], __( 'Score (Optional)', 'mc_form' ), 'fit' ),
				2 => array( $name_prefix . '[settings][options][' . $o_key . '][num]', $option['num'], __( 'Numeric Value', 'mc_form' ), 'fit' ),
			);

			$sda_opt_items[] = $new_data;
		}

		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_rows"><?php _e( 'Rows', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_columns"><?php _e( 'Cols', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_options"><?php _e( 'Options', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_rows">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'List of Rows', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the Rows. These are basically the primary ratings.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items_rows, $sda_data_row, $max_key_row ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_columns">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'List of Columns', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the Columns. These are basically the selection options.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_col_columns,
								'labels' => $labels,
							), $sda_items_columns, $sda_data_column, $max_key_column ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_options">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][empty]', __( 'Empty Option Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][empty]', $data['settings']['empty'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the first empty option that is shown to the user.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][multiple]', __( 'Multiple Values', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][multiple]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['multiple'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then the user will be able to select multiple values across the row.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'Dropdown Options', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the Options. These will appear inside every column.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_opt_columns,
								'labels' => $labels,
							), $sda_opt_items, $sda_opt_data, $max_opt_key ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_likedislike( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
	?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][liked]', __( 'liked by Default', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][liked]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['liked'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn this feature on to make it liked by default.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][like]', __( 'Liked State Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][like]', $data['settings']['like'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the liked state label that will be shown to the user.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][dislike]', __( 'Disliked State Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][dislike]', $data['settings']['dislike'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the disliked state label that will be shown to the user.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_feedback]', __( 'Optional Feedback', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_feedback]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['show_feedback'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If you want to ask for feedback, then enable it here and a textbox will appear upon selecting a smiley.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][feedback_label]', __( 'Feedback Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][feedback_label]', $data['settings']['feedback_label'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown on an empty feedback textarea.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_toggle( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
	?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_states"><?php _e( 'States', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_states">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][checked]', __( 'Checked by Default', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][checked]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['checked'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn this feature on to make the checkbox checked by default.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][on]', __( 'Checked State Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][on]', $data['settings']['on'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the checked state label that will be shown to the user.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][off]', __( 'Unchecked State Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][off]', $data['settings']['off'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the unchecked state label that will be shown to the user.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_sorting( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_user_sortable( $element, $key, $data, $element_structure, $name_prefix, true );
	}

	public function build_feedback_large( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$types = array(
			array(
				'label' => 'Standard Qwerty Keyboard',
				'value' => 'qwerty',
			),
			array(
				'label' => 'International Qwerty Keyboard',
				'value' => 'qwerty',
			),
			array(
				'label' => 'Numerical Keyboard (ten-key)',
				'value' => 'num',
			),
			array(
				'label' => 'Alphabetical Keyboard',
				'value' => 'alpha',
			),
			array(
				'label' => 'Dvorak Simplified Keyboard',
				'value' => 'dvorak',
			),
		);
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
	?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_score"><?php _e( 'Scoring', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][keypad]', __( 'Show Keyboard', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][keypad]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['keypad'], '1', false, true, array(
								'condid' => 'mc_form_builder_fl_' . $key . '_wrap',
							) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether or not to show a keyboard on this element.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo 'mc_form_builder_fl_' . $key . '_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][ktype]', __( 'Keyboard Type', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][ktype]', $types, $data['settings']['ktype'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the keyboard type.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][email]', __( 'Send to Address', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][email]', $data['settings']['email'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The email address to which this submission will be sent. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_score">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score]', __( 'Score', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][score]', $data['settings']['score'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The score admin can assign for this question. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
					<?php $this->feedback_auto_score( $name_prefix, $key, $data ); ?>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_feedback_small( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$types = array(
			array(
				'label' => 'Standard Qwerty Keyboard',
				'value' => 'qwerty',
			),
			array(
				'label' => 'International Qwerty Keyboard',
				'value' => 'qwerty',
			),
			array(
				'label' => 'Numerical Keyboard (ten-key)',
				'value' => 'num',
			),
			array(
				'label' => 'Alphabetical Keyboard',
				'value' => 'alpha',
			),
			array(
				'label' => 'Dvorak Simplified Keyboard',
				'value' => 'dvorak',
			),
		);
		// Inline Appearance
		$inline_items = [];
		// Enabled
		$inline_items[] = [
			'name' => $name_prefix . '[settings][inline][enabled]',
			'label' => __( 'Fill in the Blank Type', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $name_prefix . '[settings][inline][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['inline']['enabled'], '1', false, true, [
				'condid' => 'mc_form_builder_fs_' . $key . '_inline_prefix_wrap,mc_form_builder_fs_' . $key . '_inline_suffix_wrap,mc_form_builder_fs_' . $key . '_inline_width_wrap',
			] ],
			'help' => __( 'Enabled inline appearance or fill in the blank type appearance for this element.', 'mc_form' ),
		];
		// Prefix
		$inline_items[] = [
			'name' => $name_prefix . '[settings][inline][prefix]',
			'label' => __( 'Inline Prefix', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $name_prefix . '[settings][inline][prefix]', $data['settings']['inline']['prefix'], __( 'HTML Enabled', 'mc_form' ) ],
			'help' => __( 'Put the HTML prefix before the element. You can also put interactive tags if the settings are enabled.', 'mc_form' ),
			'id' => 'mc_form_builder_fs_' . $key . '_inline_prefix_wrap',
		];
		// Suffix
		$inline_items[] = [
			'name' => $name_prefix . '[settings][inline][suffix]',
			'label' => __( 'Inline Suffix', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $name_prefix . '[settings][inline][suffix]', $data['settings']['inline']['suffix'], __( 'HTML Enabled', 'mc_form' ) ],
			'help' => __( 'Put the HTML suffix after the element. You can also put interactive tags if the settings are enabled.', 'mc_form' ),
			'id' => 'mc_form_builder_fs_' . $key . '_inline_suffix_wrap',
		];
		// Width
		$inline_items[] = [
			'name' => $name_prefix . '[settings][inline][width]',
			'label' => __( 'Inline Width', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $name_prefix . '[settings][inline][width]', $data['settings']['inline']['width'], __( 'px', 'mc_form' ) ],
			'help' => __( 'Mention the width, in pixels of the inline element.', 'mc_form' ),
			'id' => 'mc_form_builder_fs_' . $key . '_inline_width_wrap',
		];
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
	?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_score"><?php _e( 'Scoring', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][keypad]', __( 'Show Keyboard', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][keypad]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['keypad'], '1', false, true, array(
								'condid' => 'mc_form_builder_fs_' . $key . '_wrap',
							) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether or not to show a keyboard on this element.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo 'mc_form_builder_fs_' . $key . '_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][ktype]', __( 'Keyboard Type', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][ktype]', $types, $data['settings']['ktype'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the keyboard type.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][email]', __( 'Send to Address', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][email]', $data['settings']['email'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The email address to which this submission will be sent. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
					<?php $this->ui->form_table( $inline_items, false ); ?>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_score">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][score]', __( 'Score', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][score]', $data['settings']['score'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The score admin can assign for this question. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
					<?php $this->feedback_auto_score( $name_prefix, $key, $data ); ?>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_upload( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		$upload_ifs_items = [];
		// Upload Button Label
		$upload_ifs_items[] = [
			'name' => $name_prefix . '[settings][upload_label]',
			'label' => __( 'Upload Button Label', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $name_prefix . '[settings][upload_label]', $data['settings']['upload_label'], __( 'Required', 'mc_form' ) ],
			'help' => __( 'Enter the label of the upload button.', 'mc_form' ),
		];
		// Upload Specific Type
		$upload_accept_types = [
			'all' => __( 'All Files', 'mc_form' ),
			'image' => __( 'Image Files Only', 'mc_form' ),
			'video' => __( 'Video Files Only', 'mc_form' ),
			'audio' => __( 'Audio Files Only', 'mc_form' ),
		];
		$upload_ifs_items[] = [
			'name' => $name_prefix . '[settings][accept]',
			'label' => __( 'Upload Button will accept', 'mc_form' ),
			'ui' => 'select',
			'param' => [ $name_prefix . '[settings][accept]', $upload_accept_types, $data['settings']['accept'] ],
			'help' => __( 'You can force accepted files types through the upload button here. Use it in conjunction with Capture Mode to force camera upload through front/back facing camera on mobile or compatible devices. <strong>DO NOT FORGET TO SET THE VALIDATION</strong> for this to work properly. Also enabling Select One file at a time is useful.', 'mc_form' ),
		];
		$upload_capture_types = [
			'none' => __( 'None', 'mc_form' ),
			'user' => __( 'User/Front Facing Image/Video', 'mc_form' ),
			'environment' => __( 'Environment/Rear Facing Image/Video', 'mc_form' ),
			'audio' => __( 'Audio Capture', 'mc_form' ),
		];
		$upload_ifs_items[] = [
			'name' => $name_prefix . '[settings][capture]',
			'label' => __( 'Capture Mode', 'mc_form' ),
			'ui' => 'select',
			'param' => [ $name_prefix . '[settings][capture]', $upload_capture_types, $data['settings']['capture'] ],
			'help' => __( 'When supported you can force the capture mode. This is useful while uploading images, videos or audio through mobile or compatible devices.', 'mc_form' ),
		];
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the title. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->ui->form_table( $upload_ifs_items, false ); ?>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][wp_media_integration]', __( 'Integrate to WP Media', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][wp_media_integration]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['wp_media_integration'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enable to automatically add the uploads to WordPress Media List. You can then easily put them inside posts or use any media functions on them.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][auto_upload]', __( 'Immediate Upload', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][auto_upload]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['auto_upload'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enable to start upload the files immediately after added. Otherwise user would need to click on the Start Upload button to actually upload the files.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][minimal_ui]', __( 'Minimal UI', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][minimal_ui]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['minimal_ui'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enabling this will only show the upload button and just the list of uploaded files without checkboxes and bulk action buttons.', 'mc_form' ) ); ?>
						</td>
					</tr>

					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][single_upload]', __( 'Select one file at a time', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][single_upload]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['single_upload'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enabling this will make the user to select only one file at a time when browsing. This is recommended only if you want to have access to Upload from camera feature on iOS devices.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][drag_n_drop]', __( 'Drag and Drop Interface', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][drag_n_drop]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['drag_n_drop'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If enabled, the upload container will have a nice drag and drop zone where users can simply put their files for upload.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][dragdrop]', __( 'Drag and Drop Instruction', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][dragdrop]', $data['settings']['dragdrop'], __( 'Required', 'mc_form' ) ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the instruction text for the drag and drop zone. Should be compact and precise.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][progress_bar]', __( 'Show Progress Bar', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][progress_bar]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['progress_bar'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If enabled, users will be shown a progress bar to track upload progress.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][preview_media]', __( 'Preview Media', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][preview_media]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['preview_media'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If enabled, users will have options to preview uploaded media - images, audio and video files.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][can_delete]', __( 'Delete Capability', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][can_delete]', __( 'Enabled', 'mc_form' ), __( 'Disabled', 'mc_form' ), $data['settings']['can_delete'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'If enabled, users can delete their uploaded files before making the final submission.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<table class="form-table">
				<tbody>
					<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'], false ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][accept_file_types]', __( 'Accepted File Types', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][accept_file_types]', $data['settings']['accept_file_types'], __( 'Accept everything (can be dangerous)', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter a comma separated list of extensions of files that you would allow the user to upload. Leaving it empty will cause unrestricted file upload. But for security purpose we are still going to disable uploading of .php files and other executable files.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][max_number_of_files]', __( 'Maximum Number of Files', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max_number_of_files]', $data['settings']['max_number_of_files'], __( 'No limit', 'mc_form' ), 1, 100, 1 ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter maximum number of files. Leave blank for unlimited files. Please note that PHP file limit may still be restricting the overall size.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][min_number_of_files]', __( 'Minimum Number of Files', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][min_number_of_files]', $data['settings']['min_number_of_files'], __( 'Validation Dependent', 'mc_form' ), 1, 100, 1 ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter minimum number of files. Leave blank for fallback to validation.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][max_file_size]', __( 'Max File Size (bytes)', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max_file_size]', $data['settings']['max_file_size'], __( 'No limit', 'mc_form' ), 1, 100000000, 1000 ); ?>
							<p class="description"><?php printf( __( '<strong>PHP Upload Limit:</strong> <code>%s</code> bytes', 'mc_form' ), $this->get_maximum_file_upload_size() ); ?></p>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter maximum file size in bytes. Leave blank for unlimited file size. Please note that PHP file limit may still be restricting the actual size.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][min_file_size]', __( 'Min File Size (bytes)', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][min_file_size]', $data['settings']['min_file_size'], __( 'No limit', 'mc_form' ), 1, 100000000, 1000 ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter minimum file size in bytes. Minimum will always be 1.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_mathematical( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the title. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden]', __( 'Not visible inside form', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If this option is enabled, then the element will not be visible inside the form. It will be visible in the summary table though (if you do not explicitly disable it) and also you can put conditional logic on it.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][editable]', __( 'Value Editable By User', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][editable]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['editable'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether or not the calculated value would be editable by user.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][right]', __( 'Align Right ( Row )', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][right]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['right'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the mathematical element will have a row like look aligned to the right. Works only with material themes.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][fancy]', __( 'Fancy Appearance', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][fancy]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['fancy'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the mathematical element will have a slick look attached to the right side of the form. Works only with material themes. Will override the Align Right appearance.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][noanim]', __( 'Disable countUp/Down Animation', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][noanim]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['noanim'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled then the numbers would not animate when a change occurs.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][formula]', __( 'Formula Input', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][formula]', $data['settings']['formula'], __( 'Valid Mathematical String', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter mathematical formula here. <code>(M1+M2)/(M3+F1)</code>. More advanced formula can be inserted. Please <a href="https://wp.me/p3Zesg-1gM" target="_blank">follow this guide</a>.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][precision]', __( 'Decimal Precision', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][precision]', $data['settings']['precision'], __( 'Automatic', 'mc_form' ), 1, 10, 1 ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the number of digits that should be rounded off after decimal point. Leaving empty will automate the process and will take into consideration of the final number.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][grouping]', __( 'Use Grouping', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][grouping]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['grouping'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled then number will be grouped by thousands separator.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][separator]', __( 'Thousands Separator', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][separator]', $data['settings']['separator'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the thousands separator. Default <code>,</code>.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][decimal]', __( 'Decimal Separator', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][decimal]', $data['settings']['decimal'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the decimal separator. Default <code>.</code>.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][prefix]', __( 'Prefix', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[settings][prefix]', $data['settings']['prefix'], __( 'HTML allowed', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the prefix text here.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][suffix]', __( 'Suffix', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[settings][suffix]', $data['settings']['suffix'], __( 'HTML allowed', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the suffix text here.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_payment( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		$countries = MC_FORM_Form_Elements_Static::get_countries();
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the heading. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][country]', __( 'Preselected Country', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][country]', $countries, $data['settings']['country'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'User needs to enter their country for Credit Card Payments. Please select the country which should be pre selected.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][ptitle]', __( 'Payment Mode Selection Title', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][ptitle]', $data['settings']['ptitle'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the title that will be shown against the payment mode selection.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][ctitle]', __( 'Credit Card Form Title', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][ctitle]', $data['settings']['ctitle'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the title that will be shown against the cc form.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][ppmsg]', __( 'PayPal Express Checkout Message', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[settings][ppmsg]', $data['settings']['ppmsg'], __( 'HTML allowed', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the message that will be shown to users who chooses paypal express checkout.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][noanim]', __( 'Disable countUp/Down Animation', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][noanim]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['noanim'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled then the numbers would not animate when a change occurs.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][right]', __( 'Align Right ( Row )', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][right]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['right'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the mathematical element will have a row like look aligned to the right. Works only with material themes.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][fancy]', __( 'Fancy Appearance', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][fancy]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['fancy'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the mathematical element will have a slick look attached to the right side of the form. Works only with material themes. Will override the Align Right appearance.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th>
							<?php $this->ui->generate_label( $name_prefix . '[settings][precision]', __( 'Decimal Precision', 'mc_form' ) ); ?>
						</th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][precision]', $data['settings']['precision'], __( 'Automatic', 'mc_form' ), 1, 10, 1 ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the number of digits that should be rounded off after decimal point.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][grouping]', __( 'Use Grouping', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][grouping]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['grouping'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled then number will be grouped by thousands separator.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][separator]', __( 'Thousands Separator', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][separator]', $data['settings']['separator'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the thousands separator. Default <code>,</code>.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][decimal]', __( 'Decimal Separator', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][decimal]', $data['settings']['decimal'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the decimal separator. Default <code>.</code>.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][prefix]', __( 'Prefix', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[settings][prefix]', $data['settings']['prefix'], __( 'HTML allowed', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the prefix text here.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][suffix]', __( 'Suffix', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[settings][suffix]', $data['settings']['suffix'], __( 'HTML allowed', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the suffix text here.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_feedback_matrix( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Label', 'mc_form' ),
				'type' => 'text',
				'size' => '100',
			),
		);
		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Item', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data_row = array(
			0 => array( $name_prefix . '[settings][rows][__SDAKEY__]', '', __( 'Enter label', 'mc_form' ), 'fit' ),
		);
		$sda_items_rows = array();
		$max_key_row = null;
		foreach ( (array)$data['settings']['rows'] as $o_key => $option ) {
			$max_key_row = max( array( $max_key_row, $o_key ) );
			$sda_items_rows[] = array(
				0 => array( $name_prefix . '[settings][rows][' . $o_key . ']', $option, __( 'Enter label', 'mc_form' ), 'fit' ),
			);
		}

		$sda_col_columns = array(
			0 => array(
				'label' => __( 'Label', 'mc_form' ),
				'type' => 'text',
				'size' => '100',
			),
		);
		$sda_data_column = array(
			0 => array( $name_prefix . '[settings][columns][__SDAKEY__]', '', __( 'Enter label', 'mc_form' ), 'fit' ),
		);
		$sda_items_columns = array();
		$max_key_column = null;
		foreach ( (array)$data['settings']['columns'] as $o_key => $option ) {
			$max_key_column = max( array( $max_key_column, $o_key ) );
			$sda_items_columns[] = array(
				0 => array( $name_prefix . '[settings][columns][' . $o_key . ']', $option, __( 'Enter label', 'mc_form' ), 'fit' ),
			);
		}
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_rows"><?php _e( 'Rows', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_columns"><?php _e( 'Cols', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][multiline]', __( 'Multiline Values', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][multiline]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['multiline'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If turned on, then the user will be given textareas instead of text inputs across the row.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear inside the selected radio/checkbox.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_rows">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'List of Rows', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the Rows. These are basically the primary ratings.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items_rows, $sda_data_row, $max_key_row ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_columns">
			<table class="form-table">
				<tbody>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'List of Columns', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the Columns. These are basically the selection options.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_col_columns,
								'labels' => $labels,
							), $sda_items_columns, $sda_data_column, $max_key_column ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_gps( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
	?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the title. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][radius]', __( 'Accuracy Radius', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][radius]', $data['settings']['radius'], __( 'None', 'mc_form' ) ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the accuracy circle radius.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][zoom]', __( 'Map Zoom', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][zoom]', $data['settings']['zoom'], __( 'None', 'mc_form' ) ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the zoom in value for map.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][scrollwheel]', __( 'Make Scroll using Mouse Wheel', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][scrollwheel]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['scrollwheel'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then user will be able to zoom in or out using scroll wheel.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][manualcontrol]', __( 'Manual Control', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][manualcontrol]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['manualcontrol'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then user will be able to manually set address.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][lat_label]', __( 'Latitude Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][lat_label]', $data['settings']['lat_label'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown on an empty Latitude text.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][long_label]', __( 'Longitude Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][long_label]', $data['settings']['long_label'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown on an empty Longitude text.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][location_name_label]', __( 'Location Name Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][location_name_label]', $data['settings']['location_name_label'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown on an empty Location Name text. This field will be populated by google places API.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][update_label]', __( 'Update Button Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][update_label]', $data['settings']['update_label'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown on the manual update button.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][nolocation_label]', __( 'No Location Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][nolocation_label]', $data['settings']['nolocation_label'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown when no location is given.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>


	<?php
	$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_signature( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the title. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][color]', __( 'Pen Color', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->colorpicker( $name_prefix . '[settings][color]', $data['settings']['color'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Choose signature pen color. Default: <code>#212121</code>.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][reset]', __( 'Reset Button Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][reset]', $data['settings']['reset'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown when to the reset button.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][undo]', __( 'Undo Button Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][undo]', $data['settings']['undo'], __( 'Enter label', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the label that will shown when to the undo button.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_f_name( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_l_name( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_email( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_phone( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_p_name( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_p_email( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_p_phone( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_textinput( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_textarea( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php $this->_helper_build_prefil_text( $name_prefix, $data ); ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][readonly]', __( 'Readonly', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][readonly]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['readonly'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would not be editable by user. Make sure the validation matches, otherwise it might lead to error.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_guestblog( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear before the text. Select none to disable.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<td colspan="3"><p class="description"><?php _e( 'This element would simply act like a textinput supporting rich text editor if Guest Blogging is not enabled explicitly from the WP Core settings. If enabled, then an actual guest blog would be published respecting the settings.', 'mc_form' ); ?></p></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][title_label]', __( 'Article Title Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][title_label]', $data['settings']['title_label'], __( 'Write Here', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown to the article title textinput.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][editor_type]', __( 'Editor Type', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][editor_type]', array(
								'rich' => __( 'Rich Text Editor', 'mc_form' ),
								'html' => __( 'RAW HTML Editor', 'mc_form' ),
							), $data['settings']['editor_type'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Set the editor type you would like to use for the guest blogging. Rich text would render a light weight WYSIWYG editor, whereas HTML would provide a large textarea.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_password( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>

					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][confirm_duplicate]', __( 'Enter Password Twice', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][confirm_duplicate]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['confirm_duplicate'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn this feature on to make the user enter the password twice for validation.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hide_in_summary]', __( 'Do not reveal password', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hide_in_summary]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hide_in_summary'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn this feature on to never reveal password, neither in the form, nor in the summary table or email.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	public function build_p_radio( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_mcq_option_questions( $element, $key, $data, $element_structure, $name_prefix, false, false );
	}

	public function build_p_checkbox( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_mcq_option_questions( $element, $key, $data, $element_structure, $name_prefix, false, false );
	}

	public function build_p_select( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_mcq_option_questions( $element, $key, $data, $element_structure, $name_prefix, true, false );
	}

	public function build_s_checkbox( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_states"><?php _e( 'States', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear inside the selected radio/checkbox.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_states">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][checked]', __( 'Checked by Default', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][checked]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['checked'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn this feature on to make the checkbox checked by default.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
	}

	public function build_address( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$placeholders = array(
			'recipient' => __( 'Recipient', 'mc_form' ),
			'line_one' => __( 'Address line one', 'mc_form' ),
			'line_two' => __( 'Address line two', 'mc_form' ),
			'line_three' => __( 'Address line three', 'mc_form' ),
			'country' => __( 'Country', 'mc_form' ),
			'province' => __( 'Province', 'mc_form' ),
			'zip' => __( 'Postal Code', 'mc_form' ),
		);

		$country_list = MC_FORM_Form_Elements_Static::get_country_list();
		$country_list_items = array(
			0 => array(
				'value' => '',
				'label' => __( 'Disabled', 'mc_form' ),
			),
		);
		foreach ( $country_list as $ctkey => $ctval ) {
			$country_list_items[] = array(
				'value' => $ctkey,
				'label' => $ctval
			);
		}
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_items"><?php _e( 'Items', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_items">
			<table class="form-table">
				<tbody>
					<tr>
						<td colspan="2"><label for=""><?php _e( 'Placeholders and Fields', 'mc_form' ); ?></label></td>
						<td><?php $this->ui->help( __( 'mcForm supports several fields inside the address field. Each field should have a placeholder, if you leave the placeholder blank, then the field will not be shown.', 'mc_form' ) ); ?></td>
					</tr>
					<?php foreach ( $placeholders as $p_key => $ph ) : ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][' . $p_key . ']', $ph ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][' . $p_key . ']', $data['settings'][$p_key], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty. If left empty, then the field would not be shown.', 'mc_form' ) ); ?></td>
					</tr>
					<?php endforeach; ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][preset_country]', __( 'Preset Country', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][preset_country]', $country_list_items, $data['settings']['preset_country'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the preset country. If you do not want to show the country dropdown at all, then simply remove the placeholder of country field.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_keypad( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$types = array(
			array(
				'label' => 'Standard Qwerty Keyboard',
				'value' => 'qwerty',
			),
			array(
				'label' => 'International Qwerty Keyboard',
				'value' => 'qwerty',
			),
			array(
				'label' => 'Numerical Keyboard (ten-key)',
				'value' => 'num',
			),
			array(
				'label' => 'Alphabetical Keyboard',
				'value' => 'alpha',
			),
			array(
				'label' => 'Dvorak Simplified Keyboard',
				'value' => 'dvorak',
			),
		);
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][mask]', __( 'Mask Input', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][mask]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['mask'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn this feature on to take masked inputs (just like passwords).', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][multiline]', __( 'Accept Multiline', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][multiline]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['multiline'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn this feature on to take multiline inputs.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][type]', __( 'Keyboard Type', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][type]', $types, $data['settings']['type'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the keyboard type.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_datetime( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$types = array(
			array(
				'label' => __( 'Date Only', 'mc_form' ),
				'value' => 'date',
				'data' => array(
					'condid' => 'mc_form_form_builder_datetime_' . $key . '_date_wrap',
				),
			),
			array(
				'label' => __( 'Time Only', 'mc_form' ),
				'value' => 'time',
				'data' => array(
					'condid' => 'mc_form_form_builder_datetime_' . $key . '_time_wrap',
				),
			),
			array(
				'label' => __( 'Date & Time', 'mc_form' ),
				'value' => 'datetime',
				'data' => array(
					'condid' => 'mc_form_form_builder_datetime_' . $key . '_time_wrap,mc_form_form_builder_datetime_' . $key . '_date_wrap',
				),
			),
		);
		$date_formats = array(
			'yy-mm-dd' => date_i18n( 'Y-m-d', current_time( 'timestamp' ) ),
			'mm/dd/yy' => date_i18n( 'm/d/Y', current_time( 'timestamp' ) ),
			'dd.mm.yy' => date_i18n( 'd.m.Y', current_time( 'timestamp' ) ),
			'dd-mm-yy' => date_i18n( 'd-m-Y', current_time( 'timestamp' ) ),
		);
		$time_formats = array(
			'HH:mm:ss' => date_i18n( 'H:i:s', current_time( 'timestamp' ) ),
			'hh:mm:ss TT' => date_i18n( 'h:i:s A', current_time( 'timestamp' ) ),
		);
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][placeholder]', __( 'Placeholder Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][placeholder]', $data['settings']['placeholder'], __( 'Disabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Text that is shown by default when the field is empty.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hide_icon]', __( 'Hide Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hide_icon]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hide_icon'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enable this if you do not wish to show the icon beside the element.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_current]', __( 'Show Current Time', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_current]', __( 'Show', 'mc_form' ), __( 'Don\'t Show', 'mc_form' ), $data['settings']['show_current'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The current time will be calculated on the browser.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][type]', __( 'Picker Type', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][type]', $types, $data['settings']['type'], false, true ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the date and/or time picker type.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="mc_form_form_builder_datetime_<?php echo $key; ?>_date_wrap">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][date_format]', __( 'Picker Date Format', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][date_format]', $date_formats, $data['settings']['date_format'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the date and/or time picker date format. It will be translated automatically and will change the older date times if you happen to change the format in future.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="mc_form_form_builder_datetime_<?php echo $key; ?>_time_wrap">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][time_format]', __( 'Picker Time Format', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][time_format]', $time_formats, $data['settings']['time_format'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the date and/or time picker time format. It will be translated automatically and will change the older date times if you happen to change the format in future.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][year_range]', __( 'Default Year Range', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][year_range]', $data['settings']['year_range'], __( '50', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the default range that appears initially in the year dropdown of the calendar.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_p_sorting( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$this->build_user_sortable( $element, $key, $data, $element_structure, $name_prefix );
	}

	public function build_hidden( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		$types = array(
			0 => array(
				'value' => 'url',
				'label' => __( 'URL Parameter Based', 'mc_form' ),
			),
			1 => array(
				'value' => 'meta',
				'label' => __( 'User Meta Based', 'mc_form' ),
			),
			2 => array(
				'value' => 'logged_in',
				'label' => __( 'If logged in', 'mc_form' ),
			),
			3 => array(
				'value' => 'postmeta',
				'label' => __( 'Post Meta Based', 'mc_form' ),
			),
			4 => array(
				'value' => 'prefedined',
				'label' => __( 'Predefined (Static)', 'mc_form' ),
			),

		);
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][type]', __( 'Value Type', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][type]', $types, $data['settings']['type'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Set the type of value the hidden field will get. It can be based on URL parameter or user meta key. You can even make it constant by setting it to predefined and defining a default value. In case of <strong>If logged in</strong> the default value would be set if the user is logged in. Otherwise no value (effectively empty value) would be set. You can use this behavior to apply conditional logic on other elements too. For post meta based values, the post where this form is published through shortcode, would be considered. If you enter parameter like <code>10:key_value</code> then post meta <code>key_value</code> of post <code>10</code> would be considered, regardless of where the form is published.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][default]', __( 'Default Value', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][default]', $data['settings']['default'], __( 'None', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the default value of this element. This would be set if URL or meta parameter does not override. Empty value can also override the default value. But the value has to be set, i.e, either URL parameter or user metakey needs to be present.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][parameter]', __( 'Key Parameter', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][parameter]', $data['settings']['parameter'], __( 'Required', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the key parameter. In case of URL type value, <code>$_REQUEST[ $key ]</code> would be used. In case of User meta type value, the mentioned metakey would be used to retrieve the metavalue. It can not be empty or no value would be generated.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][admin_only]', __( 'Only Admin Can View', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][admin_only]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['admin_only'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then the recorded value would be visible by admins only.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
	}

	public function build_repeatable( $element, $key, $data, $element_structure, $name_prefix, $submission_data = null, $submission_structure = null, $context = null ) {
		// Element Type
		$element_types = array();
		$element_types[] = array(
			'value' => 'radio',
			'label' => __( 'Radio', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'checkbox',
			'label' => __( 'Checkbox', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'select',
			'label' => __( 'Dropdown', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'select_multiple',
			'label' => __( 'Multiple Dropdown', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'text',
			'label' => __( 'Text Input', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'password',
			'label' => __( 'Password', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'textarea',
			'label' => __( 'Textarea', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'phone',
			'label' => __( 'Phone Number', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'url',
			'label' => __( 'Anchor Links (URL)', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'email',
			'label' => __( 'Email Address', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'number',
			'label' => __( 'Only Numbers (Float or Integers)', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'integer',
			'label' => __( 'Only Integers', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'personName',
			'label' => __( 'Person\'s Name - eg, Mr. John Doe', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'date',
			'label' => __( 'Date Picker', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'datetime',
			'label' => __( 'DateTime Picker', 'mc_form' ),
		);
		$element_types[] = array(
			'value' => 'time',
			'label' => __( 'Time Picker', 'mc_form' ),
		);

		$column_sizes = array();
		$column_sizes[] = array(
			'value' => 'full',
			'label' => __( 'Full', 'mc_form' ),
		);
		$column_sizes[] = array(
			'value' => 'half',
			'label' => __( 'Half', 'mc_form' ),
		);
		$column_sizes[] = array(
			'value' => 'third',
			'label' => __( 'One Third', 'mc_form' ),
		);
		$column_sizes[] = array(
			'value' => 'two_third',
			'label' => __( 'Two Third', 'mc_form' ),
		);
		$column_sizes[] = array(
			'value' => 'forth',
			'label' => __( 'One Fourth', 'mc_form' ),
		);
		$column_sizes[] = array(
			'value' => 'three_forth',
			'label' => __( 'Three Fourth', 'mc_form' ),
		);

		// SDA Config
		$sda_columns = array(
			0 => array(
				'label' => __( 'Title', 'mc_form' ),
				'type' => 'text',
				'size' => '50'
			),
			1 => array(
				'label' => __( 'Type', 'mc_form' ),
				'type' => 'select',
				'size' => '20'
			),
			2 => array(
				'label' => __( 'Size', 'mc_form' ),
				'type' => 'select',
				'size' => '20'
			),
			3 => array(
				'label' => __( 'Req', 'mc_form' ),
				'type' => 'checkbox',
				'size' => '10',
			),
			4 => array(
				'label' => __( 'Options', 'mc_form' ),
				'type' => 'textarea',
				'size' => '50'
			),
			5 => array(
				'label' => __( 'Filters', 'mc_form' ),
				'type' => 'textarea',
				'size' => '40'
			),
			6 => array(
				'label' => __( 'Clear', 'mc_form' ),
				'type' => 'checkbox',
				'size' => '10',
			),
		);

		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Element', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data = array(
			0 => array( $name_prefix . '[settings][group][__SDAKEY__][title]', __( 'Title' ), __( 'Required', 'mc_form' ) ),
			1 => array( $name_prefix . '[settings][group][__SDAKEY__][type]', $element_types, 'choice', false, false, false, true, array( 'fit' ) ),
			2 => array( $name_prefix . '[settings][group][__SDAKEY__][column]', $column_sizes, 'half', false, false, false, true, array( 'fit' ) ),
			3 => array( $name_prefix . '[settings][group][__SDAKEY__][required]', array( 'value' => '1', 'label' => '' ), false ),
			4 => array( $name_prefix . '[settings][group][__SDAKEY__][options]', '', __( 'Choices/Placeholder', 'mc_form' ) ),
			5 => array( $name_prefix . '[settings][group][__SDAKEY__][attr]', '', __( 'Filters', 'mc_form' ) ),
			6 => array( $name_prefix . '[settings][group][__SDAKEY__][clear]', array( 'value' => '1', 'label' => '' ), false ),
		);

		$sda_items = array();
		$max_key = null;
		foreach ( $data['settings']['group'] as $o_key => $option ) {
			$max_key = max( array( $max_key, $o_key ) );
			$sda_items[] = array(
				0 => array( $name_prefix . '[settings][group][' . $o_key . '][title]', $option['title'], __( 'Required', 'mc_form' ) ),
				1 => array( $name_prefix . '[settings][group][' . $o_key . '][type]', $element_types, $option['type'], false, false, false, true, array( 'fit' ) ),
				2 => array( $name_prefix . '[settings][group][' . $o_key . '][column]', $column_sizes, $option['column'], false, false, false, true, array( 'fit' ) ),
				3 => array( $name_prefix . '[settings][group][' . $o_key . '][required]', array( 'value' => '1', 'label' => '' ), isset( $option['required'] ) ? true : false ),
				4 => array( $name_prefix . '[settings][group][' . $o_key . '][options]', $option['options'], __( 'Choices/Placeholder', 'mc_form' ) ),
				5 => array( $name_prefix . '[settings][group][' . $o_key . '][attr]', $option['attr'], __( 'Filters', 'mc_form' ) ),
				6 => array( $name_prefix . '[settings][group][' . $o_key . '][clear]', array( 'value' => '1', 'label' => '' ), isset( $option['clear'] ) ? true : false ),
			);
		}
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_options"><?php _e( 'Options', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the heading icon.', 'mc_form' ) ) ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][show_icons]', __( 'Icons on Elements', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][show_icons]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['show_icons'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then input type elements will have relevant icons beside them.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hide_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hide_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hide_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][button]', __( 'Button Text', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][button]', $data['settings']['button'], __( 'None', 'mc_form' ) ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the Text of the add button.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][sortable]', __( 'Sortable', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][sortable]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['sortable'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If user can sort the group of elements.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][deletable]', __( 'Deletable/Addable', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][deletable]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['deletable'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If user can delete the group of elements.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_options">
			<table class="form-table">
				<tbody>
					<tr>
						<td colspan="2">
							<?php $this->ui->generate_label( '', __( 'Item Group List', 'mc_form' ) ); ?>
						</td>
						<td>
							<?php $this->ui->help_head(); ?>
							<p><?php _e( 'Create the repeatable groups here.', 'mc_form' ); ?></p>
							<h3><?php _e( 'Element Type', 'mc_form' ); ?></h3>
							<p><?php _e( 'Select the type of the element you would like to show here.' ) ?></p>
							<h3><?php _e( 'Element Options', 'mc_form' ); ?></h3>
							<p><?php _e( 'For radio, checkbox and dropdowns, this would be used to populate options. You need to write one option per line. You can even have an empty placeholder option on the first line and assign numeric values. Please see the example below.', 'mc_form' ); ?></p>
<pre>Please select[empty]
Option 1[num=10]
Option 2[num=-10]</pre>
							<p><?php _e( 'For text type elements, this would act as the placeholder.', 'mc_form' ); ?></p>
							<h3><?php _e( 'Element Filters', 'mc_form' ); ?></h3>
							<p><?php _e( 'Custom validation attributes. There can be a total of 8 attributes.', 'mc_form' ); ?></p>
<pre>min="10" max="20" minSize="1" maxSize="4" minCheckbox="1" maxCheckbox="2" future="NOW" past="NOW"</pre>
							<ul class="ul-disc">
								<li><?php _e( 'min: Determines minimum numeric value. Works for numbers or integers.', 'mc_form' ); ?></li>
								<li><?php _e( 'max: Determines maximum numeric value. Works for numbers or integers.', 'mc_form' ); ?></li>
								<li><?php _e( 'minSize: Determines minimum length of value. Works for text inputs.', 'mc_form' ); ?></li>
								<li><?php _e( 'maxSize: Determines maximum length of value. Works for text inputs.', 'mc_form' ); ?></li>
								<li><?php _e( 'minCheckbox: Determines minimum checkbox items to be selected.', 'mc_form' ); ?></li>
								<li><?php _e( 'maxCheckbox: Determines maximum checkbox items to be selected.', 'mc_form' ); ?></li>
								<li><?php _e( 'futute: Determines what the date should be future of. Could be yy-mm-dd formatted date string or NOW for current date. Works only with datepicker.', 'mc_form' ); ?></li>
								<li><?php _e( 'past: Determines what the date should be past of. Could be yy-mm-dd formatted date string or NOW for current date. Works only with datepicker.', 'mc_form' ); ?></li>
							</ul>
							<h3><?php _e( 'Required', 'mc_form' ); ?></h3>
							<p><?php _e( 'Enable to make this element compulsory.', 'mc_form' ); ?></p>
							<?php $this->ui->help_tail(); ?>
						</td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items, $sda_data, $max_key ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][num]', __( 'Initial Number of Elements', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][num]', $data['settings']['num'], __( 'None', 'mc_form' ) ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the initial number of element groups that will be shown for empty form.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][min]', __( 'Minimum Number of Elements', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][min]', $data['settings']['min'], __( 'None', 'mc_form' ) ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the minimum number of element groups.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][max]', __( 'Maximum Number of Elements', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->spinner( $name_prefix . '[settings][max]', $data['settings']['max'], __( 'None', 'mc_form' ) ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the maximum number of element groups.', 'mc_form' ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
	}

	/*==========================================================================
	 * SOME INTERNAL FUNCTIONS
	 *========================================================================*/
	protected function build_col($name_prefix, $data) {
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
		?>
<div class="mc_uif_tabs">
	<ul>
		<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
		<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
	</ul>
	<div id="<?php echo $tab_names; ?>_elm">
		<table class="form-table">
			<tbody>
				<tr>
					<td colspan="3">
						<p class="description"><?php _e( 'Please expand the column by clicking the <span class="mc-icomoon-arrow-down"></span> Expand Icon and drop more elements inside.', 'mc_form' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
					</td>
					<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div id="<?php echo $tab_names; ?>_logic">
		<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
	</div>
</div>

		<?php
	}

	protected function build_user_sortable( $element, $key, $data, $element_structure, $name_prefix, $score = false ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Label', 'mc_form' ),
				'type' => 'text',
				'size' => '100'
			),
		);
		if ( $score ) {
			$sda_columns[0]['size'] = '70';
			$sda_columns[1] = array(
				'label' => __( 'Score', 'mc_form' ),
				'type' => 'spinner',
				'size' => '30',
			);
		}

		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Item', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__][label]', '', __( 'Option Label', 'mc_form' ), 'fit' ),
		);
		if ( $score ) {
			$sda_data[1] = array( $name_prefix . '[settings][options][__SDAKEY__][score]', '', __( 'Score (Optional)', 'mc_form' ), 'fit' );
		}

		$sda_items = array();
		$max_key = null;
		foreach ( $data['settings']['options'] as $o_key => $option ) {
			$max_key = max( array( $max_key, $o_key ) );
			$new_data = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . '][label]', $option['label'], __( 'Enter Option Label', 'mc_form' ), 'fit' ),
			);
			if ( $score ) {
				$new_data[1] = array( $name_prefix . '[settings][options][' . $o_key . '][score]', $option['score'], __( 'Score (Optional)', 'mc_form' ), 'fit' );
			}
			$sda_items[] = $new_data;
		}
		$types = array(
			array(
				'label' => 'Individual Positioning',
				'value' => 'individual',
			),
			array(
				'label' => 'Combined Positioning',
				'value' => 'combined',
			),
		);
		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_items"><?php _e( 'Items', 'mc_form' ); ?></a></li>
			<?php if ( $score ) : ?>
				<li><a href="#<?php echo $tab_names; ?>_score"><?php _e( 'Scoring', 'mc_form' ); ?></a></li>
			<?php endif; ?>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_items">
			<table class="form-table">
				<tbody>
					<tr>
						<td colspan="3">
							<p class="description">
								<?php if ( $score ) : ?>
									<?php _e( 'The correct sorting order is the order you give. The output will be randomized and the surveyee will need to put it into the correct order to get the maximum score.', 'mc_form' ); ?>
								<?php else : ?>
									<?php _e( 'The output of the sortable list will be the order you give. The surveyee can order the items the way he or she wishes.', 'mc_form' ); ?>
								<?php endif; ?>
							</p>
						</td>
					</tr>
					<?php if ( isset( $data['settings']['no_shuffle'] ) ) : ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][no_shuffle]', __( 'Shuffling', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][no_shuffle]', __( 'No shuffle', 'mc_form' ), __( 'Shuffle', 'mc_form' ), $data['settings']['no_shuffle'] ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'By default the output of the list will be shuffled. If you wish to prevent it, then customize the toggle button.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<?php endif; ?>
					<tr>
						<th colspan="2"><?php $this->ui->generate_label( '', __( 'Item List', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->help( __( 'Enter the options. ', 'mc_form' ) . ( $score ? __( 'You can also have score associated to the options. The value of the score should be numeric positive or negative number.', 'mc_form' ) : '' ) ); ?></td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items, $sda_data, $max_key ); ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<?php if ( $score ) : ?>
			<div id="<?php echo $tab_names; ?>_score">
				<table class="form-table">
					<tbody>
						<tr>
							<th><?php $this->ui->generate_label( $name_prefix . '[settings][base_score]', __( 'Base Score', 'mc_form' ) ); ?></th>
							<td>
								<?php $this->ui->spinner( $name_prefix . '[settings][base_score]', $data['settings']['base_score'], __( 'None', 'mc_form' ) ); ?>
							</td>
							<td>
								<?php $this->ui->help( __( 'Enter the base score for a perfect sort. Consult to the help of Score Calculation Type to get more information.', 'mc_form' ) ); ?>
							</td>
						</tr>
						<tr>
							<th><?php $this->ui->generate_label( $name_prefix . '[settings][score_type]', __( 'Score Calculation Type', 'mc_form' ) ); ?></th>
							<td>
								<?php $this->ui->select( $name_prefix . '[settings][score_type]', $types, $data['settings']['score_type'] ); ?>
							</td>
							<td>
								<?php $this->ui->help_head(); ?>
								<?php _e( 'First all the items will be scrambled randomly. Then the user will need to sort them in the provided order to get score. Scoring can be of two types.', 'mc_form' ); ?>
								<ul class="ul-disc">
									<li>
										<strong><?php _e( 'Individual Positioning:', 'mc_form' ) ?></strong> <?php _e( 'Individual scores will be added to all items positioned at the right place. If all are in right places, then the Base Score will also be added.', 'mc_form' ); ?>
									</li>
									<li>
										<strong><?php _e( 'Combined Positioning:', 'mc_form' ) ?></strong> <?php _e( 'If all are in right places, then the Base Score will be added. Otherwise no score will be given.', 'mc_form' ); ?>
									</li>
								</ul>
								<?php $this->ui->help_tail(); ?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>
		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	/**
	 *
	 *
	 * @param type    $element
	 * @param type    $key
	 * @param type    $data
	 * @param type    $element_structure
	 * @param type    $name_prefix
	 * @param type    $for_select
	 * @param type    $score
	 */
	protected function build_mcq_option_questions( $element, $key, $data, $element_structure, $name_prefix, $for_select = false, $score = true ) {
		$sda_columns = array(
			0 => array(
				'label' => __( 'Option', 'mc_form' ),
				'type' => 'text',
				'size' => '70',
			),
		);
		if ( $score ) {
			$sda_columns[0]['size'] = '55';
			$sda_columns[1] = array(
				'label' => __( 'Score', 'mc_form' ),
				'type' => 'spinner',
				'size' => '15',
			);
		}
		$sda_columns[] = array(
			'label' => __( 'Numeric', 'mc_form' ),
			'type' => 'spinner',
			'size' => '15',
		);
		$sda_columns[] = array(
			'label' => __( 'Default', 'mc_form' ),
			'type' => 'toggle',
			'size' => '15',
		);

		$labels = array(
			'confirm' => __( 'Confirm delete. This action can not be undone.', 'mc_form' ),
			'add' => __( 'Add New Option', 'mc_form' ),
			'del' => __( 'Click to delete', 'mc_form' ),
			'drag' => __( 'Drag this to rearrange', 'mc_form' ),
		);
		$sda_data = array(
			0 => array( $name_prefix . '[settings][options][__SDAKEY__][label]', '', __( 'Enter Option Label', 'mc_form' ), 'fit' ),
		);
		if ( $score ) {
			$sda_data[1] = array( $name_prefix . '[settings][options][__SDAKEY__][score]', '', __( 'Score (Optional)', 'mc_form' ), 'fit' );
		}
		$sda_data[] = array( $name_prefix . '[settings][options][__SDAKEY__][num]', '', __( 'Numeric Value', 'mc_form' ), 'fit' );
		$sda_data[] = array( $name_prefix . '[settings][options][__SDAKEY__][default]', '', '', false );

		$sda_items = array();
		$max_key = null;
		foreach ( $data['settings']['options'] as $o_key => $option ) {
			$max_key = max( array( $max_key, $o_key ) );
			$new_data = array(
				0 => array( $name_prefix . '[settings][options][' . $o_key . '][label]', $option['label'], __( 'Enter Option Label', 'mc_form' ), 'fit' ),
			);
			if ( $score ) {
				$new_data[1] = array( $name_prefix . '[settings][options][' . $o_key . '][score]', $option['score'], __( 'Score (Optional)', 'mc_form' ), 'fit' );
			}

			if ( ! isset( $option['num'] ) ) {
				$option['num'] = '';
			}
			$new_data[] = array( $name_prefix . '[settings][options][' . $o_key . '][num]', $option['num'], __( 'Numeric Value', 'mc_form' ), 'fit' );
			$new_data[] = array( $name_prefix . '[settings][options][' . $o_key . '][default]', '', '', ( isset( $option['default'] ) && true == $option['default'] ? true : false ) );

			$sda_items[] = $new_data;
		}

		$prefill_types = array(
			0 => array(
				'value' => 'none',
				'label' => __( 'None', 'mc_form' ),
			),
			1 => array(
				'value' => 'url',
				'label' => __( 'URL Parameter Based', 'mc_form' ),
			),
			2 => array(
				'value' => 'meta',
				'label' => __( 'User Meta Based', 'mc_form' ),
			),
		);

		$tab_names = $this->ui->generate_id_from_name( $name_prefix ) . '_settings_tab_';
?>
	<div class="mc_uif_tabs">
		<ul>
			<li><a href="#<?php echo $tab_names; ?>_elm"><?php _e( 'Appearance', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_ifs"><?php _e( 'Interface', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_options"><?php _e( 'Options', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_validation"><?php _e( 'Validation', 'mc_form' ); ?></a></li>
			<li><a href="#<?php echo $tab_names; ?>_logic"><?php _e( 'Logic', 'mc_form' ); ?></a></li>
		</ul>
		<div id="<?php echo $tab_names; ?>_elm">
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[title]', __( 'Title', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[title]', $data['title'], __( 'Enter Primary Label', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[subtitle]', __( 'Subtitle', 'mc_form' ) ); ?></th>
						<td><?php $this->ui->text( $name_prefix . '[subtitle]', $data['subtitle'], __( 'Description Text (Optional)', 'mc_form' ), 'large' ); ?></td>
						<td></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][vertical]', __( 'Label Alignment', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][vertical]', __( 'Vertical', 'mc_form' ), __( 'Horizontal', 'mc_form' ), $data['settings']['vertical'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'The alignment of the label(question) and options. Making Horizontal will show the label on left, whereas making vertical will show it on top.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][centered]', __( 'Center Content', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][centered]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['centered'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then labels and elements will be centered. This will force vertical the content.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][hidden_label]', __( 'Hide Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][hidden_label]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['hidden_label'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If enabled, then label along with subtitle and description would be hidden on the form. It would be visible only on the summary table and on emails. When using this, place a meaningful text in the placeholder.', 'mc_form' ) ); ?></td>
					</tr>
					<?php if ( isset( $data['settings']['icon'] ) ) : ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][icon]', __( 'Select Icon', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->icon_selector( $name_prefix . '[settings][icon]', $data['settings']['icon'], __( 'Do not use any icon', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the icon you want to appear inside the selected radio/checkbox.', 'mc_form' ) ) ?></td>
					</tr>
					<?php endif; ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[tooltip]', __( 'Tooltip', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( $name_prefix . '[tooltip]', $data['tooltip'], __( 'HTML Enabled', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'If you want to show tooltip, then please enter it here. You can write custom HTML too. Leave empty to disable.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_ifs">
			<table class="form-table">
				<tbody>
					<?php if ( $for_select ) : ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][e_label]', __( 'Placeholder Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][e_label]', $data['settings']['e_label'], __( 'Enter the label', 'mc_form' ), 'large' ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the label of the first option which will correspond to an empty answer. Leaving it blank will disable this feature.', 'mc_form' ) ); ?>
						</td>
					</tr>
					<?php endif; ?>
					<?php if ( isset( $data['settings']['multiple'] ) ) : ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][multiple]', __( 'Select Multiple', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][multiple]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['multiple'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Whether to allow user to select multiple options.', 'mc_form' ) ); ?></td>
					</tr>
					<?php endif; ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][type]', __( 'Prefill Type', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->select( $name_prefix . '[settings][type]', $prefill_types, $data['settings']['type'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Set the type of the prefill value the field will get. It can be based on URL parameter or user meta key. Leave to None if you do not wish to prefill the value.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][parameter]', __( 'Key Parameter', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][parameter]', $data['settings']['parameter'], __( 'Required', 'mc_form' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Enter the key parameter. In case of URL type value, <code>$_REQUEST[ $key ]</code> would be used. In case of User meta type value, the mentioned metakey would be used to retrieve the metavalue. It can not be empty or no value would be generated.', 'mc_form' ) ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_options">
			<table class="form-table">
				<tbody>
					<?php if ( !$for_select ) : ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][columns]', __( 'Options Columns', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->layout_select( $name_prefix . '[settings][columns]', $data['settings']['columns'] ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Select the number of columns in which you want the options to appear. Ideally it should be left to 2.', 'mc_form' ) ); ?></td>
					</tr>
					<?php endif; ?>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][shuffle]', __( 'Shuffle Options', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][shuffle]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['shuffle'], '1' ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Shuffle the options.', 'mc_form' ) ); ?></td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][others]', __( 'Show Others Option', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->toggle( $name_prefix . '[settings][others]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['others'], '1', false, true, array( 'condid' => $this->ui->generate_id_from_name( $name_prefix . '[settings][o_label]' )  . '_wrap' ) ); ?>
						</td>
						<td><?php $this->ui->help( __( 'Turn the feature on to show user enterable option.', 'mc_form' ) ); ?></td>
					</tr>
					<tr id="<?php echo $this->ui->generate_id_from_name( $name_prefix . '[settings][o_label]' )  . '_wrap'; ?>">
						<th><?php $this->ui->generate_label( $name_prefix . '[settings][o_label]', __( 'Others Label', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( $name_prefix . '[settings][o_label]', $data['settings']['o_label'], __( 'Enter the label', 'mc_form' ), 'large' ); ?>
						</td>
						<td>
							<?php $this->ui->help( __( 'Enter the label of the "Other" option.', 'mc_form' ) ); ?>
						</td>
					</tr>

					<tr>
						<th colspan="2"><?php _e( 'Option List', 'mc_form' ); ?></th>
						<td>
							<?php $this->ui->help( __( 'Enter the options. ', 'mc_form' ) . ( $score ? __( 'You can also have score associated to the options. The value of the score should be numeric positive or negative number.', 'mc_form' ) : '' ) ); ?>
						</td>
					</tr>
					<tr>
						<td colspan="3">
							<?php $this->ui->sda_list( array(
								'columns' => $sda_columns,
								'labels' => $labels,
							), $sda_items, $sda_data, $max_key ); ?>
							<div class="clear"></div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="<?php echo $tab_names; ?>_validation">
			<?php $this->build_validation( $name_prefix, $element_structure['validation'], $data['validation'] ); ?>
		</div>
		<div id="<?php echo $tab_names; ?>_logic">
			<?php $this->build_conditional( $name_prefix, $data['conditional'] ); ?>
		</div>
	</div>

		<?php
		$this->ui->textarea_linked_wp_editor( $name_prefix . '[description]', $data['description'], '' );
	}

	public function build_conditional_config( $name_prefix, $configs, $cond_suffix, $cond_id, $data, $outer_key = '__SDAKEY__' ) {
		$sda_outer = array();
		$sda_conditional = array();

		// Create the inner one with conditional logic
		$cond_name_prefix = $name_prefix . '[' . $outer_key . ']' . '[' . $cond_suffix . ']' . '[__CONDKEY__]';
		$sda_conditional['columns'] = array(
			0 => array(
				'label' => __( '(X)', 'mc_form' ),
				'size' => '16',
				'type' => 'select',
			),
			1 => array(
				'label' => __( '{KEY}', 'mc_form' ),
				'size' => '16',
				'type' => 'spinner',
			),
			2 => array(
				'label' => __( 'has', 'mc_form' ),
				'size' => '16',
				'type' => 'select',
			),
			3 => array(
				'label' => __( 'which', 'mc_form' ),
				'size' => '15',
				'type' => 'select',
			),
			4 => array(
				'label' => __( 'this value', 'mc_form' ),
				'size' => '24',
				'type' => 'text',
			),
			5 => array(
				'label' => __( 'rel', 'mc_form' ),
				'size' => '13',
				'type' => 'select',
			),
		);
		$sda_conditional['items'] = array();
		$m_type_select = array(
			0 => array(
				'value' => 'mcq',
				'label' => __( '(M) MCQ', 'mc_form' ),
			),
			1 => array(
				'value' => 'freetype',
				'label' => __( '(F) Text Input', 'mc_form' ),
			),
			2 => array(
				'value' => 'pinfo',
				'label' => __( '(O) Others', 'mc_form' ),
			),
		);
		$has_select = array( // check logic
			0 => array(
				'value' => 'val',
				'label' => __( 'value', 'mc_form' ),
			),
			1 => array(
				'value' => 'len',
				'label' => __( 'length', 'mc_form' ),
			),
		);
		$which_is_select = array( // operator logic
			0 => array(
				'value' => 'eq',
				'label' => __( 'equals to', 'mc_form' ),
			),
			1 => array(
				'value' => 'neq',
				'label' => __( 'not equals to', 'mc_form' ),
			),
			2 => array(
				'value' => 'gt',
				'label' => __( 'greater than', 'mc_form' ),
			),
			3 => array(
				'value' => 'lt',
				'label' => __( 'less than', 'mc_form' ),
			),
			4 => array(
				'value' => 'ct',
				'label' => __( 'contains', 'mc_form' ),
			),
			5 => array(
				'value' => 'dct',
				'label' => __( 'does not contain', 'mc_form' ),
			),
			6 => array(
				'value' => 'sw',
				'label' => __( 'starts with', 'mc_form' ),
			),
			7 => array(
				'value' => 'ew',
				'label' => __( 'ends with', 'mc_form' ),
			),
		);
		$rel_select = array(
			0 => array(
				'value' => 'and',
				'label' => __( 'AND', 'mc_form' ),
			),
			1 => array(
				'value' => 'or',
				'label' => __( 'OR', 'mc_form' ),
			),
		);
		$sda_conditional['data'] = array(
			0 => array( $cond_name_prefix . '[m_type]', $m_type_select, 'mcq', false, false, false, true, array( 'fit-text' ) ),
			1 => array( $cond_name_prefix . '[key]', '0', __( '{key}', 'mc_form' ), 0, 500 ),
			2 => array( $cond_name_prefix . '[check]', $has_select, 'val', false, false, false, true, array( 'fit-text' ) ),
			3 => array( $cond_name_prefix . '[operator]', $which_is_select, 'eq', false, false, false, true, array( 'fit-text' ) ),
			4 => array( $cond_name_prefix . '[value]', '', '' ),
			5 => array( $cond_name_prefix . '[rel]', $rel_select, 'and', false, false, false, true, array( 'fit-text' ) ),
		);
		$sda_conditional['max_key'] = 0;

		// Setup conditional SDA additional settings
		$sda_conditional['labels'] = array(
			'add' => __( 'Add New Logic', 'mc_form' ),
		);
		$sda_conditional['key'] = '__CONDKEY__';

		// Now complete the outer one
		$sda_outer['columns'] = array();
		$sda_outer['items'] = array();
		$sda_outer['data'] = array();
		$sda_outer['max_key'] = 0;
		// Loop through and create the column and data
		foreach ( $configs as $config_key => $config ) {
			$sda_outer['columns'][] = array(
				'label' => $config['label'],
				'size' => $config['size'],
				'type' => $config['type']
			);
			$sda_outer['data'][] = $config['data'];
		}

		// Loop through data and create items
		foreach ( $data as $item_key => $item ) {
			$new_sda_outer_item = array();
			foreach ( $item as $data_key => $values ) {
				// If for the logics
				if ( $cond_suffix == $data_key ) {
					// Create the basic items config
					$sda_cond_item_data = $sda_conditional['data'];
					foreach ( $sda_cond_item_data as $scidkey => $scidval ) {
						$scidval[0] = str_replace( $outer_key, $item_key, $scidval[0] );
						$sda_cond_item_data[ $scidkey ] = $scidval;
					}
					$sda_conditional_items = array(
						'settings' => array(
							'key' => $sda_conditional['key'],
							'columns' => $sda_conditional['columns'],
							'labels' => $sda_conditional['labels'],
						),
						'items' => array(),
						'data' => $sda_cond_item_data,
						'max_key' => 0,
						'id' => $cond_id . $data_key . '_logics',
					);
					// Now loop through and add data to the conditional
					$cond_items_name_prefix = $name_prefix . '[' . $item_key . ']' . '[' . $cond_suffix . ']' . '[%d]';
					foreach ( $values as $cond_key => $logic ) {
						$sda_conditional_items['max_key'] = max( $sda_conditional_items['max_key'], $cond_key );
						$sda_conditional_items['items'][ $cond_key ] = array(
							0 => array( sprintf( $cond_items_name_prefix . '[m_type]', $cond_key ), $m_type_select, $logic['m_type'], false, false, false, true, array( 'fit-text' ) ),
							1 => array( sprintf( $cond_items_name_prefix . '[key]', $cond_key ), $logic['key'], __( '{key}', 'mc_form' ), 0, 500 ),
							2 => array( sprintf( $cond_items_name_prefix . '[check]', $cond_key ), $has_select, $logic['check'], false, false, false, true, array( 'fit-text' ) ),
							3 => array( sprintf( $cond_items_name_prefix . '[operator]', $cond_key ), $which_is_select, $logic['operator'], false, false, false, true, array( 'fit-text' ) ),
							4 => array( sprintf( $cond_items_name_prefix . '[value]', $cond_key ), $logic['value'], '' ),
							5 => array( sprintf( $cond_items_name_prefix . '[rel]', $cond_key ), $rel_select, $logic['rel'], false, false, false, true, array( 'fit-text' ) ),
						);
					}
					$new_sda_outer_item[] = array_values( $sda_conditional_items );
				// For other config items
				} else {
					$new_sda_outer_item[] = $values;
				}
				$sda_outer['items'][ $item_key ] = $new_sda_outer_item;
			}
		}

		// Calculate max keys
		if ( count( $sda_outer['items'] ) ) {
			$sda_outer['max_key'] = max( array_keys( $sda_outer['items'] ) );
		}

		// Add the conditional SDA inside outer SDA
		$sda_outer['columns'][] = array(
			'label' => __( 'Conditional Logic', 'mc_form' ),
			'size' => '100',
			'type' => 'sda_list',
		);
		$sda_outer['data'][] = array_values( array(
			'settings' => array(
				'key' => $sda_conditional['key'],
				'columns' => $sda_conditional['columns'],
				'labels' => $sda_conditional['labels'],
			),
			'items' => array(),
			'data' => $sda_conditional['data'],
			'max_key' => $sda_conditional['max_key'],
			'id' => $cond_id . $sda_conditional['key'] . '_logics',
		) );

		// Done, now print
		echo '<div class="mcform-conditional-config">';
		$this->ui->sda_list( array(
			'key' => $outer_key,
			'columns' =>  $sda_outer['columns'],
			'labels' => array(
				'add' => __( 'Add New Config', 'mc_form' ),
			),
		), $sda_outer['items'], $sda_outer['data'], $sda_outer['max_key'], $cond_id );
		echo '</div>';
	}

	public function build_conditional( $name_prefix, $data, $header_title = '', $show_status = true, $name_suffix = '[conditional]', $toggle_title = '' ) {
		$name_prefix = $name_prefix . $name_suffix;
		$cond_id = $this->generate_id_from_name( $name_prefix ) . '_conditional_type_wrap';

		$sda_columns = array(
			0 => array(
				'label' => __( '(X)', 'mc_form' ),
				'size' => '16',
				'type' => 'select',
			),
			1 => array(
				'label' => __( '{KEY}', 'mc_form' ),
				'size' => '16',
				'type' => 'spinner',
			),
			2 => array(
				'label' => __( 'has', 'mc_form' ),
				'size' => '16',
				'type' => 'select',
			),
			3 => array(
				'label' => __( 'which', 'mc_form' ),
				'size' => '15',
				'type' => 'select',
			),
			4 => array(
				'label' => __( 'this value', 'mc_form' ),
				'size' => '24',
				'type' => 'text',
			),
			5 => array(
				'label' => __( 'rel', 'mc_form' ),
				'size' => '13',
				'type' => 'select',
			),
		);
		$sda_labels = array(
			'add' => __( 'Add New Logic', 'mc_form' ),
		);
		$m_type_select = array(
			0 => array(
				'value' => 'mcq',
				'label' => __( '(M) MCQ', 'mc_form' ),
			),
			1 => array(
				'value' => 'freetype',
				'label' => __( '(F) Text Input', 'mc_form' ),
			),
			2 => array(
				'value' => 'pinfo',
				'label' => __( '(O) Others', 'mc_form' ),
			),
		);
		$has_select = array( // check logic
			0 => array(
				'value' => 'val',
				'label' => __( 'value', 'mc_form' ),
			),
			1 => array(
				'value' => 'len',
				'label' => __( 'length', 'mc_form' ),
			),
		);
		$which_is_select = array( // operator logic
			0 => array(
				'value' => 'eq',
				'label' => __( 'equals to', 'mc_form' ),
			),
			1 => array(
				'value' => 'neq',
				'label' => __( 'not equals to', 'mc_form' ),
			),
			2 => array(
				'value' => 'gt',
				'label' => __( 'greater than', 'mc_form' ),
			),
			3 => array(
				'value' => 'lt',
				'label' => __( 'less than', 'mc_form' ),
			),
			4 => array(
				'value' => 'ct',
				'label' => __( 'contains', 'mc_form' ),
			),
			5 => array(
				'value' => 'dct',
				'label' => __( 'does not contain', 'mc_form' ),
			),
			6 => array(
				'value' => 'sw',
				'label' => __( 'starts with', 'mc_form' ),
			),
			7 => array(
				'value' => 'ew',
				'label' => __( 'ends with', 'mc_form' ),
			),
		);
		$rel_select = array(
			0 => array(
				'value' => 'and',
				'label' => __( 'AND', 'mc_form' ),
			),
			1 => array(
				'value' => 'or',
				'label' => __( 'OR', 'mc_form' ),
			),
		);
		$sda_data_name_prefix = $name_prefix . '[logic][__SDAKEY__]';
		$sda_data = array(
			0 => array( $sda_data_name_prefix . '[m_type]', $m_type_select, 'mcq', false, false, false, true, array( 'fit-text' ) ),
			1 => array( $sda_data_name_prefix . '[key]', '0', __( '{key}', 'mc_form' ), 0, 500 ),
			2 => array( $sda_data_name_prefix . '[check]', $has_select, 'val', false, false, false, true, array( 'fit-text' ) ),
			3 => array( $sda_data_name_prefix . '[operator]', $which_is_select, 'eq', false, false, false, true, array( 'fit-text' ) ),
			4 => array( $sda_data_name_prefix . '[value]', '', '' ),
			5 => array( $sda_data_name_prefix . '[rel]', $rel_select, 'and', false, false, false, true, array( 'fit-text' ) ),
		);

		$sda_items = array();
		$sda_max_key = null;
		$sda_items_name_prefix = $name_prefix . '[logic][%d]';
		foreach ( (array) $data['logic'] as $s_key => $logic ) {
			$sda_max_key = max( array( $sda_max_key, $s_key ) );
			$sda_items[] = array(
				0 => array( sprintf( $sda_items_name_prefix . '[m_type]', $s_key ), $m_type_select, $logic['m_type'], false, false, false, true, array( 'fit-text' ) ),
				1 => array( sprintf( $sda_items_name_prefix . '[key]', $s_key ), $logic['key'], __( '{key}', 'mc_form' ), 0, 500 ),
				2 => array( sprintf( $sda_items_name_prefix . '[check]', $s_key ), $has_select, $logic['check'], false, false, false, true, array( 'fit-text' ) ),
				3 => array( sprintf( $sda_items_name_prefix . '[operator]', $s_key ), $which_is_select, $logic['operator'], false, false, false, true, array( 'fit-text' ) ),
				4 => array( sprintf( $sda_items_name_prefix . '[value]', $s_key ), $logic['value'], '' ),
				5 => array( sprintf( $sda_items_name_prefix . '[rel]', $s_key ), $rel_select, $logic['rel'], false, false, false, true, array( 'fit-text' ) ),
			);
		}
		if ( $toggle_title == '' ) {
			$toggle_title = __( 'Use conditional logic on this element', 'mc_form' );
		}
		?>
<?php if ( '' != $header_title ) : ?>
	<h3><?php echo $header_title; ?></h3>
<?php endif; ?>
<table class="form-table">
	<thead>
		<tr>
			<th>
				<?php $this->ui->generate_label( $name_prefix . '[active]', $toggle_title ); ?>
			</th>
			<td>
				<?php $this->ui->toggle( $name_prefix . '[active]', __( 'YES', 'mc_form' ), __( 'NO', 'mc_form' ), $data['active'], '1', false, true, array(
					'condid' => $cond_id,
				) ); ?>
			</td>
			<td>
				<?php $this->ui->help( sprintf( __( 'Enable or disable conditional logic for this element. More information can be found <a href="%1$s" target="_blank">at this link</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/conditional-logic/' ) ); ?>
			</td>
		</tr>
	</thead>
	<tbody id="<?php echo $cond_id ?>">
		<?php if ( $show_status == true ) : ?>
		<tr>
			<th>
				<?php $this->ui->generate_label( $name_prefix . '[status]', __( 'Initial Status', 'mc_form' ) ); ?>
			</th>
			<td>
				<?php $this->ui->toggle( $name_prefix . '[status]', __( 'Shown', 'mc_form' ), __( 'Hidden', 'mc_form' ), $data['status'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Initial visual status of this element. You can hide it initially and conditionally show it.', 'mc_form' ) ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( $name_prefix . '[change]', __( 'Change status to', 'mc_form' ) ); ?>
			</th>
			<td>
				<?php $this->ui->toggle( $name_prefix . '[change]', __( 'Show', 'mc_form' ), __( 'Hide', 'mc_form' ), $data['change'] ); ?>
			</td>
			<td>
				<?php $this->ui->help_head( __( 'Conditional Logic', 'mc_form' ) ); ?>
				<p>
					<?php printf( __( 'Here you can build the conditional logic based on existing elements and comparing their value and/or length. When conditional logic is active, the validation logic will have implicit effect, i.e, the validation logic will only be considered, when according to the conditional logic the field is shown. So, you can make an element required, but hidden at first which would only be shown for certain cases. When the case criteria is matched, it would become mandatory for the users to fill this element. More information can be found <a href="%1$s" target="_blank">at this link</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/conditional-logic/' ); ?>
				</p>
				<p>
					<?php _e( 'Conditional logics are also grouped automatically against the OR operator.', 'mc_form' ); ?>
				</p>
				<p>
					<?php _e( 'So for instance if you have a logic defined as:<code>C1 AND C2 OR C2 AND C3 AND C4 OR C5 AND C6</code> it will be interpreted as <code>(C1 AND C2) OR (C2 AND C3 AND C4) OR (C5 AND C6)</code>.', 'mc_form' ); ?>
				</p>
				<p>
					<?php _e( 'If any of the conditions separated by OR is true, the logic is regared as true.', 'mc_form' ); ?>
				</p>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<tr>
			<td colspan="3"><p class="description"><?php _e( 'If the following conditions are met.', 'mc_form' ); ?></p></td>
		</tr>
		<?php else : ?>
		<tr>
			<td colspan="3">
				<?php $this->ui->help_head( __( 'Conditional Logic', 'mc_form' ) ); ?>
				<p>
					<?php printf( __( 'Here you can build the conditional logic based on existing elements and comparing their value and/or length. When conditional logic is active, the validation logic will have implicit effect, i.e, the validation logic will only be considered, when according to the conditional logic the field is shown. So, you can make an element required, but hidden at first which would only be shown for certain cases. When the case criteria is matched, it would become mandatory for the users to fill this element. More information can be found <a href="%1$s" target="_blank">at this link</a>.', 'mc_form' ), 'https://www.binarypoets.net/kb/form/conditional-logic/' ); ?>
				</p>
				<p>
					<?php _e( 'Conditional logics are also grouped automatically against the OR operator.', 'mc_form' ); ?>
				</p>
				<p>
					<?php _e( 'So for instance if you have a logic defined as:<code>C1 AND C2 OR C2 AND C3 AND C4 OR C5 AND C6</code> it will be interpreted as <code>(C1 AND C2) OR (C2 AND C3 AND C4) OR (C5 AND C6)</code>.', 'mc_form' ); ?>
				</p>
				<p>
					<?php _e( 'If any of the conditions separated by OR is true, the logic is regared as true.', 'mc_form' ); ?>
				</p>
				<?php $this->ui->help_tail(); ?>
			</td>
		</tr>
		<?php endif; ?>
		<tr>
			<td colspan="3">
				<?php $this->ui->sda_list( array(
					'columns' => $sda_columns,
					'labels' => $sda_labels,
				), $sda_items, $sda_data, $sda_max_key ); ?>
			</td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function build_validation( $name_prefix, $validation, $data, $close_table = true ) {
		$name_prefix = $name_prefix . '[validation]';
		$cond_id = $this->generate_id_from_name( $name_prefix ) . '_validation_type_wrap_';
		$valid_types = array( //phone, url, email, date, number, integer, ipv4, onlyNumberSp, onlyLetterSp, onlyLetterNumber
			array(
				'value' => 'all',
				'label' => __( 'Everything', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'minsize,' . $cond_id . 'maxsize' ),
			),
			array(
				'value' => 'phone',
				'label' => __( 'Phone Number', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'minsize,' . $cond_id . 'maxsize' ),
			),
			array(
				'value' => 'url',
				'label' => __( 'Anchor Links (URL)', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'none' ),
			),
			array(
				'value' => 'email',
				'label' => __( 'Email Address', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'none' ),
			),
			array(
				'value' => 'ipv4',
				'label' => __( 'IP V4 Address Format', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'none' ),
			),
			array(
				'value' => 'number',
				'label' => __( 'Only Numbers (Float or Integers)', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'min,' . $cond_id . 'max' ),
			),
			array(
				'value' => 'integer',
				'label' => __( 'Only Integers', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'min,' . $cond_id . 'max' ),
			),
			array(
				'value' => 'onlyNumberSp',
				'label' => __( 'Only Numbers and Spaces', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'minsize,' . $cond_id . 'maxsize' ),
			),
			array(
				'value' => 'onlyLetterSp',
				'label' => __( 'Only Letters and Spaces', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'minsize,' . $cond_id . 'maxsize' ),
			),
			array(
				'value' => 'onlyLetterNumber',
				'label' => __( 'Only Letters and Numbers', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'minsize,' . $cond_id . 'maxsize' ),
			),
			array(
				'value' => 'onlyLetterNumberSp',
				'label' => __( 'Only Letters, Numbers and Spaces', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'minsize,' . $cond_id . 'maxsize' ),
			),
			array(
				'value' => 'noSpecialCharacter',
				'label' => __( 'No Special Characters', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'minsize,' . $cond_id . 'maxsize' ),
			),
			array(
				'value' => 'personName',
				'label' => __( 'Person\'s Name - eg, Mr. John Doe', 'mc_form' ),
				'data' => array( 'condid' => $cond_id . 'none' ),
			),
		);

		// Input masking
		$masking_items = [];
		if ( isset( $validation['mask'] ) ) {
			// Enabled
			$masking_items[] = [
				'name' => $name_prefix . '[mask][enabled]',
				'label' => __( 'Mask Input', 'mc_form' ),
				'ui' => 'toggle',
				'param' => [ $name_prefix . '[mask][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['mask']['enabled'], '1', false, true, [
					'condid' => $cond_id . '_mask_type,' . $cond_id . '_mask_mask,' . $cond_id . '_mask_placeholder,' . $cond_id . '_mask_greedy',
				] ],
				'help' => __( 'Enable Input masking for this freetype element. Please follow the <a rel="noopener" target="_blank" href="https://github.com/RobinHerbots/Inputmask#static-masks">official guide</a> for setting up proper masking values.', 'mc_form' ),
			];
			// Type
			$mask_types = [
				'mask' => __( 'Static Mask', 'mc_form' ),
				'regex' => __( 'Regex Based Mask', 'mc_form' ),
			];
			$masking_items[] = [
				'name' => $name_prefix . '[mask][type]',
				'label' => __( 'Masking Definition Type', 'mc_form' ),
				'ui' => 'select',
				'param' => [ $name_prefix . '[mask][type]', $mask_types, $data['mask']['type'] ],
				'help' => __( 'Set the masking type. Static Masks are easy to implement, but you can have regex based masks too.', 'mc_form' ),
				'id' => $cond_id . '_mask_type',
			];
			// Mask
			$masking_items[] = [
				'name' => $name_prefix . '[mask][mask]',
				'label' => __( 'Static Mask or Regex', 'mc_form' ),
				'ui' => 'textarea',
				'param' => [ $name_prefix . '[mask][mask]', $data['mask']['mask'], __( 'Required', 'mc_form' ) ],
				'help' => __( 'Enter static or regex definition here.', 'mc_form' ),
				'id' => $cond_id . '_mask_mask',
			];
			// Placeholder
			$masking_items[] = [
				'name' => $name_prefix . '[mask][placeholder]',
				'label' => __( 'Mask Placeholder', 'mc_form' ),
				'ui' => 'text',
				'param' => [ $name_prefix . '[mask][placeholder]', $data['mask']['placeholder'], __( 'Required', 'mc_form' ) ],
				'help' => __( 'Enter placeholder. Multi character also supported.', 'mc_form' ),
				'id' => $cond_id . '_mask_placeholder',
			];
			// Greedy
			$masking_items[] = [
				'name' => $name_prefix . '[mask][greedy]',
				'label' => __( 'Greedy Comparison', 'mc_form' ),
				'ui' => 'toggle',
				'param' => [ $name_prefix . '[mask][greedy]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['mask']['greedy'] ],
				'help' => __( 'EToggle to allocate as much possible or the opposite. Non-greedy repeat function. With the non-greedy option set to false, you can specify * as repeat. This makes an endless repeat.', 'mc_form' ),
				'id' => $cond_id . '_mask_greedy',
			];
		}
		?>
	<?php if ( $close_table ) : ?>
	<table class="form-table">
		<tbody>
	<?php endif; ?>
			<?php if ( isset( $validation['required'] ) ) : ?>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[required]', __( 'Compulsory', 'mc_form' ) ); ?></th>
				<td colspan="2">
					<?php $this->ui->toggle( $name_prefix . '[required]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['required'] ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['equals'] ) ) : ?>
				<tr>
					<th><?php $this->ui->generate_label( $name_prefix . '[equals]', __( 'Equals to', 'mc_form' ) ); ?></th>
					<td>
						<?php $this->ui->text( $name_prefix . '[equals]', $data['equals'], __( 'Disabled', 'mc_form' ) ); ?>
					</td>
					<td>
						<?php $this->ui->help( sprintf( __( 'Set the field ID of the element with which this must be equal to. Works only for freetype elements. Mention the full id of the element like this <code>F10</code> or <code>O11</code>.', 'mc_form' ), date( 'Y-m-d' ) ) ); ?>
					</td>
				</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters'] ) ) : ?>

			<?php if ( isset( $validation['filters']['type'] ) ) : ?>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][type]', __( 'Input Filter', 'mc_form' ) ); ?></th>
				<td colspan="2">
					<?php $this->ui->select( $name_prefix . '[filters][type]', $valid_types, $data['filters']['type'], false, true ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters']['min'] ) ) : ?>
			<tr id="<?php echo $cond_id . 'min'; ?>">
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][min]', __( 'Minimum Value', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->spinner( $name_prefix . '[filters][min]', $data['filters']['min'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Validates when the field\'s value is less than, or equal to, the given parameter. Can contain floating number.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters']['max'] ) ) : ?>
			<tr id="<?php echo $cond_id . 'max'; ?>">
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][max]', __( 'Maximum Value', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->spinner( $name_prefix . '[filters][max]', $data['filters']['max'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Validates when the field\'s value is more than, or equal to, the given parameter. Can contain floating number.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters']['minSize'] ) ) : ?>
			<tr id="<?php echo $cond_id . 'minsize'; ?>">
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][minSize]', __( 'Minumum Size', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->spinner( $name_prefix . '[filters][minSize]', $data['filters']['minSize'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Validates if the element content size (in characters) is more than, or equal to, the given integer.<br /><code>integer <= input.value.length</code>', 'mc_form' ) ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters']['maxSize'] ) ) : ?>
			<tr id="<?php echo $cond_id . 'maxsize'; ?>">
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][maxSize]', __( 'Maximum Size', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->spinner( $name_prefix . '[filters][maxSize]', $data['filters']['maxSize'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Validates if the element content size (in characters) is less than, or equal to, the given integer.<br /><code>input.value.length <= integer</code>', 'mc_form' ) ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters']['past'] ) ) : ?>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][past]', __( 'Before', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->text( $name_prefix . '[filters][past]', $data['filters']['past'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( sprintf( __( 'Checks if the element\'s value (which is implicitly a date) is less than the given date. When <code>NOW</code> is used as a parameter, the date will be calculate in the server only, in accordance with the timezone you have set for your website. You can also use arithmetic like <code>NOW+5</code> or <code>NOW-10</code> to add or subtract <strong>days</strong> from current date. You have to enter date in <code>YYYY-MM-DD</code> (Strict ISO Standard) format, for example %1$s. Also you can refer to other datepicker element, by entering their ID, like <code>O12</code> where the element is represented by <code>(O){12}</code>. This can be used for creating date ranges. This works for date pickers only, not for datetime or time pickers.', 'mc_form' ), date( 'Y-m-d' ) ) ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters']['future'] ) ) : ?>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][future]', __( 'After', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->text( $name_prefix . '[filters][future]', $data['filters']['future'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( sprintf( __( 'Checks if the element\'s value (which is implicitly a date) is greater than the given date. When <code>NOW</code> is used as a parameter, the date will be calculate in the server only, in accordance with the timezone you have set for your website. You can also use arithmetic like <code>NOW+5</code> or <code>NOW-10</code> to add or subtract <strong>days</strong> from current date. You have to enter date in <code>YYYY-MM-DD</code> (Strict ISO Standard) format, for example %1$s. Also you can refer to other datepicker element, by entering their ID, like <code>O12</code> where the element is represented by <code>(O){12}</code>. This can be used for creating date ranges. This works for date pickers only, not for datetime or time pickers.', 'mc_form' ), date( 'Y-m-d' ) ) ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters']['minCheckbox'] ) ) : ?>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][minCheckbox]', __( 'Minimum Selected Checkboxes', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->spinner( $name_prefix . '[filters][minCheckbox]', $data['filters']['minCheckbox'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Validates when a minimum of integer checkboxes are selected.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<?php endif; ?>
			<?php if ( isset( $validation['filters']['maxCheckbox'] ) ) : ?>
			<tr>
				<th><?php $this->ui->generate_label( $name_prefix . '[filters][maxCheckbox]', __( 'Maximum Selected Checkboxes', 'mc_form' ) ); ?></th>
				<td>
					<?php $this->ui->spinner( $name_prefix . '[filters][maxCheckbox]', $data['filters']['maxCheckbox'], __( 'Disabled', 'mc_form' ) ); ?>
				</td>
				<td>
					<?php $this->ui->help( __( 'Limits the maximum number of selected check boxes.', 'mc_form' ) ); ?>
				</td>
			</tr>
			<?php endif; ?>

			<?php endif; ?>

			<?php if ( isset( $validation['mask'] ) ) : ?>
				<?php $this->ui->form_table( $masking_items, false ); ?>
			<?php endif; ?>
		<?php if ( $close_table ) : ?>
		</tbody>
	</table>
		<?php endif; ?>
		<?php
	}

	public function material_options( $form ) {
		$skins = array(
			0 => array(
				'label' => __( 'Light Background', 'mc_form' ),
				'value' => 'light',
			),
			1 => array(
				'label' => __( 'Dark Background', 'mc_form' ),
				'value' => 'dark',
			),
		);

		$bg_repeat = array(
			'repeat' => __( 'Repeat both', 'mc_form' ),
			'repeat-x' => __( 'Repeat in x axis', 'mc_form' ),
			'repeat-y' => __( 'Repeat in y axis', 'mc_form' ),
			'no-repeat' => __( 'No repeat', 'mc_form' ),
		);
		$bg_origin = array(
			'padding-box' => __( 'Padding Box (Upper Left)', 'mc_form' ),
			'border-box' => __( 'Border Box (Upper Left of Border)', 'mc_form' ),
			'content-box' => __( 'Content Box (Upper Left of Content)', 'mc_form' ),
		);
		$bg_clip = array(
			'padding-box' => __( 'Padding Box (Upper Left)', 'mc_form' ),
			'border-box' => __( 'Border Box (Upper Left of Border)', 'mc_form' ),
			'content-box' => __( 'Content Box (Upper Left of Content)', 'mc_form' ),
		);
		$bg_attachment = array(
			'scroll' => __( 'Scroll with element', 'mc_form' ),
			'fixed' => __( 'Fixed in viewport', 'mc_form' ),
			'local' => __( 'Scroll with element content', 'mc_form' ),
		);

		$colors = array(
			'primary-color-dark' => __( 'Dark Primary Color', 'mc_form' ),
			'primary-color' => __( 'Primary Color', 'mc_form' ),
			'primary-color-light' => __( 'Light Primary Color', 'mc_form' ),
			'primary-color-text' => __( 'Text Color on Primary BG', 'mc_form' ),
			'accent-color' => __( 'Accent Color', 'mc_form' ),
			'background-color' => __( 'Background Color', 'mc_form' ),
			'primary-text-color' => __( 'Primary Text Color', 'mc_form' ),
			'secondary-text-color' => __( 'Secondary Text Color', 'mc_form' ),
			'border-color' => __( 'Border Color', 'mc_form' ),
			'divider-color' => __( 'Divider Color', 'mc_form' ),
			'disabled-color' => __( 'Disabled Background Color', 'mc_form' ),
			'disabled-color-text' => __( 'Disabled Text Color', 'mc_form' ),
			'ui-bg-color' => __( 'Small UI BG Color', 'mc_form' ),
			'widget-bg-color' => __( 'Large Widget BG Color', 'mc_form' ),
		);

		$button_variants = [];
		$button_variants[] = [
			'value' => 'classic',
			'label' =>  __( 'Classic Full Width', 'mc_form' ),
		];
		$button_variants[] = [
			'value' => 'flat',
			'label' =>  __( 'Flat', 'mc_form' ),
			'data' => [
				'condid' => 'mc-mcform-builder-config-style-material-br-wrap',
			],
		];
		$button_variants[] = [
			'value' => 'border',
			'label' =>  __( '3d Bordered', 'mc_form' ),
			'data' => [
				'condid' => 'mc-mcform-builder-config-style-material-br-wrap',
			],
		];
		$button_variants[] = [
			'value' => 'gradient',
			'label' =>  __( 'Gradient', 'mc_form' ),
			'data' => [
				'condid' => 'mc-mcform-builder-config-style-material-br-wrap',
			],
		];
		$button_variants[] = [
			'value' => 'outline',
			'label' =>  __( 'Outline', 'mc_form' ),
			'data' => [
				'condid' => 'mc-mcform-builder-config-style-material-br-wrap',
			],
		];

		$op = $this->settings['theme']['material'];
		$defaults = $this->get_default_settings()['theme']['material'];
		?>
<script type="text/javascript">
	jQuery( document ).ready( function( $ ) {
		var checkMaterialColor = function() {
			var theme = $( '#settings_theme_template' ).val(),
			elm = $( '#mcform-material-custom-skin, #mcform-material-custom-color' );
			if ( 'material-custom' == theme ) {
				elm.fadeIn( 'fast' );
			} else {
				elm.fadeOut( 'fast' );
			}
		};
		checkMaterialColor();
		$( '#settings_theme_template' ).on( 'change', checkMaterialColor );
	} );
</script>
<table class="form-table">
	<tbody>
		<tr id="mcform-material-custom-skin" style="display: none;">
			<th><?php $this->ui->generate_label( 'settings[theme][material][skin]', __( 'Skin' ) ); ?></th>
			<td>
				<?php $this->ui->select( 'settings[theme][material][skin]', $skins, $op['skin'], false, true ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Select the skin for the material theme. You can choose one of the presets or create your own.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mcform-material-custom-color" style="display: none;">
			<td colspan="3">
				<table class="form-table">
					<tbody>
						<?php $c_i = 1; ?>
						<tr>
						<?php foreach ( $colors as $color_key => $color_label ) : ?>
							<th><?php $this->ui->generate_label( 'settings[theme][material][colors][' . $color_key . ']', $color_label ); ?></th>
							<td><?php $this->ui->colorpicker( 'settings[theme][material][colors][' . $color_key . ']', $op['colors'][ $color_key ], '', $defaults['colors'][ $color_key ] ); ?></td>
							<?php if ( 0 == ( $c_i % 2 ) && $c_i != count( $colors ) ) : ?>
						</tr>
						<tr>
							<?php endif; ?>
							<?php $c_i++; ?>
						<?php endforeach; ?>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[theme][material][width]', __( 'Form Width', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->text( 'settings[theme][material][width]', $op['width'], __( '100%', 'mc_form' ) ); ?></td>
			<td><?php $this->ui->help( __( 'Set the width of your form. This will be the maximum width, if the viewport width is less, then the form will always take up on the width of the viewport..', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[theme][material][button_style]', __( 'Progress Button Style', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->select( 'settings[theme][material][button_style]', $button_variants, $op['button_style'], false, true ); ?></td>
			<td><?php $this->ui->help( __( 'Set progress button style.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[theme][material][alternate_pb]', __( 'Button Color', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->toggle( 'settings[theme][material][alternate_pb]', __( 'Theme', 'mc_form' ), __( 'Grey', 'mc_form' ), $op['alternate_pb'] ) ?></td>
			<td><?php $this->ui->help( __( 'Alternate design for the progress buttons. Enable this if you want dark button toolbar design with primary color scheme.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mc-mcform-builder-config-style-material-br-wrap">
			<th><?php $this->ui->generate_label( 'settings[theme][material][button_rounded]', __( 'Rounded Buttons', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->toggle( 'settings[theme][material][button_rounded]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['button_rounded'] ) ?></td>
			<td><?php $this->ui->help( __( 'Enable to have the inline buttons rounded appearance.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( 'settings[theme][material][bg][enabled]', __( 'Modify Form Background', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->toggle( 'settings[theme][material][bg][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $op['bg']['enabled'], '1', false, true, array(
				'condid' => 'mcform-material-bg-config-image,mcform-material-bg-config-position,mcform-material-bg-config-size,mcform-material-bg-config-repeat,mcform-material-bg-config-origin,mcform-material-bg-config-clip,mcform-material-bg-config-attachment',
			) ) ?></td>
			<td><?php $this->ui->help( __( 'Customize the background of your form', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mcform-material-bg-config-image">
			<th><?php $this->ui->generate_label( 'settings[theme][material][bg][background-image]', __( 'Background Image', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->upload( 'settings[theme][material][bg][background-image]', $op['bg']['background-image'], __( 'Form Background Image', 'mc_form' ) ); ?></td>
			<td><?php $this->ui->help( __( 'Set the background image of your form.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mcform-material-bg-config-position">
			<th><?php $this->ui->generate_label( 'settings[theme][material][bg][background-position]', __( 'Background Position', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->text( 'settings[theme][material][bg][background-position]', $op['bg']['background-position'], __( 'auto', 'mc_form' ) ); ?></td>
			<td><?php $this->ui->help( __( 'Set the <a href="http://www.w3schools.com/cssref/pr_background-position.asp" target="_blank">background image position</a> of your form.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mcform-material-bg-config-size">
			<th><?php $this->ui->generate_label( 'settings[theme][material][bg][background-size]', __( 'Background Size', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->text( 'settings[theme][material][bg][background-size]', $op['bg']['background-size'], __( 'auto', 'mc_form' ) ); ?></td>
			<td><?php $this->ui->help( __( 'Set the <a href="http://www.w3schools.com/cssref/css3_pr_background-size.asp" target="_blank">background image size</a> of your form.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mcform-material-bg-config-repeat">
			<th><?php $this->ui->generate_label( 'settings[theme][material][bg][background-repeat]', __( 'Background Repeat', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->select( 'settings[theme][material][bg][background-repeat]', $bg_repeat, $op['bg']['background-repeat'] ); ?></td>
			<td><?php $this->ui->help( __( 'Set the <a href="http://www.w3schools.com/cssref/pr_background-repeat.asp" target="_blank">background image repeat</a> of your form.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mcform-material-bg-config-origin">
			<th><?php $this->ui->generate_label( 'settings[theme][material][bg][background-origin]', __( 'Background Origin', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->select( 'settings[theme][material][bg][background-origin]', $bg_origin, $op['bg']['background-origin'] ); ?></td>
			<td><?php $this->ui->help( __( 'Set the <a href="http://www.w3schools.com/cssref/css3_pr_background-origin.asp" target="_blank">background image origin</a> of your form.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mcform-material-bg-config-clip">
			<th><?php $this->ui->generate_label( 'settings[theme][material][bg][background-clip]', __( 'Background Clip', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->select( 'settings[theme][material][bg][background-clip]', $bg_clip, $op['bg']['background-clip'] ); ?></td>
			<td><?php $this->ui->help( __( 'Set the <a href="http://www.w3schools.com/cssref/css3_pr_background-clip.asp" target="_blank">background image clip</a> of your form.', 'mc_form' ) ); ?></td>
		</tr>
		<tr id="mcform-material-bg-config-attachment">
			<th><?php $this->ui->generate_label( 'settings[theme][material][bg][background-attachment]', __( 'Background Scroll', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->select( 'settings[theme][material][bg][background-attachment]', $bg_attachment, $op['bg']['background-attachment'] ); ?></td>
			<td><?php $this->ui->help( __( 'Set the <a href="http://www.w3schools.com/cssref/pr_background-attachment.asp" target="_blank">background image scroll behavior</a> of your form.', 'mc_form' ) ); ?></td>
		</tr>
	</tbody>
</table>
		<?php
	}

	public function material_custom( $return_id, $name, $settings, $layout, $save_process, $form_type, $form_category ) {
		// Init the save path
		$wp_upload_dir = wp_upload_dir();
		$save_path = $wp_upload_dir['basedir'] . '/mcform-custom-material';
		$save_file = $save_path . '/form-theme-' . $return_id . '.css';
		$checksum_file = $save_path . '/.form-theme-' . $return_id . '.checksum';
		@wp_mkdir_p( $save_path );

		// Get the checksum beforehand
		$existing_checksum = '';
		if ( file_exists( $checksum_file ) ) {
			$existing_checksum = file_get_contents( $checksum_file );
		}

		// Get our color settings
		$colors = $settings['theme']['material']['colors'];

		// Set import path
		$import_path = MC_MCFORM_ABSPATH . 'static/front/css/source/';

		// Create variables
		$variables = array(
			'selector'                             => 'mc-uif-custom-material-custom',
			'img-path'                             => str_replace( array( 'http://', 'https://' ), array( '//', '//' ), MC_FORM_Loader::$static_location . 'front/images/' ),
			'primary-color-dark'                   => $colors['primary-color-dark'],
			'primary-color'                        => $colors['primary-color'],
			'primary-color-light'                  => $colors['primary-color-light'],
			'primary-color-text'                   => $colors['primary-color-text'],
			'accent-color'                         => $colors['accent-color'],
			'primary-text-color'                   => $colors['primary-text-color'],
			'heading-text-color'                   => 'darken( $primary-text-color, 10% )',
			'passive-tab-notifier'                 => 'lighten( $primary-color, 5% )',
			'secondary-text-color'                 => $colors['secondary-text-color'],
			'divider-color'                        => $colors['divider-color'], //l3
			'disabled-color'                       => $colors['disabled-color'], //l4
			'disabled-color-text'                  => $colors['disabled-color-text'], //l3
			'preset-bg'                            => $colors['background-color'],
			'preset-button-container'              => $colors['disabled-color'], //l4
			'preset-button-container-button-hover' => $colors['disabled-color-text'], //l3
			'input-border-color'                   => $colors['border-color'], //base
			'switch-unchecked-bg'                  => $colors['disabled-color'], //l4
			'switch-unchecked-lever-bg'            => $colors['ui-bg-color'], //l2
			'slider-bg-color'                      => $colors['ui-bg-color'], //l2
			'select2-highlight-selected'           => $colors['ui-bg-color'],//l2
			'sortable-icon-color'                  => $colors['secondary-text-color'],//l1
			'sortable-border-color'                => $colors['divider-color'],//l3
			'table-striped-color'                  => $colors['disabled-color'],//l4
			'keyboard-bg'                          => $colors['widget-bg-color'],//l5
			'keyboard-num-border-color'            => $colors['disabled-color'],//l4
			'keyboard-action-bg'                   => $colors['disabled-color'], //l4
			'up-button-container'                  => $colors['disabled-color'], //l4
			'styled-container-bg'                  => $colors['widget-bg-color'], //l5
			'estimator-slider-bg'                  => 'lighten($primary-color, 30%)',
			'estimator-slider-slide'               => 'darken($primary-color, 30%)',
		);

		// Create new checksum
		$new_checksum_string = implode( '::', array_values( $variables ) ) . '::' . $import_path . '::' . MC_FORM_Loader::$version;
		$new_checksum = (string) crc32( $new_checksum_string );

		// If checksum matches, then do nothing
		if ( $existing_checksum === $new_checksum ) {
			// Do nothing
			return;
		}

		// Create Compiler
		$compiler = new Leafo\ScssPhp\Compiler();

		// Set import path
		$compiler->setImportPaths( $import_path );

		// Set variables
		$compiler->setVariables( $variables );

		// Set formatter
		$compiler->setFormatter( 'Leafo\ScssPhp\Formatter\Compressed' );

		// Create source code accordingly
		$scss_code = '@import "compile"';
		if ( 'dark' == $settings['theme']['material']['skin'] ) {
			$scss_code = '@import "compile-dark";';
		}

		// Get compiled code
		try {
			$compiled_css = $compiler->compile( $scss_code );
		} catch ( Exception $e ) {
			// Some compilation exception, so use the defaults
			// Error with the default?? Something wrong with the SCSS Files?
			$compiled_css =
			'#mc_form_form_wrap_' . $this->form_id . '::before {
				display: block;
				content: "' . $e->getMessage() . ': If the error is about variable, then check your color codes. Common mistakes are #transparent whereas it should be just transparent. Otherwise something wrong with SCSS source. Clean installation of mcForm might help.";
				background: #EF5350;
				padding: 16px;
				text-align: center;
				color: #fff;
				font-size: 20px;
				border-bottom: 8px solid #D32F2F;
				margin: 8px 0;
			}';
		}

		// Save css file
		file_put_contents( $save_file, $compiled_css );
		file_put_contents( $checksum_file, $new_checksum );
		// Save checksum
	}

	public function _helper_build_prefil_text( $name_prefix, $data ) {
		$prefill_types = array(
			0 => array(
				'value' => 'none',
				'label' => __( 'None', 'mc_form' ),
			),
			1 => array(
				'value' => 'url',
				'label' => __( 'URL Parameter Based', 'mc_form' ),
			),
			2 => array(
				'value' => 'meta',
				'label' => __( 'User Meta Based', 'mc_form' ),
			),
			3 => array(
				'value' => 'postmeta',
				'label' => __( 'Post Meta Based', 'mc_form' ),
			),
		);
		?>
		<tr>
			<th><?php $this->ui->generate_label( $name_prefix . '[settings][default]', __( 'Default Value', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( $name_prefix . '[settings][default]', $data['settings']['default'], __( 'None', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enter the default value of this element. This would be set if URL or meta parameter does not override. Empty value can also override the default value. But the value has to be set, i.e, either URL parameter or user metakey needs to be present.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( $name_prefix . '[settings][type]', __( 'Prefill Type', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->select( $name_prefix . '[settings][type]', $prefill_types, $data['settings']['type'] ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Set the type of the prefill value the field will get. It can be based on URL parameter or user meta key. Leave to None if you do not wish to prefill the value. For post meta based values, the post where this form is published through shortcode, would be considered. If you enter parameter like <code>10:key_value</code> then post meta <code>key_value</code> of post <code>10</code> would be considered, regardless of where the form is published.', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th><?php $this->ui->generate_label( $name_prefix . '[settings][parameter]', __( 'Key Parameter', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( $name_prefix . '[settings][parameter]', $data['settings']['parameter'], __( 'Required', 'mc_form' ) ); ?>
			</td>
			<td><?php $this->ui->help( __( 'Enter the key parameter. In case of URL type value, <code>$_REQUEST[ $key ]</code> would be used. In case of User meta type value, the mentioned metakey would be used to retrieve the metavalue. It can not be empty or no value would be generated.', 'mc_form' ) ); ?></td>
		</tr>
		<?php
	}

	/**
	 * A helper method to print score config for feedback elements
	 *
	 * @param      string  $name_prefix  The name prefix
	 * @param      string  $key          The key
	 * @param      array   $data         Configuration data
	 */
	protected function feedback_auto_score( $name_prefix, $key, $data ) {
		// Score types
		$score_types = [
			'contains' => __( 'Text Contains', 'mc_form' ),
			'starts' => __( 'Text Starts With', 'mc_form' ),
			'ends' => __( 'Text Ends With', 'mc_form' ),
			'equals' => __( 'Exactly Equals To', 'mc_form' ),
		];
		// Items
		$items = [];
		// Enabled
		$items[] = [
			'name' => $name_prefix . '[settings][autoscore][enabled]',
			'label' => __( 'Automatic Scoring', 'mc_form' ),
			'ui' => 'toggle',
			'param' => [ $name_prefix . '[settings][autoscore][enabled]', __( 'Yes', 'mc_form' ), __( 'No', 'mc_form' ), $data['settings']['autoscore']['enabled'], '1', false, true, [
				'condid' => 'mc_form_builder_fs_' . $key . '_as_type_wrap,mc_form_builder_fs_' . $key . '_as_text_wrap',
			] ],
			'help' => __( 'Enable automatic score calculation for this element.', 'mc_form' ),
		];
		// Type
		$items[] = [
			'name' => $name_prefix . '[settings][autoscore][type]',
			'label' => __( 'Assign Score if Text', 'mc_form' ),
			'ui' => 'select',
			'param' => [ $name_prefix . '[settings][autoscore][type]', $score_types, $data['settings']['autoscore']['type'] ],
			'id' => 'mc_form_builder_fs_' . $key . '_as_type_wrap',
			'help' => __( 'Enter the condition which will be used to check the relation between user text and your text.', 'mc_form' ),
		];
		// Text
		$items[] = [
			'name' => $name_prefix . '[settings][autoscore][text]',
			'label' => __( 'Check Against', 'mc_form' ),
			'ui' => 'text',
			'param' => [ $name_prefix . '[settings][autoscore][text]', $data['settings']['autoscore']['text'], __( 'Required', 'mc_form' ) ],
			'id' => 'mc_form_builder_fs_' . $key . '_as_text_wrap',
		];
		$this->ui->form_table( $items, false );
	}
}
