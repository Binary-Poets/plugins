<?php
/**
 * Simple Line Icons
 *
 */

require_once dirname( __FILE__ ) . '/font.php';

/**
 * Icon type: Simple Line Icons
 *
 */

class OE_Icon_Picker_Type_Simple_Line_Icons extends OE_Icon_Picker_Type_Font {

	/**
	 * Icon type ID
	 *
	 */
	protected $id = 'line-icon';

	/**
	 * Icon type name
	 *
	 */
	protected $name = 'Simple Line Icons';

	/**
	 * Icon type version
	 *
	 */
	protected $version = '2.4.0';

	/**
	 * Stylesheet ID
	 *
	 */
	protected $stylesheet_id = 'simple-line-icons';

	/**
	 * Get icon groups
	 *
	 */
	public function get_groups() {
		$groups = array(
			array(
				'id'   => 'actions',
				'name' => __( 'Actions', 'binary-extra' ),
			),
			array(
				'id'   => 'media',
				'name' => __( 'Media', 'binary-extra' ),
			),
			array(
				'id'   => 'misc',
				'name' => __( 'Misc.', 'binary-extra' ),
			),
			array(
				'id'   => 'social',
				'name' => __( 'Social', 'binary-extra' ),
			),
		);

		/**
		 * Filter simple line icons groups
		 *
		 */
		$groups = apply_filters( 'oe_icon_picker_simple_line_icons_groups', $groups );

		return $groups;
	}

	/**
	 * Get icon names
	 *
	 */
	public function get_items() {
		$items = array(
			array(
				'group' => 'misc',
				'id'    => 'icon-user',
				'name'  => __( 'User', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-people',
				'name'  => __( 'People', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-user-female',
				'name'  => __( 'User Female', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-user-follow',
				'name'  => __( 'User Follow', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-user-following',
				'name'  => __( 'User Following', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-user-unfollow',
				'name'  => __( 'User Unfollow', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-login',
				'name'  => __( 'Login', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-logout',
				'name'  => __( 'Logout', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-emotsmile',
				'name'  => __( 'Emotsmile', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-phone',
				'name'  => __( 'Phone', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-call-end',
				'name'  => __( 'Call End', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-call-in',
				'name'  => __( 'Call In', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-call-out',
				'name'  => __( 'Call Out', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-map',
				'name'  => __( 'Map', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-location-pin',
				'name'  => __( 'Location Pin', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-direction',
				'name'  => __( 'Direction', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-directions',
				'name'  => __( 'Directions', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-compass',
				'name'  => __( 'Compass', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-layers',
				'name'  => __( 'Layers', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-menu',
				'name'  => __( 'Menu', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-list',
				'name'  => __( 'List', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-options-vertical',
				'name'  => __( 'Options Vertical', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-options',
				'name'  => __( 'Options', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-arrow-down',
				'name'  => __( 'Arrow Down', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-arrow-left',
				'name'  => __( 'Arrow Left', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-arrow-right',
				'name'  => __( 'Arrow Right', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-arrow-up',
				'name'  => __( 'Arrow Up', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-arrow-up-circle',
				'name'  => __( 'Arrow Up Circle', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-arrow-left-circle',
				'name'  => __( 'Arrow Left Circle', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-arrow-right-circle',
				'name'  => __( 'Arrow Right Circle', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-arrow-down-circle',
				'name'  => __( 'Arrow Down Circle', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-check',
				'name'  => __( 'Check', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-clock',
				'name'  => __( 'Clock', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-plus',
				'name'  => __( 'Plus', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-minus',
				'name'  => __( 'Minus', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-close',
				'name'  => __( 'Close', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-exclamation',
				'name'  => __( 'Exclamation', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-organization',
				'name'  => __( 'Organization', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-trophy',
				'name'  => __( 'Trophy', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-screen-smartphone',
				'name'  => __( 'Screen Smartphone', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-screen-desktop',
				'name'  => __( 'Screen Desktop', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-plane',
				'name'  => __( 'Plane', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-notebook',
				'name'  => __( 'Notebook', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-mustache',
				'name'  => __( 'Mustache', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-mouse',
				'name'  => __( 'Mouse', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-magnet',
				'name'  => __( 'Magnet', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-energy',
				'name'  => __( 'Energy', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-disc',
				'name'  => __( 'Disc', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-cursor',
				'name'  => __( 'Cursor', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-cursor-move',
				'name'  => __( 'Cursor Move', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-crop',
				'name'  => __( 'Crop', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-chemistry',
				'name'  => __( 'Chemistry', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-speedometer',
				'name'  => __( 'Speedometer', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-shield',
				'name'  => __( 'Shield', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-screen-tablet',
				'name'  => __( 'Screen Tablet', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-magic-wand',
				'name'  => __( 'Magic Wand', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-hourglass',
				'name'  => __( 'Hourglass', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-graduation',
				'name'  => __( 'Graduation', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-ghost',
				'name'  => __( 'Ghost', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-game-controller',
				'name'  => __( 'Game Controller', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-fire',
				'name'  => __( 'Fire', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-eyeglass',
				'name'  => __( 'Eyeglass', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-envelope-open',
				'name'  => __( 'Envelope Open', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-envelope-letter',
				'name'  => __( 'Envelope Letter', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-bell',
				'name'  => __( 'Bell', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-badge',
				'name'  => __( 'Badge', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-anchor',
				'name'  => __( 'Anchor', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-wallet',
				'name'  => __( 'Wallet', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-vector',
				'name'  => __( 'Vector', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-speech',
				'name'  => __( 'Speech', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-puzzle',
				'name'  => __( 'Puzzle', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-printer',
				'name'  => __( 'Printer', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-present',
				'name'  => __( 'Present', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-playlist',
				'name'  => __( 'Playlist', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-pin',
				'name'  => __( 'Pin', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-picture',
				'name'  => __( 'Picture', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-handbag',
				'name'  => __( 'Handbag', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-globe-alt',
				'name'  => __( 'Globe Alt', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-globe',
				'name'  => __( 'Globe', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-folder-alt',
				'name'  => __( 'Folder Alt', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-folder',
				'name'  => __( 'Folder', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-film',
				'name'  => __( 'Film', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-feed',
				'name'  => __( 'Feed', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-drop',
				'name'  => __( 'Drop', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-drawer',
				'name'  => __( 'Drawer', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-docs',
				'name'  => __( 'Docs', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-doc',
				'name'  => __( 'Doc', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-diamond',
				'name'  => __( 'Diamond', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-cup',
				'name'  => __( 'Cup', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-calculator',
				'name'  => __( 'Calculator', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-bubbles',
				'name'  => __( 'Bubbles', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-briefcase',
				'name'  => __( 'Briefcase', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-book-open',
				'name'  => __( 'Book Open', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-basket-loaded',
				'name'  => __( 'Basket Loaded', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-basket',
				'name'  => __( 'Basket', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-bag',
				'name'  => __( 'Bag', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-action-undo',
				'name'  => __( 'Action Undo', 'binary-extra' ),
			),
			array(
				'group' => 'actions',
				'id'    => 'icon-action-redo',
				'name'  => __( 'Action Redo', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-wrench',
				'name'  => __( 'Wrench', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-umbrella',
				'name'  => __( 'Umbrella', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-trash',
				'name'  => __( 'Trash', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-tag',
				'name'  => __( 'Tag', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-support',
				'name'  => __( 'Support', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-frame',
				'name'  => __( 'Frame', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-size-fullscreen',
				'name'  => __( 'Size Fullscreen', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-size-actual',
				'name'  => __( 'Size Actual', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-shuffle',
				'name'  => __( 'Shuffle', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-share-alt',
				'name'  => __( 'Share Alt', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-share',
				'name'  => __( 'Share', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-rocket',
				'name'  => __( 'Rocket', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-question',
				'name'  => __( 'Question', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-pie-chart',
				'name'  => __( 'Pie Chart', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-pencil',
				'name'  => __( 'Pencil', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-note',
				'name'  => __( 'Note', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-loop',
				'name'  => __( 'Loop', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-home',
				'name'  => __( 'Home', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-grid',
				'name'  => __( 'Grid', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-graph',
				'name'  => __( 'Graph', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-microphone',
				'name'  => __( 'Microphone', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-music-tone-alt',
				'name'  => __( 'Music Tone Alt', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-music-tone',
				'name'  => __( 'Music Tone', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-earphones-alt',
				'name'  => __( 'Earphones Alt', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-earphones',
				'name'  => __( 'Earphones', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-equalizer',
				'name'  => __( 'Equalizer', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-like',
				'name'  => __( 'Like', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-dislike',
				'name'  => __( 'Dislike', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-control-start',
				'name'  => __( 'Control Start', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-control-rewind',
				'name'  => __( 'Control Rewind', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-control-play',
				'name'  => __( 'Control Play', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-control-pause',
				'name'  => __( 'Control Pause', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-control-forward',
				'name'  => __( 'Control Forward', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-control-end',
				'name'  => __( 'Control End', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-volume-1',
				'name'  => __( 'Volume 1', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-volume-2',
				'name'  => __( 'Volume 2', 'binary-extra' ),
			),
			array(
				'group' => 'media',
				'id'    => 'icon-volume-off',
				'name'  => __( 'Volume Off', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-calendar',
				'name'  => __( 'Calendar', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-bulb',
				'name'  => __( 'Bulb', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-chart',
				'name'  => __( 'Chart', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-ban',
				'name'  => __( 'Ban', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-bubble',
				'name'  => __( 'Bubble', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-camrecorder',
				'name'  => __( 'Camrecorder', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-camera',
				'name'  => __( 'Camera', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-cloud-download',
				'name'  => __( 'Cloud Download', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-cloud-upload',
				'name'  => __( 'Cloud Upload', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-envelope',
				'name'  => __( 'Envelope', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-eye',
				'name'  => __( 'Eye', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-flag',
				'name'  => __( 'Flag', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-heart',
				'name'  => __( 'Heart', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-info',
				'name'  => __( 'Info', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-key',
				'name'  => __( 'Key', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-link',
				'name'  => __( 'Link', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-lock',
				'name'  => __( 'Lock', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-lock-open',
				'name'  => __( 'Lock Open', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-magnifier',
				'name'  => __( 'Magnifier', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-magnifier-add',
				'name'  => __( 'Magnifier Add', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-magnifier-remove',
				'name'  => __( 'Magnifier Remove', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-paper-clip',
				'name'  => __( 'Paper Clip', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-paper-plane',
				'name'  => __( 'Paper Plane', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-power',
				'name'  => __( 'Power', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-refresh',
				'name'  => __( 'Refresh', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-reload',
				'name'  => __( 'Reload', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-settings',
				'name'  => __( 'Settings', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-star',
				'name'  => __( 'Star', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-symbol-female',
				'name'  => __( 'Symbol Female', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-symbol-male',
				'name'  => __( 'Symbol Male', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-target',
				'name'  => __( 'Target', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-credit-card',
				'name'  => __( 'Credit Card', 'binary-extra' ),
			),
			array(
				'group' => 'misc',
				'id'    => 'icon-paypal',
				'name'  => __( 'Paypal', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-tumblr',
				'name'  => __( 'Social Tumblr', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-twitter',
				'name'  => __( 'Social Twitter', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-facebook',
				'name'  => __( 'Social Facebook', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-instagram',
				'name'  => __( 'Social Instagram', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-linkedin',
				'name'  => __( 'Social Linkedin', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-pinterest',
				'name'  => __( 'Social Pinterest', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-github',
				'name'  => __( 'Social Github', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-google',
				'name'  => __( 'Social Google', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-reddit',
				'name'  => __( 'Social Reddit', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-skype',
				'name'  => __( 'Social Skype', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-dribbble',
				'name'  => __( 'Social Dribbble', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-behance',
				'name'  => __( 'Social Behance', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-foursqare',
				'name'  => __( 'Social Foursqare', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-soundcloud',
				'name'  => __( 'Social Soundcloud', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-spotify',
				'name'  => __( 'Social Spotify', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-stumbleupon',
				'name'  => __( 'Social Stumbleupon', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-youtube',
				'name'  => __( 'Social Youtube', 'binary-extra' ),
			),
			array(
				'group' => 'social',
				'id'    => 'icon-social-dropbox',
				'name'  => __( 'Social Dropbox', 'binary-extra' ),
			),
		);

		/**
		 * Filter simple line icons items
		 *
		 */
		$items = apply_filters( 'oe_icon_picker_simple_line_icons_items', $items );

		return $items;
	}
}
