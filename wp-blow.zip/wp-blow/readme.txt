=== WP Blow - Best WordPress Blow Plugin ===
Tags: wordpress blow, blow database, blow wordpress database, blow, advanced wordpress blow, restart wordpress, clean wordpress, default wp, default wordpress, blow wp, wp blow, developer, wp-cli, webhooks, backup, database backup
Contributors: WebFactory, wpblow, googlemapswidget, underconstructionpage
Requires at least: 4.0
Requires PHP: 5.2
Tested up to: 5.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Blow blows the whole site, or just the chosen parts, to the default values. It's safe to use with a built-in restore function.

== Description ==

<a href="https://wpblow.com/?utm_source=wordpressorg&utm_medium=content&utm_campaign=wp-blow&utm_term=wp-blow-top">WP Blow</a> quickly blows the site's database to the default installation values without modifying any files. It deletes all customizations and content, or just chosen parts like theme settings. WP Blow is fast and safe to use thanks to the built-in snapshots which provide 1-click restore functionality. It has multiple fail-safe mechanisms so you can never accidentally lose data. WP Blow is extremely helpful for plugin and theme developers. It **speeds up testing & debugging** by providing a quick way to blow settings and re-test code. It's the only WP development tool for non-developers.

https://youtu.be/qMnkCW2PFoI?rel=0

For support please use the <a href="https://wordpress.org/support/plugin/wp-blow">official forum</a>, and if you need more information visit <a href="https://wpblow.com/?utm_source=wordpressorg&utm_medium=content&utm_campaign=wp-blow&utm_term=wpblow.com">wpblow.com</a> and be sure to check out the <a href="https://wpblow.com/roadmap/?utm_source=wordpressorg&utm_medium=content&utm_campaign=wp-blow&utm_term=roadmap">roadmap</a> for the list of upcoming features.

Access WP Blow admin page via the "Tools" menu.

WP Blow is fully integrated with <a href="https://wordpress.org/plugins/wp-webhooks/">WP Webhooks</a> plugin - a secure, universal system that connects WP to any 3rd party systems and enables you to initiate actions both from WordPress (for instance start a MailChimp campaign once a new user registers), and from any other application (create a new user in WP when a purchase is made on a 3rd party system). View more <a href="https://underconstructionpage.com/wp-webhooks-connect-integrate-wordpress/" target="_blank">practical use-cases</a> that save hours of repetitive work.


**Please read carefully before proceeding to understand what WP Blow does, and remember to always create a snapshot**

#### Blowing will delete:

* all posts, pages, custom post types, comments, media entries, users
* all default WP database tables
* all custom database tables that have the same prefix table prefix as the one defined in _wp-config.php_ and used by default tables

#### Blowing will not delete or modify:

* media files - they remain in the _wp-uploads_ folder untouched but will no longer be listed under Media in admin
* no files are touched; plugins, themes, uploads - everything stays
* site title, WordPress address, site address, site language and search engine visibility settings
* currently logged in user will be restored with the current username and password

#### What happens when I click the Blow button?

* remember to always create a snapshot first or a full backup
* you will have to confirm the action one more time because there is NO UNDO
* everything will be blow; see bullets above for details
* site title, WordPress address, site address, site language, search engine visibility settings as well as the current user will be restored
* you will be logged out, automatically logged in and taken to the admin dashboard
* WP Blow plugin will be reactivated if that option is chosen in the post-blow options

#### Undoing a blow

Before doing a blow, create a snapshot. The button is located right next to the blow button and it takes less than 10 seconds to create a snapshot. After blow is done, if you need to undo it simply restore the snapshot and that's it.

#### WP-CLI support

WP Blow comes with full WP-CLI support. Help on our WP-CLI commands is available via _wp help blow_. By default the commands have to be confirmed but you can use the `--yes` option to skip confirmation. Instead of the active user, the first user with admin privileges found in the database will be restored after blow. Please be careful when using WP Blow with WP-CLI - as with using the GUI always make a snapshot or backup first.

Currently supported WP-CLI commands:

* `wp blow blow`
* `wp blow version`
* `wp blow delete`
* `wp blow snapshots`


#### Database Snapshots

Database snapshot is a copy of all WP database tables, standard and custom ones, saved in the currently used database (as set by _wp-config.php_). Files are not saved or included in snapshots in any way.
Snapshots are primarily a development tool. Although they can be used for backups (and downloaded as gzipped SQL dumps), we suggest finding a more suitable tool for doing backups of live sites. Use snapshots to find out what changes a plugin made to your database - what custom tables were created, modified, deleted or what changes were made to site's settings. Or use it to quickly restore the development environment after testing database related changes.
Restoring a snapshot does not affect other snapshots, or WP Blow settings. Snapshots can be compared to current database tables, restored (by overwriting current tables), exported ad gzipped SQL dumps, or deleted. Creating a snapshot on an average WordPress installation takes 1-2 seconds.

https://youtu.be/xBfMmS12vMY?rel=0

#### Multisite (WP-MU) Support

WP Blow has yet to be completely tested with multisite! Please be careful when using it with multisite enabled. We don't recommend to blowting the main site. Sub-sites should be OK. We're working on making WP Blow fully compatible with WP-MU. Till then please be careful. Thank you for understanding.

#### Partial Blow Tools

* Delete transients - deletes all transient related database entries. Including expired and non-expired transients, and orphaned timeout entries.
* Delete uploads - delete all files and folder in the /uploads/ folder.
* Delete plugins - deletes all plugins except WP Blow which remains active.
* Blow theme options - blows all options for all themes that use the WP theme mods API.
* Delete themes - deletes all themes.
* Empty or delete custom tables - empties (truncates) or deletes (drops) all custom database tables.
* Delete .htaccess file - deletes the .htaccess file. If you need to edit .htaccess without FTP use our free <a href="https://wordpress.org/plugins/wp-htaccess-editor/">WP Htaccess Editor</a> plugin.


#### Friends who helped us translate WP Blow

* French - <a href="https://www.infrenchtranslation.com/">Jeff Inho</a>


== Installation ==

Follow the usual routine;

1. Open WordPress admin, go to Plugins, click Add New
2. Enter "wp blow" in search and hit Enter
3. Plugin will show up as the first on the list (look for our black&red round logo), click "Install Now"
4. Activate & open plugin's settings page located under the Tools menu

Or if needed, upload manually;

1. Download the latest stable version from from <a href="https://downloads.wordpress.org/plugin/wp-blow.latest-stable.zip">downloads.wordpress.org/plugin/wp-blow.latest-stable.zip</a>
2. Unzip it and upload to _/wp-content/plugins/_
3. Open WordPress admin - Plugins and click "Activate" next to "WP Blow"
4. Open plugin's admin page located under the Tools menu


== Screenshots ==

1. WP Blow - main blow page
2. All blow actions have to be confirmed
3. Additional tools for blowting and deleting various WordPress objects
4. Database Snapshots enable 1-click restoring and testing
5. Use our 1-click backup feature before running any blow tools

== Changelog ==

= v1.0 =
* 2019/11/12
* bug fixes
* more GUI improvements
* updates for WP v5.3
* removed the 1-click backup tool in favor of snapshots - less confusing & same end result
* two huge bug fixes thanks to @markwill
* 1,241,470 downloads

= v1.70 =
* 2019/09/27
* bug fixes
* completely new GUI
* added .htaccess file to protect snapshots and backups folder
* added 1-click backup feature

= v1.65 =
* 2019/07/15
* bug fixes

= v1.60 =
* 2019/04/15
* bug fixes
* new tool: Blow theme options
* added Product Hunt banner
* added actions (hooks) to all tools and snapshot actions; all action names start with "wp-blow-"
* removed features survey
* announced plugin & theme collections

= v1.55 =
* 2019/03/25
* 100k users hit on 2019/01/15 with 560,300 downloads; 34 days for +10k & 71k downloads
* bug fixes
* support for WP Webhooks
* added features survey

= v1.50 =
* 2019/01/08
* new tool: delete .htaccess file
* new WP-CLI command: wp blow delete htaccess
* 90k users hit on 2018/12/12 with 489,100 downloads; 27 days for +10k & 58k downloads

= v1.45 =
* 2018/11/27
* new tool: truncate or drop custom DB tables
* truncate / drop tables tool added to WP-CLI
* all snapshot tools added to WP-CLI
* 80k users hit on 2018/11/15 with 430,800 downloads; 30 days for +10k & 57k downloads

= v1.40 =
* 2018/10/24
* new tool: DB Snapshots
* rewrote code documentation for most functions
* some parts of Snapshots need refactoring
* 70k users hit on 2018/10/16 with 373,300 downloads; 30 days for +10k & 50k downloads

= v1.35 =
* 2018/09/18
* sponsorship by IP Geolocation
* 60k users hit on 2018/09/16 with 323,300 downloads; 35 days for +10k
* added all tools to WP-CLI
* new tool: delete all files in uploads folder

= v1.30 =
* 2018/08/27
* more code clean-up
* added new blow params to WP-CLI
* big GUI changes
* started adding various tools; delete transients, delete all plugins, delete all themes
* we hit 50,000 installations on 2018/08/11 with 274,000 downloads

= v1.25 =
* 2018/07/30
* code clean-up
* post-blow options - reactivate plugin, themes & WP Blow
* added WP-MU warning till we make WP Blow fully compatible with it
* Tidy Repo notice
* added option to collapse boxes
* modified rating notice

= v1.20 =
* 2018/07/09
* we hit 40k installations on 2018/06/26
* WP-CLI support via "wp blow" command
* new logo
* ask for rating notice
* GUI improvements
* code clean up
* preparations for further development and new features

= v1.10 =
* 2018/05/09
* WebFactory took over development
* numerous bug fixes and improvements
* 30,000 installations; 199,000 downloads

= v1.0 =
* 2016/05/16
* Initial release

== Frequently Asked Questions ==

= Does WP Blow make backups? =

Automatically no, it does not. But we have "download backup" links besides every tool in the plugin so make sure you download a backup before running them. Backups only contain the database, no files!

= How can I log in after blowting? =

Use the same username and password you used while doing the blow. Only one user will be restored after blowting. The one you used at that time.

= Will any files be deleted or modified when I blow the site? =

No. All files are left untouched if you do a full blow. However, there are tool like "delete themes" that do delete files.

= Will I have to reconfigure wp-config.php? =

Absolutely not. No reconfiguration is needed. No files are modified.

= Do you support WP-CLI? =

We sure do! Just type "wp blow" in your shell to see the list of available commands and options.

= How long does it take for the blow operation to complete? =

On most installations a second or two. If you have a huge amounts of data in tables then up to ten seconds.
