<?php
/**
 * Trackback with Gutenberg
 */

namespace MCFormV4\Blocks\System;

class Trackback {

}
