<?php
/*
Plugin Name: Binary Easy Social Share
Description: Easily display social share buttons for your posts, pages and custom post types. Supports Facebook, Twitter, Reddit, Pinterest, Email, Google+, LinkedIn, StumbleUpon, WhatsApp and vKontakte.
Version: 1.2.1
Author: BinaryPoets
Author URI: https://binarypoets.net/
Text Domain: binary-easy-social-share
Domain Path: /languages
*/

/* Prevent direct access */
if ( !defined( 'DB_NAME' ) ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

define( 'BINARY_ESS_URL', trailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'BINARY_ESS_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );
define( 'BINARY_ESS_VER', '1.2.1' );
define( 'BINARY_ESS_BASENAME', plugin_basename( __FILE__ ) );

/* Includes */
require_once BINARY_ESS_DIR . 'inc/functions.php';
require_once BINARY_ESS_DIR . 'inc/class-share.php';


/* Start plugin */
add_action( 'init', 'binary_ess_init' );

function binary_ess_init() {
	$binary_ess = Binary_ESS::get_instance();
}
