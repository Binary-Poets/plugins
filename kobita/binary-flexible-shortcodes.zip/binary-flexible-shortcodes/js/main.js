(function($) {
    $(document).ready(function($) {

        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {

            $("body").on("touchstart", ".bps_accordion_heading", function(e) {
                bps_accordion_handle($(this));
            });

            $("body").on("touchstart", ".bps_toggle_heading", function(e) {
                bps_toggle_handle($(this));
            });


            $("body").on("touchstart", ".bps_tabs_nav .bps_tab_nav_item", function(e) {
                bps_tab_handle($(this));
            });

        } else {

            $("body").on("click", ".bps_accordion_heading", function(e) {
                bps_accordion_handle($(this));
            });


            $("body").on("click", ".bps_toggle_heading", function(e) {
                bps_toggle_handle($(this));
            });


            $("body").on("click", ".bps_tabs_nav .bps_tab_nav_item", function(e) {
                bps_tab_handle($(this));
            });
        }



    }); // end $(document).ready()
    
    /* Initialize tabs */

    $(window).load(function(){
        $('.bps_tabs').each(function(){
            bps_init_tabs($(this));
        });
        
        bps_tabs_check_switch( $('.bps_tabs') );
    });

    $(window).resize(function() {   
        bps_tabs_check_switch( $('.bps_tabs'));
    });

    function bps_tabs_check_switch( obj ) {
        if ( !obj.length ) return;

        obj.each(function() {

            var tabs_holder = $(this); 
            var tabs_nav_wrapper = tabs_holder.find('.bps_tabs_nav');  

            if ( !tabs_holder.hasClass('bps-accordion-switched') ) {

                var tabs_width = bps_check_tabs_width( tabs_holder );
                if( tabs_width && !tabs_holder.hasClass('vertical')){
                    bps_tabs_to_accordion( tabs_holder, tabs_width );
                }

                var vertical_tabs_width = tabs_holder.hasClass('vertical') && tabs_nav_wrapper.width() < 80 ? tabs_holder.width() : false;
                if( vertical_tabs_width ){
                    bps_tabs_to_accordion( tabs_holder, vertical_tabs_width );
                }

            } else {

                if ( tabs_holder.hasClass('bps-accordion-switched') ) {
                    var resized_on = tabs_holder.attr('data-resized-on');
                    if(resized_on && resized_on < tabs_holder.width()){
                        bps_init_tabs( tabs_holder );
                    }
                } 
            }

        }); 

    } 

    function bps_init_tabs(obj){

            var tabs_holder = obj; 
            var tabs_nav_wrapper = tabs_holder.find('.bps_tabs_nav');  
            var tabs_content = tabs_holder.find('.bps_tab_item, .bps_accordion_item');

            tabs_holder.removeClass('bps_accordion bps-accordion-switched');
            tabs_holder.find('.bps_accordion_item, .bps_tab_item').remove();
            tabs_nav_wrapper.show();
            
            if ( tabs_holder.hasClass('vertical') ) {
                tabs_holder.css('padding' , '0 0 0 19.9%');
            } else {
                tabs_holder.css('padding' , '40px 0 0 0');
            }

            tabs_content.each(function(){
                tabs_nav_wrapper.append('<div class="bps_tab_nav_item">' + $(this).find('.nav').html() + '</div>');
                
                if ( $(this).hasClass('bps_accordion_item') ) {
                    tabs_holder.append('<div class="bps_tab_item" style="display:none;">' + $(this).find('.bps_accordion_content').html() + '</div>').hide();
                } else {
                    tabs_holder.append('<div class="bps_tab_item" style="display:none;">' + $(this).html() + '</div>').hide();
                }

            });

            tabs_nav_wrapper.find('.bps_tab_nav_item:first').addClass('active');
            tabs_holder.find('.nav').hide();
            tabs_holder.find('.bps_tab_item:first').show();
            tabs_holder.show(); 


    }

    function bps_check_tabs_width(obj) {

        var tabs_nav_wrapper = obj.find('.bps_tabs_nav');
        var tabs_width = tabs_nav_wrapper.width();
        var tab = tabs_nav_wrapper.find('.bps_tab_nav_item');
        var tab_width = 0;
            
        tab.each(function(){
            tab_width += $(this).outerWidth();
        });

        if ( tabs_width <= tab_width + 24 ) {
            return tabs_width;
        }
        return false;
    }


    function bps_tabs_to_accordion( obj, resized_on ) {
        
        var tabs_holder = obj; 
        var tabs_nav_wrapper = tabs_holder.find('.bps_tabs_nav');  
        var tabs_content = tabs_holder.find('.bps_tab_item');    
        
        tabs_holder.addClass('bps_accordion bps-accordion-switched').attr('data-resized-on', resized_on);
        tabs_holder.find('.bps_tab_item').remove();
        tabs_nav_wrapper.children().remove();
        tabs_nav_wrapper.hide();
        tabs_holder.css({
            'display' : 'block',
            'padding' : 0
        });
        
        tabs_content.each(function(){
            tabs_holder.append('<div class="bps_accordion_item"><div class="bps_accordion_heading">' + $(this).find('.nav').html() + 
                '<i class="fa fa-plus"></i><i class="fa fa-minus"></i></div><div class="bps_accordion_content">' + $(this).html() + '</div></div>');
        });

        tabs_holder.find('.nav').hide();
        
    }

    function bps_accordion_handle($obj) {
        var toggle = $obj.parent('.bps_accordion_item');
        if (!toggle.hasClass('bps_accordion_active')) {
            toggle.parent('div').find('.bps_accordion_item').find('.bps_accordion_content:visible').slideUp("fast");
            toggle.parent('div').find('.bps_accordion_active').removeClass('bps_accordion_active');
            toggle.find('.bps_accordion_content').slideToggle("fast", function() {
                toggle.addClass('bps_accordion_active');
                if ((toggle.offset().top + 100) < $(window).scrollTop()) {
                    $('html, body').stop().animate({
                        scrollTop: (toggle.offset().top - 100)
                    }, '300');
                }
            });
        } else {
            toggle.parent('div').find('.bps_accordion_item').find('.bps_accordion_content:visible').slideUp("fast");
            toggle.parent('div').find('.bps_accordion_active').removeClass('bps_accordion_active');
        }
    }

    function bps_toggle_handle($obj) {
        var toggle = $obj.parent('.bps_toggle');
        toggle.find('.bps_toggle_content').slideToggle("fast", function() {
            toggle.toggleClass('bps_toggle_active');
        });
    }

    function bps_tab_handle($obj) {
        if ($obj.hasClass('active') === false) {

            tab_to_show = $obj.parent('.bps_tabs_nav').find('.bps_tab_nav_item').index($obj);

            $obj.parent('.bps_tabs_nav').parent('.bps_tabs').find('.bps_tab_item').hide();
            $obj.parent('.bps_tabs_nav').parent('.bps_tabs').find('.bps_tab_item').eq(tab_to_show).show();

            $obj.parent('.bps_tabs_nav').find('.bps_tab_nav_item').removeClass('active');
            $obj.addClass('active');

        }
    }

})(jQuery);