<form id="bps_shortcode_tabs">
	
	<table class="form-table">
		<tbody>
			<tr>
		 		<th><h3><?php _e('Options','binary-flexible-shortcodes'); ?></h3></th><td>&nbsp;</td>
			</tr>
	   <tr>
		<tr>
				<th><?php _e('Number of items','binary-flexible-shortcodes'); ?>:</th>
				<td><input type="text" name="num_items" value="3" class="small-text" /></td>
		</tr>
		
		<tr>
				<th>
					<?php _e('Navigation type','binary-flexible-shortcodes'); ?>:
				</th>
				<td>
					<input type="radio" name="nav" value="horizontal" checked /> <?php _e('Horizontal','binary-flexible-shortcodes'); ?>&nbsp;&nbsp;
					<input type="radio" name="nav" value="vertical"/> <?php _e('Vertical','binary-flexible-shortcodes'); ?>&nbsp;&nbsp;
				</td>
		</tr>
	
		<tr>
				<th><input type="submit" class="button-primary" value="<?php _e('Insert Tabs','binary-flexible-shortcodes'); ?>"></th> 
				<td>&nbsp;</td>
		</tr>
	
	</tbody>
	</table>
</form>

<script type="text/javascript">
	/* <![CDATA[ */
  (function($) {
    	$('#bps_shortcode_tabs').submit(function(e) {
    			e.preventDefault();
    			bps_shortcode_modal_obj.dialog('close');
    			var num_items = parseInt($(this).find('input[name="num_items"]').val());
    			var nav = $(this).find('input[name="nav"]:checked').val();
    			var content = '[bps_tabs nav="'+nav+'"]';
    			for(i=0; i < num_items; i++){
    				content += '<br/>[bps_tab_item title="Title '+(i+1)+'"]<br/>Example content '+(i+1)+'<br/>[/bps_tab_item]';
    			}
    			content += '<br/>[/bps_tabs]';
    			
    			bps_shortcode.setContent(content);
			});
			
			
			
	})(jQuery);
	/* ]]> */
</script>