<?php
/**
 * MC FORM About
 *
 * Class for handling the About & Add-ons page under mcForm
 *
 * @author BinaryPoets <hello@binarypoets.net>
 * @package mcForm - Premium Form System
 * @subpackage Admin\About
 * @codeCoverageIgnore
 */
class MC_FORM_About extends MC_FORM_Admin_Base {
	public function __construct() {
		$this->capability = 'manage_feedback';
		$this->action_nonce = 'mc_form_about_nonce';

		parent::__construct();

		$this->icon = 'dashboard';

		global $mc_form_settings;

		// Check if trackback page is set
		if ( $mc_form_settings['track_page'] == '0' || ! $mc_form_settings['track_page'] || $mc_form_settings['utrack_page'] == '0' || ! $mc_form_settings['utrack_page'] ) {
			if ( ! isset( $_GET['action'] )|| $_GET['action'] != 'form_setup_wizard' ) {
				add_action( 'admin_notices', array( $this, 'form_trackback_notice' ) );
			}
		}
	}

	public function form_trackback_notice() {
		?>
		<div class="notice notice-warning">
			<p><?php _e( 'mcForm requires setting up two specific pages. To get started, please <a href="admin.php?page=mc_form_about&action=form_setup_wizard" class="button-primary">click here</a>.', 'mc_form' ); ?></p>
		</div>
		<?php
	}

	/*==========================================================================
	 * SYSTEM METHODS
	 *========================================================================*/

	public function admin_menu() {
		$this->pagehook = add_submenu_page( 'mc_form_dashboard', __( 'mcForm - Premium Form System', 'mc_form' ), __( 'Addons & Guide', 'mc_form' ), $this->capability, 'mc_form_about', array( $this, 'index' ) );
		parent::admin_menu();
	}

	public function index() {
		if ( isset( $_GET['action'] ) && $_GET['action'] == 'form_setup_wizard' ) {
			$this->setup_wizard();
			return;
		}
		$this->wizard_complete();
	}

	/*==========================================================================
	 * Interacting with BinaryPoets JSON API
	 *========================================================================*/

	public function get_mc_form_json() {
		if ( false === ( $mc_form_json = get_transient( 'mc_form_json' ) ) ) {
			// It wasn't there, so regenerate the data and save the transient
			// And rmcform version and addons
			// Then return
			$do_not_set = false;
			$mc_form_api = wp_remote_get( 'https://www.binarypoets.net/wp-json/mc-api/v1/form/' );

			if ( ! is_wp_error( $mc_form_api ) ) {
				try {
					$mc_form_json = $this->formulate_response_json( wp_remote_retrieve_body( $mc_form_api ) );
					if ( $mc_form_json == false ) {
						$mc_form_json = array(
							'version' => MC_FORM_Loader::$version,
							'url' => '',
							'addons' => array(),
						);
						$do_not_set = true;
					}
				} catch ( Exception $e ) {
					// Some error
					// So we revert back to empty values
					$mc_form_json = array(
						'version' => MC_FORM_Loader::$version,
						'url' => '',
						'addons' => array(),
					);
					$do_not_set = true;
				}
			} else {
				// Some error
				// So we revert back to empty values
				$mc_form_json = array(
					'version' => MC_FORM_Loader::$version,
					'url' => '',
					'addons' => array(),
				);
				$do_not_set = true;
			}

			if ( ! $do_not_set ) {
				// Set the transient and make it expire after 7 days
				set_transient( 'mc_form_json', $mc_form_json, ( 7 * 24 * 60 * 60 ) );
			} else {
				// Set the transient but only for a day
				// Why make the site slow because of BinaryPoets.com errors?
				set_transient( 'mc_form_json', $mc_form_json, ( 24 * 60 * 60 ) );
			}
		}
		return $mc_form_json;
	}

	private function formulate_response_json( $body ) {
		$json = json_decode( $body, true );
		if ( ! is_array( $json ) || ! isset( $json['ep'] ) ) {
			$json = false;
		}
		return $json;
	}


	/*==========================================================================
	 * Primary Setup
	 *========================================================================*/
	public function setup_wizard() {

		global $mc_form_settings;

		if ( ! current_user_can( 'manage_feedback' ) ) {
			$this->ui->msg_error( __( 'You do not have sufficient permission to complete FORM setup. Please contact your administrator', 'mc_form' ) );
			return;
		}

		// respond to the wizard
		if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
			$this->wizard_update();
		}
		$this->index_head( __( 'mcForm <span class="mc-icomoon-arrow-right2"></span> Setup Wizard', 'mc_form' ), false );
		echo '<form method="POST" action="admin.php?page=mc_form_about&action=form_setup_wizard">';
		if ( $mc_form_settings['email'] == '' ) {
			$this->ui->iconbox( __( 'Set Notification Email', 'mc_form' ), array( $this, 'wizard_email' ), 'envelope' );
		} else if ( $mc_form_settings['track_page'] == '0' || ! $mc_form_settings['track_page'] ) {
			$this->ui->iconbox( __( 'Set Trackback Page', 'mc_form' ), array( $this, 'wizard_track' ), 'file-text' );
		} else if ( $mc_form_settings['utrack_page'] == '0' || ! $mc_form_settings['utrack_page'] ) {
			$this->ui->iconbox( __( 'Set User Portal Page', 'mc_form' ), array( $this, 'wizard_utrack' ), 'user' );
		} else {
			$this->ui->msg_okay( __( 'Congratulations! You have completed the setup of mcForm. Now head to <a href="admin.php?page=mc_form_all_forms">All Forms</a> pages to get started.', 'mc_form' ) );
		}
		echo '</form>';
		$this->index_foot( false, '', '', false );
	}

	public function wizard_complete() {
		global $mc_form_info;
		delete_transient( 'mc_form_json' );
		$mc_form_json = $this->get_mc_form_json();

		$addons = $mc_form_json['addons'];
		?>
<style type="text/css">
	.plugin-card a {
		text-decoration: none;
	}
	.col iframe {
		max-width: 100%;
	}
</style>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		var hashtags = [];
		$('.nav-tab-wrapper a').each(function() {
			var elm = $( $(this).attr('href') );
			hashtags[$(this).attr('href')] = $(this);
			if ( $(this).hasClass('nav-tab-active') ) {
				elm.show();
			} else {
				elm.hide();
			}
		});
		$('.nav-tab-wrapper').on( 'click', 'a', function(e) {
			e.preventDefault();
			$(this).siblings('a').removeClass('nav-tab-active').each(function() {
				$( $(this).attr('href') ).stop(true, true).hide();
			});
			$(this).addClass('nav-tab-active');
			$( $(this).attr('href') ).fadeIn('fast');
		} );
		// Check if hashtag is there
		var winHash = window.location.hash.replace( '!', '' );
		if ( hashtags[winHash] != undefined ) {
			hashtags[winHash].trigger('click');
		}
	});
</script>
<div class="wrap about-wrap">
	<h1><?php printf( __( 'Welcome to %2$s - %1$s', 'mc_form' ), MC_FORM_Loader::$version, 'iForm' ); ?></h1>
	<div class="about-text"><?php printf( __( 'Thank you for installing mcForm version %s. Please see below for available addons and new features.', 'mc_form' ), MC_FORM_Loader::$version ); ?></div>
	<div class="wp-badge" style="background-image: url('<?php echo MC_FORM_Loader::$static_location . 'admin/images/mcform-logo.png' ?>'); width: 140px; height: 140px; background-size: cover; background-repeat: no-repeat; background-position: center; padding: 0;"></div>

	<h2 class="nav-tab-wrapper">
		<a href="#form-addons" class="nav-tab nav-tab-active"><?php _e( 'Addons', 'mc_form' ); ?></a>
		<a href="#form-whats-new" class="nav-tab"><?php _e( 'What\'s New', 'mc_form' ); ?></a>
		<a href="#form-video-guide" class="nav-tab"><?php _e( 'Video Guides', 'mc_form' ); ?></a>
	</h2>
	<div id="form-whats-new">
		<p>
			<img src="<?php echo plugins_url( '/static/admin/images/wpquark-branding.jpg', MC_FORM_Loader::$abs_file ); ?>" />
		</p>
		<p>
			<img src="<?php echo plugins_url( '/static/admin/images/mcform-preview.png?version=' . MC_FORM_Loader::$version, MC_FORM_Loader::$abs_file ); ?>" />
		</p>
		<?php // translators: %2$s is replaced by current semver of mcForm ?>
		<h2><?php printf( __( '%2$s<sup style="font-size: 0.5em;">v%1$s</sup> - Premium Form System', 'mc_form' ), MC_FORM_Loader::$version, 'iForm' ); ?></h2>
		<p>Version 4.7 is out with further improvements to WooCommerce, Convertkit Integration and more.</p>
		<ul class="ul-disc">
			<li><strong>Live</strong> form builder.</li>
			<li><strong>Boxy</strong> element styling.</li>
			<li><strong>Offline Payment Gateway</strong> Support.</li>
			<li><strong>Authorize.net</strong> Payment Gateway.</li>
			<li>Better <strong>Stripe &amp; Paypal</strong> support.</li>
			<li><strong>Estimation Slider</strong> for quickly showing your client the cost breakdown.</li>
			<li><strong>Pricing Table</strong> form element to better convert your sales.</li>
			<li><strong>Buttons</strong> design element to get manual control of form buttons.</li>
		</ul>
		<p>We have completely rewritten the form builder internal script, resulting in a faster interface and better ux. We hope you like it and we are always open for suggestions.</p>
		<p><a href="https://www.binarypoets.net/releasing-mcform-version-4-7/" class="button button-primary">Read More</a></p>
		<p>
			<?php _e( 'For all of you who were enjoying mcForm, we hope that you find our changes arresting.', 'mc_form' ); ?>
		</p>
		<p>
			<?php _e( 'And if you are new to our system, we believe that you will find mcForm unparalled & appealing.', 'mc_form' ); ?>
		</p>
		<p>
			<?php _e( 'Thank you for believing - <a href="https://wpquark.com">Team @ BinaryPoets</a>.', 'mc_form' ); ?>
		</p>
		<h3><?php _e( 'Release Highlights', 'mc_form' ); ?></h3>
		<p><strong>Version 1.0.1</strong> Convertkit Integration, Migrate to WooCommerce CRUD API & manual form buttons. 6 new features, 3 enhancements and 4 bug fixes.</p>
		<p><strong>Version 4.6.1</strong> WooCommerce integration improvements to accept product variant Id and multiple status to mark submission as paid.</p>
		<p><strong>Version 4.6.0</strong> Complete form builder rewrite and ux improvement. 7 new features, 2 enhancements and 8 bug fixes.</p>
		<p><strong>Version 4.5.2</strong> 3 bug fixes.</p>
		<p><strong>Version 4.5.1</strong> Form Builder UX improvements.</p>
		<p><strong>Version 4.5.0</strong> Form Builder enhancement, new boxy theme, 2 updates and 5 bug fixes.</p>
		<p><strong>Version 4.2.1</strong> 1 enhancement and 1 bug fix.</p>
		<p><strong>Version 4.2.0</strong> 3 new features, 2 updates and 4 bug fixes.</p>
		<p><strong>Version 4.1.3</strong> 3 bug fixes.</p>
		<p><strong>Version 4.1.2</strong> 2 bug fixes.</p>
		<p><strong>Version 4.1.1</strong> 3 Enhancement, 1 bug fix and MailPoet 3 integration.</p>
		<p><strong>Version 4.1.0</strong> Subscription form and few bug fixes.</p>
		<p><strong>Version 4.0.3</strong> Minor bug fixes on Guest Blogging Element.</p>
		<p><strong>Version 4.0.2</strong> Minor bug fixes on Payment Forms.</p>
		<p><strong>Version 4.0.1</strong> Compatibility with MultiSite Cloning Plugins.</p>
		<p><strong>Version 4.0.0</strong> Focused improvement on payment features.</p>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3><?php _e( 'Refreshed Form Builder', 'mc_form' ); ?></h3>
				<p>With version 4.5, we have introduced split screen live form editing experience.</p>
				<ul class="ul-disc">
					<li><strong>CONFIG</strong>: Open form configuration window. From submission message, to form type, integrations, notifications, everything is included here at your disposal.</li>
					<li><strong>STYLE</strong>: Open form theme selector. You can select from many predefined color schemes, both light and dark version or create your own.</li>
					<li><strong>FORM ELEMENTS</strong>: Below the top toolbar, you will find form elements toolbar. Open relevant slide, and you will find individual elements which you can click or drag.</li>
					<li><strong>FORM PAGES</strong>: All forms are multipaged form by design. From here you can manage pages and settings.</li>
					<li><strong>ELEMENT LAYOUT</strong>: Finally sort, add and manage individual elements.</li>
				</ul>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/SylAM0uPxMw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3><?php _e( 'Boxy Themes', 'mc_form' ); ?></h3>
				<p>We have introduced traditional form element styling with this version.</p>
				<p>We call it <strong>Boxy Theme</strong> and it has the perfect harmony between modern interactiveness and classical looks.</p>
				<p>Do check them out. Under <code>STYLE</code> just select <strong>Boxy</strong> element design.</p>
				<p>They work with existing color schemes.</p>
			</div>
			<div class="col">
				<img src="<?php echo plugins_url( '/static/admin/images/mcform-boxy-theme.png', MC_FORM_Loader::$abs_file ); ?>" alt="<?php esc_attr_e( 'Eform Material Theme', 'mc_form' ) ?>">
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3>Stripe Subscription Payment System</h3>
				<p>mcForm Version 4.1 brings in new subscription system. Now you can make your users subscribe to your plans.</p>
				<p>With Stripe you can select a static plan or create a dynamic plan on the go and assign customer to the plans. Once created, your customers will be able to access and use their saved Credit Cards to easily subscribe to other plans / forms.</p>
				<p>This is just the first iteration of subscription system. In future we will introduce subscription portals (from where users can access their old subscriptions and cards) and more gateways.</p>
				<p><a href="https://www.binarypoets.net/kb/form/payment-system/" class="button button-secondary">Read More</a></p>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/bw3m53MOwOI" frameborder="0" gesture="media" allowfullscreen></iframe>
			</div>
		</div>
		<div class="feature-section two-col">
			<div class="col">
				<h3>Better Payment System</h3>
				<p>mcForm Version 4.0 comes with a better payment system. The payment form has been simplified and now includes zip and address fields for direct credit card payments.</p>
				<p>Stripe and PayPal both have been rewritten using latest SDK. Now you will need to enter <strong>Stripe Publisahable Key</strong> in the form settings and as per Stripe recommendation, the CC fields won't touch your server. So you can worry less about PCI compliance when paying through Stripe.</p>
				<p>Authorize.net has also been integrated as a gateway for mcForm. It will accept Credit Card as payment handler.</p>
				<p>To complement the changes, we have introduced a new element, <strong>Pricing Table</strong> and a new interface <strong>Estimation Slider</strong>.</p>
				<p>You can about them in our knowledgebase.</p>
				<p><a href="https://www.binarypoets.net/kb/form/payment-system/" class="button button-secondary">Read More</a></p>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/D9LF9hsl8bQ" frameborder="0" allowfullscreen></iframe>
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3>Interactive Form Elements</h3>
				<p>All modern forms should support interactive elements. Meaning, the value of one form element, changes the heading, label or description of another element.</p>
				<p>Up until now, mcForm didn't support this. But no more.</p>
				<p>Interactivity has been added to almost all elements. You can simply put template tags like <code>%M0%</code> to show the value of MCQ element with key 0 anywhere in your form. It works for element title, subtitle, option labels and almost everywhere.</p>
				<p>To learn how to activate, read our knowledgebase.</p>
				<p><a href="https://www.binarypoets.net/kb/form/form-form/interactive-form-piping-element-value-labels/" class="button button-secondary">Read More</a></p>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/_MRcFH6gFVI" frameborder="0" allowfullscreen></iframe>
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3>Input Masking</h3>
				<p>We have extended validation tools with the support for input masking.</p>
				<p>Now you can force a certain pattern when expecting freetype input from user.</p>
				<p>Check out the example on the video to see how we are setting Social Security Number, Driver's License etc with valid input masks.</p>
				<p>Read our knowledgebase to learn how to set it up.</p>
				<p><a href="https://www.binarypoets.net/kb/form/form-form/make-form-elements-not-required-and-customize-validation-filters/#mc_kb_toc_5947_4" class="button button-secondary">Read More</a></p>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/6-86BFEuAtc" frameborder="0" allowfullscreen></iframe>
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3><?php _e( 'Material Themes', 'mc_form' ); ?></h3>
				<p><?php _e( 'mcForm v3.5 comes with 38 material inspired themes. We even have a customizer from where you can pick your color and create your own theme.', 'mc_form' ); ?></p>
				<p><?php _e( 'All previous themes has been deprecated and removed. If your forms were using one, it will be upgraded automatically.' ) ?></p>
				<p><?php _e( 'We plan to revamp Bootstrap theme and add more skins in future.', 'mc_form' ); ?></p>
			</div>
			<div class="col">
				<img src="<?php echo plugins_url( '/static/admin/images/mcform-material-theme.jpg', MC_FORM_Loader::$abs_file ); ?>" alt="<?php esc_attr_e( 'Eform Material Theme', 'mc_form' ) ?>">
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3><?php _e( 'Repeatable Element', 'mc_form' ); ?></h3>
				<p><?php _e( 'mcForm v3.5 comes with a new form element, called Repeatable Element.', 'mc_form' ); ?></p>
				<p><?php _e( 'You can use this to give users option to add more "rows" to the form. Every repeatable element can have any number of elements from radio, checkboxes, dropdowns or texts.' ) ?></p>
				<p><?php _e( 'Given the option, your users can repeat the grouped elements in any number they want.', 'mc_form' ); ?></p>
				<p><?php _e( 'Of course we have provided configuration for limiting repeats between a minimum and a maximum value.', 'mc_form' ); ?></p>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/ddahLkHcyjk" frameborder="0" allowfullscreen></iframe>
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3><?php _e( 'WooCommerce Integration', 'mc_form' ); ?></h3>
				<p><?php _e( 'mcForm now integrates smoothly with WooCommerce. This brings the power of WooCommerce checkout and mcForm customizability together for your users.', 'mc_form' ); ?></p>
				<ul class="ul-disc">
					<li><?php _e( 'Create a dummy WooCommerce Product and note down the ID.', 'mc_form' ); ?></li>
					<li><?php _e( 'Setup an mcForm with mathematical element and enable WooCommerce from Payment tab.', 'mc_form' ); ?></li>
					<li><?php _e( 'Simply let mcForm decide product price and WooCommerce handles the rest.', 'mc_form' ); ?></li>
					<li><?php _e( 'Optionally use conditional logic to select different product for different cases.', 'mc_form' ); ?></li>
				</ul>
				<p><?php _e( 'Product attributes are added directly from the mathematical formula and are always shown both to user and admin. So you would not need to check in the submission to get the data.', 'mc_form' ); ?></p>
				<p><a href="https://www.binarypoets.net/kb/form/payment-system/woocommerce-integration-mcform/" target="_blank"><?php _e( 'Read More', 'mc_form' ); ?></a></p>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/Jj4TvH2oTrs" frameborder="0" allowfullscreen></iframe>
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3><?php _e( 'WP Core Integration', 'mc_form' ); ?></h3>
				<p><?php _e( 'mcForm v3.4 has introduced features to incorporate some of the core WordPress functionalities.' ) ?></p>
				<ul class="ul-disc">
					<li><?php _e( 'Show a login form through shortcode. Redirect to desired page after login.', 'mc_form' ); ?></li>
					<li><?php _e( 'Let user register through submitting mcForm. Additionally assign custom or built in user meta data through any of the mcForm elements.', 'mc_form' ); ?></li>
					<li><?php _e( 'Let user submit guest post anonymously or while logged in. Even register user while submitting a guest post and assign the article to the newly registered user.', 'mc_form' ); ?></li>
					<li><?php _e( 'Let user update metadata by filling out an mcForm.', 'mc_form' ); ?></li>
				</ul>
				<p><?php _e( 'Check the video to get an idea of how WP Core integration works. Do checkout our documentation for more information and implementation guide.', 'mc_form' ); ?></p>
				<p><a href="https://www.binarypoets.net/kb/form/wp-core-integrations/" target="_blank"><?php _e( 'Read More', 'mc_form' ); ?></a></p>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/XCDLoNHuOFo" frameborder="0" allowfullscreen></iframe>
			</div>
		</div>
		<hr />
		<div class="feature-section two-col">
			<div class="col">
				<h3><?php _e( 'Statistics Shortcodes', 'mc_form' ); ?></h3>
				<p><?php _e( 'Now show-off how your forms and users are performing with the new statistics shortcodes.', 'mc_form' ); ?></p>
				<p><?php _e( 'With mcForm v3.4 we have introduced a total of six beautifully crafted shortcodes for publishing quick stats.', 'mc_form' ); ?></p>
				<ul class="ul-disc">
					<li><?php _e( 'Form and User submission breakdown.', 'mc_form' ); ?></li>
					<li><?php _e( 'Form and User score breakdown.', 'mc_form' ); ?></li>
					<li><?php _e( 'Form and User overall submission statistics.', 'mc_form' ); ?></li>
				</ul>
				<p><?php _e( 'Each shortcode can handle multiple forms at once. Moreover, user shortcodes can be tuned for currently logged in users and can show a login form otherwise.', 'mc_form' ); ?></p>
				<p><?php _e( 'Our advice is to use user statistics in the user portal page.', 'mc_form' ); ?></p>
			</div>
			<div class="col">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/MIyMDOAH3Ug" frameborder="0" allowfullscreen></iframe>
			</div>
		</div>
		<hr />
		<div class="changelog">
			<h2><?php _e( 'Under the Hood', 'mc_form'); ?></h2>
			<div class="under-the-hood three-col">
				<div class="col">
					<h3>New ApiGen Documentation</h3>
					<p>Working with mcForm functions and classes has been easier thanks to our refactored codebase. Now the documentation can be found online.</p>
					<p><a href="https://wpq-develop.wpquark.xyz/mc-estimator/docs/apigen/" class="button button-secondary">ApiGen Documenation</a></p>
				</div>
				<div class="col">
					<h3>New Action &amp; Filter Reference</h3>
					<p>We have integrated a build system to generate all mcForm actions and hooks. Use this list if you are trying to extend mcForm.</p>
					<p><a href="https://wpq-develop.wpquark.xyz/mc-estimator/docs/apiwp/" class="button button-secondary">Hook Reference</a></p>
				</div>
				<div class="col">
					<h3>Automatic Plugin Updates through DevOps</h3>
					<p>We use <a href="https://about.gitlab.com">GitLab</a> for our development lab. We have leveraged the powerful CI/CD to streamline our workflow. Now you will get automatic updates once you have activated mcForm.</p>
					<p>The current status of the development can be found here.</p>
					<p><a href="https://wpq-develop.wpquark.xyz/mc-estimator/" class="button button-secondary">mcForm DevOps</a></p>
				</div>
			</div>
				<div class="under-the-hood three-col">
					<div class="col">
						<h3><?php _e( 'Developer\'s API', 'mc_form' ); ?></h3>
						<p><?php _e( 'mcForm now comes with a comprehensive <a href="http://wpquark.com/kb/form/form-api/" target="_blank">Developer\'s API</a>. If you wish to extend mcForm with newer elements or want to integrate with your mailing system, it is now possible without touching the core.', 'mc_form' ); ?></p>
					</div>
					<div class="col">
						<h3><?php _e( 'Complete Javascript Rewrite', 'mc_form' ); ?></h3>
						<p><?php _e( 'Both frontend and backend rendering are now upto 400% faster. We have rewritten every javascript code from scratch and we now enqueue minified files only. But all minified files have source mapping which is cool for console debugging.', 'mc_form' ); ?></p>
					</div>
					<div class="col">
						<h3><?php _e( 'Updated Format Strings', 'mc_form' ); ?></h3>
						<p><?php _e( 'Now both admin and user notification email, as well as success message have all the <a href="http://wpquark.com/kb/form/form-submission-related/available-format-strings-custom-notifications/" target="_blank">formatting strings</a> available. We even added mathematical evaluator fields to the format strings.' ) ?></p>
					</div>
				</div>

				<div class="under-the-hood three-col">
					<div class="col">
						<h3><?php _e( 'Theme My Login Compatibility', 'mc_form' ); ?></h3>
						<p><?php _e( 'mcForm now just works with TML, peace.', 'mc_form' ); ?></p>
					</div>
					<div class="col">
						<h3><?php _e( 'Visual Composer Compatibility', 'mc_form' ); ?></h3>
						<p><?php _e( 'mcForm now works with any version of Visual Composer. We implemented a rather smart way to bypass any version of jQuery WayPoints library loaded in any order.', 'mc_form' ); ?></p>
					</div>
					<div class="col">
						<h3><?php _e( 'Admin Notification Improvement', 'mc_form' ); ?></h3>
						<p><?php _e( 'Admin <code>from</code> address can now be changed. It adds a <code>from</code> and <code>reply-to</code> header while keeping the <code>sender</code> header originating from your domain.', 'mc_form' ); ?></p>
						<p><?php _e( 'Additionally you can configure to add just <code>reply-to</code> and not add <code>from</code> to play nice with Yahoo Emails.', 'mc_form' ); ?></p>
					</div>
				</div>
			<div class="return-to-dashboard">
				<a href="admin.php?page=mc_form_dashboard"><?php _e( 'Go to mcForm → Dashboard', 'mc_form' ); ?></a>
			</div>
		</div>

		<div class="clear"></div>
	</div>
	<div id="form-video-guide" class="mc_uif">
		<h3><?php _e( 'Basic mcForm Setup', 'mc_form' ); ?></h3>
		<div class="golden-video-wrap">
			<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLtWVAk_srzCa7qxBN4oqW9KjAdlW6wjA1" frameborder="0" allowfullscreen></iframe>
		</div>
		<h3><?php _e( 'Advanced mcForm Setup', 'mc_form' ); ?></h3>
		<div class="golden-video-wrap">
			<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLtWVAk_srzCbZijXogkXQNoC5Pc_U5h7z" frameborder="0" allowfullscreen></iframe>
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
<?php $this->populate_addons( $addons ); ?>
<div class="mc_uif">
	<p>
		<?php printf( __( '<strong>Plugin Version:</strong> <em>%s(Scrmc)/%s(DB)</em>', 'mc_form' ), MC_FORM_Loader::$version, $mc_form_info['version'] ); ?> | <?php _e( 'Icons Used from: ', 'mc_form' ); ?> <a href="http://icomoon.io/" title="IcoMoon" target="_blank">IcoMoon</a>
		<br />
		<span class="description">
			<?php _e( 'If the Scrmc version and DB version do not match, then deactivate the plugin and reactivate again. This should solve the problem. If the problem persists then contact the developer.', 'mc_form' ); ?>
		</span>
	</p>
</div>
		<?php
	}

	public function populate_addons( $addons, $id = 'form-addons' ) {
		if ( empty( $addons ) || ! is_array( $addons ) ) {
			?>
			<p><?php _e( 'We have not published any addons yet. Please stay tuned.', 'mc_form' ) ?></p>
			<?php
			return;
		}
		?>
<style type="text/css">
	body .plugin-card-top {
		min-height: 190px;
	}
</style>
<div id="form-addons" class="wrap">
	<div id="the-list">
		<?php foreach ( $addons as $akey => $addon ) : ?>
		<?php
		$exists = false;
		if ( class_exists( $addon['class'] ) ) {
			$exists = true;
		}
		?>
		<div class="plugin-card plugin-card-<?php echo $akey; ?>">
			<div class="plugin-card-top">
				<div class="name column-name">
					<h3>
						<?php if ( $addon['url'] != '' ) : ?>
						<a href="<?php echo $addon['url']; ?>">
						<?php endif; ?>
						<?php echo $addon['name']; ?>
						<img src="<?php echo $addon['image']; ?>" class="plugin-icon" alt="">
						<?php if ( $addon['url'] != '' ) : ?>
						</a>
						<?php endif; ?>
					</h3>
				</div>
				<div class="action-links">
					<ul class="plugin-action-buttons">
						<?php if ( $exists ) : ?>
						<li><button class="install-now button disabled" disabled="disabled"><?php _e( 'Active', 'mc_form' ); ?></button></li>
						<li><small><?php printf( __( 'version: %1$s', 'mc_form' ), $addon['class']::$version ); ?></small></li>
						<?php else : ?>

						<?php if ( $addon['url'] != '' ) : ?>
						<li><a target="_blank" class="install-now button" href="<?php echo $addon['url']; ?>"><?php _e( 'Install Now', 'mc_form' ); ?></a></li>
						<?php else : ?>
						<li><a target="_blank" class="install-now button disabled" disabled href="javascript:void(null);"><?php _e( 'Coming Soon', 'mc_form' ); ?></a></li>
						<?php endif; ?>

						<?php endif; ?>
					</ul>
				</div>
				<div class="desc column-description">
					<?php echo wpautop( $addon['description'] ); ?>
					<p class="authors"> <cite><?php printf( __( 'By <a href="%1$s">%2$s</a>', 'mc_form' ), $addon['authorurl'], $addon['author'] ); ?></cite></p>
				</div>
			</div>
			<div class="plugin-card-bottom">
				<div class="vers column-rating">
					<div class="star-rating" title="<?php printf( esc_attr__( '%1$s rating based on %2$s ratings', 'mc_form' ), $addon['star'], $addon['starnum'] ); ?>"><?php
					$max_star = floor( $addon['star'] );
					// First print all the full stars
					for ( $i = 1; $i <= $max_star && $i <= 5; $i++ ) {
						echo '<div class="star star-full"></div>';
					}
					// Now adjust the half/full star for next
					if ( $max_star < 5 ) {
						$adjuster = $addon['star'] - $max_star;
						if ( $adjuster > 0.7 ) {
							echo '<div class="star star-full"></div>';
						} else if ( $adjuster <= 0.7 && $adjuster >= 0.3 ) {
							echo '<div class="star star-half"></div>';
						} else {
							echo '<div class="star star-empty"></div>';
						}
					}
					// Now print the rest empty stars
					if ( ( $max_star + 1 ) < 5 ) {
						for ( $i = 0; $i < ( 4 - $max_star ); $i++ ) {
							echo '<div class="star star-empty"></div>';
						}
					}
					?></div>
					<span class="num-ratings">(<?php echo $addon['starnum']; ?>)</span>
				</div>
				<div class="column-updated">
					<?php if ( $addon['url'] != '' ) : ?>
					<strong><?php _e( 'Last Updated:' , 'mc_form' ); ?></strong> <span> <?php echo date_i18n( get_option( 'date_format' ), strtotime( $addon['date'] ) ); ?> <small><?php printf( _x( '( %1$s )', 'mc_form_addon_version', 'mc_form' ), $addon['version'] ); ?></small></span>
					<?php else : ?>
					<strong><?php _e( 'Expected Release:' , 'mc_form' ); ?></strong> <span> <?php echo date_i18n( get_option( 'date_format' ), strtotime( $addon['date'] ) ); ?></span>
					<?php endif; ?>
				</div>
				<div class="column-downloaded">
					<?php if ( $addon['url'] != '' && $addon['downloaded'] > 0 ) : ?>
					<?php printf( __( '%d+ sales', 'mc_form' ), $addon['downloaded'] );; ?>
					<?php endif; ?>
				</div>
				<div class="column-compatibility">
					<?php if ( version_compare( get_bloginfo( 'version' ), $addon['compatible'], '>=' ) ) : ?>
					<span class="compatibility-compatible"><?php _e( '<strong>Compatible</strong> with your version of WordPress', 'mc_form' ); ?></span>
					<?php else : ?>
					<span class="compatibility-untested"><?php _e( 'Untested with your version of WordPress', 'mc_form' ); ?></span>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
</div>
<div class="clear"></div>
		<?php
	}

	public function wizard_update() {
		global $mc_form_settings;
		if ( isset( $this->post['form']['email'] ) ) {
			$mc_form_settings['email'] = $this->post['form']['email'];
		}
		if ( isset( $this->post['form']['track'] ) ) {
			$page_title = $this->post['form']['track']['title'];
			$form_label = $this->post['form']['track']['label'];
			$template = $this->post['form']['track']['template'];
			$submit = $this->post['form']['track']['submit'];

			$shortcode = '[mc_form_trackback label="' . $form_label . '" submit="' . $submit . '"]';

			$page_id = wp_insert_post( array(
				'post_title' => $page_title,
				'post_content' => $shortcode,
				'page_template' => $template,
				'post_type' => 'page',
				'post_status' => 'publish',
			) );
			if ( $page_id ) {
				$mc_form_settings['track_page'] = "$page_id";
				?>
				<div class="notice notice-success">
					<p><?php printf( __( 'Successfully created Trackback page. To edit, please <a target="_blank" href="post.php?post=%d&action=edit">click here</a>.', 'mc_form' ), $page_id ); ?></p>
				</div>
				<?php
			} else {
				?>
				<div class="notice notice-error">
					<p><?php printf( __( 'Cound not create the trackback page. Something must have went wrong. Please create a page manually and set it up from mcForm > Settings.', 'mc_form' ), $page_id ); ?></p>
				</div>
				<?php
			}
		}
		if ( isset( $_POST['form']['utrack'] ) ) {
			$page_title = $this->post['form']['utrack']['ptitle'];
			$template = $this->post['form']['utrack']['template'];

			$utrack_defaults = array(
				// 'content' => __( 'Welcome %NAME%. Below is the list of all submissions you have made.', 'mc_form' ),
				'nosubmission' => __( 'No submissions yet.', 'mc_form' ),
				'login' => __( 'You need to login in order to view your submissions.', 'mc_form' ),
				'show_register' => '0',
				'show_forgot' => '0',
				'formlabel' => __( 'Form', 'mc_form' ),
				'filters' => '0',
				'showcategory' => '0',
				'categorylabel' => __( 'Category', 'mc_form' ),
				'datelabel' => __( 'Date', 'mc_form' ),
				'showscore' => '0',
				'scorelabel' => __( 'Score', 'mc_form' ),
				'mscorelabel' => __( 'Max', 'mc_form' ),
				'pscorelabel' => __( '%-age', 'mc_form' ),
				'showremarks' => '0',
				'remarkslabel' => __( 'Remarks', 'mc_form' ),
				'linklabel' => __( 'View', 'mc_form' ),
				'actionlabel' => __( 'Action', 'mc_form' ),
				'editlabel' => __( 'Edit', 'mc_form' ),
				'avatar' => '96',
				'theme' => 'material-default',
				'title' => __( 'mcForm User Portal', 'mc_form' ),
				'logout_r' => '',
			);

			$shortcode = '[mc_form_utrackback';

			foreach ( $utrack_defaults as $key => $val ) {
				$attr = ' ' . $key . '="';
				// Checkboxes
				if ( is_numeric( $val ) && $val <= 1 ) {
					if ( isset( $this->post['form']['utrack'][$key] ) && '' != $this->post['form']['utrack'][$key] ) {
						$attr .= '1';
					} else {
						$attr .= '0';
					}
				// Else it is text
				} else {
					if ( isset( $this->post['form']['utrack'][$key] ) && '' != $this->post['form']['utrack'][$key] ) {
						$attr .= str_replace( '"', '&quot;', $this->post['form']['utrack'][$key] );
					} else {
						$attr .= $val;
					}
				}
				$attr .= '"';
				$shortcode .= $attr;
			}

			$shortcode .= ']' . $this->post['form']['utrack']['content'] . '[/mc_form_utrackback]';

			$page_id = null;
			$page_id = wp_insert_post( array(
				'post_title' => $page_title,
				'post_content' => $shortcode,
				'page_template' => $template,
				'post_type' => 'page',
				'post_status' => 'publish',
			) );
			if ( $page_id ) {
				$mc_form_settings['utrack_page'] = "$page_id";
				?>
				<div class="notice notice-success">
					<p><?php printf( __( 'Successfully created User Portal page. To edit, please <a target="_blank" href="post.php?post=%d&action=edit">click here</a>.', 'mc_form' ), $page_id ); ?></p>
				</div>
				<?php
			} else {
				?>
				<div class="notice notice-error">
					<p><?php printf( __( 'Cound not create the trackback page. Something must have gone wrong. Please create a page manually and set it up from mcForm > Settings.', 'mc_form' ), $page_id ); ?></p>
				</div>
				<?php
			}
		}
		update_option( 'mc_form_settings', $mc_form_settings );
	}

	public function wizard_email() {
		$buttons = array(
			array( __( 'Next', 'mc_form' ), '', 'large', 'primary', 'normal', array(), 'submit' ),
		);
		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'form[email]', __( 'Set Global Notification Email', 'mc_form' ) ); ?></th>
			<td>
				<?php $this->ui->text( 'form[email]', get_option( 'admin_email' ), __( 'Email address', 'mc_form' ) ); ?>
				<span class="description"><?php _e( 'This can be changed later from mcForm > Settings', 'mc_form' ); ?></span>
			</td>
		</tr>
	</tbody>
</table>
<?php $this->ui->buttons( $buttons ); ?>
		<?php
	}

	public function wizard_track() {
		$buttons = array(
			array( __( 'Next', 'mc_form' ), '', 'large', 'primary', 'normal', array(), 'submit' ),
		);

		?>
<table class="form-table">
	<tbody>
		<tr>
			<th><?php $this->ui->generate_label( 'form[track][title]', __( 'Page Title', 'mc_form' ) ); ?></th>
			<td><?php $this->ui->text( 'form[track][title]', __( 'Submission Confirmed', 'mc_form' ), __(  'WP Page Title', 'mc_form' ) ); ?></td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'form[track][template]', __( 'Page Template', 'mc_form' ) ); ?>
			</th>
			<td>
				<?php $this->ui->select( 'form[track][template]', $this->get_template_items(), '' ); ?><br />
				<span class="description"><?php _e( 'You can change the page template later from WordPress Pages.', 'mc_form' ); ?></span>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'form[track][label]', __( 'Form Label', 'mc_form' ) ); ?>
			</th>
			<td>
				<?php $this->ui->text( 'form[track][label]', __( 'Track Code', 'mc_form' ), __( 'Required', 'mc_form' ) ); ?><br />
				<span class="description"><?php _e( 'Enter the label of the text input where the surveyee will need to paste his/her trackback code.', 'mc_form' ); ?></span>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'form[track][submit]', __( 'Submit Button Label', 'mc_form' ) ); ?>
			</th>
			<td>
				<?php $this->ui->text( 'form[track][submit]', __( 'Submit', 'mc_form' ), __( 'Required', 'mc_form' ) ); ?><br />
				<span class="description"><?php _e( 'Enter the label of the submit button.', 'mc_form' ); ?></span>
			</td>
		</tr>
	</tbody>
</table>
<?php $this->ui->buttons( $buttons ); ?>
		<?php

	}

	public function wizard_utrack() {
		$buttons = array(
			array( __( 'Finish', 'mc_form' ), '', 'large', 'primary', 'normal', array(), 'submit' ),
		);
		$utrack_attrs = array(
			'login_attr' => array(
				'login' => __( 'Message to logged out users', 'mc_form' ),
				'show_register' => __( 'Show the registration button', 'mc_form' ),
				'show_forgot' => __( 'Show password recovery link', 'mc_form' ),
			),
			'portal_attr' => array(
				'title' => __( 'Welcome Title', 'mc_form' ),
				'content' => __( 'Welcome message', 'mc_form' ),
				'nosubmission' => __( 'No submissions message', 'mc_form' ),
				'formlabel' => __( 'Form Heading Label', 'mc_form' ),
				'filters' => __( 'Show Filters for Forms and Categories', 'mc_form' ),
				'showcategory' => __( 'Show Category', 'mc_form' ),
				'categorylabel' => __( 'Category Label', 'mc_form' ),
				'datelabel' => __( 'Date Heading Label', 'mc_form' ),
				'showscore' => __( 'Show Score Column', 'mc_form' ),
				'scorelabel' => __( 'Score Heading Label', 'mc_form' ),
				'mscorelabel' => __( 'Max Score Heading Label', 'mc_form' ),
				'pscorelabel' => __( 'Percentage Score Heading Label', 'mc_form' ),
				'showremarks' => __( 'Show Admin Remarks Column', 'mc_form' ),
				'remarkslabel' => __( 'Admin Remarks Label', 'mc_form' ),
				'actionlabel' => __( 'Action Column Heading Label', 'mc_form' ),
				'linklabel' => __( 'Trackback Button Label', 'mc_form' ),
				'editlabel' => __( 'Edit Button Label', 'mc_form' ),
				'avatar' => __( 'Avatar Size', 'mc_form' ),
				'theme' => __( 'Page Theme', 'mc_form' ),
				'logout_r' => __( 'Redirection after Logout', 'mc_form' ),
			),
		);
		$utrack_labels = array(
			'login_attr' => __( 'Login Page Modifications', 'mc_form' ),
			'portal_attr' => __( 'Portal Page Modifications', 'mc_form' ),
		);
		$utrack_defaults = array(
			'content' => __( 'Welcome %NAME%. Below is the list of all submissions you have made.', 'mc_form' ),
			'nosubmission' => __( 'No submissions yet.', 'mc_form' ),
			'login' => __( 'You need to login in order to view your submissions.', 'mc_form' ),
			'show_register' => '1',
			'show_forgot' => '1',
			'formlabel' => __( 'Form', 'mc_form' ),
			'filters' => '1',
			'showcategory' => '0',
			'categorylabel' => __( 'Category', 'mc_form' ),
			'datelabel' => __( 'Date', 'mc_form' ),
			'showscore' => '1',
			'scorelabel' => __( 'Score', 'mc_form' ),
			'mscorelabel' => __( 'Max', 'mc_form' ),
			'pscorelabel' => __( '%-age', 'mc_form' ),
			'showremarks' => '0',
			'remarkslabel' => __( 'Remarks', 'mc_form' ),
			'linklabel' => __( 'View', 'mc_form' ),
			'actionlabel' => __( 'Action', 'mc_form' ),
			'editlabel' => __( 'Edit', 'mc_form' ),
			'avatar' => '96',
			'theme' => 'material-default',
			'title' => __( 'mcForm User Portal', 'mc_form' ),
			'logout_r' => '',
		);
		$form_element = new MC_FORM_Form_Elements_Base();
		$themes = $form_element->get_available_themes();
		?>
		<h3><?php _e( 'Page Settings', 'mc_form' ); ?></h3>
		<table class="form-table">
			<tbody>
				<tr>
					<th><?php $this->ui->generate_label( 'form[utrack][ptitle]', __( 'Page Title', 'mc_form' ) ); ?></th>
					<td><?php $this->ui->text( 'form[utrack][ptitle]', __( 'Browse Submissions', 'mc_form' ), __(  'WP Page Title', 'mc_form' ) ); ?></td>
				</tr>
				<tr>
					<th>
						<?php $this->ui->generate_label( 'form[utrack][template]', __( 'Page Template', 'mc_form' ) ); ?>
					</th>
					<td>
						<?php $this->ui->select( 'form[utrack][template]', $this->get_template_items(), '' ); ?><br />
						<span class="description"><?php _e( 'You can change the page template later from WordPress Pages.', 'mc_form' ); ?></span>
					</td>
				</tr>
			</tbody>
		</table>
		<?php foreach ( $utrack_attrs as $attr => $labels ) : ?>
		<h3><?php echo $utrack_labels[$attr]; ?></h3>
		<table class="form-table">
			<?php foreach ( $labels as $key => $label ) : ?>
			<tr>
				<th>
					<?php $this->ui->generate_label( 'form[utrack][' . $key . ']', $label ); ?>
				</th>
				<td>
					<?php if ( $key == 'content' ) : ?>
					<?php $this->ui->textarea( 'form[utrack][' . $key . ']', $utrack_defaults[$key], __( 'Required', 'mc_form' ) ); ?>
					<?php elseif ( $key == 'theme' ) : ?>
					<select id="form_utrack_<?php echo $key; ?>" name="form[utrack][<?php echo $key; ?>]" class="mc_uif_select">
						<?php foreach ( $themes as $theme_grp ) : ?>
						<optgroup label="<?php echo $theme_grp['label']; ?>">
							<?php foreach ( $theme_grp['themes'] as $theme_key => $theme ) : ?>
							<option value="<?php echo $theme_key; ?>"<?php if ( $utrack_defaults[$key] == $theme_key ) echo ' selected="selected"'; ?>><?php echo $theme['label']; ?></option>
							<?php endforeach; ?>
						</optgroup>
						<?php endforeach; ?>
					</select>
					<?php elseif ( is_numeric( $utrack_defaults[$key] ) && $utrack_defaults[$key] <= 1 ) : ?>
					<input type="checkbox" value="1" class="" id="form_utrack_<?php echo $key; ?>" name="form[utrack][<?php echo $key; ?>]"<?php if ( $utrack_defaults[$key] == '1' ) echo ' checked="checked"'; ?> />
					<?php else : ?>
					<?php $this->ui->text( 'form[utrack][' . $key . ']', $utrack_defaults[$key], '' ); ?>
					<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; ?>
		</table>
		<?php endforeach; ?>
		<?php $this->ui->buttons( $buttons ); ?>
		<?php
	}

	public function get_template_items() {
		$templates = get_page_templates();
		$template_items = array();
		$template_items[] = array(
			'value' => '',
			'label' => __( 'Default page template', 'mc_form' ),
		);
		if ( ! is_array( $templates ) || count( $templates ) < 1 ) {
			return $template_items;
		}
		foreach ( $templates as $label => $value ) {
			$template_items[] = array(
				'value' => $value,
				'label' => $label,
			);
		}
		return $template_items;
	}
}
