<?php
/**
 * Font Awesome
 *
 */

require_once dirname( __FILE__ ) . '/font.php';

/**
 * Icon type: Font Awesome
 *
 */
class OE_Icon_Picker_Type_Font_Awesome_Solid extends OE_Icon_Picker_Type_Font {

	/**
	 * Icon type ID
	 *
	 */
	protected $id = 'fas';

	/**
	 * Icon type name
	 *
	 */
	protected $name = 'FontAwesome Solid';

	/**
	 * Icon type version
	 *
	 */
	protected $version = '5.11.2';

	/**
	 * Stylesheet ID
	 *
	 */
	protected $stylesheet_id = 'font-awesome';

	/**
	 * Get icon groups
	 *
	 */
	public function get_groups() {
		$groups = array(
			array(
				'id'   => 'solid',
				'name' => __( 'Solid', 'binary-extra' ),
			),
		);

		/**
		 * Filter genericon groups
		 *
		 */
		$groups = apply_filters( 'oe_icon_picker_fas_groups', $groups );

		return $groups;
	}

	/**
	 * Get icon names
	 *
	 */
	public function get_items() {
		$items = array(
			array(
				'group' => 'solid',
				'id'    => 'fa-ad',
				'name'  => __( 'AD', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-address-book',
				'name'  => __( 'Address Book', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-address-card',
				'name'  => __( 'Address Card', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-adjust',
				'name'  => __( 'Adjust', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-air-freshener',
				'name'  => __( 'Air Freshener', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-align-center',
				'name'  => __( 'Align Center', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-align-justify',
				'name'  => __( 'Align Justify', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-align-left',
				'name'  => __( 'Align Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-align-right',
				'name'  => __( 'Align Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-ambulance',
				'name'  => __( 'Ambulance', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-american-sign-language-interpreting',
				'name'  => __( 'American Sign Language', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-anchor',
				'name'  => __( 'Anchor', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-angle-double-down',
				'name'  => __( 'Angle Double Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-angle-double-left',
				'name'  => __( 'Angle Double Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-angle-double-right',
				'name'  => __( 'Angle Double Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-angle-double-up',
				'name'  => __( 'Angle Double Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-angle-down',
				'name'  => __( 'Angle Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-angle-left',
				'name'  => __( 'Angle Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-angle-right',
				'name'  => __( 'Angle Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-angle-up',
				'name'  => __( 'Angle Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-ankh',
				'name'  => __( 'Ankh', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-apple-alt',
				'name'  => __( 'Apple Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-archive',
				'name'  => __( 'Archive', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-archway',
				'name'  => __( 'Archway', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-alt-circle-down',
				'name'  => __( 'Arrow Alt Circle Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-alt-circle-left',
				'name'  => __( 'Arrow Alt Circle Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-alt-circle-right',
				'name'  => __( 'Arrow Alt Circle Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-alt-circle-up',
				'name'  => __( 'Arrow Alt Circle up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-circle-down',
				'name'  => __( 'Arrow Circle Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-circle-left',
				'name'  => __( 'Arrow Circle Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-circle-right',
				'name'  => __( 'Arrow Circle Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-circle-up',
				'name'  => __( 'Arrow Circle up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-down',
				'name'  => __( 'Arrow Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-left',
				'name'  => __( 'Arrow Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-right',
				'name'  => __( 'Arrow Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrow-up',
				'name'  => __( 'Arrow up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-arrows-alt',
				'name'  => __( 'Arrow Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-assistive-listening-systems',
				'name'  => __( 'Assistive Listening Systems', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-asterisk',
				'name'  => __( 'Asterisk', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-asterisk',
				'name'  => __( 'Asterisk', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-at',
				'name'  => __( 'At', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-atlas',
				'name'  => __( 'Atlas', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-atom',
				'name'  => __( 'Atom', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-audio-description',
				'name'  => __( 'Audio Description', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-award',
				'name'  => __( 'Award', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-baby',
				'name'  => __( 'Baby', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-baby-carriage',
				'name'  => __( 'Baby Carriage', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-backspace',
				'name'  => __( 'Backspace', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-backward',
				'name'  => __( 'Backward', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-balance-scale',
				'name'  => __( 'Balance Scale', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-ban',
				'name'  => __( 'Ban', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-barcode',
				'name'  => __( 'Barcode', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bars',
				'name'  => __( 'Bars', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-baseball-ball',
				'name'  => __( 'Baseball Ball', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-basketball-ball',
				'name'  => __( 'Basketball Ball', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bath',
				'name'  => __( 'Bath', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-battery-empty',
				'name'  => __( 'Battery Empty', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-battery-full',
				'name'  => __( 'Battery Full', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bed',
				'name'  => __( 'Bed', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-beer',
				'name'  => __( 'Beer', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bell',
				'name'  => __( 'Bell', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bell-slash',
				'name'  => __( 'Bell Slash', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bezier-curve',
				'name'  => __( 'Bezier Curve', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bicycle',
				'name'  => __( 'Bicycle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-biking',
				'name'  => __( 'Biking', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-binoculars',
				'name'  => __( 'Binoculars', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-biohazard',
				'name'  => __( 'Biohazard', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-birthday-cake',
				'name'  => __( 'Birthday Cake', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-blender',
				'name'  => __( 'Blender', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-blind',
				'name'  => __( 'Blind', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-blog',
				'name'  => __( 'Blog', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bold',
				'name'  => __( 'Bold', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bolt',
				'name'  => __( 'Bolt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bomb',
				'name'  => __( 'Bomb', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bong',
				'name'  => __( 'Bong', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-book',
				'name'  => __( 'Book', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bookmark',
				'name'  => __( 'Bookmark', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-border-all',
				'name'  => __( 'Border All', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-border-none',
				'name'  => __( 'Border None', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bowling-ball',
				'name'  => __( 'Bowling Ball', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-box',
				'name'  => __( 'Box', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-box-open',
				'name'  => __( 'Box Open', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-boxes',
				'name'  => __( 'Boxes', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-braille',
				'name'  => __( 'Braille', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-brain',
				'name'  => __( 'Brain', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bread-slice',
				'name'  => __( 'Bread Slice', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-briefcase',
				'name'  => __( 'Briefcase', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-briefcase-medical',
				'name'  => __( 'Briefcase Medical', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-broadcast-tower',
				'name'  => __( 'Broadcast Tower', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-broom',
				'name'  => __( 'Broom', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-brush',
				'name'  => __( 'Brush', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bug',
				'name'  => __( 'Bug', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-building',
				'name'  => __( 'Building', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bullhorn',
				'name'  => __( 'Bullhorn', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bullseye',
				'name'  => __( 'Bullseye', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-burn',
				'name'  => __( 'Burn', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-bus-alt',
				'name'  => __( 'Bus Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-business-time',
				'name'  => __( 'Business Time', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-calculator',
				'name'  => __( 'Calculator', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-calendar',
				'name'  => __( 'Calendar', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-calendar-alt',
				'name'  => __( 'Calendar Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-calendar-check',
				'name'  => __( 'Calendar Check', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-calendar-day',
				'name'  => __( 'Calendar Day', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-calendar-minus',
				'name'  => __( 'Calendar Minus', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-calendar-plus',
				'name'  => __( 'Calendar Plus', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-calendar-times',
				'name'  => __( 'Calendar Times', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-camera',
				'name'  => __( 'Camera', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-camera-retro',
				'name'  => __( 'Camera Retro', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-campground',
				'name'  => __( 'Campground', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cannabis',
				'name'  => __( 'Cannabis', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-capsules',
				'name'  => __( 'Capsules', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-car',
				'name'  => __( 'Car', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-caret-down',
				'name'  => __( 'Caret Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-caret-left',
				'name'  => __( 'Caret Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-caret-right',
				'name'  => __( 'Caret Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-caret-square-down',
				'name'  => __( 'Caret Square Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-caret-square-left',
				'name'  => __( 'Caret Square Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-caret-square-right',
				'name'  => __( 'Caret Square Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-caret-square-up',
				'name'  => __( 'Caret Square Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-caret-up',
				'name'  => __( 'Caret Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-carrot',
				'name'  => __( 'Carrot', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cart-plus',
				'name'  => __( 'Cart Plus', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-certificate',
				'name'  => __( 'Certificate', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chart-area',
				'name'  => __( 'Chart Area', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chart-bar',
				'name'  => __( 'Chart Bar', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chart-line',
				'name'  => __( 'Chart Line', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chart-pie',
				'name'  => __( 'Chart Pie', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-check',
				'name'  => __( 'Check', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-check-circle',
				'name'  => __( 'Check Circle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-check-double',
				'name'  => __( 'Check Double', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-check-square',
				'name'  => __( 'Check Square', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cheese',
				'name'  => __( 'Cheese', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chess',
				'name'  => __( 'Chess', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chess-king',
				'name'  => __( 'Chess King', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chess-queen',
				'name'  => __( 'Chess Queen', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chevron-circle-down',
				'name'  => __( 'Chevron Circle Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chevron-circle-left',
				'name'  => __( 'Chevron Circle Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chevron-circle-right',
				'name'  => __( 'Chevron Circle Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chevron-circle-up',
				'name'  => __( 'Chevron Circle Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chevron-down',
				'name'  => __( 'Chevron Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chevron-left',
				'name'  => __( 'Chevron Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chevron-right',
				'name'  => __( 'Chevron Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-chevron-up',
				'name'  => __( 'Chevron Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-child',
				'name'  => __( 'Child', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-circle',
				'name'  => __( 'Circle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-circle-notch',
				'name'  => __( 'Circle Notch', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-clinic-medical',
				'name'  => __( 'Clinic Medical', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-clipboard',
				'name'  => __( 'Clipboard', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-clipboard-check',
				'name'  => __( 'Clipboard Check', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-clipboard-list',
				'name'  => __( 'Clipboard List', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-clock',
				'name'  => __( 'Clock', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-clone',
				'name'  => __( 'Clone', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-closed-captioning',
				'name'  => __( 'Closed Captioning', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cloud',
				'name'  => __( 'Cloud', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cloud-download-alt',
				'name'  => __( 'Cloud Download Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cloud-upload-alt',
				'name'  => __( 'Cloud Upload Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cocktail',
				'name'  => __( 'Cocktail', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-code',
				'name'  => __( 'Code', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-code-branch',
				'name'  => __( 'Code Branch', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-coffee',
				'name'  => __( 'Coffee', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cog',
				'name'  => __( 'Cog', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cogs',
				'name'  => __( 'Cogs', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-coins',
				'name'  => __( 'Coins', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-columns',
				'name'  => __( 'Columns', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-comment',
				'name'  => __( 'Comment', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-comment-alt',
				'name'  => __( 'Comment Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-comment-dots',
				'name'  => __( 'Comment Dots', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-comment-slash',
				'name'  => __( 'Comment Slash', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-comments',
				'name'  => __( 'comments', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-compact-disc',
				'name'  => __( 'Compact Disc', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-compass',
				'name'  => __( 'Compass', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-compress',
				'name'  => __( 'Compress', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-compress-arrows-alt',
				'name'  => __( 'Compress Arrows Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-concierge-bell',
				'name'  => __( 'Concierge Bell', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cookie',
				'name'  => __( 'Cookie', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cookie-bite',
				'name'  => __( 'Cookie Bite', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-copy',
				'name'  => __( 'Copy', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-copyright',
				'name'  => __( 'Copyright', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-credit-card',
				'name'  => __( 'Credit Card', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-crop',
				'name'  => __( 'Crop', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-crosshairs',
				'name'  => __( 'Crosshairs', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-crown',
				'name'  => __( 'Crown', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cube',
				'name'  => __( 'Cube', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cubes',
				'name'  => __( 'Cubes', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-cut',
				'name'  => __( 'Cut', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-database',
				'name'  => __( 'Database', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-deaf',
				'name'  => __( 'Deaf', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-desktop',
				'name'  => __( 'Desktop', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-dice',
				'name'  => __( 'Dice', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-dice-d6',
				'name'  => __( 'Dice D6', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-directions',
				'name'  => __( 'Directions', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-dog',
				'name'  => __( 'Dog', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-dollar-sign',
				'name'  => __( 'Dollar Sign', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-dolly',
				'name'  => __( 'Dolly', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-donate',
				'name'  => __( 'Donate', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-download',
				'name'  => __( 'Download', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-drafting-compass',
				'name'  => __( 'Drafting Compass', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-drum',
				'name'  => __( 'Drum', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-drum-steelpan',
				'name'  => __( 'Drum Steelpan', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-dumbbell',
				'name'  => __( 'Dumbbell', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-dumpster',
				'name'  => __( 'Dumpster', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-edit',
				'name'  => __( 'Edit', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-egg',
				'name'  => __( 'Egg', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-eject',
				'name'  => __( 'Eject', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-ellipsis-v',
				'name'  => __( 'Ellipsis V', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-envelope',
				'name'  => __( 'Envelope', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-envelope-open',
				'name'  => __( 'Envelope Open', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-envelope-open-text',
				'name'  => __( 'Envelope Open Text', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-envelope-square',
				'name'  => __( 'Envelope Square', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-equals',
				'name'  => __( 'Equals', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-eraser',
				'name'  => __( 'Eraser', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-euro-sign',
				'name'  => __( 'Euro Sign', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-exclamation',
				'name'  => __( 'Exclamation', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-exchange-alt',
				'name'  => __( 'Exchange Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-exclamation-circle',
				'name'  => __( 'Exclamation Circle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-exclamation-triangle',
				'name'  => __( 'Exclamation Triangle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-expand',
				'name'  => __( 'Expand', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-expand-arrows-alt',
				'name'  => __( 'Expand Arrows Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-external-link-alt',
				'name'  => __( 'External Link Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-external-link-square-alt',
				'name'  => __( 'External Link Square Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-eye',
				'name'  => __( 'Eye', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-eye-dropper',
				'name'  => __( 'Eye Dropper', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-eye-slash',
				'name'  => __( 'Eye Slash', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fan',
				'name'  => __( 'Fan', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fast-backward',
				'name'  => __( 'Fast Backward', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fast-forward',
				'name'  => __( 'Fast Forward', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fax',
				'name'  => __( 'Fax', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-feather',
				'name'  => __( 'Feather', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-feather-alt',
				'name'  => __( 'Feather Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-female',
				'name'  => __( 'Female', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fighter-jet',
				'name'  => __( 'Fighter Jet', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file',
				'name'  => __( 'File', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-alt',
				'name'  => __( 'File Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-archive',
				'name'  => __( 'File Archive', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-audio',
				'name'  => __( 'File Audio', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-code',
				'name'  => __( 'File Code', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-contract',
				'name'  => __( 'File Contract', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-csv',
				'name'  => __( 'File CSV', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-download',
				'name'  => __( 'File Download', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-excel',
				'name'  => __( 'File Excel', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-export',
				'name'  => __( 'File Export', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-image',
				'name'  => __( 'File Image', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-import',
				'name'  => __( 'File Import', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-invoice',
				'name'  => __( 'File Invoice', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-invoice-dollar',
				'name'  => __( 'File Invoice Dollar', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-pdf',
				'name'  => __( 'File Pdf', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-powerpoint',
				'name'  => __( 'File Powerpoint', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-prescription',
				'name'  => __( 'File Prescription', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-signature',
				'name'  => __( 'File Signature', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-upload',
				'name'  => __( 'File Upload', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-video',
				'name'  => __( 'File Video', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-file-word',
				'name'  => __( 'File Word', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fill',
				'name'  => __( 'Fill', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fill-drip',
				'name'  => __( 'Fill Drip', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-film',
				'name'  => __( 'Film', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-filter',
				'name'  => __( 'Filter', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fingerprint',
				'name'  => __( 'Fingerprint', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fire',
				'name'  => __( 'Fire', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-fire-alt',
				'name'  => __( 'Fire Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-flag',
				'name'  => __( 'Flag', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-flag-usa',
				'name'  => __( 'Flag USA', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-flask',
				'name'  => __( 'Flask', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-folder',
				'name'  => __( 'Folder', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-folder-open',
				'name'  => __( 'Folder Open', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-font',
				'name'  => __( 'Font', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-football-ball',
				'name'  => __( 'Football Ball', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-forward',
				'name'  => __( 'Forward', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-futbol',
				'name'  => __( 'Futbol', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-gamepad',
				'name'  => __( 'Gamepad', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-gem',
				'name'  => __( 'Gem', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-genderless',
				'name'  => __( 'Genderless', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-ghost',
				'name'  => __( 'Ghost', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-gift',
				'name'  => __( 'Gift', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-gifts',
				'name'  => __( 'Gifts', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-glass-cheers',
				'name'  => __( 'Glass Cheers', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-glass-martini',
				'name'  => __( 'Glass Martini', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-glass-martini-alt',
				'name'  => __( 'Glass Martini Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-glasses',
				'name'  => __( 'Glasses', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-globe',
				'name'  => __( 'Globe', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-globe-africa',
				'name'  => __( 'Globe Africa', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-globe-americas',
				'name'  => __( 'Globe Americas', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-globe-asia',
				'name'  => __( 'Globe Asia', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-globe-europe',
				'name'  => __( 'Globe Europe', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-graduation-cap',
				'name'  => __( 'Graduation Cap', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-grin',
				'name'  => __( 'Grin', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-grin-alt',
				'name'  => __( 'Grin Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-grin-beam',
				'name'  => __( 'Grin Beam', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-grin-beam-sweat',
				'name'  => __( 'Grin Beam Sweat', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-grin-hearts',
				'name'  => __( 'Grin Hearts', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-grip-horizontal',
				'name'  => __( 'Grip Horizontal', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-guitar',
				'name'  => __( 'Guitar', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-h-square',
				'name'  => __( 'H-Square', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hamburger',
				'name'  => __( 'Hamburger', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-holding',
				'name'  => __( 'Hand Holding', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-holding-heart',
				'name'  => __( 'Hand Holding Heart', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-holding-usd',
				'name'  => __( 'Hand Holding USD', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-lizard',
				'name'  => __( 'Hand-Lizard', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-middle-finger',
				'name'  => __( 'Hand Middle Finger', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-paper',
				'name'  => __( 'Hand Paper', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-peace',
				'name'  => __( 'Hand Peace', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-point-down',
				'name'  => __( 'Hand Point Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-point-left',
				'name'  => __( 'Hand Point Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-point-right',
				'name'  => __( 'Hand Point Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-point-up',
				'name'  => __( 'Hand Point Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hand-pointer',
				'name'  => __( 'Hand Pointer', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hands',
				'name'  => __( 'Hands', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hands-helping',
				'name'  => __( 'Hands Helping', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-handshake',
				'name'  => __( 'Handshake', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hashtag',
				'name'  => __( 'Hashtag', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hat-cowboy',
				'name'  => __( 'Hat Cowboy', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hdd',
				'name'  => __( 'HDD', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-heading',
				'name'  => __( 'Heading', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-headphones',
				'name'  => __( 'Headphones', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-headphones-alt',
				'name'  => __( 'Headphones Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-headset',
				'name'  => __( 'Headset', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-heart',
				'name'  => __( 'Heart', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-heartbeat',
				'name'  => __( 'Heartbeat', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hiking',
				'name'  => __( 'Hiking', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-history',
				'name'  => __( 'History', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-home',
				'name'  => __( 'Home', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hospital',
				'name'  => __( 'Hospital', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hotel',
				'name'  => __( 'Hotel', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hourglass',
				'name'  => __( 'Hourglass', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hourglass-end',
				'name'  => __( 'Hourglass End', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hourglass-half',
				'name'  => __( 'Hourglass Half', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-hourglass-start',
				'name'  => __( 'Hourglass Start', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-ice-cream',
				'name'  => __( 'Ice Cream', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-icons',
				'name'  => __( 'Icons', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-id-badge',
				'name'  => __( 'Id Badge', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-id-card',
				'name'  => __( 'Id Card', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-id-card-alt',
				'name'  => __( 'Id Card Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-image',
				'name'  => __( 'Image', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-images',
				'name'  => __( 'Images', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-inbox',
				'name'  => __( 'Inbox', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-indent',
				'name'  => __( 'Indent', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-industry',
				'name'  => __( 'Industry', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-infinity',
				'name'  => __( 'Infinity', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-info',
				'name'  => __( 'Info', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-info-circle',
				'name'  => __( 'Info Circle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-italic',
				'name'  => __( 'Italic', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-key',
				'name'  => __( 'Key', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-keyboard',
				'name'  => __( 'Keyboard', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-landmark',
				'name'  => __( 'Landmark', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-language',
				'name'  => __( 'Language', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-laptop',
				'name'  => __( 'Laptop', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-laptop-code',
				'name'  => __( 'Laptop Code', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-layer-group',
				'name'  => __( 'Layer Group', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-leaf',
				'name'  => __( 'Leaf', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-level-down-alt',
				'name'  => __( 'Level Down Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-level-up-alt',
				'name'  => __( 'Level Up Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-life-ring',
				'name'  => __( 'Life Ring', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-lightbulb',
				'name'  => __( 'Lightbulb', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-link',
				'name'  => __( 'Link', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-list',
				'name'  => __( 'List', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-location-arrow',
				'name'  => __( 'Location Arrow', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-lock',
				'name'  => __( 'Lock', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-lock-open',
				'name'  => __( 'Lock Open', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-long-arrow-alt-down',
				'name'  => __( 'Long Arrow Alt Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-long-arrow-alt-left',
				'name'  => __( 'Long Arrow Alt Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-long-arrow-alt-right',
				'name'  => __( 'Long Arrow Alt Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-long-arrow-alt-up',
				'name'  => __( 'Long Arrow Alt Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-magic',
				'name'  => __( 'Magic', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-magnet',
				'name'  => __( 'Magnet', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-male',
				'name'  => __( 'Male', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-map',
				'name'  => __( 'Map', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-map-marked-alt',
				'name'  => __( 'Map Marked Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-map-marker-alt',
				'name'  => __( 'Map Marker Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-mars',
				'name'  => __( 'Mars', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-mars-double',
				'name'  => __( 'Mars Double', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-mars-stroke',
				'name'  => __( 'Mars Stroke', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-medal',
				'name'  => __( 'Medal', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-medkit',
				'name'  => __( 'Medkit', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-mercury',
				'name'  => __( 'Mercury', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-microchip',
				'name'  => __( 'Microchip', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-microphone',
				'name'  => __( 'Microphone', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-microphone-alt',
				'name'  => __( 'Microphone Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-microphone-alt-slash',
				'name'  => __( 'Microphone Alt Slash', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-microphone-slash',
				'name'  => __( 'Microphone Slash', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-microscope',
				'name'  => __( 'Microscope', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-mobile-alt',
				'name'  => __( 'Mobile Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-money-bill',
				'name'  => __( 'Money Bill', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-money-check-alt',
				'name'  => __( 'Money Check Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-motorcycle',
				'name'  => __( 'Motorcycle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-mountain',
				'name'  => __( 'Mountain', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-mug-hot',
				'name'  => __( 'Mug Hot', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-music',
				'name'  => __( 'Music', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-network-wired',
				'name'  => __( 'Network Wired', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-notes-medical',
				'name'  => __( 'Notes Medical', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-om',
				'name'  => __( 'Om', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-outdent',
				'name'  => __( 'Outdent', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-paint-brush',
				'name'  => __( 'Paint Brush', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-palette',
				'name'  => __( 'Palette', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-paper-plane',
				'name'  => __( 'Paper Plane', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-paperclip',
				'name'  => __( 'Paperclip', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-paragraph',
				'name'  => __( 'Paragraph', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-passport',
				'name'  => __( 'Passport', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-paste',
				'name'  => __( 'Paste', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-pause',
				'name'  => __( 'Pause', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-paw',
				'name'  => __( 'Paw', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-pen-nib',
				'name'  => __( 'Pen Nib', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-pen-square',
				'name'  => __( 'Pen Square', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-pencil-ruler',
				'name'  => __( 'Pencil Ruler', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-phone-alt',
				'name'  => __( 'Phone Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-phone-slash',
				'name'  => __( 'Phone Slash', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-phone-square-alt',
				'name'  => __( 'Phone Square Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-phone-volume',
				'name'  => __( 'Phone Volume', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-piggy-bank',
				'name'  => __( 'Piggy Bank', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-pizza-slice',
				'name'  => __( 'Pizza Slice', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-plane-departure',
				'name'  => __( 'Plane Departure', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-play',
				'name'  => __( 'Play', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-play-circle',
				'name'  => __( 'Play Circle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-plug',
				'name'  => __( 'Plug', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-plus-circle',
				'name'  => __( 'Plus Circle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-plus-square',
				'name'  => __( 'Plus Square', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-podcast',
				'name'  => __( 'Podcast', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-poll',
				'name'  => __( 'Poll', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-poll-h',
				'name'  => __( 'Poll-H', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-poo',
				'name'  => __( 'Poo', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-portrait',
				'name'  => __( 'Portrait', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-pound-sign',
				'name'  => __( 'Pound Sign', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-power-off',
				'name'  => __( 'Power Off', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-print',
				'name'  => __( 'Print', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-project-diagram',
				'name'  => __( 'Project Diagram', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-qrcode',
				'name'  => __( 'Qrcode', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-question-circle',
				'name'  => __( 'Question Circle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-quote-left',
				'name'  => __( 'Quote Left', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-quote-right',
				'name'  => __( 'Quote Right', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-radiation',
				'name'  => __( 'Radiation', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-radiation-alt',
				'name'  => __( 'Radiation Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-random',
				'name'  => __( 'Random', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-receipt',
				'name'  => __( 'Receipt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-redo',
				'name'  => __( 'Redo', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-redo-alt',
				'name'  => __( 'Redo Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-registered',
				'name'  => __( 'Registered', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-reply',
				'name'  => __( 'Reply', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-reply-all',
				'name'  => __( 'Reply All', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-retweet',
				'name'  => __( 'Retweet', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-rocket',
				'name'  => __( 'Rocket', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-route',
				'name'  => __( 'Route', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-rss',
				'name'  => __( 'RSS', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-ruble-sign',
				'name'  => __( 'Ruble Sign', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-running',
				'name'  => __( 'Running', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-rupee-sign',
				'name'  => __( 'Rupee Sign', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-satellite',
				'name'  => __( 'Satellite', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-save',
				'name'  => __( 'Save', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sd-card',
				'name'  => __( 'SD Card', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-search',
				'name'  => __( 'Search', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-search-location',
				'name'  => __( 'Search Location', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-server',
				'name'  => __( 'Server', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-share',
				'name'  => __( 'Share', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-share-alt',
				'name'  => __( 'Share Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-share-alt-square',
				'name'  => __( 'Share Alt Square', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-share-square',
				'name'  => __( 'Share Square', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-shield-alt',
				'name'  => __( 'Shield Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-shipping-fast',
				'name'  => __( 'Shipping Fast', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-shopping-bag',
				'name'  => __( 'Shopping Bag', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-shopping-basket',
				'name'  => __( 'Shopping Basket', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-shopping-cart',
				'name'  => __( 'Shopping Cart', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sign-in-alt',
				'name'  => __( 'Sign In Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sign-language',
				'name'  => __( 'Sign Language', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sign-out-alt',
				'name'  => __( 'Sign Out Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-signal',
				'name'  => __( 'Signal', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sitemap',
				'name'  => __( 'Sitemap', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-skating',
				'name'  => __( 'Skating', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-skiing',
				'name'  => __( 'Skiing', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-skiing-nordic',
				'name'  => __( 'Skiing Nordic', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sliders-h',
				'name'  => __( 'Sliders-H', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-smile',
				'name'  => __( 'Smile', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-smoking-ban',
				'name'  => __( 'Smoking Ban', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-snowboarding',
				'name'  => __( 'Snowboarding', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-snowflake',
				'name'  => __( 'Snowflake', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-snowman',
				'name'  => __( 'Snowman', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-socks',
				'name'  => __( 'Socks', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sort',
				'name'  => __( 'Sort', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sort-alpha-down',
				'name'  => __( 'Sort Alpha Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sort-alpha-down-alt',
				'name'  => __( 'Sort Alpha Down Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sort-alpha-up',
				'name'  => __( 'Sort Alpha Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sort-alpha-up-alt',
				'name'  => __( 'Sort Alpha Up Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-spell-check',
				'name'  => __( 'Spell Check', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-spider',
				'name'  => __( 'Spider', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-spinner',
				'name'  => __( 'Spinner', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-star',
				'name'  => __( 'Star', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-star-half',
				'name'  => __( 'Star Half', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-star-half-alt',
				'name'  => __( 'Star Half Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-stethoscope',
				'name'  => __( 'Stethoscope', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sticky-note',
				'name'  => __( 'Sticky Note', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-store',
				'name'  => __( 'Store', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-store-alt',
				'name'  => __( 'Store Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-street-view',
				'name'  => __( 'Street View', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-subway',
				'name'  => __( 'Subway', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-suitcase',
				'name'  => __( 'Suitcase', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-suitcase-rolling',
				'name'  => __( 'Suitcase Rolling', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sync',
				'name'  => __( 'Sync', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-sync-alt',
				'name'  => __( 'Sync Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-table',
				'name'  => __( 'Table', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-tag',
				'name'  => __( 'Tag', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-tags',
				'name'  => __( 'Tags', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-tasks',
				'name'  => __( 'Tasks', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-taxi',
				'name'  => __( 'Taxi', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-th',
				'name'  => __( 'Th', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-th-large',
				'name'  => __( 'Th Large', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-th-list',
				'name'  => __( 'Th List', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-thumbs-down',
				'name'  => __( 'Thumbs Down', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-thumbs-up',
				'name'  => __( 'Thumbs Up', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-thumbtack',
				'name'  => __( 'Thumbtack', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-ticket-alt',
				'name'  => __( 'Ticket Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-tint',
				'name'  => __( 'Tint', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-tools',
				'name'  => __( 'Tools', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-traffic-light',
				'name'  => __( 'Traffic Light', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-tooth',
				'name'  => __( 'Tooth', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-train',
				'name'  => __( 'Train', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-tram',
				'name'  => __( 'Tram', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-train',
				'name'  => __( 'Train', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-transgender',
				'name'  => __( 'Transgender', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-transgender-alt',
				'name'  => __( 'Transgender Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-trash',
				'name'  => __( 'Trash', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-trash-alt',
				'name'  => __( 'Trash Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-trophy',
				'name'  => __( 'Trophy', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-truck',
				'name'  => __( 'Truck', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-tshirt',
				'name'  => __( 'Tshirt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-umbrella',
				'name'  => __( 'Umbrella', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-universal-access',
				'name'  => __( 'Universal Access', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-university',
				'name'  => __( 'University', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-unlink',
				'name'  => __( 'Unlink', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-unlock',
				'name'  => __( 'Unlock', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-unlock-alt',
				'name'  => __( 'Unlock Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-upload',
				'name'  => __( 'Upload', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-user',
				'name'  => __( 'User', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-user-circle',
				'name'  => __( 'User Circle', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-user-graduate',
				'name'  => __( 'User Graduate', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-user-lock',
				'name'  => __( 'User Lock', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-user-md',
				'name'  => __( 'User Md', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-user-tie',
				'name'  => __( 'User Tie', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-users',
				'name'  => __( 'Users', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-utensils',
				'name'  => __( 'Utensils', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-vector-square',
				'name'  => __( 'Vector Square', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-venus',
				'name'  => __( 'Venus', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-venus-double',
				'name'  => __( 'Venus Double', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-venus-mars',
				'name'  => __( 'Venus Mars', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-video',
				'name'  => __( 'Video', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-voicemail',
				'name'  => __( 'Voicemail', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-walking',
				'name'  => __( 'Walking', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-wallet',
				'name'  => __( 'Wallet', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-wheelchair',
				'name'  => __( 'Wheelchair', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-wifi',
				'name'  => __( 'Wifi', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-wine-glass',
				'name'  => __( 'Wine Glass', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-wine-glass-alt',
				'name'  => __( 'Wine Glass Alt', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-wrench',
				'name'  => __( 'Wrench', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-yen-sign',
				'name'  => __( 'Yen Sign', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-yin-yang',
				'name'  => __( 'Yin Yang', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-window-restore',
				'name'  => __( 'Window Restore', 'binary-extra' ),
			),
			array(
				'group' => 'solid',
				'id'    => 'fa-school',
				'name'  => __( 'School', 'binary-extra' ),
			),
		);

		/**
		 * Filter FontAwesome items
		 *
		 */
		$items = apply_filters( 'oe_icon_picker_fas_items', $items );

		return $items;
	}
}
