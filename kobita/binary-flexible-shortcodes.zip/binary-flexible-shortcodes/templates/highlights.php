<form id="bps_shortcode_highlights">
	<table class="form-table">
		<tbody>
			<tr>
		 		<th><h3><?php _e('Options','binary-flexible-shortcodes'); ?></h3></th><td>&nbsp;</td>
			</tr>
		<tr>
				<th><?php _e('Background Color','binary-flexible-shortcodes'); ?>:</th>
				<td><input id="bps_highlight_color" type="text" name="color" value="#ffffff"/></td>
		</tr>
		<tr>
				<th><input type="submit" class="button-primary" value="<?php _e('Insert Highlight','binary-flexible-shortcodes'); ?>"></th> 
				<td>&nbsp;</td>
		</tr>
	
	</tbody>
	</table>
</form>

<script type="text/javascript">
	/* <![CDATA[ */
  (function($) {
    	$('#bps_shortcode_highlights').submit(function(e) {
    			e.preventDefault();
    			bps_shortcode_modal_obj.dialog('close');
    			var color = $(this).find('input[name="color"]').val();
    			var content = '[bps_highlight color="'+color+'"][/bps_highlight]';
    			bps_shortcode.setContent(content);
			});
			
			if($('#bps_highlight_color').length && jQuery.isFunction(jQuery.fn.wpColorPicker)){
    		$('#bps_highlight_color').wpColorPicker(); 		
    	}
			
	})(jQuery);
	/* ]]> */
</script>