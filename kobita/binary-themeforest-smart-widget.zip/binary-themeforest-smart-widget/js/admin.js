(function($) {
    $(document).ready(function() {

        $('body').on('click', '.binary-themeforest-smart-widget-type', function(){
            var type = $(this).val();
            var wrap = $(this).closest('.widget-content');
            var user = wrap.find('.binary-themeforest-smart-widget-user');
            var cat = wrap.find('.binary-themeforest-smart-widget-cat');
            var order = wrap.find('.binary-themeforest-smart-widget-order');
            if(type == 'popular'){
                user.fadeOut(300);
                cat.fadeOut(300);
                order.fadeOut(300);
            } else if (type == 'latest'){
                user.fadeOut(300);
                cat.fadeIn(300);
                order.fadeOut(300);
            } else {
                //user
                user.fadeIn(300);
                cat.fadeIn(300);
                order.fadeIn(300);
            }
        });

    });

})(jQuery);