<?php
/**
 * MC FORM Category
 *
 * Class for handling the Category page under mcForm
 *
 * @author BinaryPoets <hello@binarypoets.net>
 * @package mcForm - Premium Form System
 * @subpackage Admin\FormCategory
 * @codeCoverageIgnore
 */
class MC_FORM_Form_Category extends MC_FORM_Admin_Base {
	public $table_view;
	public $page_action;

	public function __construct() {
		$this->capability = 'manage_feedback';
		$this->action_nonce = 'mc_form_form_category_nonce';

		parent::__construct();

		$this->icon = 'folder-open';

		$this->post_result[4] = array(
			'type' => 'okay',
			'msg' => __( 'Successfully created the category.', 'mc_form' ),
		);
		$this->post_result[5] = array(
			'type' => 'okay',
			'msg' => __( 'Successfully updated the category.', 'mc_form' ),
		);
		$this->post_result[6] = array(
			'type' => 'update',
			'msg' => __( 'Successfully deleted the category.', 'mc_form' ),
		);
		$this->post_result[7] = array(
			'type' => 'update',
			'msg' => __( 'Successfully deleted selected categories.', 'mc_form' ),
		);

		add_filter( 'set-screen-option', array( $this, 'table_set_option' ), 10, 3 );
	}

	/*==========================================================================
	 * SYSTEM METHODS
	 *========================================================================*/
	public function admin_menu() {
		$this->pagehook = add_submenu_page( 'mc_form_dashboard', __( 'Form Categories', 'mc_form' ), __( 'Form Category', 'mc_form' ), $this->capability, 'mc_form_form_category', array( $this, 'index' ) );
		parent::admin_menu();
	}

	public function index() {
		global $mc_form_info;
		$this->index_head( __( 'mcForm <span class="mc-icomoon-arrow-right2"></span> Form Category <a href="admin.php?page=mc_form_form_category&paction=new_cat" class="add-new-h2">Add New</a>', 'mc_form' ), false );
		switch( $this->page_action ) {
			case 'new_cat' :
				$this->category_form();
				break;
			case 'edit_cat' :
				$this->category_form( $_GET['cat_id'] );
				break;
			default :
				$this->show_table();
		}
		$this->index_foot();
	}

	public function save_post( $check_referer = true ) {
		parent::save_post();
		$action = $this->post['db_action'];
		if ( $action == 'insert' ) {
			MC_FORM_Form_Elements_Static::create_category( $this->post['form_cat']['name'], $this->post['form_cat']['description'] );
			wp_redirect( add_query_arg( array( 'post_result' => 4 ), $_POST['_wp_http_referer'] ) );
		} else {
			MC_FORM_Form_Elements_Static::update_category( $this->post['form_cat']['id'], $this->post['form_cat']['name'], $this->post['form_cat']['description'] );
			wp_redirect( add_query_arg( array( 'post_result' => 5 ), admin_url( 'admin.php?page=mc_form_form_category' ) ) );
		}
		die();
	}

	public function on_load_page() {
		$this->table_view = new MC_FORM_Category_Table();
		// form_category_per_page
		$option = 'per_page';
		$args = array(
			'label' => __( 'Categories Per Page', 'mc_form' ),
			'default' => 20,
			'option' => 'form_category_per_page',
		);
		add_screen_option( $option, $args );

		$this->page_action = isset( $_GET['paction'] ) ? $_GET['paction'] : 'table_view';
		$action = $this->table_view->current_action();

		if ( $action == 'delete' ) {
			if ( isset( $_GET['cat_id'] ) ) {
				if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'mc_form_category_delete_' . $_GET['cat_id'] ) ) {
					wp_die( __( 'Cheatin&#8217; uh?' ) );
				}
				MC_FORM_Form_Elements_Static::delete_categories( $_GET['cat_id'] );
				wp_redirect( add_query_arg( array( 'post_result' => 6 ), admin_url( 'admin.php?page=mc_form_form_category' ) ) );
			} else {
				if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'bulk-mc_form_category_items' ) ) {
					wp_die( __( 'Cheatin&#8217; uh?' ) );
				}

				MC_FORM_Form_Elements_Static::delete_categories( $_GET['cat_ids'] );
				wp_redirect( add_query_arg( array( 'post_result' => 7 ), admin_url( 'admin.php?page=mc_form_form_category' ) ) );
			}

			die();
		}

		get_current_screen()->add_help_tab( array(
			'id'  => 'overview',
			'title'  => __( 'Overview', 'mc_form' ),
			'content' =>
			'<p>' . __( 'This screen displays all your form categories. You can customize the display of this screen to suit your workflow.', 'mc_form' ) . '</p>' .
			'<p>' . __( 'By default, this screen will show all the categories. You can also create a new category by clicking on the <strong>Add New</strong> Button. Please check the Screen Content for more information.', 'mc_form' ) . '</p>'
		) );
		get_current_screen()->add_help_tab( array(
			'id'  => 'screen-content',
			'title'  => __( 'Screen Content', 'mc_form' ),
			'content' =>
			'<p>' . __( 'You can customize the display of this screen&#8217;s contents in a number of ways:' ) . '</p>' .
			'<ul>' .
			'<li>' . __( 'You can sort categories based on name.', 'mc_form' ) . '</li>' .
			'<li>' . __( 'You can hide/display columns based on your needs and decide how many categories to list per screen using the Screen Options tab.', 'mc_form' ) . '</li>' .
			'<li>' . __( 'You can search a particular category by using the Search Form. You can type in just the name.', 'mc_form' ) . '</li>' .
			'</ul>'
		) );
		get_current_screen()->add_help_tab( array(
			'id'  => 'new-category-form',
			'title'  => __( 'Add New Category', 'mc_form' ),
			'content' =>
			'<p>' . __( 'Click on the <strong>Add New</strong> button to get started.' ) . '</p>' .
			'<ul>' .
			'<li>' . __( '<strong>Category Name</strong>: A short name of the category. This will be shown on admin lists and user portals.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Category Description</strong>: A description of the category. HTML allowed.', 'mc_form' ) . '</li>' .
			'</ul>' .
			'<p>' . __( 'Once done, click on the <strong>Create Category</strong> button and it will be added to the list.', 'mc_form' )
		) );
		get_current_screen()->add_help_tab( array(
			'id'  => 'action-links',
			'title'  => __( 'Available Actions', 'mc_form' ),
			'content' =>
			'<p>' . __( 'Hovering over a row in the posts list will display action links that allow you to manage your submissions. You can perform the following actions:', 'mc_form' ) . '</p>' .
			'<ul>' .
			'<li>' . __( '<strong>View Forms</strong> will take you to the all forms page, filtered by this category only.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>View Submissions</strong> will take you to the all submissions page, filtered by this category only.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Edit</strong> lets you recustomize the category.', 'mc_form' ) . '</li>' .
			'<li>' . __( '<strong>Delete</strong> removes your category this list as well as from the database. Any form associated with it will be unassigned. You can not restore it back, so make sure you want to delete it before you do.', 'mc_form' ) . '</li>' .
			'</ul>'
		) );
		get_current_screen()->add_help_tab( array(
			'id'  => 'bulk-actions',
			'title'  => __( 'Bulk Actions', 'mc_form' ),
			'content' =>
			'<p>' . __( 'There are a number of bulk actions available. Here are the details.', 'mc_form' ) . '</p>' .
			'<ul>' .
			'<li>' . __( '<strong>Delete</strong>. This will permanently delete the ticked categories from the database. Any form associated with these will be unassigned.', 'mc_form' ) . '</li>' .
			'</ul>'
		) );

		get_current_screen()->set_help_sidebar(
			'<p><strong>' . __( 'For more information:' ) . '</strong></p>' .
			'<p>' . sprintf( __( '<a href="%s" target="_blank">Documentation</a>', 'mc_form' ), MC_FORM_Loader::$documentation ) . '</p>' .
			'<p>' . sprintf( __( '<a href="%s" target="_blank">Support Forums</a>', 'mc_form' ), MC_FORM_Loader::$support_forum ) . '</p>'
		);

		parent::on_load_page();
	}

	protected function show_table() {
		$this->table_view->prepare_items();
		?>
<div class="mc_uif_iconbox mc_uif_shadow glowy">
	<div class="mc_uif_box cyan">
		<h3><span class="mc-icomoon-pencil"></span><?php _e( 'Modify and/or View Form Categories', 'mc_form' ); ?></h3>
	</div>
	<div class="mc_uif_iconbox_inner">
		<form action="" method="get">
			<?php foreach ( $_GET as $k => $v ) : ?>
				<?php if ( $k == 'order' || $k == 'orderby' || $k == 'page' ) : ?>
					<input type="hidden" name="<?php echo $k; ?>" value="<?php echo $v; ?>" />
				<?php endif; ?>
			<?php endforeach; ?>
			<?php $this->table_view->search_box( __( 'Search Categories', 'mc_form' ), 'search_id' ); ?>
			<?php $this->table_view->display(); ?>
		</form>
	</div>
</div>
		<?php
	}

	protected function category_form( $id = '' ) {
		$buttons = array(
			array( __( 'Create Category', 'mc_form' ), '', 'medium', 'primary', 'normal', array(), 'submit' ),
			array( __( 'Reset', 'mc_form' ), '', 'medium', 'secondary', 'normal', array(), 'reset' ),
			array( __( 'View All', 'mc_form' ), '', 'medium', 'secondary', 'normal', array(), 'anchor', array(), array(), admin_url( 'admin.php?page=mc_form_form_category' ) ),
		);
		if ( $id == '' ) {
			$category = new stdClass();
			$category->name = '';
			$category->description = '';
			$category->id = '';
		} else {
			$category = MC_FORM_Form_Elements_Static::get_category( $id );
			if ( $category == null ) {
				$this->ui->msg_error( __( 'Invalid Category ID', 'mc_form' ) );
				$this->ui->button( __( 'View All', 'mc_form' ), '', 'medium', 'primary', 'normal', array(), 'anchor', true, array(), array(), admin_url( 'admin.php?page=mc_form_form_category' ) );
				return;
			}
			$buttons[0][0] = __( 'Update Category', 'mc_form' );
		}
		?>
<div class="mc_uif_iconbox mc_uif_shadow glowy">
	<div class="mc_uif_box cyan">
		<h3>
			<span class="mc-icomoon-tag2"></span>
			<?php if ( $category->id == '' ) : ?>
			<?php _e( 'Create a new Category', 'mc_form' ); ?>
			<?php else : ?>
			<?php _e( 'Update Category', 'mc_form' ); ?>
			<?php endif; ?>
		</h3>
	</div>
	<div class="mc_uif_iconbox_inner">
		<form method="post" action="admin-post.php" id="<?php echo $this->pagehook; ?>_form_primary">
			<input type="hidden" name="action" value="<?php echo $this->admin_post_action; ?>" />
			<?php wp_nonce_field( $this->action_nonce, $this->action_nonce ); ?>
			<input type="hidden" name="db_action" value="<?php echo ( $category->id == '' ? 'insert' : 'update' ); ?>" />
			<input type="hidden" name="form_cat[id]" value="<?php echo $category->id; ?>" />
			<table class="form-table">
				<tbody>
					<tr>
						<th><?php $this->ui->generate_label( 'form_cat[name]', __( 'Category Name', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->text( 'form_cat[name]', $category->name, __( 'Shortname of the category', 'mc_form' ) ); ?>
						</td>
					</tr>
					<tr>
						<th><?php $this->ui->generate_label( 'form_cat[description]', __( 'Category Description', 'mc_form' ) ); ?></th>
						<td>
							<?php $this->ui->textarea( 'form_cat[description]', $category->description, '' ); ?>
						</td>
					</tr>
				</tbody>
			</table>
			<div class="clear"></div>
			<?php $this->ui->buttons( $buttons ); ?>
		</form>
	</div>
</div>
		<?php
	}

	public function table_set_option( $status, $option, $value ) {
		return $value;
	}
}
